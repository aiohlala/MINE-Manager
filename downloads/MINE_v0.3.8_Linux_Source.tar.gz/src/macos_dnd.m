#import <Cocoa/Cocoa.h>
#import <CoreGraphics/CoreGraphics.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

@interface MineDragSource : NSObject <NSDraggingSource>
@property (nonatomic, assign) BOOL allowMove;
@end

static MineDragSource *g_active_drag_source = nil;
static int g_drag_ended = 0;
static int g_drag_dropped = 0;
static int g_drag_was_move = 0;

static NSString *const kMineCutPasteboardType = @"com.aiohlala.mine.clipboard-cut";
static NSString *const kMineLegacyFilenamesType = @"NSFilenamesPboardType";

@implementation MineDragSource

- (NSDragOperation)draggingSession:(NSDraggingSession *)session
    sourceOperationMaskForDraggingContext:(NSDraggingContext)context {
    (void)session;
    if (context == NSDraggingContextOutsideApplication) {
        if (self.allowMove) {
            return NSDragOperationMove | NSDragOperationCopy;
        }
        return NSDragOperationCopy;
    }
    return NSDragOperationCopy | NSDragOperationMove | NSDragOperationGeneric;
}

- (BOOL)ignoreModifierKeysForDraggingSession:(NSDraggingSession *)session {
    (void)session;
    return self.allowMove ? NO : YES;
}

- (void)draggingSession:(NSDraggingSession *)session
           endedAtPoint:(NSPoint)screenPoint
              operation:(NSDragOperation)operation {
    (void)session;
    (void)screenPoint;
    g_drag_ended = 1;
    g_drag_dropped = (operation != NSDragOperationNone) ? 1 : 0;
    g_drag_was_move = (operation == NSDragOperationMove) ? 1 : 0;
    g_active_drag_source = nil;
}

@end

static NSWindow *mine_find_main_window(void) {
    NSWindow *win = [NSApp keyWindow];
    if (win != nil && [win contentView] != nil) {
        return win;
    }
    win = [NSApp mainWindow];
    if (win != nil && [win contentView] != nil) {
        return win;
    }
    for (NSWindow *w in [NSApp windows]) {
        if ([w isVisible] && [w contentView] != nil) {
            return w;
        }
    }
    return nil;
}

int mine_macos_is_left_mouse_down(void) {
    return (([NSEvent pressedMouseButtons] & (NSUInteger)1) != 0) ? 1 : 0;
}

int mine_macos_is_cursor_over_other_window(void) {
    @autoreleasepool {
        NSWindow *win = mine_find_main_window();
        if (win == nil) {
            return 0;
        }
        NSPoint pt = [NSEvent mouseLocation];
        if (!NSPointInRect(pt, [win frame])) {
            return 1;
        }
        NSInteger topWin = [NSWindow windowNumberAtPoint:pt belowWindowWithWindowNumber:0];
        if (topWin != 0 && topWin != [win windowNumber]) {
            return 1;
        }
        return 0;
    }
}

int mine_macos_cursor_pos_in_window(float *out_x, float *out_y) {
    @autoreleasepool {
        NSWindow *win = mine_find_main_window();
        if (win == nil || [win contentView] == nil) {
            return 0;
        }
        NSView *view = [win contentView];
        NSPoint screenPt = [NSEvent mouseLocation];
        NSPoint winPt = [win convertRectFromScreen:NSMakeRect(screenPt.x, screenPt.y, 0.0, 0.0)].origin;
        NSPoint viewPt = [view convertPoint:winPt fromView:nil];
        NSRect bounds = [view bounds];
        float x = (float)viewPt.x;
        float y = [view isFlipped] ? (float)viewPt.y : (float)(bounds.size.height - viewPt.y);
        if (x < 0.0f || y < 0.0f || x > (float)bounds.size.width || y > (float)bounds.size.height) {
            return 0;
        }
        if (out_x != NULL) {
            *out_x = x;
        }
        if (out_y != NULL) {
            *out_y = y;
        }
        return 1;
    }
}

int mine_macos_begin_file_drag(const char *const *paths_utf8, int count, int allow_move) {
    if (paths_utf8 == NULL || count <= 0) {
        return 0;
    }

    @autoreleasepool {
        @try {
            NSWindow *win = mine_find_main_window();
            if (win == nil) {
                return 0;
            }
            NSView *view = [win contentView];
            if (view == nil) {
                return 0;
            }

            NSPoint screenPt = [NSEvent mouseLocation];
            NSRect screenRect = NSMakeRect(screenPt.x, screenPt.y, 0.0, 0.0);
            NSPoint winPt = [win convertRectFromScreen:screenRect].origin;
            NSPoint viewPt = [view convertPoint:winPt fromView:nil];

            NSMutableArray<NSDraggingItem *> *items = [NSMutableArray arrayWithCapacity:(NSUInteger)count];
            NSImage *cachedIcon = nil;
            const CGFloat sz = 48.0;

            for (int i = 0; i < count; i++) {
                if (paths_utf8[i] == NULL) {
                    continue;
                }
                NSString *pathStr = [NSString stringWithUTF8String:paths_utf8[i]];
                if (pathStr == nil || [pathStr length] == 0) {
                    continue;
                }
                NSURL *url = [NSURL fileURLWithPath:pathStr];
                if (url == nil) {
                    continue;
                }

                NSDraggingItem *item = [[NSDraggingItem alloc] initWithPasteboardWriter:url];
                if (item == nil) {
                    continue;
                }

                CGFloat off = (CGFloat)(i < 5 ? i : 4) * 5.0;
                NSRect frame = NSMakeRect(viewPt.x - sz * 0.5 + off, viewPt.y - sz * 0.5 - off, sz, sz);

                if (i < 8 || cachedIcon == nil) {
                    NSImage *icon = [[NSWorkspace sharedWorkspace] iconForFile:pathStr];
                    if (icon != nil) {
                        NSImage *copyIcon = [icon copy];
                        [copyIcon setSize:NSMakeSize(sz, sz)];
                        cachedIcon = copyIcon;
                    }
                }
                if (cachedIcon != nil) {
                    [item setDraggingFrame:frame contents:cachedIcon];
                } else {
                    [item setDraggingFrame:frame contents:nil];
                }
                [items addObject:item];
            }

            if ([items count] == 0) {
                return 0;
            }

            NSEvent *dragEvent = [NSApp currentEvent];
            if (dragEvent == nil ||
                (dragEvent.type != NSEventTypeLeftMouseDown && dragEvent.type != NSEventTypeLeftMouseDragged) ||
                dragEvent.windowNumber != [win windowNumber]) {
                dragEvent = [NSEvent mouseEventWithType:NSEventTypeLeftMouseDragged
                                               location:winPt
                                          modifierFlags:[NSEvent modifierFlags]
                                              timestamp:[[NSProcessInfo processInfo] systemUptime]
                                           windowNumber:[win windowNumber]
                                                context:nil
                                            eventNumber:0
                                             clickCount:1
                                               pressure:1.0f];
            }
            if (dragEvent == nil) {
                return 0;
            }

            g_drag_ended = 0;
            g_drag_dropped = 0;
            g_drag_was_move = 0;
            MineDragSource *src = [MineDragSource new];
            src.allowMove = (allow_move != 0);
            g_active_drag_source = src;

            NSDraggingSession *session = [view beginDraggingSessionWithItems:items
                                                                       event:dragEvent
                                                                      source:g_active_drag_source];
            if (session == nil) {
                g_active_drag_source = nil;
                return 0;
            }
            session.animatesToStartingPositionsOnCancelOrFail = YES;
            session.draggingFormation = NSDraggingFormationPile;
            return 1;
        } @catch (NSException *ex) {
            (void)ex;
            g_active_drag_source = nil;
            return 0;
        }
    }
}

int mine_macos_is_drag_session_running(void) {
    return g_active_drag_source != nil ? 1 : 0;
}

int mine_macos_poll_drag_ended(int *out_dropped, int *out_was_move) {
    if (g_drag_ended) {
        if (out_dropped != NULL) {
            *out_dropped = g_drag_dropped;
        }
        if (out_was_move != NULL) {
            *out_was_move = g_drag_was_move;
        }
        g_drag_ended = 0;
        return 1;
    }
    return 0;
}

// ---- Native macOS NSPasteboard File Clipboard ----

static int mine_write_files_to_pb(NSPasteboard *pb, const char *const *paths_utf8, int count, int is_cut) {
    if (pb == nil || paths_utf8 == NULL || count <= 0) {
        return 0;
    }

    @autoreleasepool {
        NSMutableArray<NSPasteboardItem *> *pbItems = [NSMutableArray arrayWithCapacity:(NSUInteger)count];
        NSMutableArray<NSString *> *pathList = [NSMutableArray arrayWithCapacity:(NSUInteger)count];

        for (int i = 0; i < count; i++) {
            if (paths_utf8[i] == NULL) {
                continue;
            }
            NSString *pathStr = [NSString stringWithUTF8String:paths_utf8[i]];
            if (pathStr == nil || [pathStr length] == 0) {
                continue;
            }
            NSURL *url = [NSURL fileURLWithPath:pathStr];
            if (url == nil) {
                continue;
            }
            NSString *absUrl = [url absoluteString];
            if (absUrl == nil) {
                continue;
            }

            NSPasteboardItem *item = [[NSPasteboardItem alloc] init];
            [item setString:absUrl forType:NSPasteboardTypeFileURL];
            NSString *fname = [pathStr lastPathComponent];
            if (fname != nil && [fname length] > 0) {
                [item setString:fname forType:NSPasteboardTypeString];
            }
            if (is_cut != 0 && [pbItems count] == 0) {
                [item setString:@"1" forType:kMineCutPasteboardType];
            }
            [pbItems addObject:item];
            [pathList addObject:pathStr];
        }

        if ([pbItems count] == 0) {
            return 0;
        }

        [pb clearContents];
        BOOL ok = [pb writeObjects:pbItems];
        [pb addTypes:@[kMineLegacyFilenamesType] owner:nil];
        [pb setPropertyList:pathList forType:kMineLegacyFilenamesType];
        return ok ? 1 : 0;
    }
}

static int mine_has_files_in_pb(NSPasteboard *pb) {
    if (pb == nil) {
        return 0;
    }
    @autoreleasepool {
        NSDictionary *opts = @{NSPasteboardURLReadingFileURLsOnlyKey : @YES};
        if ([pb canReadObjectForClasses:@[[NSURL class]] options:opts]) {
            return 1;
        }
        id plist = [pb propertyListForType:kMineLegacyFilenamesType];
        if ([plist isKindOfClass:[NSArray class]] && [(NSArray *)plist count] > 0) {
            return 1;
        }
        return 0;
    }
}

static int mine_read_files_from_pb(NSPasteboard *pb, uint8_t **out_buf, int *out_len, int *out_is_cut) {
    if (out_buf) *out_buf = NULL;
    if (out_len) *out_len = 0;
    if (out_is_cut) *out_is_cut = 0;
    if (pb == nil || out_buf == NULL || out_len == NULL) {
        return 0;
    }

    @autoreleasepool {
        NSMutableArray<NSString *> *resolvedPaths = [NSMutableArray array];
        NSDictionary *opts = @{NSPasteboardURLReadingFileURLsOnlyKey : @YES};
        NSArray *urls = [pb readObjectsForClasses:@[[NSURL class]] options:opts];
        if (urls != nil) {
            for (id obj in urls) {
                if ([obj isKindOfClass:[NSURL class]]) {
                    NSString *p = [(NSURL *)obj path];
                    if (p != nil && [p length] > 0) {
                        [resolvedPaths addObject:p];
                    }
                }
            }
        }
        if ([resolvedPaths count] == 0) {
            id plist = [pb propertyListForType:kMineLegacyFilenamesType];
            if ([plist isKindOfClass:[NSArray class]]) {
                for (id entry in (NSArray *)plist) {
                    if ([entry isKindOfClass:[NSString class]] && [(NSString *)entry length] > 0) {
                        [resolvedPaths addObject:(NSString *)entry];
                    }
                }
            }
        }
        if ([resolvedPaths count] == 0) {
            return 0;
        }

        NSMutableData *data = [NSMutableData data];
        const uint8_t nul = 0;
        for (NSString *p in resolvedPaths) {
            const char *utf8 = [p UTF8String];
            if (utf8 != NULL && utf8[0] != '\0') {
                [data appendBytes:utf8 length:strlen(utf8)];
                [data appendBytes:&nul length:1];
            }
        }
        NSUInteger totalLen = [data length];
        if (totalLen == 0) {
            return 0;
        }

        uint8_t *raw = (uint8_t *)malloc((size_t)totalLen);
        if (raw == NULL) {
            return 0;
        }
        memcpy(raw, [data bytes], (size_t)totalLen);

        int isCut = 0;
        NSString *cutVal = [pb stringForType:kMineCutPasteboardType];
        if (cutVal != nil && [cutVal isEqualToString:@"1"]) {
            isCut = 1;
        }

        *out_buf = raw;
        *out_len = (int)totalLen;
        if (out_is_cut != NULL) {
            *out_is_cut = isCut;
        }
        return 1;
    }
}

int mine_macos_has_file_clipboard(void) {
    return mine_has_files_in_pb([NSPasteboard generalPasteboard]);
}

int mine_macos_set_file_clipboard(const char *const *paths_utf8, int count, int is_cut) {
    return mine_write_files_to_pb([NSPasteboard generalPasteboard], paths_utf8, count, is_cut);
}

int mine_macos_get_file_clipboard(uint8_t **out_buf, int *out_len, int *out_is_cut) {
    return mine_read_files_from_pb([NSPasteboard generalPasteboard], out_buf, out_len, out_is_cut);
}

void mine_macos_clear_file_clipboard(void) {
    @autoreleasepool {
        [[NSPasteboard generalPasteboard] clearContents];
    }
}

void mine_macos_free_buffer(uint8_t *ptr) {
    if (ptr != NULL) {
        free(ptr);
    }
}

int mine_macos_is_paste_shortcut_down(int *out_force_move) {
    if (out_force_move != NULL) {
        *out_force_move = 0;
    }
    bool v_down = CGEventSourceKeyState(kCGEventSourceStateCombinedSessionState, (CGKeyCode)9);
    if (!v_down) {
        return 0;
    }
    NSEventModifierFlags flags = [NSEvent modifierFlags];
    BOOL has_cmd_or_ctrl = ((flags & NSEventModifierFlagCommand) != 0) ||
                           ((flags & NSEventModifierFlagControl) != 0);
    BOOL has_shift = (flags & NSEventModifierFlagShift) != 0;
    if (has_cmd_or_ctrl && !has_shift) {
        if (out_force_move != NULL) {
            *out_force_move = ((flags & NSEventModifierFlagOption) != 0) ? 1 : 0;
        }
        return 1;
    }
    return 0;
}

int mine_macos_test_pasteboard_roundtrip(
    const char *const *paths_utf8,
    int count,
    int is_cut,
    uint8_t **out_buf,
    int *out_len,
    int *out_is_cut
) {
    @autoreleasepool {
        NSPasteboard *pb = [NSPasteboard pasteboardWithUniqueName];
        if (pb == nil) {
            return 0;
        }
        int wrote = mine_write_files_to_pb(pb, paths_utf8, count, is_cut);
        int has = mine_has_files_in_pb(pb);
        int read = mine_read_files_from_pb(pb, out_buf, out_len, out_is_cut);
        [pb releaseGlobally];
        return (wrote && has && read) ? 1 : 0;
    }
}
