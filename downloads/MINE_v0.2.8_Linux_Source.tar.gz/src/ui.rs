use crate::app::{ContextMenuState, MineApp, SidebarTab};
use crate::fs_ops::{format_size, PreviewPayload, SmbStatus};
use crate::gesture::{GestureAction, GestureTracker};
use crate::i18n::Language;
use crate::search::{PaneSearchMode, SearchProgressMsg};
use crate::state::{
    AppTheme, MdiChildPane, PaneColumn, PaneViewMode, ScrollRequest, SortColumn, WindowLayoutMode,
    WorkspaceGroupBookmark,
};
use egui::{Color32, Pos2, Rect, RichText, Sense, Stroke, Vec2};
use egui_extras::{Column, TableBuilder};
use std::path::PathBuf;
use sysinfo::{ProcessesToUpdate, System};

impl eframe::App for MineApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.apply_theme(ctx);
        self.poll_background_channels(ctx);
        self.poll_thumbnails_and_properties(ctx);
        self.handle_global_shortcuts_and_gestures(ctx);

        let t = self.config.language.texts();

        // 1. Top Menu Bar + MDIE Quick Toolbar + Multi-Window Tab Strip
        egui::TopBottomPanel::top("mine_top_header").show(ctx, |ui| {
            self.render_menu_bar(ui, t);
            ui.separator();
            self.render_quick_toolbar(ui, t);
            ui.separator();
            self.render_mdi_tab_bar(ui, t);
        });

        // 2. Bottom Status Bar (Responsive layout preventing text collision on vertical monitors)
        egui::TopBottomPanel::bottom("mine_status_bar").show(ctx, |ui| {
            let avail_w = ui.available_width();
            ui.horizontal(|ui| {
                let active_idx = self.active_pane_index();
                if let Some(p) = self.panes.get(active_idx) {
                    ui.label(
                        RichText::new(format!(
                            "📂 {} {} | ☑ {} {}",
                            p.filtered_indices.len(),
                            t.status_items,
                            p.selected_paths.len(),
                            t.status_selected
                        ))
                        .strong(),
                    );
                }
                if !self.status_toast.is_empty() && avail_w > 600.0 {
                    ui.separator();
                    ui.label(RichText::new(&self.status_toast).color(Color32::from_rgb(0, 120, 215)));
                }

                // Right-to-left layout with responsive threshold hiding to avoid overlapping
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    let ram_text = if avail_w > 650.0 {
                        format!("⚡ RAM: {:.1} MB ({} MDI Windows)", self.process_ram_mb, self.panes.len())
                    } else {
                        format!("⚡ {:.1} MB", self.process_ram_mb)
                    };
                    ui.label(
                        RichText::new(ram_text)
                            .color(Color32::from_rgb(20, 140, 60))
                            .strong(),
                    );

                    if avail_w > 800.0 {
                        ui.separator();
                        ui.label(RichText::new(t.status_portable_mode).small());
                    }

                    if avail_w > 1080.0 {
                        ui.separator();
                        ui.label(RichText::new(t.status_gesture_hint).small());
                    }
                });
            });
        });

        // 3. Left Sidebar (Drives, Favorites & Workspace Groups, Non-blocking SMB, Closed Tabs)
        if self.config.show_sidebar {
            egui::SidePanel::left("mine_left_sidebar")
                .default_width(260.0)
                .width_range(160.0..=500.0)
                .resizable(true)
                .frame(
                    egui::Frame::side_top_panel(&ctx.style())
                        .fill(if self.config.theme == AppTheme::ModernDark {
                            Color32::from_rgb(22, 24, 30)
                        } else {
                            Color32::from_rgb(240, 242, 246)
                        })
                        .inner_margin(egui::Margin {
                            left: 6.0,
                            right: 0.0,
                            top: 4.0,
                            bottom: 4.0,
                        }),
                )
                .show(ctx, |ui| {
                    ui.set_width(ui.available_width());
                    self.render_left_sidebar(ui, t);
                });
        }

        // 4. Right Safe Sandbox Preview Panel (Crash-proof HEIC / Image / Text / Encoding)
        if self.config.show_preview {
            egui::SidePanel::right("mine_right_preview")
                .default_width(290.0)
                .width_range(210.0..=480.0)
                .resizable(true)
                .frame(
                    egui::Frame::side_top_panel(&ctx.style())
                        .fill(if self.config.theme == AppTheme::ModernDark {
                            Color32::from_rgb(22, 24, 30)
                        } else {
                            Color32::from_rgb(240, 242, 246)
                        })
                        .inner_margin(egui::Margin {
                            left: 0.0,
                            right: 6.0,
                            top: 4.0,
                            bottom: 4.0,
                        }),
                )
                .show(ctx, |ui| {
                    ui.set_width(ui.available_width());
                    self.render_right_preview(ui, t);
                });
        }

        // 5. Central MDI Multi-Window Workspace
        egui::CentralPanel::default()
            .frame(
                egui::Frame::central_panel(&ctx.style())
                    .fill(if self.config.theme == AppTheme::ModernDark {
                        Color32::from_rgb(16, 18, 22)
                    } else {
                        Color32::from_rgb(171, 178, 191) // Classic MDIE MDI Workspace gray-blue backdrop
                    })
                    .inner_margin(egui::Margin {
                        left: 0.0,
                        right: 0.0,
                        top: 2.0,
                        bottom: 2.0,
                    }),
            )
            .show(ctx, |ui| {
                self.render_mdi_workspace(ui, t);
            });

        // 6. Floating Right-Click Context Menu
        self.render_context_menu(ctx, t);

        // 7. Floating Modals & Dialogs (Global Search, SMB Manager, Gesture Customizer, Rename, About)
        self.render_dialogs(ctx, t);
        self.render_properties_modal(ctx);
        self.render_perm_delete_modal(ctx);

        // 8. Render Live Mouse Gesture Neon Trail & HUD Overlay on top of everything
        self.render_gesture_overlay(ctx);
    }
}

impl MineApp {
    fn poll_background_channels(&mut self, ctx: &egui::Context) {
        let show_hidden = self.config.show_hidden;
        let mut any_loading = false;
        for pane in &mut self.panes {
            if pane.poll_async_load(show_hidden) {
                ctx.request_repaint();
            }
            if pane.is_loading {
                any_loading = true;
            }
        }

        // Poll asynchronous sidebar directory tree loader
        while let Ok((path, children)) = self.tree_load_rx.try_recv() {
            self.tree_pending.remove(&path);
            self.tree_cache.insert(path, children);
            ctx.request_repaint();
        }

        // Poll asynchronous background OS remote folder discovery
        let mut trigger_smb_probes = false;
        if let Some(ref rx) = self.remote_discovery_rx {
            match rx.try_recv() {
                Ok(remotes) => {
                    self.system_smb_shares = remotes;
                    self.is_discovering_remotes = false;
                    self.remote_discovery_rx = None;
                    trigger_smb_probes = true;
                    ctx.request_repaint();
                }
                Err(std::sync::mpsc::TryRecvError::Empty) => {
                    any_loading = true;
                }
                Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                    self.is_discovering_remotes = false;
                    self.remote_discovery_rx = None;
                }
            }
        }
        if trigger_smb_probes {
            self.probe_all_smb();
        }

        // Poll asynchronous background local disk capacity discovery
        if let Some(ref rx) = self.disks_discovery_rx {
            match rx.try_recv() {
                Ok(disks) => {
                    if !disks.is_empty() {
                        self.sys_disks = disks;
                    }
                    self.disks_discovery_rx = None;
                    ctx.request_repaint();
                }
                Err(std::sync::mpsc::TryRecvError::Empty) => {
                    any_loading = true;
                }
                Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                    self.disks_discovery_rx = None;
                }
            }
        }

        // Poll auto-discovered OS remote folders non-blocking probes
        self.system_smb_probes
            .retain(|(idx, rx)| match rx.try_recv() {
                Ok(status) => {
                    if let Some(smb) = self.system_smb_shares.get_mut(*idx) {
                        smb.status = status;
                    }
                    ctx.request_repaint();
                    false
                }
                Err(std::sync::mpsc::TryRecvError::Empty) => {
                    any_loading = true;
                    true
                }
                Err(std::sync::mpsc::TryRecvError::Disconnected) => false,
            });

        // Poll custom SMB non-blocking probes
        self.smb_probes.retain(|(idx, rx)| match rx.try_recv() {
            Ok(status) => {
                if let Some(smb) = self.config.smb_bookmarks.get_mut(*idx) {
                    smb.status = status;
                }
                ctx.request_repaint();
                false
            }
            Err(std::sync::mpsc::TryRecvError::Empty) => {
                any_loading = true;
                true
            }
            Err(std::sync::mpsc::TryRecvError::Disconnected) => false,
        });

        // Poll Sandboxed Preview
        if let Some(ref rx) = self.preview_rx {
            if let Ok(payload) = rx.try_recv() {
                if let PreviewPayload::Image {
                    width,
                    height,
                    ref rgba,
                    ..
                } = payload
                {
                    let color_img = egui::ColorImage::from_rgba_unmultiplied([width, height], rgba);
                    self.preview_texture = Some(ctx.load_texture(
                        "sandbox_preview_tex",
                        color_img,
                        egui::TextureOptions::LINEAR,
                    ));
                }
                self.preview_state = payload;
                self.preview_rx = None;
                ctx.request_repaint();
            } else {
                any_loading = true;
            }
        }

        // Poll Multi-threaded Deep Search
        if let Some(ref rx) = self.deep_search_rx {
            while let Ok(msg) = rx.try_recv() {
                match msg {
                    SearchProgressMsg::Batch(mut batch, scanned) => {
                        if let Some(p) = self.panes.iter_mut().find(|p| p.is_search_results) {
                            for r in &batch {
                                p.entries.push(r.entry.clone());
                            }
                            let show_hidden = self.config.show_hidden;
                            p.apply_sort_and_filter(show_hidden);
                        }
                        self.deep_search_results.append(&mut batch);
                        self.deep_search_scanned = scanned;
                        ctx.request_repaint();
                    }
                    SearchProgressMsg::Finished(scanned, elapsed_ms) => {
                        self.deep_search_scanned = scanned;
                        self.deep_search_elapsed_ms = elapsed_ms;
                        self.deep_search_running = false;
                        self.deep_search_rx = None;
                        self.deep_search_results
                            .sort_by(|a, b| b.score.cmp(&a.score));
                        if let Some(p) = self.panes.iter_mut().find(|p| p.is_search_results) {
                            let show_hidden = self.config.show_hidden;
                            p.apply_sort_and_filter(show_hidden);
                        }
                        ctx.request_repaint();
                        break;
                    }
                }
            }
            if self.deep_search_running {
                any_loading = true;
            }
        }

        // Refresh process memory telemetry every 4 seconds
        if self.last_telemetry_tick.elapsed() > std::time::Duration::from_secs(4) {
            self.last_telemetry_tick = std::time::Instant::now();
            if let Ok(pid) = sysinfo::get_current_pid() {
                let mut sys = System::new();
                sys.refresh_processes(ProcessesToUpdate::Some(&[pid]), true);
                if let Some(proc_info) = sys.process(pid) {
                    self.process_ram_mb = (proc_info.memory() as f64) / (1024.0 * 1024.0);
                }
            }
        }

        // Automatically re-probe remote folders every 5 seconds in the background so Tailscale/VPN/NAS state changes update live
        if !self.is_discovering_remotes
            && self.system_smb_probes.is_empty()
            && self.smb_probes.is_empty()
            && self.last_smb_probe_tick.elapsed() > std::time::Duration::from_secs(5)
        {
            self.probe_all_smb();
        }

        if any_loading {
            ctx.request_repaint_after(std::time::Duration::from_millis(40));
        }
    }

    fn handle_global_shortcuts_and_gestures(&mut self, ctx: &egui::Context) {
        // Right-click + Mouse Wheel -> MDIE fast scroll to top/bottom
        let rmb_down = ctx.input(|i| i.pointer.secondary_down());
        let scroll_y = ctx.input(|i| i.smooth_scroll_delta.y);
        if rmb_down && scroll_y.abs() > 8.0 {
            let idx = self.active_pane_index();
            if let Some(p) = self.panes.get_mut(idx) {
                if scroll_y > 0.0 {
                    p.scroll_request = ScrollRequest::Top;
                    self.status_toast = "🖱 Right-Click + Wheel Up -> 捲動至列表開頭 (Top)".into();
                } else {
                    p.scroll_request = ScrollRequest::Bottom;
                    self.status_toast =
                        "🖱 Right-Click + Wheel Down -> 捲動至列表結尾 (Bottom)".into();
                }
            }
            self.gesture_tracker.is_tracking = false;
            return;
        }

        let win_ctrl_v_now = crate::fs_ops::is_win_ctrl_v_down();
        let win_ctrl_v_edge = win_ctrl_v_now && !self.win_ctrl_v_was_down;
        self.win_ctrl_v_was_down = win_ctrl_v_now;

        let win_shift_del_now = crate::fs_ops::is_win_shift_delete_down();
        let win_shift_del_edge = win_shift_del_now && !self.win_shift_del_was_down;
        self.win_shift_del_was_down = win_shift_del_now;

        let modal_blocking = self.show_smb_dialog
            || self.show_network_shares_manager
            || self.show_gesture_dialog
            || self.show_about_dialog
            || self.show_save_group_modal
            || self.show_quick_access_manager
            || self.show_add_quick_access_modal
            || self.create_item_modal.is_some()
            || self.rename_modal.is_some()
            || self.properties_modal.is_some()
            || self.perm_delete_modal.is_some();

        // Keyboard shortcuts when not typing in a text box or blocking modal
        if !modal_blocking && !ctx.wants_keyboard_input() {
            let mut open_search = false;
            let mut refresh = false;
            let mut go_up = false;
            let mut new_win = false;
            let mut close_win = false;
            let mut rename_f2 = false;
            let mut do_copy = false;
            let mut do_cut = false;
            let mut do_paste = false;
            let mut paste_from_egui = false;
            let mut do_select_all = false;
            let mut do_delete = false;
            let mut do_perm_delete = false;

            let os_focused = ctx.input(|i| {
                let cmd = i.modifiers.command || i.modifiers.ctrl;
                for ev in &i.events {
                    match ev {
                        egui::Event::Copy => do_copy = true,
                        egui::Event::Cut => {
                            // egui-winit on Windows translates Shift+Delete into Event::Cut (legacy CUA binding)
                            if cfg!(target_os = "windows") && i.modifiers.shift && !cmd {
                                do_perm_delete = true;
                            } else {
                                do_cut = true;
                            }
                        }
                        egui::Event::Paste(_) => {
                            do_paste = true;
                            paste_from_egui = true;
                        }
                        _ => {}
                    }
                }
                if cmd && i.key_pressed(egui::Key::F) {
                    open_search = true;
                }
                if cmd && i.key_pressed(egui::Key::N) {
                    new_win = true;
                }
                if cmd && i.key_pressed(egui::Key::W) {
                    close_win = true;
                }
                if cmd && i.key_pressed(egui::Key::C) {
                    do_copy = true;
                }
                if cmd && i.key_pressed(egui::Key::X) {
                    do_cut = true;
                }
                if cmd && i.key_pressed(egui::Key::V) {
                    do_paste = true;
                    paste_from_egui = true;
                }
                if cmd && i.key_pressed(egui::Key::A) {
                    do_select_all = true;
                }
                if i.key_pressed(egui::Key::Delete) || (cmd && i.key_pressed(egui::Key::Backspace)) {
                    if i.modifiers.shift {
                        do_perm_delete = true;
                    } else {
                        do_delete = true;
                    }
                } else if i.key_pressed(egui::Key::Backspace) {
                    go_up = true;
                }
                if i.key_pressed(egui::Key::F5) {
                    refresh = true;
                }
                if i.key_pressed(egui::Key::F2) {
                    rename_f2 = true;
                }
                if i.key_pressed(egui::Key::Escape) {
                    self.context_menu = None;
                    self.drag_payload = None;
                }
                i.focused
            });

            let now = std::time::Instant::now();
            if paste_from_egui {
                let suppressed = self
                    .last_win_paste_time
                    .map(|t| now.duration_since(t) < std::time::Duration::from_millis(180))
                    .unwrap_or(false);
                if suppressed {
                    do_paste = false;
                } else {
                    self.last_egui_paste_time = Some(now);
                }
            }
            if !do_paste && win_ctrl_v_edge && os_focused {
                let suppressed = self
                    .last_egui_paste_time
                    .map(|t| now.duration_since(t) < std::time::Duration::from_millis(180))
                    .unwrap_or(false);
                if !suppressed {
                    do_paste = true;
                    self.last_win_paste_time = Some(now);
                }
            }
            if !do_perm_delete && win_shift_del_edge && os_focused {
                do_perm_delete = true;
            }

            if open_search {
                self.config.show_sidebar = true;
                self.sidebar_tab = SidebarTab::Search;
                self.focus_search_input = true;
            }
            if new_win {
                self.execute_gesture_action(GestureAction::NewMdiWindow);
            }
            if close_win {
                self.execute_gesture_action(GestureAction::CloseActiveWindow);
            }
            if refresh {
                self.execute_gesture_action(GestureAction::RefreshActiveWindow);
            }
            if do_copy {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get(idx) {
                    let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                    self.copy_or_cut_paths(list, false);
                }
                self.context_menu = None;
            }
            if do_cut {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get(idx) {
                    let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                    self.copy_or_cut_paths(list, true);
                }
                self.context_menu = None;
            }
            if do_paste {
                let idx = self.active_pane_index();
                if let Some(dest) = self.panes.get(idx).map(|p| p.current_path.clone()) {
                    self.paste_clipboard_into(&dest);
                }
                self.context_menu = None;
            }
            if do_select_all {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get_mut(idx) {
                    for &i in &p.filtered_indices {
                        if let Some(e) = p.entries.get(i) {
                            p.selected_paths.insert(e.path.clone());
                        }
                    }
                }
            }
            if do_perm_delete {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get(idx) {
                    let targets: Vec<PathBuf> = p
                        .selected_paths
                        .iter()
                        .filter(|path| path.parent().is_some() && !crate::fs_ops::is_this_pc_path(path))
                        .cloned()
                        .collect();
                    if !targets.is_empty() {
                        self.perm_delete_modal = Some(targets);
                        self.context_menu = None;
                    }
                }
            } else if do_delete {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get(idx) {
                    let targets: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                    if !targets.is_empty() {
                        self.move_paths_to_trash(&targets);
                        self.context_menu = None;
                    }
                }
            }
            if rename_f2 {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get(idx) {
                    if let Some(first) = p.selected_paths.iter().next() {
                        let cur_name = first
                            .file_name()
                            .unwrap_or_default()
                            .to_string_lossy()
                            .into_owned();
                        self.rename_modal = Some((first.clone(), cur_name));
                    }
                }
            }
            if go_up {
                self.execute_gesture_action(GestureAction::NavigateUp);
            }
        }
    }

    fn render_menu_bar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        egui::menu::bar(ui, |ui| {
            // App Branding Badge with Japanese Minimalist Cute Icon
            if let Some(ref tex) = self.app_icon_tex {
                ui.add(egui::Image::new((tex.id(), Vec2::new(20.0, 20.0))).rounding(4.0));
            }
            ui.label(
                RichText::new("MINE")
                    .strong()
                    .color(Color32::from_rgb(0, 102, 204)),
            );
            ui.separator();

            // 1. File(F)
            ui.menu_button(t.menu_file, |ui| {
                if ui.button(t.file_new_pane).clicked() {
                    self.execute_gesture_action(GestureAction::NewMdiWindow);
                    ui.close_menu();
                }
                if ui.button(t.file_clone_pane).clicked() {
                    self.execute_gesture_action(GestureAction::CloneActiveWindow);
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.file_new_folder).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        self.create_item_modal =
                            Some((p.current_path.clone(), true, "New_Folder".into()));
                    }
                    ui.close_menu();
                }
                if ui.button(t.file_new_file).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        self.create_item_modal =
                            Some((p.current_path.clone(), false, "note.txt".into()));
                    }
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.file_open_terminal).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        open_terminal_at(&p.current_path);
                    }
                    ui.close_menu();
                }
                if ui.button(t.file_open_native).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let _ = open::that(&p.current_path);
                    }
                    ui.close_menu();
                }
                if ui.button(t.file_restore_closed).clicked() {
                    self.restore_last_closed_pane();
                    ui.close_menu();
                }
                if ui.button(t.file_close_pane).clicked() {
                    let id = self.active_pane_id;
                    self.close_pane_by_id(id);
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.file_exit).clicked() {
                    let _ = self.config.save();
                    std::process::exit(0);
                }
            });

            // 2. Edit(E)
            ui.menu_button(t.menu_edit, |ui| {
                if ui.button(t.edit_copy).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                        self.copy_or_cut_paths(list, false);
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_cut).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                        self.copy_or_cut_paths(list, true);
                    }
                    ui.close_menu();
                }
                if ui
                    .add_enabled(
                        self.has_pasteable_clipboard(),
                        egui::Button::new(t.edit_paste),
                    )
                    .clicked()
                {
                    let idx = self.active_pane_index();
                    if let Some(dest) = self.panes.get(idx).map(|p| p.current_path.clone()) {
                        self.paste_clipboard_into(&dest);
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_rename).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        if let Some(first) = p.selected_paths.iter().next() {
                            let cur_name = first
                                .file_name()
                                .unwrap_or_default()
                                .to_string_lossy()
                                .into_owned();
                            self.rename_modal = Some((first.clone(), cur_name));
                        }
                    }
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.edit_copy_path).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let target = p
                            .selected_paths
                            .iter()
                            .next()
                            .cloned()
                            .unwrap_or_else(|| p.current_path.clone());
                        if let Ok(mut cb) = arboard::Clipboard::new() {
                            let _ = cb.set_text(target.to_string_lossy().into_owned());
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_select_all).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get_mut(idx) {
                        for &i in &p.filtered_indices {
                            if let Some(e) = p.entries.get(i) {
                                p.selected_paths.insert(e.path.clone());
                            }
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_invert_selection).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get_mut(idx) {
                        let mut next_set = std::collections::HashSet::new();
                        for &i in &p.filtered_indices {
                            if let Some(e) = p.entries.get(i) {
                                if !p.selected_paths.contains(&e.path) {
                                    next_set.insert(e.path.clone());
                                }
                            }
                        }
                        p.selected_paths = next_set;
                    }
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.edit_delete).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let targets: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                        self.move_paths_to_trash(&targets);
                    }
                    ui.close_menu();
                }
                let perm_lbl = if self.config.language == Language::ZhTw {
                    "🔥 永久刪除 (Shift+Del)"
                } else {
                    "🔥 Permanent Delete (Shift+Del)"
                };
                if ui
                    .button(RichText::new(perm_lbl).color(Color32::from_rgb(220, 45, 45)))
                    .clicked()
                {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let targets: Vec<PathBuf> = p
                            .selected_paths
                            .iter()
                            .filter(|path| path.parent().is_some() && !crate::fs_ops::is_this_pc_path(path))
                            .cloned()
                            .collect();
                        if !targets.is_empty() {
                            self.perm_delete_modal = Some(targets);
                        }
                    }
                    ui.close_menu();
                }
            });

            // 3. View(V)
            ui.menu_button(t.menu_view, |ui| {
                let is_zh = self.config.language == Language::ZhTw;
                ui.menu_button(if is_zh { "👁 檢視模式 (View)" } else { "👁 View Mode" }, |ui| {
                    let target_id = self.active_pane_id;
                    self.render_view_mode_menu_items(ui, target_id);
                });
                ui.separator();
                if ui
                    .checkbox(&mut self.config.show_sidebar, t.view_sidebar)
                    .changed()
                {
                    let _ = self.config.save();
                }
                ui.menu_button(t.menu_sidebar_sub, |ui| {
                    let is_zh = self.config.language == Language::ZhTw;
                    if ui
                        .selectable_label(
                            self.config.show_sidebar && self.sidebar_tab == SidebarTab::DrivesAndTree,
                            format!("{} (Ctrl+T)", t.side_tree),
                        )
                        .clicked()
                    {
                        self.config.show_sidebar = true;
                        self.sidebar_tab = SidebarTab::DrivesAndTree;
                        ui.close_menu();
                    }
                    if ui
                        .selectable_label(
                            self.config.show_sidebar && self.sidebar_tab == SidebarTab::Favorites,
                            format!("{} (Ctrl+I)", t.side_favorites),
                        )
                        .clicked()
                    {
                        self.config.show_sidebar = true;
                        self.sidebar_tab = SidebarTab::Favorites;
                        ui.close_menu();
                    }
                    if ui
                        .selectable_label(
                            self.config.show_sidebar && self.sidebar_tab == SidebarTab::Search,
                            format!("{} (Ctrl+F)", t.side_search),
                        )
                        .clicked()
                    {
                        self.config.show_sidebar = true;
                        self.sidebar_tab = SidebarTab::Search;
                        self.focus_search_input = true;
                        ui.close_menu();
                    }
                    ui.separator();
                    if ui
                        .checkbox(
                            &mut self.config.show_sidebar_quick_access,
                            if is_zh { "顯示 ⭐ 常用資料夾" } else { "Show Quick Access" },
                        )
                        .changed()
                    {
                        let _ = self.config.save();
                    }
                    if ui
                        .checkbox(
                            &mut self.config.show_sidebar_this_pc,
                            if is_zh { "顯示 💻 本機電腦" } else { "Show This PC" },
                        )
                        .changed()
                    {
                        let _ = self.config.save();
                    }
                    if ui
                        .checkbox(
                            &mut self.config.show_sidebar_network,
                            if is_zh { "顯示 🌐 網路磁碟與共用" } else { "Show Network Shares" },
                        )
                        .changed()
                    {
                        let _ = self.config.save();
                    }
                    if ui
                        .checkbox(
                            &mut self.config.hide_offline_network_shares,
                            if is_zh { "🛡 隱藏離線網路磁碟" } else { "Hide Offline Network Shares" },
                        )
                        .changed()
                    {
                        let _ = self.config.save();
                    }
                    ui.separator();
                    if ui
                        .button(if is_zh { "⚙ 管理常用資料夾..." } else { "⚙ Manage Quick Access..." })
                        .clicked()
                    {
                        self.show_quick_access_manager = true;
                        ui.close_menu();
                    }
                });
                if ui
                    .checkbox(&mut self.config.show_preview, t.view_preview)
                    .changed()
                {
                    if self.config.show_preview {
                        self.sync_preview_to_active_selection();
                    }
                    let _ = self.config.save();
                }
                if ui
                    .checkbox(&mut self.config.show_hidden, t.view_hidden_files)
                    .changed()
                {
                    let show_hidden = self.config.show_hidden;
                    for p in &mut self.panes {
                        p.apply_sort_and_filter(show_hidden);
                    }
                    let _ = self.config.save();
                }
                ui.separator();
                if ui
                    .selectable_value(&mut self.config.theme, AppTheme::ClassicMdie, t.view_theme_classic_mdie)
                    .clicked()
                    || ui
                        .selectable_value(&mut self.config.theme, AppTheme::ModernDark, t.view_theme_dark)
                        .clicked()
                    || ui
                        .selectable_value(&mut self.config.theme, AppTheme::CleanLight, t.view_theme_light)
                        .clicked()
                {
                    let _ = self.config.save();
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.view_refresh).clicked() {
                    for p in &mut self.panes {
                        p.trigger_reload();
                    }
                    ui.close_menu();
                }
            });

            // 4. Favorites(A) - Including MDIE Multi-Window Workspace Groups!
            ui.menu_button(t.menu_favorites, |ui| {
                if self.panes.len() > 1 {
                    let active_idx = self.active_pane_index();
                    let target_title = self.panes.get(active_idx).map(|p| p.title.as_str()).unwrap_or("1");
                    let target_hint = if self.config.language == Language::ZhTw {
                        format!("🎯 目標視窗：[{}] {}", active_idx + 1, target_title)
                    } else {
                        format!("🎯 Target Window: [{}] {}", active_idx + 1, target_title)
                    };
                    ui.label(RichText::new(target_hint).small().color(Color32::from_rgb(0, 120, 215)).strong());
                    ui.separator();
                }
                if ui.button(t.fav_add_current_folder).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let name = p.title.clone();
                        let path_s = p.current_path.to_string_lossy().into_owned();
                        self.config.favorite_folders.push((name, path_s));
                        let _ = self.config.save();
                    }
                    ui.close_menu();
                }
                if ui.button(t.fav_save_workspace_group).clicked() {
                    self.show_save_group_modal = true;
                    ui.close_menu();
                }
                ui.separator();
                ui.label(RichText::new(t.fav_groups_header).strong());
                let groups = self.config.workspace_groups.clone();
                for grp in groups {
                    if ui
                        .button(format!("📦 {} ({} 視窗)", grp.name, grp.paths.len()))
                        .clicked()
                    {
                        self.panes.clear();
                        for (i, ps) in grp.paths.iter().enumerate() {
                            self.panes.push(MdiChildPane::new(i + 1, PathBuf::from(ps)));
                        }
                        self.next_pane_id = self.panes.len() + 1;
                        self.active_pane_id = 1;
                        self.config.layout_mode = grp.layout;
                        self.sync_config_paths();
                        ui.close_menu();
                    }
                }
                ui.separator();
                ui.label(RichText::new(t.fav_folders_header).strong());
                let favs = self.config.favorite_folders.clone();
                for (name, path_s) in favs {
                    if ui.button(format!("⭐ {}", name)).clicked() {
                        let idx = self.active_pane_index();
                        if let Some(p) = self.panes.get_mut(idx) {
                            p.navigate_to(PathBuf::from(path_s), true);
                        }
                        ui.close_menu();
                    }
                }
            });

            // 5. Tools(T)
            ui.menu_button(t.menu_tools, |ui| {
                if ui.button(t.tools_global_search).clicked() {
                    self.config.show_sidebar = true;
                    self.sidebar_tab = SidebarTab::Search;
                    self.focus_search_input = true;
                    ui.close_menu();
                }
                if ui.button(t.tools_smb_manager).clicked() {
                    self.show_smb_dialog = true;
                    ui.close_menu();
                }
                if ui.button(t.tools_gesture_settings).clicked() {
                    self.show_gesture_dialog = true;
                    ui.close_menu();
                }
                ui.separator();
                if ui
                    .button(t.tools_folder_options)
                    .on_hover_text(t.tools_folder_options_tip)
                    .clicked()
                {
                    open_system_folder_options();
                    self.status_toast = if self.config.language == Language::ZhTw {
                        "📁 已開啟系統「資料夾選項」設定視窗".into()
                    } else {
                        "📁 Opened System Folder Options".into()
                    };
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.tools_save_portable).clicked() {
                    if let Ok(p) = self.config.save() {
                        self.status_toast = format!("💾 Saved portable config: {}", p.to_string_lossy());
                    }
                    ui.close_menu();
                }
                if ui.button(t.tools_export_reg_script).clicked() {
                    if let Ok(reg_path) = export_windows_shell_reg() {
                        self.status_toast = format!("🛠 已匯出 Windows 登錄檔: {}", reg_path.to_string_lossy());
                    }
                    ui.close_menu();
                }
            });

            // 6. Window(W) - Exact replica of MDIE's iconic Window menu from the screenshot!
            ui.menu_button(t.menu_window, |ui| {
                ui.label(RichText::new(t.win_mode_title).strong());
                if ui
                    .selectable_value(
                        &mut self.config.layout_mode,
                        WindowLayoutMode::TileHorizontally,
                        t.win_mode_tile_horiz,
                    )
                    .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::TileVertically,
                            t.win_mode_tile_vert,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::TileGrid,
                            t.win_mode_tile_grid,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::Cascade,
                            t.win_mode_cascade,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::MdiFree,
                            t.win_mode_mdi_free,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::TabbedMaximized,
                            t.win_mode_tabbed,
                        )
                        .clicked()
                {
                    if self.config.layout_mode == WindowLayoutMode::Cascade {
                        self.needs_cascade_recalc = true;
                    }
                    let _ = self.config.save();
                    ui.close_menu();
                }

                ui.separator();
                if ui.button(t.win_scroll_top).clicked() {
                    self.execute_gesture_action(GestureAction::ScrollToTop);
                    ui.close_menu();
                }
                if ui.button(t.win_scroll_bottom).clicked() {
                    self.execute_gesture_action(GestureAction::ScrollToBottom);
                    ui.close_menu();
                }
                ui.checkbox(&mut self.config.sync_scroll, t.win_sync_scroll);
                if ui.button(t.win_close_all_except_active).clicked() {
                    let active_id = self.active_pane_id;
                    self.panes.retain(|p| p.id == active_id);
                    self.sync_config_paths();
                    ui.close_menu();
                }

                ui.separator();
                // Numbered window list just like MDIE's Window menu (1 This PC, 2 DarkTable, 3 Style...)
                for (i, pane) in self.panes.iter().enumerate() {
                    let checked = pane.id == self.active_pane_id;
                    if ui
                        .selectable_label(checked, format!("{} {}", i + 1, pane.title))
                        .clicked()
                    {
                        self.active_pane_id = pane.id;
                        ui.close_menu();
                    }
                }
            });

            // 7. Help(H)
            ui.menu_button(t.menu_help, |ui| {
                if ui.button("ℹ 關於 MINE (About MINE)").clicked() {
                    self.show_about_dialog = true;
                    ui.close_menu();
                }
                ui.separator();
                let sponsor_label = if self.config.language == Language::ZhTw {
                    "☕ 贊助鼓勵作者 (Ko-fi)"
                } else {
                    "☕ Support the Author on Ko-fi"
                };
                if ui
                    .button(
                        RichText::new(sponsor_label)
                            .color(Color32::from_rgb(255, 94, 91))
                            .strong(),
                    )
                    .on_hover_text("https://ko-fi.com/aiohlala")
                    .clicked()
                {
                    let _ = open::that("https://ko-fi.com/aiohlala");
                    ui.close_menu();
                }
            });

            // Right-aligned Language Switcher & Quick Buttons (Responsive to prevent collision)
            let avail_w = ui.available_width();
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if avail_w > 820.0 {
                    if ui
                        .selectable_label(self.config.language == Language::En, "🌐 EN")
                        .clicked()
                    {
                        self.config.language = Language::En;
                        let _ = self.config.save();
                    }
                    if ui
                        .selectable_label(self.config.language == Language::ZhTw, "🌐 繁中")
                        .clicked()
                    {
                        self.config.language = Language::ZhTw;
                        let _ = self.config.save();
                    }
                } else {
                    let cur_lang_label = if self.config.language == Language::ZhTw { "🌐 繁" } else { "🌐 EN" };
                    if ui.button(cur_lang_label).on_hover_text("Switch Language (切換語系)").clicked() {
                        self.config.language = if self.config.language == Language::ZhTw {
                            Language::En
                        } else {
                            Language::ZhTw
                        };
                        let _ = self.config.save();
                    }
                }

                if avail_w > 720.0 {
                    ui.separator();
                    if ui.button(t.top_deep_search).clicked() {
                        self.config.show_sidebar = true;
                        self.sidebar_tab = SidebarTab::Search;
                        self.focus_search_input = true;
                    }
                }
                if avail_w > 890.0 {
                    if ui.button(t.top_gestures).clicked() {
                        self.show_gesture_dialog = true;
                    }
                }
            });
        });
    }

    fn render_quick_toolbar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.horizontal_wrapped(|ui| {
            // Navigation controls for active pane
            if ui.button(t.btn_back).clicked() {
                self.execute_gesture_action(GestureAction::NavigateBack);
            }
            if ui.button(t.btn_forward).clicked() {
                self.execute_gesture_action(GestureAction::NavigateForward);
            }
            if ui.button(t.btn_up).clicked() {
                self.execute_gesture_action(GestureAction::NavigateUp);
            }
            if ui.button(t.btn_refresh).clicked() {
                self.execute_gesture_action(GestureAction::RefreshActiveWindow);
            }

            ui.separator();

            // One-click Unlimited MDI Window Spawner & Layout Switcher
            if ui
                .button(RichText::new(t.quick_new_window).strong())
                .on_hover_text(t.quick_new_window_tip)
                .clicked()
            {
                self.execute_gesture_action(GestureAction::NewMdiWindow);
            }
            if ui
                .button(t.quick_clone_window)
                .on_hover_text(t.quick_clone_window_tip)
                .clicked()
            {
                self.execute_gesture_action(GestureAction::CloneActiveWindow);
            }

            ui.separator();
            ui.label(RichText::new(t.quick_layout_label).strong());
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TileHorizontally,
                    t.quick_layout_horiz,
                )
                .on_hover_text(t.quick_layout_horiz_tip)
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TileHorizontally;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TileVertically,
                    t.quick_layout_vert,
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TileVertically;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TileGrid,
                    t.quick_layout_grid,
                )
                .on_hover_text(t.quick_layout_grid_tip)
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TileGrid;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::Cascade,
                    t.quick_layout_cascade,
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::Cascade;
                self.needs_cascade_recalc = true;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::MdiFree,
                    t.quick_layout_free,
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::MdiFree;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TabbedMaximized,
                    t.quick_layout_tabbed,
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TabbedMaximized;
            }

            ui.separator();

            // Quick toggle buttons for Left Sidebar, Search, and Right Preview Panel
            if ui
                .selectable_label(self.config.show_sidebar, t.quick_sidebar)
                .on_hover_text(t.view_sidebar)
                .clicked()
            {
                self.config.show_sidebar = !self.config.show_sidebar;
                let _ = self.config.save();
            }

            let search_active = self.config.show_sidebar && self.sidebar_tab == SidebarTab::Search;
            if ui
                .selectable_label(search_active, RichText::new(t.quick_search).strong())
                .on_hover_text(t.quick_search_tip)
                .clicked()
            {
                if search_active {
                    self.sidebar_tab = SidebarTab::DrivesAndTree;
                } else {
                    self.config.show_sidebar = true;
                    self.sidebar_tab = SidebarTab::Search;
                    self.focus_search_input = true;
                }
            }

            if ui
                .selectable_label(self.config.show_preview, t.quick_preview)
                .on_hover_text(t.view_preview)
                .clicked()
            {
                self.config.show_preview = !self.config.show_preview;
                if self.config.show_preview {
                    self.sync_preview_to_active_selection();
                }
                let _ = self.config.save();
            }

            // Quick Dropdown for OS Auto-Discovered Remote Folders & Local Drives (even when Sidebar is hidden!)
            let remote_menu_label = if self.config.language == Language::ZhTw {
                format!(
                    "🌐 遠端與磁碟 ({})",
                    self.system_smb_shares.len() + self.config.smb_bookmarks.len()
                )
            } else {
                format!(
                    "🌐 Drives & Remote ({})",
                    self.system_smb_shares.len() + self.config.smb_bookmarks.len()
                )
            };
            ui.menu_button(remote_menu_label, |ui| {
                ui.set_min_width(270.0);
                if self.panes.len() > 1 {
                    let active_idx = self.active_pane_index();
                    let target_title = self.panes.get(active_idx).map(|p| p.title.as_str()).unwrap_or("1");
                    let target_hint = if self.config.language == Language::ZhTw {
                        format!("🎯 目標視窗：[{}] {}", active_idx + 1, target_title)
                    } else {
                        format!("🎯 Target Window: [{}] {}", active_idx + 1, target_title)
                    };
                    ui.label(RichText::new(target_hint).small().color(Color32::from_rgb(0, 120, 215)).strong());
                    ui.separator();
                }
                ui.horizontal(|ui| {
                    ui.label(RichText::new(t.side_remote_header).strong());
                    let refresh_btn_text = if self.config.language == Language::ZhTw { "🔄 重新抓取" } else { "🔄 Refresh" };
                    if ui
                        .small_button(refresh_btn_text)
                        .on_hover_text(t.side_refresh_tip)
                        .clicked()
                    {
                        self.refresh_system_remote_folders();
                    }
                    let manage_btn_text = if self.config.language == Language::ZhTw { "⚙ 管理" } else { "⚙ Manage" };
                    if ui.small_button(manage_btn_text).clicked() {
                        self.show_smb_dialog = true;
                        ui.close_menu();
                    }
                });
                ui.separator();

                let sys_smbs = self.system_smb_shares.clone();
                let usr_smbs = self.config.smb_bookmarks.clone();
                if sys_smbs.is_empty() && usr_smbs.is_empty() {
                    ui.label(
                        RichText::new(if self.config.language == Language::ZhTw {
                            "目前未偵測到系統已設定的遠端資料夾"
                        } else {
                            "No OS remote folders detected"
                        })
                        .small()
                        .color(Color32::GRAY),
                    );
                }
                for smb in sys_smbs.iter().chain(usr_smbs.iter()) {
                    let is_offline = matches!(smb.status, SmbStatus::Offline(_));
                    let btn_label = match &smb.status {
                        SmbStatus::Online(_) => RichText::new(&smb.name),
                        SmbStatus::Offline(_) => RichText::new(format!(
                            "{} {}",
                            smb.name,
                            if self.config.language == Language::ZhTw {
                                "[✖ 無法連線]"
                            } else {
                                "[✖ Disconnected]"
                            }
                        ))
                        .color(Color32::from_rgb(240, 100, 100)),
                        SmbStatus::Probing | SmbStatus::Unknown => RichText::new(format!(
                            "{} {}",
                            smb.name,
                            if self.config.language == Language::ZhTw {
                                "[偵測中...]"
                            } else {
                                "[Checking...]"
                            }
                        )),
                    };
                    let is_zh = self.config.language == Language::ZhTw;
                    let hover_tip = match &smb.status {
                        SmbStatus::Online(ms) => {
                            if is_zh {
                                format!("● 已連線 ({} ms)\n{}", ms, smb.unc_or_mount_path)
                            } else {
                                format!("● Online ({} ms)\n{}", ms, smb.unc_or_mount_path)
                            }
                        }
                        SmbStatus::Offline(err) => {
                            if is_zh {
                                format!("✖ 無法連線 ({})\n{}", err, smb.unc_or_mount_path)
                            } else {
                                format!("✖ Disconnected ({})\n{}", err, smb.unc_or_mount_path)
                            }
                        }
                        SmbStatus::Probing | SmbStatus::Unknown => {
                            if is_zh {
                                format!("⏳ 正在偵測連線狀態...\n{}", smb.unc_or_mount_path)
                            } else {
                                format!("⏳ Probing connection...\n{}", smb.unc_or_mount_path)
                            }
                        }
                    };
                    ui.horizontal(|ui| {
                        draw_smb_status_icon(ui, &smb.status);
                        if ui.button(btn_label).on_hover_text(&hover_tip).clicked() {
                            let idx = self.active_pane_index();
                            if is_offline {
                                self.status_toast = if is_zh {
                                    format!(
                                        "✖ 無法連線至遠端資料夾「{}」— 請確認網路或 Tailscale/VPN 是否已連線",
                                        smb.name
                                    )
                                } else {
                                    format!(
                                        "✖ Unable to connect to remote folder '{}' - check network or Tailscale/VPN",
                                        smb.name
                                    )
                                };
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.error_banner = Some(if is_zh {
                                        format!(
                                            "✖ 無法連線至「{}」({}) — 請確認網路或 Tailscale/VPN 是否已開啟 (已維持目前資料夾「{}」)",
                                            smb.name, smb.unc_or_mount_path, p.title
                                        )
                                    } else {
                                        format!(
                                            "✖ Cannot connect to '{}' ({}) - please verify network or VPN (kept current folder '{}')",
                                            smb.name, smb.unc_or_mount_path, p.title
                                        )
                                    });
                                }
                                self.probe_all_smb();
                            }
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(PathBuf::from(&smb.unc_or_mount_path), true);
                            }
                            ui.close_menu();
                        }
                        if ui
                            .small_button("➕")
                            .on_hover_text(t.side_add_window_tip)
                            .clicked()
                        {
                            if is_offline {
                                self.status_toast = format!(
                                    "✖ 無法連線至遠端資料夾「{}」— 請確認網路或 Tailscale/VPN 是否已連線",
                                    smb.name
                                );
                                let idx = self.active_pane_index();
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.error_banner = Some(format!(
                                        "✖ 無法連線至「{}」({}) — 請確認網路或 Tailscale/VPN 是否已開啟",
                                        smb.name, smb.unc_or_mount_path
                                    ));
                                }
                                self.probe_all_smb();
                            } else {
                                self.spawn_new_pane(PathBuf::from(&smb.unc_or_mount_path));
                            }
                            ui.close_menu();
                        }
                    });
                }

                ui.separator();
                ui.label(
                    RichText::new(if self.config.language == Language::ZhTw {
                        "💽 本機磁碟"
                    } else {
                        "💽 Local Drives"
                    })
                    .strong(),
                );
                let disks = self.sys_disks.clone();
                for (label, mount, _, _) in disks {
                    ui.horizontal(|ui| {
                        if ui.button(format!("🖴 {}", label)).clicked() {
                            let idx = self.active_pane_index();
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(mount.clone(), true);
                            }
                            ui.close_menu();
                        }
                        if ui.small_button("➕").clicked() {
                            self.spawn_new_pane(mount);
                            ui.close_menu();
                        }
                    });
                }
            });

            ui.separator();

            // Quick Theme Switcher Buttons (Dark / Light / Classic MDIE)
            if ui
                .selectable_label(self.config.theme == AppTheme::ModernDark, t.quick_theme_dark)
                .on_hover_text(t.view_theme_dark)
                .clicked()
            {
                self.config.theme = AppTheme::ModernDark;
                let _ = self.config.save();
            }

            if ui
                .selectable_label(self.config.theme == AppTheme::CleanLight, t.quick_theme_light)
                .on_hover_text(t.view_theme_light)
                .clicked()
            {
                self.config.theme = AppTheme::CleanLight;
                let _ = self.config.save();
            }

            if ui
                .selectable_label(self.config.theme == AppTheme::ClassicMdie, t.quick_theme_classic)
                .on_hover_text(t.view_theme_classic_mdie)
                .clicked()
            {
                self.config.theme = AppTheme::ClassicMdie;
                let _ = self.config.save();
            }

            ui.separator();
            let is_zh = self.config.language == Language::ZhTw;
            ui.label(
                RichText::new(if is_zh { "🔤 清單字體:" } else { "🔤 List Font:" })
                    .small()
                    .strong(),
            );
            let mut font_val = self.config.file_list_font_size;
            let font_slider = egui::Slider::new(&mut font_val, 10.0..=22.0)
                .step_by(0.5)
                .suffix("px")
                .show_value(true);
            let font_tip = if is_zh {
                "調整中間資料夾視窗的文字大小與行高 (預設 13.5px)"
            } else {
                "Adjust folder pane font size & row height (default 13.5px)"
            };
            if ui.add(font_slider).on_hover_text(font_tip).changed() {
                self.config.file_list_font_size = font_val;
                let _ = self.config.save();
            }
            if (self.config.file_list_font_size - 13.5).abs() > 0.1 {
                if ui
                    .small_button("↺")
                    .on_hover_text(if is_zh {
                        "恢復預設字體大小 (13.5px)"
                    } else {
                        "Reset default font size (13.5px)"
                    })
                    .clicked()
                {
                    self.config.file_list_font_size = 13.5;
                    let _ = self.config.save();
                }
            }

            ui.separator();
            let active_vm = self
                .panes
                .iter()
                .find(|p| p.id == self.active_pane_id)
                .map(|p| p.view_mode)
                .unwrap_or(self.config.view_mode);
            let vm_label = match (active_vm, is_zh) {
                (PaneViewMode::Details, true) => "☰ 詳細資料 ▾",
                (PaneViewMode::Details, false) => "☰ Details ▾",
                (PaneViewMode::List, true) => "▤ 清單 ▾",
                (PaneViewMode::List, false) => "▤ List ▾",
                (PaneViewMode::SmallIcons, true) => "▪ 小圖示 ▾",
                (PaneViewMode::SmallIcons, false) => "▪ Small Icons ▾",
                (PaneViewMode::LargeIcons, true) => "▫ 大圖示 ▾",
                (PaneViewMode::LargeIcons, false) => "▫ Large Icons ▾",
                (PaneViewMode::Thumbnails, true) => "🖼 縮圖 ▾",
                (PaneViewMode::Thumbnails, false) => "🖼 Thumbnails ▾",
            };
            let active_id = self.active_pane_id;
            ui.menu_button(vm_label, |ui| {
                self.render_view_mode_menu_items(ui, active_id);
            });
        });
    }

    fn render_view_mode_menu_items(&mut self, ui: &mut egui::Ui, target_pane_id: usize) -> bool {
        let is_zh = self.config.language == Language::ZhTw;
        let current_vm = self
            .panes
            .iter()
            .find(|p| p.id == target_pane_id)
            .map(|p| p.view_mode)
            .unwrap_or(self.config.view_mode);
        let modes = [
            (PaneViewMode::LargeIcons, if is_zh { "▫ 大圖示 (Large Icons)" } else { "▫ Large Icons" }),
            (PaneViewMode::SmallIcons, if is_zh { "▪ 小圖示 (Small Icons)" } else { "▪ Small Icons" }),
            (PaneViewMode::List, if is_zh { "▤ 清單 (List)" } else { "▤ List" }),
            (PaneViewMode::Details, if is_zh { "☰ 詳細資料 (Details)" } else { "☰ Details" }),
            (PaneViewMode::Thumbnails, if is_zh { "🖼 縮圖 (Thumbnails)" } else { "🖼 Thumbnails" }),
        ];
        let mut changed = false;
        for (mode, label) in modes {
            let selected = current_vm == mode;
            let prefix = if selected { "● " } else { "    " };
            if ui
                .selectable_label(selected, format!("{}{}", prefix, label))
                .clicked()
            {
                if let Some(p) = self.panes.iter_mut().find(|p| p.id == target_pane_id) {
                    p.view_mode = mode;
                }
                self.config.view_mode = mode;
                let _ = self.config.save();
                ui.close_menu();
                changed = true;
            }
        }
        changed
    }

    fn sync_preview_to_active_selection(&mut self) {
        let maybe_path = self
            .panes
            .iter()
            .find(|p| p.id == self.active_pane_id)
            .and_then(|p| {
                if let Some(idx) = p.last_clicked_idx {
                    if let Some(&e_idx) = p.filtered_indices.get(idx) {
                        if let Some(entry) = p.entries.get(e_idx) {
                            if p.selected_paths.contains(&entry.path) {
                                return Some(entry.path.clone());
                            }
                        }
                    }
                }
                p.selected_paths.iter().next().cloned()
            });
        if let Some(p) = maybe_path {
            self.trigger_preview(p);
        }
    }

    fn render_mdi_tab_bar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.horizontal_wrapped(|ui| {
            let mut close_id = None;
            let mut activate_id = None;

            for (idx, pane) in self.panes.iter().enumerate() {
                let is_active = pane.id == self.active_pane_id;
                let frame_bg = if is_active {
                    Color32::from_rgb(0, 110, 210)
                } else {
                    Color32::from_gray(215)
                };
                let text_col = if is_active {
                    Color32::WHITE
                } else {
                    Color32::BLACK
                };

                let frame_resp = egui::Frame::none()
                    .fill(frame_bg)
                    .rounding(egui::Rounding {
                        nw: 4.0,
                        ne: 4.0,
                        sw: 0.0,
                        se: 0.0,
                    })
                    .inner_margin(egui::Margin::symmetric(8.0, 3.0))
                    .show(ui, |ui| {
                        let resp = ui.add(
                            egui::Label::new(
                                RichText::new(format!("📁 {}: {}", idx + 1, pane.title))
                                    .color(text_col)
                                    .strong(),
                            )
                            .sense(Sense::click()),
                        );
                        if resp.clicked() {
                            activate_id = Some(pane.id);
                        }
                        if resp.middle_clicked() {
                            close_id = Some(pane.id);
                        }
                        if ui
                            .add(
                                egui::Button::new(RichText::new("×").color(text_col).small())
                                    .frame(false),
                            )
                            .clicked()
                        {
                            close_id = Some(pane.id);
                        }
                    });
                if ui
                    .interact(
                        frame_resp.response.rect,
                        egui::Id::new(("tab_pill_hit", pane.id)),
                        Sense::click(),
                    )
                    .clicked()
                {
                    activate_id = Some(pane.id);
                }
            }

            if ui
                .button("➕")
                .on_hover_text(t.file_new_pane)
                .clicked()
            {
                self.execute_gesture_action(GestureAction::NewMdiWindow);
            }

            if let Some(id) = activate_id {
                if self.active_pane_id != id {
                    self.active_pane_id = id;
                    for p in &mut self.panes {
                        if p.id != id {
                            p.selected_paths.clear();
                            p.last_clicked_idx = None;
                        }
                    }
                }
            }
            if let Some(id) = close_id {
                self.close_pane_by_id(id);
            }
        });
    }

fn render_tree_folder_node_custom(
    ui: &mut egui::Ui,
    name: &str,
    path: &std::path::Path,
    default_icon: &str,
    depth: usize,
    active_path: Option<&std::path::Path>,
    theme: AppTheme,
    tree_expanded: &std::collections::HashSet<PathBuf>,
    tree_cache: &std::collections::HashMap<PathBuf, Vec<(String, PathBuf)>>,
    tree_pending: &std::collections::HashSet<PathBuf>,
    nav_target: &mut Option<PathBuf>,
    spawn_target: &mut Option<PathBuf>,
    toggle_target: &mut Option<PathBuf>,
    context_menu: Option<impl FnOnce(&mut egui::Ui)>,
) {
    let is_expanded = tree_expanded.contains(path);
    let is_loading = tree_pending.contains(path);
    let children_opt = tree_cache.get(path);
    let is_active = active_path.map(|ap| ap == path).unwrap_or(false);
    let has_children = children_opt.map(|c| !c.is_empty()).unwrap_or(true);

    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = 2.0;
        if depth > 0 {
            ui.add_space((depth as f32) * 14.0);
        }

        // 1. Expand / Collapse toggle icon
        if is_loading {
            ui.label(RichText::new("⏳").small());
        } else if has_children {
            let toggle_icon = if is_expanded { "▼" } else { "▶" };
            let toggle_col = if is_expanded {
                Color32::from_rgb(0, 120, 215)
            } else {
                Color32::from_gray(130)
            };
            let resp = ui.add(
                egui::Label::new(RichText::new(toggle_icon).small().color(toggle_col))
                    .sense(Sense::click()),
            );
            if resp.clicked() {
                *toggle_target = Some(path.to_path_buf());
            }
        } else {
            ui.label(RichText::new(" •").small().color(Color32::from_gray(120)));
        }

        // 2. Folder Icon
        if default_icon == "📁" || default_icon == "📂" {
            draw_finder_folder_widget(ui, 13.5, is_expanded, is_active);
        } else {
            ui.label(default_icon);
        }

        // 3. Clickable Name Label
        let text_color = if is_active {
            Color32::WHITE
        } else if theme == AppTheme::ModernDark {
            Color32::from_gray(230)
        } else {
            Color32::BLACK
        };

        let label_resp = ui.add(
            egui::SelectableLabel::new(
                is_active,
                RichText::new(name).color(text_color).strong(),
            ),
        );

        if label_resp.clicked() {
            *nav_target = Some(path.to_path_buf());
        }
        if label_resp.double_clicked() {
            *toggle_target = Some(path.to_path_buf());
        }

        if let Some(cm) = context_menu {
            label_resp.context_menu(cm);
        }

        // 4. Quick New Window button on hover
        if label_resp.hovered() || is_active {
            if ui.small_button("➕").on_hover_text("在新視窗開啟此資料夾").clicked() {
                *spawn_target = Some(path.to_path_buf());
            }
        }
    });

    // Subdirectory children (recursive)
    if is_expanded {
        if is_loading {
            ui.horizontal(|ui| {
                ui.add_space(((depth + 1) as f32) * 14.0);
                ui.label(RichText::new("⏳ 讀取中...").small().color(Color32::GRAY));
            });
        } else if let Some(sub_dirs) = children_opt {
            if sub_dirs.is_empty() {
                ui.horizontal(|ui| {
                    ui.add_space(((depth + 1) as f32) * 14.0);
                    ui.label(RichText::new("（無子資料夾）").small().color(Color32::from_gray(140)));
                });
            } else {
                for (sub_name, sub_path) in sub_dirs {
                    Self::render_tree_folder_node(
                        ui,
                        sub_name,
                        sub_path,
                        "📁",
                        depth + 1,
                        active_path,
                        theme,
                        tree_expanded,
                        tree_cache,
                        tree_pending,
                        nav_target,
                        spawn_target,
                        toggle_target,
                    );
                }
            }
        }
    }
}

fn render_tree_folder_node(
    ui: &mut egui::Ui,
    name: &str,
    path: &std::path::Path,
    default_icon: &str,
    depth: usize,
    active_path: Option<&std::path::Path>,
    theme: AppTheme,
    tree_expanded: &std::collections::HashSet<PathBuf>,
    tree_cache: &std::collections::HashMap<PathBuf, Vec<(String, PathBuf)>>,
    tree_pending: &std::collections::HashSet<PathBuf>,
    nav_target: &mut Option<PathBuf>,
    spawn_target: &mut Option<PathBuf>,
    toggle_target: &mut Option<PathBuf>,
) {
    Self::render_tree_folder_node_custom(
        ui,
        name,
        path,
        default_icon,
        depth,
        active_path,
        theme,
        tree_expanded,
        tree_cache,
        tree_pending,
        nav_target,
        spawn_target,
        toggle_target,
        None::<fn(&mut egui::Ui)>,
    );
}

    fn render_left_sidebar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.set_width(ui.available_width());

        ui.horizontal_wrapped(|ui| {
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::DrivesAndTree, t.side_tree);
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::Favorites, t.side_favorites);
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::Search, t.side_search);
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::SmbNetwork, t.side_smb);
            ui.selectable_value(
                &mut self.sidebar_tab,
                SidebarTab::ClosedHistory,
                t.side_closed_history,
            );
        });
        ui.separator();

        // When multiple sub-windows exist, clearly display the target active window at the top of the sidebar
        // and allow switching target sub-window with a single click!
        if self.panes.len() > 1 {
            let active_idx = self.active_pane_index();
            let mut switch_active_id = None;
            ui.horizontal_wrapped(|ui| {
                let target_hint = if self.config.language == Language::ZhTw {
                    "🎯 目標視窗："
                } else {
                    "🎯 Target Window:"
                };
                ui.label(RichText::new(target_hint).small().strong());
                for (idx, p) in self.panes.iter().enumerate() {
                    let is_target = idx == active_idx;
                    let pill_txt = format!("[{}] {}", idx + 1, p.title);
                    if ui.selectable_label(is_target, pill_txt).clicked() {
                        switch_active_id = Some(p.id);
                    }
                }
            });
            if let Some(id) = switch_active_id {
                self.active_pane_id = id;
                for op in &mut self.panes {
                    if op.id != id {
                        op.selected_paths.clear();
                        op.last_clicked_idx = None;
                    }
                }
            }
            ui.separator();
        }

        egui::ScrollArea::vertical()
            .auto_shrink([false, false])
            .show(ui, |ui| {
                ui.set_width(ui.available_width());
                match self.sidebar_tab {
            SidebarTab::DrivesAndTree => {
                let active_idx = self.active_pane_index();
                let active_path = self.panes.get(active_idx).map(|p| p.current_path.clone());
                let active_path_ref = active_path.as_deref();
                let theme = self.config.theme;

                let mut nav_target: Option<PathBuf> = None;
                let mut spawn_target: Option<PathBuf> = None;
                let mut toggle_target: Option<PathBuf> = None;
                let mut do_sync = false;
                let mut do_collapse_all = false;
                let mut do_refresh = false;
                let mut do_probe_smb = false;

                // Quick Tools bar for Tree View
                ui.horizontal_wrapped(|ui| {
                    if ui.small_button(t.side_tree_sync).on_hover_text("將樹狀目錄展開至目前啟用視窗的所在資料夾").clicked() {
                        do_sync = true;
                    }
                    if ui.small_button(t.side_tree_collapse_all).clicked() {
                        do_collapse_all = true;
                    }
                    if ui.small_button("🔄").on_hover_text("清除樹狀目錄快取並重新載入").clicked() {
                        do_refresh = true;
                    }
                    ui.menu_button("⚙ 區塊顯示", |ui| {
                        let is_zh = self.config.language == Language::ZhTw;
                        if ui.checkbox(&mut self.config.show_sidebar_quick_access, if is_zh { "⭐ 常用資料夾" } else { "Quick Access" }).changed() {
                            let _ = self.config.save();
                        }
                        if ui.checkbox(&mut self.config.show_sidebar_this_pc, if is_zh { "💻 本機電腦" } else { "This PC" }).changed() {
                            let _ = self.config.save();
                        }
                        if ui.checkbox(&mut self.config.show_sidebar_network, if is_zh { "🌐 網路磁碟與共用" } else { "Network Shares" }).changed() {
                            let _ = self.config.save();
                        }
                        ui.separator();
                        if ui.checkbox(&mut self.config.hide_offline_network_shares, if is_zh { "🛡 隱藏離線網路磁碟 ([✖ 無法連線])" } else { "Hide Offline Shares" }).changed() {
                            let _ = self.config.save();
                        }
                        if !self.config.hidden_network_shares.is_empty() {
                            if ui.button(if is_zh { "🔄 恢復顯示所有隱藏網路磁碟" } else { "Unhide all network shares" }).clicked() {
                                self.config.hidden_network_shares.clear();
                                let _ = self.config.save();
                                ui.close_menu();
                            }
                        }
                        ui.separator();
                        if ui.button(if is_zh { "⚙ 管理常用資料夾..." } else { "⚙ Manage Quick Access..." }).clicked() {
                            self.show_quick_access_manager = true;
                            ui.close_menu();
                        }
                        if ui.button(if is_zh { "⚙ 管理網路磁碟與共用..." } else { "⚙ Manage Network Shares..." }).clicked() {
                            self.show_network_shares_manager = true;
                            ui.close_menu();
                        }
                    });
                });
                ui.separator();

                let is_zh = self.config.language == Language::ZhTw;
                let mut qa_to_hide = None;
                let mut qa_to_remove = None;
                let mut trigger_open_manager = false;

                // 1. ⭐ 常用資料夾 (Quick Access)
                if self.config.show_sidebar_quick_access {
                    ui.horizontal(|ui| {
                        ui.label(RichText::new(t.side_tree_quick_access).strong().color(Color32::from_rgb(0, 120, 215)));
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ui.small_button("👁").on_hover_text(if is_zh { "隱藏常用資料夾區塊" } else { "Hide section" }).clicked() {
                                self.config.show_sidebar_quick_access = false;
                                let _ = self.config.save();
                            }
                            if ui.small_button("⚙").on_hover_text(if is_zh { "管理常用資料夾（自訂顯示/隱藏/新增/刪除）" } else { "Manage Quick Access" }).clicked() {
                                trigger_open_manager = true;
                            }
                            if ui.small_button("➕").on_hover_text(if is_zh { "將目前所在目錄加入常用資料夾" } else { "Pin active folder" }).clicked() {
                                if let Some(p) = self.panes.get(self.active_pane_index()).map(|p| p.current_path.clone()) {
                                    let name = p.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_else(|| p.to_string_lossy().into_owned());
                                    self.add_quick_access_item(name, p.to_string_lossy().into_owned());
                                }
                            }
                        });
                    });

                    let mut visible_qa_count = 0;
                    for item in &self.config.quick_access_items {
                        if !item.is_visible {
                            continue;
                        }
                        visible_qa_count += 1;
                        let item_path = PathBuf::from(&item.path);
                        let item_id = item.id.clone();
                        let is_builtin = item.is_builtin;

                        Self::render_tree_folder_node_custom(
                            ui,
                            &item.name,
                            &item_path,
                            &item.icon,
                            0,
                            active_path_ref,
                            theme,
                            &self.tree_expanded,
                            &self.tree_cache,
                            &self.tree_pending,
                            &mut nav_target,
                            &mut spawn_target,
                            &mut toggle_target,
                            Some(|ui: &mut egui::Ui| {
                                if ui.button(if is_zh { "📂 在當前視窗開啟" } else { "📂 Open" }).clicked() {
                                    ui.close_menu();
                                }
                                if ui.button(if is_zh { "➕ 在新視窗開啟" } else { "➕ Open in New Window" }).clicked() {
                                    ui.close_menu();
                                }
                                ui.separator();
                                if ui.button(if is_zh { "👁 隱藏此資料夾" } else { "👁 Hide" }).clicked() {
                                    qa_to_hide = Some(item_id.clone());
                                    ui.close_menu();
                                }
                                if !is_builtin {
                                    if ui.button(if is_zh { "🗑 從常用資料夾刪除" } else { "🗑 Delete" }).clicked() {
                                        qa_to_remove = Some(item_id.clone());
                                        ui.close_menu();
                                    }
                                }
                                ui.separator();
                                if ui.button(if is_zh { "⚙ 管理常用資料夾..." } else { "⚙ Manage Quick Access..." }).clicked() {
                                    trigger_open_manager = true;
                                    ui.close_menu();
                                }
                            }),
                        );
                    }

                    if visible_qa_count == 0 {
                        ui.horizontal(|ui| {
                            ui.label(RichText::new(if is_zh { "（無顯示中的常用資料夾）" } else { "(No visible items)" }).small().color(Color32::GRAY));
                            if ui.small_button(if is_zh { "⚙ 開啟管理" } else { "⚙ Manage" }).clicked() {
                                trigger_open_manager = true;
                            }
                        });
                    }

                    if let Some(id) = qa_to_hide {
                        if let Some(item) = self.config.quick_access_items.iter_mut().find(|it| it.id == id) {
                            item.is_visible = false;
                            let _ = self.config.save();
                        }
                    }
                    if let Some(id) = qa_to_remove {
                        self.remove_quick_access_item(&id);
                    }

                    ui.add_space(8.0);
                    ui.separator();
                }

                if trigger_open_manager {
                    self.show_quick_access_manager = true;
                }

                // 2. 💻 本機磁碟 (This PC / Local Drives)
                if self.config.show_sidebar_this_pc {
                    let is_this_pc_active = active_path_ref
                        .map(crate::fs_ops::is_this_pc_path)
                        .unwrap_or(false);
                    ui.horizontal(|ui| {
                        let pc_resp = ui.selectable_label(
                            is_this_pc_active,
                            RichText::new(t.side_tree_this_pc).strong().color(Color32::from_rgb(0, 120, 215)),
                        );
                        if pc_resp.clicked() {
                            nav_target = Some(PathBuf::from(crate::fs_ops::THIS_PC_PATH));
                        }
                        pc_resp.context_menu(|ui| {
                            if ui.button(if is_zh { "📂 開啟本機電腦" } else { "📂 Open This PC" }).clicked() {
                                nav_target = Some(PathBuf::from(crate::fs_ops::THIS_PC_PATH));
                                ui.close_menu();
                            }
                            if ui.button(if is_zh { "🗔 在新視窗開啟" } else { "🗔 Open in New Window" }).clicked() {
                                spawn_target = Some(PathBuf::from(crate::fs_ops::THIS_PC_PATH));
                                ui.close_menu();
                            }
                        });
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ui.small_button("👁").on_hover_text(if is_zh { "隱藏本機電腦區塊" } else { "Hide section" }).clicked() {
                                self.config.show_sidebar_this_pc = false;
                                let _ = self.config.save();
                            }
                        });
                    });
                    let disks = self.sys_disks.clone();
                    for (label, mount, avail, total) in &disks {
                        let disk_icon = "🖴";
                        let tip = format!("{} (可用 {} / 共 {})", label, format_size(*avail), format_size(*total));
                        let _ = tip;
                        Self::render_tree_folder_node(
                            ui,
                            label,
                            mount,
                            disk_icon,
                            0,
                            active_path_ref,
                            theme,
                            &self.tree_expanded,
                            &self.tree_cache,
                            &self.tree_pending,
                            &mut nav_target,
                            &mut spawn_target,
                            &mut toggle_target,
                        );
                    }
                    ui.add_space(8.0);
                    ui.separator();
                }

                // 3. 🌐 網路磁碟與遠端資料夾 (Network & Remote Shares)
                let mut share_to_hide = None;
                let mut trigger_open_network_manager = false;
                if self.config.show_sidebar_network {
                    ui.horizontal(|ui| {
                        ui.label(RichText::new(t.side_tree_network).strong().color(Color32::from_rgb(0, 120, 215)));
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ui.small_button("👁").on_hover_text(if is_zh { "隱藏網路磁碟區塊" } else { "Hide section" }).clicked() {
                                self.config.show_sidebar_network = false;
                                let _ = self.config.save();
                            }
                            if ui.small_button("⚙").on_hover_text(if is_zh { "管理網路磁碟（自訂勾選顯示/隱藏）" } else { "Manage Network Shares" }).clicked() {
                                trigger_open_network_manager = true;
                            }
                            let shield_text = if self.config.hide_offline_network_shares {
                                RichText::new("🛡 已隱藏離線").color(Color32::from_rgb(0, 180, 120)).small()
                            } else {
                                RichText::new("🛡 隱藏離線").small()
                            };
                            if ui.small_button(shield_text).on_hover_text(if is_zh { "切換是否隱藏無法連線的離線網路磁碟" } else { "Toggle hiding offline network shares" }).clicked() {
                                self.config.hide_offline_network_shares = !self.config.hide_offline_network_shares;
                                let _ = self.config.save();
                            }
                            if ui.small_button("🔄").on_hover_text(t.side_refresh_tip).clicked() {
                                do_refresh = true;
                            }
                        });
                    });

                    if self.is_discovering_remotes {
                        ui.label(RichText::new(t.side_reading_remotes).small().color(Color32::from_rgb(200, 140, 0)));
                    }

                    let sys_smbs = self.system_smb_shares.clone();
                    let usr_smbs = self.config.smb_bookmarks.clone();
                    let mut rendered_smb_count = 0;

                    for smb in sys_smbs.iter().chain(usr_smbs.iter()) {
                        let is_offline = matches!(smb.status, SmbStatus::Offline(_));
                        if is_offline && self.config.hide_offline_network_shares {
                            continue;
                        }
                        if self.config.hidden_network_shares.contains(&smb.unc_or_mount_path) {
                            continue;
                        }
                        rendered_smb_count += 1;
                        let smb_path = PathBuf::from(&smb.unc_or_mount_path);
                        let display_title = match &smb.status {
                            SmbStatus::Online(_) => smb.name.clone(),
                            SmbStatus::Offline(_) => format!("{} [✖ 無法連線]", smb.name),
                            SmbStatus::Probing | SmbStatus::Unknown => format!("{} [偵測中...]", smb.name),
                        };
                        let unc_path_clone = smb.unc_or_mount_path.clone();

                        ui.horizontal(|ui| {
                            draw_smb_status_icon(ui, &smb.status);
                            if is_offline {
                                let label_resp = ui.selectable_label(
                                    false,
                                    RichText::new(&display_title).color(Color32::from_rgb(240, 100, 100)),
                                );
                                if label_resp.clicked() {
                                    do_probe_smb = true;
                                }
                                label_resp.context_menu(|ui| {
                                    if ui.button(if is_zh { "🔄 重新偵測此連線" } else { "Re-probe connection" }).clicked() {
                                        do_probe_smb = true;
                                        ui.close_menu();
                                    }
                                    if ui.button(if is_zh { "👁 隱藏此網路磁碟" } else { "Hide this share" }).clicked() {
                                        share_to_hide = Some(unc_path_clone.clone());
                                        ui.close_menu();
                                    }
                                    ui.separator();
                                    if ui.button(if is_zh { "⚙ 管理網路磁碟顯示..." } else { "⚙ Manage Network Shares..." }).clicked() {
                                        trigger_open_network_manager = true;
                                        ui.close_menu();
                                    }
                                });
                            } else {
                                Self::render_tree_folder_node_custom(
                                    ui,
                                    &display_title,
                                    &smb_path,
                                    "🌐",
                                    0,
                                    active_path_ref,
                                    theme,
                                    &self.tree_expanded,
                                    &self.tree_cache,
                                    &self.tree_pending,
                                    &mut nav_target,
                                    &mut spawn_target,
                                    &mut toggle_target,
                                    Some(|ui: &mut egui::Ui| {
                                        if ui.button(if is_zh { "📂 開啟" } else { "Open" }).clicked() {
                                            ui.close_menu();
                                        }
                                        if ui.button(if is_zh { "➕ 在新視窗開啟" } else { "Open in New Window" }).clicked() {
                                            ui.close_menu();
                                        }
                                        ui.separator();
                                        if ui.button(if is_zh { "👁 隱藏此網路磁碟" } else { "Hide this share" }).clicked() {
                                            share_to_hide = Some(unc_path_clone.clone());
                                            ui.close_menu();
                                        }
                                        ui.separator();
                                        if ui.button(if is_zh { "⚙ 管理網路磁碟顯示..." } else { "⚙ Manage Network Shares..." }).clicked() {
                                            trigger_open_network_manager = true;
                                            ui.close_menu();
                                        }
                                    }),
                                );
                            }
                        });
                    }

                    if let Some(path_to_hide) = share_to_hide {
                        if !self.config.hidden_network_shares.contains(&path_to_hide) {
                            self.config.hidden_network_shares.push(path_to_hide);
                            let _ = self.config.save();
                        }
                    }

                    if rendered_smb_count == 0 {
                        let has_hidden = !self.config.hidden_network_shares.is_empty();
                        let msg = if has_hidden {
                            if is_zh { format!("（部分或全部網路磁碟已被隱藏，共 {} 個）", self.config.hidden_network_shares.len()) } else { "(Shares hidden)".to_string() }
                        } else if self.config.hide_offline_network_shares {
                            if is_zh { "（離線網路磁碟已隱藏，點擊上方「🛡 已隱藏離線」可恢復顯示）".to_string() } else { "(Offline shares hidden)".to_string() }
                        } else {
                            if is_zh { "目前未偵測到遠端資料夾".to_string() } else { "No remote shares found".to_string() }
                        };
                        ui.horizontal(|ui| {
                            ui.label(RichText::new(msg).small().color(Color32::GRAY));
                            if ui.small_button(if is_zh { "⚙ 開啟管理" } else { "⚙ Manage" }).clicked() {
                                trigger_open_network_manager = true;
                            }
                        });
                    }

                    if trigger_open_network_manager {
                        self.show_network_shares_manager = true;
                    }
                }

                // Apply action flags
                if do_sync {
                    self.sync_tree_to_active_folder();
                }
                if do_collapse_all {
                    self.tree_expanded.clear();
                }
                if do_refresh {
                    self.tree_cache.clear();
                    self.tree_pending.clear();
                    self.refresh_system_remote_folders();
                }
                if do_probe_smb {
                    self.probe_all_smb();
                }

                // Apply collected navigation actions
                if let Some(target) = nav_target {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get_mut(idx) {
                        p.navigate_to(target, true);
                    }
                }
                if let Some(target) = spawn_target {
                    self.spawn_new_pane(target);
                }
                if let Some(target) = toggle_target {
                    self.request_expand_tree_path(&target);
                }
            }
            SidebarTab::Search => {
                let is_zh = self.config.language == Language::ZhTw;

                ui.horizontal(|ui| {
                    ui.label(RichText::new(if is_zh { "🔍 檔案搜尋" } else { "🔍 File Search" }).strong().heading());
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.small_button(if is_zh { "📁 樹狀目錄" } else { "📁 Folder Tree" }).on_hover_text("返回資料夾樹狀目錄").clicked() {
                            self.sidebar_tab = SidebarTab::DrivesAndTree;
                        }
                    });
                });
                ui.separator();

                // 1. Search Query Input (搜尋的檔案名稱)
                ui.label(RichText::new(if is_zh { "搜尋的檔案名稱:" } else { "Search file name:" }).strong());
                let q_edit = egui::TextEdit::singleline(&mut self.deep_search_query)
                    .hint_text(if is_zh { "輸入檔名或關鍵字 (例如: min, *.txt, report)" } else { "e.g. min, *.txt, report" })
                    .desired_width(ui.available_width() - 8.0);
                let q_resp = ui.add(q_edit);
                if self.focus_search_input {
                    q_resp.request_focus();
                    self.focus_search_input = false;
                }

                // 2. Content Grep Input (📄 內文包含)
                ui.add_space(2.0);
                ui.label(if is_zh { "📄 內文包含 (選填):" } else { "📄 Content grep (optional):" });
                let grep_resp = ui.add(
                    egui::TextEdit::singleline(&mut self.deep_search_grep)
                        .hint_text(if is_zh { "搜尋檔案內部文字 (選填)" } else { "Search text inside files" })
                        .desired_width(ui.available_width() - 8.0),
                );

                ui.add_space(6.0);

                // 3. Search and Stop Action Buttons
                ui.horizontal(|ui| {
                    let search_btn = ui.add_sized(
                        [90.0, 26.0],
                        egui::Button::new(
                            RichText::new(if is_zh { "🔍 搜尋" } else { "🔍 Search" })
                                .strong()
                                .color(Color32::WHITE),
                        )
                        .fill(Color32::from_rgb(0, 120, 215)),
                    );
                    let stop_btn = ui.add_sized(
                        [70.0, 26.0],
                        egui::Button::new(if is_zh { "⏹ 中止" } else { "⏹ Stop" }),
                    );

                    let trigger = ((q_resp.lost_focus() || grep_resp.lost_focus())
                        && ui.input(|i| i.key_pressed(egui::Key::Enter)))
                        || search_btn.clicked();

                    if trigger {
                        self.execute_start_search();
                    }

                    if stop_btn.clicked() && self.deep_search_running {
                        self.deep_search_cancel.store(true, std::sync::atomic::Ordering::Relaxed);
                        self.deep_search_running = false;
                    }
                });

                ui.add_space(6.0);
                ui.separator();

                // 4. MDIE Checkbox Options (MDIE 條件勾選)
                ui.label(RichText::new(if is_zh { "搜尋條件 (MDIE 條件勾選):" } else { "Search Options (MDIE):" }).strong());
                ui.checkbox(&mut self.search_subdirs, if is_zh { "子目錄也要搜尋" } else { "Search subfolders" });
                ui.checkbox(&mut self.search_wildcard, if is_zh { "以萬用字元搜尋 (*,?)" } else { "Use wildcards (*,?)" });
                ui.checkbox(&mut self.search_case_sensitive, if is_zh { "區分大小寫" } else { "Match case" });
                ui.checkbox(&mut self.search_include_hidden, if is_zh { "隱藏的資料夾也要搜尋" } else { "Include hidden folders" });
                ui.checkbox(&mut self.search_include_system, if is_zh { "系統資料夾也要搜尋" } else { "Include system folders" });

                ui.add_space(6.0);
                ui.separator();

                // 5. Search Scope (搜尋範圍)
                ui.label(RichText::new(if is_zh { "搜尋範圍:" } else { "Search Scope:" }).strong());
                let active_dir = {
                    let idx = self.active_pane_index();
                    self.panes.get(idx).map(|p| p.current_path.clone()).unwrap_or_else(|| PathBuf::from("."))
                };
                let active_dir_s = active_dir.to_string_lossy();

                ui.radio_value(
                    &mut self.search_scope_mode,
                    crate::app::SearchScopeMode::ActivePane,
                    if is_zh { "搜尋作用中的分頁" } else { "Active tab directory" },
                );
                if self.search_scope_mode == crate::app::SearchScopeMode::ActivePane {
                    ui.label(
                        RichText::new(format!("  ↳ {}", active_dir_s))
                            .small()
                            .color(Color32::from_rgb(0, 110, 200)),
                    );
                }

                ui.radio_value(
                    &mut self.search_scope_mode,
                    crate::app::SearchScopeMode::AllPanes,
                    if is_zh { "搜尋全部分頁" } else { "All open tabs" },
                );

                ui.radio_value(
                    &mut self.search_scope_mode,
                    crate::app::SearchScopeMode::Custom,
                    if is_zh { "自訂目錄路徑" } else { "Custom directory" },
                );
                if self.search_scope_mode == crate::app::SearchScopeMode::Custom {
                    ui.horizontal(|ui| {
                        ui.add(
                            egui::TextEdit::singleline(&mut self.search_custom_path)
                                .hint_text(if is_zh { "路徑..." } else { "Path..." })
                                .desired_width(ui.available_width() - 36.0),
                        );
                        if ui.small_button("🎯").on_hover_text("填入目前視窗路徑").clicked() {
                            self.search_custom_path = active_dir_s.into_owned();
                        }
                    });
                }

                ui.add_space(8.0);
                ui.separator();

                // 6. Search Status & Results Switcher
                if self.deep_search_running {
                    ui.horizontal(|ui| {
                        ui.spinner();
                        ui.label(
                            RichText::new(if is_zh {
                                format!(
                                    "正在搜尋中... 已掃描 {} 個項目，找到 {} 筆結果",
                                    self.deep_search_scanned,
                                    self.deep_search_results.len()
                                )
                            } else {
                                format!(
                                    "Scanning... {} items, found: {}",
                                    self.deep_search_scanned,
                                    self.deep_search_results.len()
                                )
                            })
                            .color(Color32::from_rgb(0, 120, 215)),
                        );
                    });
                } else if self.deep_search_scanned > 0 || !self.deep_search_results.is_empty() {
                    ui.label(
                        RichText::new(if is_zh {
                            format!(
                                "✓ 搜尋完成: 共 {} 筆結果 (耗時 {} ms)",
                                self.deep_search_results.len(),
                                self.deep_search_elapsed_ms
                            )
                        } else {
                            format!(
                                "✓ Finished: {} results ({} ms)",
                                self.deep_search_results.len(),
                                self.deep_search_elapsed_ms
                            )
                        })
                        .color(Color32::from_rgb(0, 150, 60))
                        .strong(),
                    );
                    if ui
                        .button(if is_zh {
                            "📂 檢視「檢索結果」分頁"
                        } else {
                            "📂 Focus Search Results Tab"
                        })
                        .clicked()
                    {
                        if let Some(p) = self.panes.iter().find(|p| p.is_search_results) {
                            self.active_pane_id = p.id;
                        }
                    }
                }
            }
            SidebarTab::Favorites => {
                ui.label(RichText::new(t.fav_groups_header).strong());
                if ui.button(t.fav_save_workspace_group).clicked() {
                    self.show_save_group_modal = true;
                }
                let groups = self.config.workspace_groups.clone();
                let mut remove_grp = None;
                for (gi, grp) in groups.iter().enumerate() {
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            if ui
                                .button(RichText::new(format!("📦 {}", grp.name)).strong())
                                .clicked()
                            {
                                self.panes.clear();
                                for (i, ps) in grp.paths.iter().enumerate() {
                                    self.panes
                                        .push(MdiChildPane::new(i + 1, PathBuf::from(ps)));
                                }
                                self.next_pane_id = self.panes.len() + 1;
                                self.active_pane_id = 1;
                                self.config.layout_mode = grp.layout;
                                self.sync_config_paths();
                            }
                            if ui.small_button("🗑").clicked() {
                                remove_grp = Some(gi);
                            }
                        });
                        ui.label(
                            RichText::new(format!("包含 {} 個並排視窗", grp.paths.len())).small(),
                        );
                    });
                }
                if let Some(gi) = remove_grp {
                    self.config.workspace_groups.remove(gi);
                    let _ = self.config.save();
                }

                ui.separator();
                ui.label(RichText::new(t.fav_folders_header).strong());
                if ui.button(t.fav_add_current_folder).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        self.config.favorite_folders.push((
                            p.title.clone(),
                            p.current_path.to_string_lossy().into_owned(),
                        ));
                        let _ = self.config.save();
                    }
                }
                let favs = self.config.favorite_folders.clone();
                let mut remove_fav = None;
                for (fi, (name, path_s)) in favs.iter().enumerate() {
                    ui.horizontal(|ui| {
                        if ui.button(format!("⭐ {}", name)).clicked() {
                            let idx = self.active_pane_index();
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(PathBuf::from(path_s), true);
                            }
                        }
                        if ui.small_button("➕").clicked() {
                            self.spawn_new_pane(PathBuf::from(path_s));
                        }
                        if ui.small_button("×").clicked() {
                            remove_fav = Some(fi);
                        }
                    });
                }
                if let Some(fi) = remove_fav {
                    self.config.favorite_folders.remove(fi);
                    let _ = self.config.save();
                }
            }
            SidebarTab::SmbNetwork => {
                ui.label(RichText::new(t.smb_explorer_header).strong());
                ui.label(
                    RichText::new(t.smb_safe_note)
                        .small()
                        .color(Color32::from_rgb(0, 130, 80)),
                );
                ui.horizontal(|ui| {
                    if ui.button(t.smb_refresh_btn).clicked() {
                        self.refresh_system_remote_folders();
                    }
                    if ui.button(t.smb_custom_add_btn).clicked() {
                        self.show_smb_dialog = true;
                    }
                });
                ui.separator();

                if self.is_discovering_remotes {
                    ui.label(
                        RichText::new(t.smb_reading_bg)
                            .small()
                            .color(Color32::from_rgb(200, 140, 0)),
                    );
                }
                let sys_smbs = self.system_smb_shares.clone();
                if sys_smbs.is_empty() && !self.is_discovering_remotes {
                    ui.label(
                        RichText::new(t.smb_none_found)
                            .small()
                            .color(Color32::GRAY),
                    );
                }
                for smb in &sys_smbs {
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            draw_smb_status_icon(ui, &smb.status);
                            ui.label(RichText::new(&smb.name).strong());
                        });
                        ui.label(RichText::new(&smb.unc_or_mount_path).small().color(Color32::GRAY));
                        let is_zh = self.config.language == Language::ZhTw;
                        let (badge, col) = match &smb.status {
                            SmbStatus::Unknown => ((if is_zh { "⏳ 偵測中..." } else { "⏳ Checking..." }).to_string(), Color32::GRAY),
                            SmbStatus::Probing => (
                                (if is_zh { "⏳ 背景連線檢測中..." } else { "⏳ Probing connection..." }).to_string(),
                                Color32::from_rgb(220, 160, 20),
                            ),
                            SmbStatus::Online(ms) => (
                                if is_zh { format!("● 已連線 ({} ms)", ms) } else { format!("● Online ({} ms)", ms) },
                                Color32::from_rgb(35, 205, 90),
                            ),
                            SmbStatus::Offline(reason) => (
                                if is_zh { format!("✖ 無法連線: {}", reason) } else { format!("✖ Disconnected: {}", reason) },
                                Color32::from_rgb(240, 80, 80),
                            ),
                        };
                        ui.label(RichText::new(badge).color(col).small());
                        ui.horizontal(|ui| {
                            if ui.small_button(t.smb_btn_open).clicked() {
                                let idx = self.active_pane_index();
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.navigate_to(PathBuf::from(&smb.unc_or_mount_path), true);
                                }
                            }
                            if ui.small_button(t.smb_btn_new_window).clicked() {
                                self.spawn_new_pane(PathBuf::from(&smb.unc_or_mount_path));
                            }
                        });
                    });
                }

                if !self.config.smb_bookmarks.is_empty() {
                    ui.separator();
                    ui.label(RichText::new(t.smb_custom_header).strong());
                }
                let smbs = self.config.smb_bookmarks.clone();
                let mut remove_smb_idx = None;
                for (si, smb) in smbs.iter().enumerate() {
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            draw_smb_status_icon(ui, &smb.status);
                            ui.label(RichText::new(&smb.name).strong());
                            ui.with_layout(
                                egui::Layout::right_to_left(egui::Align::Center),
                                |ui| {
                                    if ui
                                        .small_button("×")
                                        .on_hover_text(if self.config.language == Language::ZhTw { "刪除此自訂連線書籤" } else { "Delete this bookmark" })
                                        .clicked()
                                    {
                                        remove_smb_idx = Some(si);
                                    }
                                },
                            );
                        });
                        ui.label(RichText::new(&smb.unc_or_mount_path).small().color(Color32::GRAY));
                        let is_zh = self.config.language == Language::ZhTw;
                        let (badge, col) = match &smb.status {
                            SmbStatus::Unknown => ((if is_zh { "⏳ 偵測中..." } else { "⏳ Checking..." }).to_string(), Color32::GRAY),
                            SmbStatus::Probing => (
                                (if is_zh { "⏳ 背景連線檢測中..." } else { "⏳ Probing connection..." }).to_string(),
                                Color32::from_rgb(220, 160, 20),
                            ),
                            SmbStatus::Online(ms) => (
                                if is_zh { format!("● 已連線 ({} ms)", ms) } else { format!("● Online ({} ms)", ms) },
                                Color32::from_rgb(35, 205, 90),
                            ),
                            SmbStatus::Offline(reason) => (
                                if is_zh { format!("✖ 無法連線: {}", reason) } else { format!("✖ Disconnected: {}", reason) },
                                Color32::from_rgb(240, 80, 80),
                            ),
                        };
                        ui.label(RichText::new(badge).color(col).small());
                        ui.horizontal(|ui| {
                            if ui.small_button(t.smb_btn_open).clicked() {
                                let idx = self.active_pane_index();
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.navigate_to(PathBuf::from(&smb.unc_or_mount_path), true);
                                }
                            }
                            if ui.small_button(t.smb_btn_new_window).clicked() {
                                self.spawn_new_pane(PathBuf::from(&smb.unc_or_mount_path));
                            }
                        });
                    });
                }
                if let Some(si) = remove_smb_idx {
                    self.config.smb_bookmarks.remove(si);
                    let _ = self.config.save();
                }
            }
            SidebarTab::ClosedHistory => {
                let hist_header = if self.config.language == Language::ZhTw { "🕒 已關閉視窗恢復列表" } else { "🕒 Closed Windows History" };
                ui.label(RichText::new(hist_header).strong());
                let hist = self.config.closed_history.clone();
                if hist.is_empty() {
                    ui.label(t.fav_empty);
                }
                for path_s in hist {
                    if ui.button(format!("🔄 {}", path_s)).clicked() {
                        self.spawn_new_pane(PathBuf::from(path_s));
                    }
                }
            }
            }
        });
    }

    fn render_right_preview(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.set_width(ui.available_width());
        ui.heading(t.preview_title);
        ui.label(
            RichText::new(t.preview_heic_sandboxed)
                .small()
                .color(Color32::from_rgb(20, 140, 70)),
        );
        ui.separator();

        egui::ScrollArea::vertical()
            .auto_shrink([false, false])
            .show(ui, |ui| {
                ui.set_width(ui.available_width());
                match &self.preview_state {
            PreviewPayload::None => {
                ui.label(t.preview_no_selection);
            }
            PreviewPayload::Loading(p) => {
                ui.spinner();
                ui.label(format!("沙盒非同步讀取中: {}", p.to_string_lossy()));
            }
            PreviewPayload::Image {
                path,
                width,
                height,
                format_note,
                ..
            } => {
                ui.label(RichText::new(path.file_name().unwrap_or_default().to_string_lossy()).strong());
                ui.label(RichText::new(format_note).small().color(Color32::from_rgb(0, 120, 215)));
                ui.label(format!("預覽解析度: {} × {}", width, height));
                if let Some(ref tex) = self.preview_texture {
                    let avail_w = ui.available_width().max(120.0);
                    let aspect = (*height as f32) / ((*width as f32).max(1.0));
                    let base_w = avail_w;
                    let base_h = (avail_w * aspect).max(60.0);
                    let zoom = self.preview_image_zoom;
                    let disp_size = Vec2::new(base_w * zoom, base_h * zoom);

                    egui::ScrollArea::both()
                        .max_height(340.0)
                        .auto_shrink([false, false])
                        .show(ui, |ui| {
                            ui.image((tex.id(), disp_size));
                        });

                    ui.add_space(4.0);
                    ui.horizontal(|ui| {
                        let is_zh = self.config.language == Language::ZhTw;
                        ui.label(RichText::new(if is_zh { "🔍 縮放:" } else { "🔍 Zoom:" }).small().strong());
                        if ui.small_button("➖").on_hover_text(if is_zh { "縮小" } else { "Zoom out" }).clicked() {
                            self.preview_image_zoom = (self.preview_image_zoom - 0.25).max(0.25);
                        }
                        let mut zoom_pct = (self.preview_image_zoom * 100.0).round() as i32;
                        let slider = egui::Slider::new(&mut zoom_pct, 25..=400)
                            .suffix("%")
                            .show_value(true);
                        if ui.add(slider).changed() {
                            self.preview_image_zoom = (zoom_pct as f32) / 100.0;
                        }
                        if ui.small_button("➕").on_hover_text(if is_zh { "放大" } else { "Zoom in" }).clicked() {
                            self.preview_image_zoom = (self.preview_image_zoom + 0.25).min(4.0);
                        }
                        if (self.preview_image_zoom - 1.0).abs() > 0.01 {
                            if ui
                                .small_button("100%")
                                .on_hover_text(if is_zh { "重設為 100%" } else { "Reset to 100%" })
                                .clicked()
                            {
                                self.preview_image_zoom = 1.0;
                            }
                        }
                    });
                }
            }
            PreviewPayload::Text {
                path,
                content,
                encoding_note,
            } => {
                ui.label(RichText::new(path.file_name().unwrap_or_default().to_string_lossy()).strong());
                ui.label(
                    RichText::new(encoding_note)
                        .small()
                        .color(Color32::from_rgb(20, 140, 70)),
                );
                ui.separator();
                ui.add(
                    egui::TextEdit::multiline(&mut content.as_str())
                        .font(egui::TextStyle::Monospace)
                        .desired_width(f32::INFINITY),
                );
            }
            PreviewPayload::MetadataOnly { path, summary } => {
                ui.label(RichText::new(path.to_string_lossy()).strong());
                ui.separator();
                ui.label(summary);
            }
            }
        });
    }

    fn render_mdi_workspace(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        let workspace_rect = ui.available_rect_before_wrap();
        let n = self.panes.len().max(1);

        // If workspace_rect shifted (e.g. Left Sidebar or Right Preview toggled), keep floating windows aligned inside workspace!
        if let Some(prev_ws) = self.last_workspace_rect {
            let delta_min = workspace_rect.min - prev_ws.min;
            let size_diff = (workspace_rect.size() - prev_ws.size()).length_sq();
            if delta_min.length_sq() > 1.0 || size_diff > 4.0 {
                if self.config.layout_mode == WindowLayoutMode::Cascade {
                    self.needs_cascade_recalc = true;
                } else if self.config.layout_mode == WindowLayoutMode::MdiFree {
                    for p in &mut self.panes {
                        if let Some(r) = p.float_rect {
                            p.float_rect = Some(r.translate(delta_min));
                        }
                    }
                }
            }
        }
        self.last_workspace_rect = Some(workspace_rect);

        if self.needs_cascade_recalc && self.config.layout_mode == WindowLayoutMode::Cascade {
            self.recalculate_cascade_rects(workspace_rect);
        }

        // Calculate target rectangles for each MDI child window based on active layout mode
        let mut calculated_rects: Vec<(usize, Rect)> = Vec::with_capacity(n);

        match self.config.layout_mode {
            WindowLayoutMode::TabbedMaximized => {
                let active_idx = self.active_pane_index();
                calculated_rects.push((active_idx, workspace_rect));
            }
            WindowLayoutMode::TileHorizontally => {
                let col_w = workspace_rect.width() / (n as f32);
                for i in 0..n {
                    let r = Rect::from_min_size(
                        Pos2::new(
                            workspace_rect.min.x + (i as f32) * col_w,
                            workspace_rect.min.y,
                        ),
                        Vec2::new((col_w - 3.0).max(180.0), workspace_rect.height()),
                    );
                    self.panes[i].float_rect = Some(r);
                    calculated_rects.push((i, r));
                }
            }
            WindowLayoutMode::TileVertically => {
                let row_h = workspace_rect.height() / (n as f32);
                for i in 0..n {
                    let r = Rect::from_min_size(
                        Pos2::new(
                            workspace_rect.min.x,
                            workspace_rect.min.y + (i as f32) * row_h,
                        ),
                        Vec2::new(workspace_rect.width(), (row_h - 3.0).max(140.0)),
                    );
                    self.panes[i].float_rect = Some(r);
                    calculated_rects.push((i, r));
                }
            }
            WindowLayoutMode::TileGrid => {
                let cols = (n as f32).sqrt().ceil() as usize;
                let rows = (n + cols - 1) / cols;
                let cell_h = workspace_rect.height() / (rows as f32);
                for i in 0..n {
                    let r_idx = i / cols;
                    let c = i % cols;
                    let row_start = r_idx * cols;
                    let cols_in_this_row = (n - row_start).min(cols).max(1);
                    let cell_w = workspace_rect.width() / (cols_in_this_row as f32);
                    let r = Rect::from_min_size(
                        Pos2::new(
                            workspace_rect.min.x + (c as f32) * cell_w,
                            workspace_rect.min.y + (r_idx as f32) * cell_h,
                        ),
                        Vec2::new((cell_w - 3.0).max(120.0), (cell_h - 3.0).max(100.0)),
                    );
                    self.panes[i].float_rect = Some(r);
                    calculated_rects.push((i, r));
                }
            }
            WindowLayoutMode::Cascade | WindowLayoutMode::MdiFree => {
                let max_w = (workspace_rect.width() - 8.0).max(200.0);
                let max_h = (workspace_rect.height() - 8.0).max(140.0);
                for i in 0..n {
                    let default_offset = (i as f32) * 30.0;
                    let raw_rect = self.panes[i].float_rect.unwrap_or_else(|| {
                        Rect::from_min_size(
                            Pos2::new(
                                workspace_rect.min.x + 12.0 + default_offset,
                                workspace_rect.min.y + 12.0 + default_offset,
                            ),
                            Vec2::new(
                                (workspace_rect.width() * 0.72).max(320.0),
                                (workspace_rect.height() * 0.76).max(240.0),
                            ),
                        )
                    });
                    // Strictly clamp rect inside workspace_rect so it NEVER overlaps Sidebar or Top Toolbar!
                    let w = raw_rect.width().clamp(260.0_f32.min(max_w), max_w);
                    let h = raw_rect.height().clamp(180.0_f32.min(max_h), max_h);
                    let x = raw_rect.min.x.clamp(
                        workspace_rect.min.x + 4.0,
                        (workspace_rect.max.x - w - 4.0).max(workspace_rect.min.x + 4.0),
                    );
                    let y = raw_rect.min.y.clamp(
                        workspace_rect.min.y + 4.0,
                        (workspace_rect.max.y - h - 4.0).max(workspace_rect.min.y + 4.0),
                    );
                    let rect = Rect::from_min_size(Pos2::new(x, y), Vec2::new(w, h));
                    self.panes[i].float_rect = Some(rect);
                    calculated_rects.push((i, rect));
                }
                // In overlapping mode, render active window last so it appears on top!
                let active_id = self.active_pane_id;
                calculated_rects.sort_by_key(|(idx, _)| self.panes[*idx].id == active_id);
            }
        }

        let ctx = ui.ctx().clone();
        let pointer_pos = ctx.input(|i| i.pointer.latest_pos());
        let primary_down = ctx.input(|i| i.pointer.primary_down());
        let primary_released = ctx.input(|i| i.pointer.button_released(egui::PointerButton::Primary));
        let rmb_pressed = ctx.input(|i| i.pointer.button_pressed(egui::PointerButton::Secondary));
        let rmb_down = ctx.input(|i| i.pointer.secondary_down());
        let rmb_released = ctx.input(|i| i.pointer.button_released(egui::PointerButton::Secondary));

        let is_any_overlay_open = ctx.memory(|m| m.any_popup_open())
            || self.context_menu.is_some()
            || self.show_smb_dialog
            || self.show_network_shares_manager
            || self.show_gesture_dialog
            || self.show_about_dialog
            || self.show_save_group_modal
            || self.show_quick_access_manager
            || self.show_add_quick_access_modal
            || self.create_item_modal.is_some()
            || self.rename_modal.is_some()
            || self.properties_modal.is_some()
            || self.perm_delete_modal.is_some();

        let mut pane_to_close = None;
        let mut pane_to_clone = None;
        let mut pane_to_maximize = None;
        let mut newly_activated_id = None;
        let mut preview_req = None;
        let mut drop_transfer: Option<(Vec<PathBuf>, PathBuf, bool)> = None;
        let mut hovered_drop_target: Option<(PathBuf, String)> = None;
        let mut hovered_rmb_target: Option<(usize, Option<crate::fs_ops::FileEntry>)> = None;
        let mut switch_to_free_mode = false;

        for (order_idx, (pane_idx, rect)) in calculated_rects.iter().copied().enumerate() {
            let pane_id = self.panes[pane_idx].id;
            let is_active = pane_id == self.active_pane_id;
            let clip_rect = rect.intersect(workspace_rect);

            // Check if the mouse pointer is currently inside a window that is in front of this pane
            let pointer_occluded = pointer_pos
                .map(|pos| {
                    calculated_rects[order_idx + 1..]
                        .iter()
                        .any(|(_, front_r)| front_r.intersect(workspace_rect).contains(pos))
                })
                .unwrap_or(false);

            if let Some(pos) = pointer_pos {
                if clip_rect.contains(pos) && !pointer_occluded {
                    hovered_rmb_target = Some((pane_id, None));
                    if let Some((src_pane_id, _)) = &self.drag_payload {
                        if *src_pane_id != pane_id {
                            hovered_drop_target = Some((
                                self.panes[pane_idx].current_path.clone(),
                                self.panes[pane_idx].title.clone(),
                            ));
                        }
                    }
                }
            }

            // Use a child_ui on CentralPanel's registered LayerId so `ctx.layer_id_at(pointer_pos)`
            // matches `child_ui.layer_id()`, enabling mouse wheel scrolling and scrollbar dragging!
            let mut child_ui = ui.new_child(
                egui::UiBuilder::new()
                    .max_rect(rect)
                    .layout(egui::Layout::top_down(egui::Align::Min)),
            );
            child_ui.set_clip_rect(clip_rect);
            child_ui.set_max_size(rect.size());

            // Subtle drop shadow in Cascade / MdiFree mode
            if matches!(
                self.config.layout_mode,
                WindowLayoutMode::Cascade | WindowLayoutMode::MdiFree
            ) {
                child_ui
                    .painter()
                    .with_clip_rect(workspace_rect)
                    .rect_filled(
                        rect.translate(Vec2::new(4.0, 4.0)),
                        4.0,
                        Color32::from_black_alpha(55),
                    );
            }

            // Activate this pane when clicking anywhere inside its visible rect (if not occluded by a higher pane or popup overlay)
            let is_pointer_in_pane = !is_any_overlay_open
                && !pointer_occluded
                && pointer_pos
                    .map(|p| {
                        workspace_rect.contains(p)
                            && clip_rect.contains(p)
                            && ctx.layer_id_at(p) == Some(ui.layer_id())
                    })
                    .unwrap_or(false);
            if is_pointer_in_pane && ctx.input(|i| i.pointer.primary_pressed()) {
                newly_activated_id = Some(pane_id);
            }

            let is_drop_pane_target = !pointer_occluded
                && self
                    .drag_payload
                    .as_ref()
                    .map(|(src_id, _)| {
                        *src_id != pane_id
                            && pointer_pos.map(|p| clip_rect.contains(p)).unwrap_or(false)
                    })
                    .unwrap_or(false);

            let border_color = if is_drop_pane_target {
                Color32::from_rgb(0, 185, 90)
            } else if is_active {
                Color32::from_rgb(0, 120, 215)
            } else {
                Color32::from_gray(140)
            };

            let bg_fill = if self.config.theme == AppTheme::ModernDark {
                Color32::from_rgb(28, 30, 36)
            } else {
                Color32::WHITE
            };

            // Paint the pane background strictly inside `rect` (clipped to `clip_rect`) so it NEVER
            // stretches beyond `rect` even if inner table columns are wide!
            child_ui
                .painter()
                .with_clip_rect(clip_rect)
                .rect_filled(rect, 3.0, bg_fill);

            child_ui.scope(|ui| {
                ui.set_clip_rect(clip_rect);
                ui.set_max_size(rect.size());

                // 1. Classic MDIE Sub-Window Title Bar (draggable anywhere across the full bar to move window!)
                let title_bg = if is_active {
                    if self.config.theme == AppTheme::ClassicMdie {
                        Color32::from_rgb(185, 209, 234)
                    } else {
                        Color32::from_rgb(0, 102, 204)
                    }
                } else {
                    Color32::from_gray(215)
                };
                let title_fg = if is_active && self.config.theme != AppTheme::ClassicMdie {
                    Color32::WHITE
                } else {
                    Color32::BLACK
                };

                let title_bar_rect =
                    Rect::from_min_size(rect.min, Vec2::new(rect.width(), 25.0));
                let title_bar_clipped = title_bar_rect.intersect(clip_rect);
                ui.painter()
                    .with_clip_rect(clip_rect)
                    .rect_filled(title_bar_rect, 2.0, title_bg);

                // Make the ENTIRE 25px title bar interactable so clicking anywhere on it activates the window
                // and dragging anywhere on it moves the window (in Free/Cascade mode)!
                let title_bar_hit = ui.interact(
                    title_bar_clipped,
                    egui::Id::new(("pane_title_bar_hit", pane_id)),
                    Sense::click_and_drag(),
                );
                if !is_any_overlay_open && !pointer_occluded {
                    if title_bar_hit.clicked() || title_bar_hit.drag_started() {
                        newly_activated_id = Some(pane_id);
                    }
                }
                if title_bar_hit.dragged()
                    && !pointer_occluded
                    && self.config.layout_mode != WindowLayoutMode::TabbedMaximized
                {
                    newly_activated_id = Some(pane_id);
                    switch_to_free_mode = true;
                    let delta = title_bar_hit.drag_delta();
                    if let Some(ref mut r) = self.panes[pane_idx].float_rect {
                        let mut moved = r.translate(delta);
                        let w = moved.width();
                        let h = moved.height();
                        let max_x =
                            (workspace_rect.max.x - w).max(workspace_rect.min.x);
                        let max_y =
                            (workspace_rect.max.y - h).max(workspace_rect.min.y);
                        let nx = moved.min.x.clamp(workspace_rect.min.x, max_x);
                        let ny = moved.min.y.clamp(workspace_rect.min.y, max_y);
                        moved =
                            Rect::from_min_size(Pos2::new(nx, ny), Vec2::new(w, h));
                        *r = moved;
                    }
                }

                egui::Frame::none()
                    .inner_margin(egui::Margin::symmetric(6.0, 3.0))
                    .show(ui, |ui| {
                        ui.set_max_width((rect.width() - 12.0).max(60.0));
                        ui.horizontal(|ui| {
                            draw_finder_folder_widget(ui, 13.0, true, is_active);
                            let title_text = if rect.width() >= 480.0 {
                                format!(
                                    "[{}] {}  {}",
                                    pane_idx + 1,
                                    self.panes[pane_idx].title,
                                    t.win_drag_hint
                                )
                            } else {
                                format!("[{}] {}", pane_idx + 1, self.panes[pane_idx].title)
                            };
                            let title_resp = ui
                                .add(
                                    egui::Label::new(
                                        RichText::new(title_text).color(title_fg).strong(),
                                    )
                                    .truncate()
                                    .selectable(false)
                                    .sense(Sense::click_and_drag()),
                                )
                                .on_hover_cursor(egui::CursorIcon::Default)
                                .on_hover_text(t.win_drag_tip);

                            if (title_resp.clicked() || title_resp.drag_started())
                                && !pointer_occluded
                            {
                                newly_activated_id = Some(pane_id);
                            }

                            ui.with_layout(
                                egui::Layout::right_to_left(egui::Align::Center),
                                |ui| {
                                    if ui
                                        .button(RichText::new("✕").small())
                                        .on_hover_text(t.win_close_tip)
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        pane_to_close = Some(pane_id);
                                    }
                                    if ui
                                        .button(RichText::new("🗖").small())
                                        .on_hover_text(t.win_max_restore_tip)
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        pane_to_maximize = Some(pane_id);
                                    }
                                    if ui
                                        .button(RichText::new("📑").small())
                                        .on_hover_text(t.win_clone_tip)
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        pane_to_clone =
                                            Some(self.panes[pane_idx].current_path.clone());
                                    }
                                },
                            );
                        });
                    });

                // 2. Sub-Window Address Bar + Breadcrumb + Instant MDIE Search Bar
                ui.horizontal(|ui| {
                    ui.set_max_width((rect.width() - 8.0).max(80.0));
                    if ui.small_button("⬅").clicked() && !pointer_occluded {
                        newly_activated_id = Some(pane_id);
                        self.panes[pane_idx].go_back();
                    }
                    if ui.small_button("➡").clicked() && !pointer_occluded {
                        newly_activated_id = Some(pane_id);
                        self.panes[pane_idx].go_forward();
                    }
                    if ui.small_button("⬆").clicked() && !pointer_occluded {
                        newly_activated_id = Some(pane_id);
                        self.panes[pane_idx].go_up();
                    }
                    let rem_bar_w = (ui.available_width() - 78.0).max(80.0);
                    let addr_w = (rem_bar_w * 0.56).max(50.0);
                    let search_w = (rem_bar_w * 0.40).max(36.0);

                    if self.panes[pane_idx].is_search_results {
                        let total_cnt = self.panes[pane_idx].entries.len();
                        ui.horizontal(|ui| {
                            ui.label(
                                RichText::new(format!("🔍 檢索結果 (共 {} 筆)", total_cnt))
                                    .strong()
                                    .color(Color32::from_rgb(0, 110, 200)),
                            );
                            if ui.small_button("🔄 重新搜尋").on_hover_text("使用側邊欄條件重新執行搜尋").clicked() {
                                self.execute_start_search();
                            }
                        });
                    } else {
                        let addr_resp = ui.add(
                            egui::TextEdit::singleline(&mut self.panes[pane_idx].address_input)
                                .desired_width(addr_w),
                        );
                        if (addr_resp.has_focus() || addr_resp.gained_focus() || addr_resp.clicked())
                            && !pointer_occluded
                        {
                            newly_activated_id = Some(pane_id);
                        }
                        if addr_resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                            let raw_in = self.panes[pane_idx].address_input.trim().to_string();
                            let expanded = expand_env_vars(&raw_in);
                            self.panes[pane_idx].navigate_to(PathBuf::from(expanded), true);
                        }
                        if addr_resp.has_focus() && ui.input(|i| i.key_pressed(egui::Key::Escape)) {
                            addr_resp.surrender_focus();
                        }
                    }

                    // Per-pane Instant Filter / Best Match Search Box
                    let search_resp = ui.add(
                        egui::TextEdit::singleline(&mut self.panes[pane_idx].search_query)
                            .hint_text(t.search_placeholder)
                            .desired_width(search_w),
                    );
                    if (search_resp.has_focus()
                        || search_resp.gained_focus()
                        || search_resp.changed()
                        || search_resp.clicked())
                        && !pointer_occluded
                    {
                        newly_activated_id = Some(pane_id);
                    }
                    if search_resp.changed() {
                        let show_hidden = self.config.show_hidden;
                        self.panes[pane_idx].apply_sort_and_filter(show_hidden);
                    }
                    if search_resp.has_focus() && ui.input(|i| i.key_pressed(egui::Key::Escape)) {
                        search_resp.surrender_focus();
                    }

                    egui::ComboBox::from_id_salt(format!("smode_{}", pane_id))
                        .width(64.0)
                        .selected_text(match self.panes[pane_idx].search_mode {
                            PaneSearchMode::InstantFilter => t.search_mode_filter,
                            PaneSearchMode::BestMatchJump => t.search_mode_best_match,
                            PaneSearchMode::SelectMatching => t.search_mode_filter,
                        })
                        .show_ui(ui, |ui| {
                            let show_hidden = self.config.show_hidden;
                            if ui
                                .selectable_value(
                                    &mut self.panes[pane_idx].search_mode,
                                    PaneSearchMode::InstantFilter,
                                    t.search_mode_filter,
                                )
                                .clicked()
                                || ui
                                    .selectable_value(
                                        &mut self.panes[pane_idx].search_mode,
                                        PaneSearchMode::BestMatchJump,
                                        t.search_mode_best_match,
                                    )
                                    .clicked()
                            {
                                self.panes[pane_idx].apply_sort_and_filter(show_hidden);
                            }
                        });
                });

                // 3. Error / Disconnected SMB Protection Banner (if any)
                if let Some(ref err) = self.panes[pane_idx].error_banner.clone() {
                    egui::Frame::none()
                        .fill(if self.config.theme == AppTheme::ModernDark {
                            Color32::from_rgb(70, 24, 28)
                        } else {
                            Color32::from_rgb(255, 232, 232)
                        })
                        .inner_margin(egui::Margin::symmetric(6.0, 4.0))
                        .show(ui, |ui| {
                            ui.set_max_width((rect.width() - 12.0).max(80.0));
                            ui.horizontal_wrapped(|ui| {
                                draw_smb_status_icon(ui, &SmbStatus::Offline(String::new()));
                                ui.label(
                                    RichText::new(err)
                                        .color(if self.config.theme == AppTheme::ModernDark {
                                            Color32::from_rgb(255, 165, 165)
                                        } else {
                                            Color32::from_rgb(185, 20, 20)
                                        })
                                        .strong(),
                                );
                                if ui.small_button("✕ 關閉提示").clicked() {
                                    self.panes[pane_idx].error_banner = None;
                                }
                            });
                        });
                }

                // 4. Drop Target Zone for Cross-Window File Comparison & Move/Copy
                if let Some((src_pane_id, dragged_paths)) = self.drag_payload.clone() {
                    if src_pane_id != pane_id {
                        egui::Frame::none()
                            .fill(Color32::from_rgb(220, 242, 255))
                            .inner_margin(3.0)
                            .show(ui, |ui| {
                                ui.horizontal(|ui| {
                                    ui.label(
                                        RichText::new(format!(
                                            "📥 放開滑鼠左鍵直接移動至此 (按住 Ctrl/Alt 放開為複製) [{} 個項目]:",
                                            dragged_paths.len()
                                        ))
                                        .color(Color32::from_rgb(0, 90, 180))
                                        .strong(),
                                    );
                                    if ui.small_button("📋 複製到此處").clicked() {
                                        drop_transfer = Some((
                                            dragged_paths.clone(),
                                            self.panes[pane_idx].current_path.clone(),
                                            false,
                                        ));
                                    }
                                    if ui.small_button("✂ 移動到此處").clicked() {
                                        drop_transfer = Some((
                                            dragged_paths.clone(),
                                            self.panes[pane_idx].current_path.clone(),
                                            true,
                                        ));
                                    }
                                });
                            });
                    }
                }

                // 5. High-Speed Virtualized File Table (handles 100,000+ files with zero lag)
                let show_hidden = self.config.show_hidden;
                let scroll_req = self.panes[pane_idx].scroll_request;
                self.panes[pane_idx].scroll_request = ScrollRequest::None;

                // Temporarily suppress scroll delta for occluded background windows so only the topmost window scrolls
                let saved_scroll_delta = if pointer_occluded {
                    ctx.input_mut(|i| {
                        let d = i.smooth_scroll_delta;
                        i.smooth_scroll_delta = Vec2::ZERO;
                        d
                    })
                } else {
                    Vec2::ZERO
                };

                // Progress / Loading banner while reading directory contents
                if self.panes[pane_idx].is_loading {
                    egui::Frame::none()
                        .fill(if self.config.theme == AppTheme::ModernDark {
                            Color32::from_rgb(22, 32, 48)
                        } else {
                            Color32::from_rgb(230, 242, 255)
                        })
                        .inner_margin(egui::Margin::symmetric(8.0, 4.0))
                        .show(ui, |ui| {
                            ui.horizontal(|ui| {
                                ui.spinner();
                                let is_zh = self.config.language == Language::ZhTw;
                                let load_txt = if is_zh {
                                    "⚡ 正在極速載入目錄清單中..."
                                } else {
                                    "⚡ Loading directory contents..."
                                };
                                ui.label(RichText::new(load_txt).strong().color(Color32::from_rgb(0, 120, 215)));
                            });
                        });
                }

                let table_top = (ui.cursor().min.y + 2.0).min(rect.max.y - 30.0);
                let table_rect = Rect::from_min_max(
                    Pos2::new(rect.min.x + 4.0, table_top),
                    Pos2::new(rect.max.x - 5.0, (rect.max.y - 6.0).max(table_top + 30.0)),
                );
                let table_clip = table_rect.intersect(clip_rect);
                if is_pointer_in_pane
                    && pointer_pos.map(|p| table_clip.contains(p)).unwrap_or(false)
                    && ctx.input(|i| i.pointer.primary_pressed() || i.pointer.secondary_pressed())
                {
                    if let Some(fid) = ctx.memory(|m| m.focused()) {
                        ctx.memory_mut(|m| m.surrender_focus(fid));
                    }
                }
                let avail_w = table_rect.width().max(160.0);
                let avail_h = table_rect.height().max(40.0);
                let list_font_size = self.config.file_list_font_size;
                let header_h = (list_font_size * 1.5).clamp(20.0, 32.0);
                let row_h = (list_font_size * 1.65).clamp(20.0, 42.0);
                let cell_h = (row_h - 2.0).max(18.0);
                let body_h = (avail_h - header_h - 2.0).max(24.0);
                let col_avail_w = (avail_w - 18.0).max(140.0);
                let width_bucket = (avail_w / 60.0) as i32;

                let mut table_ui = ui.new_child(
                    egui::UiBuilder::new()
                        .max_rect(table_rect)
                        .layout(egui::Layout::top_down(egui::Align::Min)),
                );
                table_ui.set_clip_rect(table_clip);
                table_ui.set_max_size(Vec2::new(avail_w, avail_h));

                // Ensure high-contrast, always-visible right scrollbar track and draggable thumb
                {
                    let vis = table_ui.visuals_mut();
                    if self.config.theme == AppTheme::ModernDark {
                        vis.extreme_bg_color = Color32::from_rgb(18, 20, 26);
                        vis.widgets.inactive.bg_fill = Color32::from_rgb(95, 105, 125);
                        vis.widgets.hovered.bg_fill = Color32::from_rgb(135, 150, 180);
                        vis.widgets.active.bg_fill = Color32::from_rgb(60, 150, 240);
                    } else {
                        vis.extreme_bg_color = Color32::from_rgb(232, 236, 244);
                        vis.widgets.inactive.bg_fill = Color32::from_rgb(165, 176, 194);
                        vis.widgets.hovered.bg_fill = Color32::from_rgb(110, 145, 195);
                        vis.widgets.active.bg_fill = Color32::from_rgb(0, 115, 215);
                    }
                }

                let is_this_pc = crate::fs_ops::is_this_pc_path(&self.panes[pane_idx].current_path);
                let is_search = self.panes[pane_idx].is_search_results;
                let view_mode = self.panes[pane_idx].view_mode;
                if is_this_pc {
                    self.render_this_pc_pane_view(
                        &mut table_ui,
                        pane_idx,
                        pane_id,
                        table_rect,
                        table_clip,
                        pointer_occluded,
                        &mut newly_activated_id,
                        &mut hovered_rmb_target,
                    );
                } else {
                    let has_thumb_slider = view_mode == PaneViewMode::Thumbnails;
                    let slider_h = if has_thumb_slider && table_rect.height() > 70.0 {
                        26.0
                    } else {
                        0.0
                    };
                    let content_rect = Rect::from_min_max(
                        table_rect.min,
                        Pos2::new(table_rect.max.x, (table_rect.max.y - slider_h).max(table_rect.min.y + 24.0)),
                    );
                    if view_mode != PaneViewMode::Details {
                        self.render_pane_alt_view(
                            &mut table_ui,
                            pane_idx,
                            pane_id,
                            content_rect,
                            table_clip,
                            pointer_occluded,
                            &mut newly_activated_id,
                            &mut hovered_rmb_target,
                            &mut preview_req,
                        );
                    } else {
                        table_ui.push_id(("pane_table", pane_id, width_bucket), |ui| {
                            ui.set_clip_rect(table_clip);
                            ui.set_max_size(Vec2::new(avail_w, avail_h));

                    let mut active_cols: Vec<PaneColumn> = self
                        .config
                        .column_order
                        .iter()
                        .copied()
                        .filter(|c| is_search || *c != PaneColumn::Directory)
                        .collect();
                    if is_search && !active_cols.contains(&PaneColumn::Directory) {
                        if let Some(pos) = active_cols.iter().position(|&c| c == PaneColumn::Name) {
                            active_cols.insert(pos + 1, PaneColumn::Directory);
                        } else {
                            active_cols.insert(0, PaneColumn::Directory);
                        }
                    }

                    let cur_drag_col = self.drag_col_source;
                    let mut new_drag_source = None;
                    let mut drag_swap = None;
                    let mut sort_target = None;
                    let cur_col = self.panes[pane_idx].sort_col;
                    let cur_asc = self.panes[pane_idx].sort_asc;

                    let mut table = TableBuilder::new(ui)
                        .striped(true)
                        .resizable(true)
                        .vscroll(true)
                        .auto_shrink([false, false])
                        .drag_to_scroll(false)
                        .cell_layout(egui::Layout::left_to_right(egui::Align::Center))
                        .min_scrolled_height(body_h)
                        .max_scroll_height(body_h);

                    for (c_idx, &col) in active_cols.iter().enumerate() {
                        let is_last = c_idx + 1 == active_cols.len();
                        if is_last {
                            let min_w = match col {
                                PaneColumn::Name => 60.0,
                                PaneColumn::Directory => 70.0,
                                PaneColumn::Size => 40.0,
                                PaneColumn::Type => 42.0,
                                PaneColumn::Modified => 50.0,
                            };
                            table = table.column(Column::remainder().at_least(min_w).clip(true));
                        } else {
                            let (init_w, min_w) = match col {
                                PaneColumn::Name => {
                                    let p = if is_search { 0.28 } else { 0.43 };
                                    ((col_avail_w * p).clamp(70.0, 320.0), 60.0)
                                }
                                PaneColumn::Directory => {
                                    ((col_avail_w * 0.35).clamp(90.0, 360.0), 70.0)
                                }
                                PaneColumn::Size => {
                                    let p = if is_search { 0.12 } else { 0.16 };
                                    ((col_avail_w * p).clamp(42.0, 95.0), 40.0)
                                }
                                PaneColumn::Type => {
                                    let p = if is_search { 0.11 } else { 0.17 };
                                    ((col_avail_w * p).clamp(45.0, 110.0), 42.0)
                                }
                                PaneColumn::Modified => {
                                    let p = if is_search { 0.14 } else { 0.24 };
                                    ((col_avail_w * p).clamp(55.0, 160.0), 50.0)
                                }
                            };
                            table = table.column(Column::initial(init_w).at_least(min_w).clip(true));
                        }
                    }

                    match scroll_req {
                        ScrollRequest::Top => {
                            table = table.scroll_to_row(0, Some(egui::Align::TOP));
                        }
                        ScrollRequest::Bottom => {
                            let last = self.panes[pane_idx]
                                .filtered_indices
                                .len()
                                .saturating_sub(1);
                            table = table.scroll_to_row(last, Some(egui::Align::BOTTOM));
                        }
                        ScrollRequest::Row(r) => {
                            table = table.scroll_to_row(r, Some(egui::Align::Center));
                        }
                        ScrollRequest::None => {}
                    }

                    table
                        .header(header_h, |mut header| {
                            for &col in &active_cols {
                                let arrow = if cur_col == col.sort_column() {
                                    if cur_asc { " ▲" } else { " ▼" }
                                } else {
                                    ""
                                };
                                let title = match col {
                                    PaneColumn::Name => format!("{}{}", t.col_name, arrow),
                                    PaneColumn::Directory => format!("{}{}", t.col_folder, arrow),
                                    PaneColumn::Size => format!("{}{}", t.col_size, arrow),
                                    PaneColumn::Type => format!("{}{}", t.col_type, arrow),
                                    PaneColumn::Modified => format!("{}{}", t.col_modified, arrow),
                                };

                                header.col(|ui| {
                                    let is_dragging_this = cur_drag_col == Some(col);
                                    let btn_text = RichText::new(&title)
                                        .size(list_font_size.clamp(11.0, 16.0))
                                        .strong();
                                    let mut btn = egui::Button::new(btn_text);
                                    if is_dragging_this {
                                        btn = btn.fill(Color32::from_rgb(215, 230, 250));
                                    }
                                    let resp = ui.add(btn.sense(Sense::click_and_drag()));
                                    let resp = resp.on_hover_cursor(if is_dragging_this {
                                        egui::CursorIcon::Grabbing
                                    } else {
                                        egui::CursorIcon::Grab
                                    });

                                    if resp.drag_started() {
                                        new_drag_source = Some(col);
                                    }

                                    let is_right_half = ui.input(|i| {
                                        i.pointer
                                            .hover_pos()
                                            .map(|p| p.x > resp.rect.center().x)
                                            .unwrap_or(false)
                                    });

                                    if let Some(src) = cur_drag_col {
                                        if src != col && resp.hovered() {
                                            let line_x = if is_right_half {
                                                resp.rect.max.x
                                            } else {
                                                resp.rect.min.x
                                            };
                                            ui.painter().line_segment(
                                                [
                                                    Pos2::new(line_x, resp.rect.min.y),
                                                    Pos2::new(line_x, resp.rect.max.y),
                                                ],
                                                Stroke::new(3.0, Color32::from_rgb(0, 120, 215)),
                                            );
                                            if ui.input(|i| i.pointer.any_released()) {
                                                drag_swap = Some((src, col, is_right_half));
                                            }
                                        }
                                    }

                                    if resp.clicked() && !pointer_occluded && cur_drag_col.is_none() {
                                        sort_target = Some(col);
                                    }
                                });
                            }
                        })
                        .body(|body| {
                            let total_rows = self.panes[pane_idx].filtered_indices.len();
                            let is_zh = self.config.language == Language::ZhTw;
                            let mut nav_dir = None;
                            let mut open_file = None;

                            body.rows(row_h, total_rows, |mut row| {
                                let row_idx = row.index();
                                let entry_idx = self.panes[pane_idx].filtered_indices[row_idx];
                                let entry = self.panes[pane_idx].entries[entry_idx].clone();
                                let is_selected = is_active
                                    && self.panes[pane_idx].selected_paths.contains(&entry.path);
                                row.set_selected(is_selected);

                                let row_bg_col = if is_selected {
                                    Color32::from_rgb(0, 120, 215)
                                } else if self.config.theme == AppTheme::ModernDark {
                                    if row_idx % 2 == 0 {
                                        Color32::from_rgb(28, 30, 36)
                                    } else {
                                        Color32::from_rgb(35, 38, 45)
                                    }
                                } else if row_idx % 2 == 0 {
                                    Color32::WHITE
                                } else {
                                    Color32::from_rgb(245, 248, 252)
                                };

                                let text_col = if is_selected {
                                    Color32::WHITE
                                } else if self.config.theme == AppTheme::ModernDark {
                                    Color32::from_gray(230)
                                } else {
                                    Color32::from_gray(20)
                                };

                                let mut r_rects: Vec<Rect> = Vec::with_capacity(active_cols.len());
                                let mut combined_resp: Option<egui::Response> = None;

                                for &col in &active_cols {
                                    match col {
                                        PaneColumn::Name => {
                                            row.col(|ui| {
                                                let label_str = if entry.had_special_encoding {
                                                    format!("{} [🛡UTF8]", entry.display_name)
                                                } else {
                                                    entry.display_name.clone()
                                                };
                                                let desired = Vec2::new(ui.available_width().max(40.0), cell_h);
                                                let (c_rect, resp) =
                                                    ui.allocate_exact_size(desired, Sense::click_and_drag());
                                                let resp = resp.on_hover_cursor(egui::CursorIcon::Default);
                                                let cell_clip = c_rect.intersect(clip_rect);
                                                let cell_painter = ui.painter().with_clip_rect(cell_clip);
                                                cell_painter.rect_filled(
                                                    c_rect,
                                                    if is_selected { 2.0 } else { 0.0 },
                                                    row_bg_col,
                                                );
                                                let icon_h = (list_font_size * 1.05).clamp(13.0, 22.0);
                                                let icon_w = (icon_h * 1.18).ceil();
                                                let icon_rect = Rect::from_center_size(
                                                    Pos2::new(c_rect.min.x + 4.0 + icon_w * 0.5, c_rect.center().y),
                                                    Vec2::new(icon_w, icon_h),
                                                );
                                                paint_entry_vector_icon(
                                                    &cell_painter,
                                                    icon_rect,
                                                    entry.is_dir,
                                                    &entry.extension,
                                                    is_selected,
                                                    self.config.theme == AppTheme::ModernDark,
                                                );
                                                cell_painter.text(
                                                    Pos2::new(c_rect.min.x + 4.0 + icon_w + 5.0, c_rect.center().y),
                                                    egui::Align2::LEFT_CENTER,
                                                    &label_str,
                                                    egui::FontId::proportional(list_font_size),
                                                    text_col,
                                                );
                                                r_rects.push(c_rect);
                                                combined_resp = Some(match combined_resp.take() {
                                                    Some(prev) => prev.union(resp),
                                                    None => resp,
                                                });
                                            });
                                        }
                                        PaneColumn::Directory => {
                                            row.col(|ui| {
                                                let folder_str = entry
                                                    .path
                                                    .parent()
                                                    .map(|p| p.to_string_lossy().into_owned())
                                                    .unwrap_or_default();
                                                let desired = Vec2::new(ui.available_width().max(40.0), cell_h);
                                                let (c_rect, resp) =
                                                    ui.allocate_exact_size(desired, Sense::click_and_drag());
                                                let resp = resp.on_hover_cursor(egui::CursorIcon::Default);
                                                let cell_clip = c_rect.intersect(clip_rect);
                                                ui.painter().with_clip_rect(cell_clip).rect_filled(
                                                    c_rect,
                                                    if is_selected { 2.0 } else { 0.0 },
                                                    row_bg_col,
                                                );
                                                ui.painter().with_clip_rect(cell_clip).text(
                                                    Pos2::new(c_rect.min.x + 3.0, c_rect.center().y),
                                                    egui::Align2::LEFT_CENTER,
                                                    &folder_str,
                                                    egui::FontId::proportional((list_font_size - 1.0).max(10.0)),
                                                    if is_selected { text_col } else { Color32::from_gray(135) },
                                                );
                                                r_rects.push(c_rect);
                                                combined_resp = Some(match combined_resp.take() {
                                                    Some(prev) => prev.union(resp),
                                                    None => resp,
                                                });
                                            });
                                        }
                                        PaneColumn::Size => {
                                            row.col(|ui| {
                                                let desired = Vec2::new(ui.available_width().max(20.0), cell_h);
                                                let (c_rect, resp) =
                                                    ui.allocate_exact_size(desired, Sense::click_and_drag());
                                                let resp = resp.on_hover_cursor(egui::CursorIcon::Default);
                                                let cell_clip = c_rect.intersect(clip_rect);
                                                ui.painter().with_clip_rect(cell_clip).rect_filled(
                                                    c_rect,
                                                    if is_selected { 2.0 } else { 0.0 },
                                                    row_bg_col,
                                                );
                                                if !entry.is_dir {
                                                    ui.painter().with_clip_rect(cell_clip).text(
                                                        Pos2::new(c_rect.min.x + 2.0, c_rect.center().y),
                                                        egui::Align2::LEFT_CENTER,
                                                        format_size(entry.size),
                                                        egui::FontId::proportional((list_font_size - 0.5).max(10.0)),
                                                        text_col,
                                                    );
                                                }
                                                r_rects.push(c_rect);
                                                combined_resp = Some(match combined_resp.take() {
                                                    Some(prev) => prev.union(resp),
                                                    None => resp,
                                                });
                                            });
                                        }
                                        PaneColumn::Type => {
                                            row.col(|ui| {
                                                let desired = Vec2::new(ui.available_width().max(20.0), cell_h);
                                                let (c_rect, resp) =
                                                    ui.allocate_exact_size(desired, Sense::click_and_drag());
                                                let resp = resp.on_hover_cursor(egui::CursorIcon::Default);
                                                let cell_clip = c_rect.intersect(clip_rect);
                                                ui.painter().with_clip_rect(cell_clip).rect_filled(
                                                    c_rect,
                                                    if is_selected { 2.0 } else { 0.0 },
                                                    row_bg_col,
                                                );
                                                ui.painter().with_clip_rect(cell_clip).text(
                                                    Pos2::new(c_rect.min.x + 2.0, c_rect.center().y),
                                                    egui::Align2::LEFT_CENTER,
                                                    entry.type_label(is_zh),
                                                    egui::FontId::proportional((list_font_size - 0.5).max(10.0)),
                                                    text_col,
                                                );
                                                r_rects.push(c_rect);
                                                combined_resp = Some(match combined_resp.take() {
                                                    Some(prev) => prev.union(resp),
                                                    None => resp,
                                                });
                                            });
                                        }
                                        PaneColumn::Modified => {
                                            row.col(|ui| {
                                                let desired = Vec2::new(ui.available_width().max(20.0), cell_h);
                                                let (c_rect, resp) =
                                                    ui.allocate_exact_size(desired, Sense::click_and_drag());
                                                let resp = resp.on_hover_cursor(egui::CursorIcon::Default);
                                                let cell_clip = c_rect.intersect(clip_rect);
                                                ui.painter().with_clip_rect(cell_clip).rect_filled(
                                                    c_rect,
                                                    if is_selected { 2.0 } else { 0.0 },
                                                    row_bg_col,
                                                );
                                                ui.painter().with_clip_rect(cell_clip).text(
                                                    Pos2::new(c_rect.min.x + 2.0, c_rect.center().y),
                                                    egui::Align2::LEFT_CENTER,
                                                    &entry.modified_str,
                                                    egui::FontId::proportional((list_font_size - 0.5).max(10.0)),
                                                    text_col,
                                                );
                                                r_rects.push(c_rect);
                                                combined_resp = Some(match combined_resp.take() {
                                                    Some(prev) => prev.union(resp),
                                                    None => resp,
                                                });
                                            });
                                        }
                                    }
                                }

                                let full_row_rect = r_rects
                                    .iter()
                                    .copied()
                                    .reduce(|a, b| a.union(b))
                                    .unwrap_or(Rect::NOTHING);

                                    // Check if pointer is inside this row (for right-click menu & folder drop target)
                                    if !pointer_occluded {
                                        if let Some(pos) = pointer_pos {
                                            if full_row_rect.contains(pos) && clip_rect.contains(pos) {
                                                hovered_rmb_target =
                                                    Some((pane_id, Some(entry.clone())));

                                                if let Some((_, ref dragged_paths)) = self.drag_payload {
                                                    if entry.is_dir
                                                        && !dragged_paths.contains(&entry.path)
                                                    {
                                                        hovered_drop_target = Some((
                                                            entry.path.clone(),
                                                            entry.display_name.clone(),
                                                        ));
                                                        if let Some(first_r) = r_rects.first() {
                                                            ctx.layer_painter(egui::LayerId::new(
                                                                egui::Order::Foreground,
                                                                egui::Id::new("row_drop_hl"),
                                                            ))
                                                            .rect_stroke(
                                                                full_row_rect.intersect(clip_rect),
                                                                3.0,
                                                                Stroke::new(
                                                                    2.0,
                                                                    Color32::from_rgb(0, 185, 80),
                                                                ),
                                                            );
                                                            let _ = first_r;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if let Some(resp) = combined_resp {
                                        if (resp.clicked() || resp.drag_started() || resp.is_pointer_button_down_on()) && !pointer_occluded {
                                            newly_activated_id = Some(pane_id);
                                        }
                                        if resp.clicked() && !pointer_occluded {
                                            self.context_menu = None;
                                            for (i, p) in self.panes.iter_mut().enumerate() {
                                                if i != pane_idx {
                                                    p.selected_paths.clear();
                                                    p.last_clicked_idx = None;
                                                }
                                            }
                                            let ctrl =
                                                ctx.input(|i| i.modifiers.command || i.modifiers.ctrl);
                                            let shift = ctx.input(|i| i.modifiers.shift);
                                            if shift {
                                                if let Some(anchor) =
                                                    self.panes[pane_idx].last_clicked_idx
                                                {
                                                    let lo = anchor.min(row_idx);
                                                    let hi = anchor.max(row_idx);
                                                    if !ctrl {
                                                        self.panes[pane_idx].selected_paths.clear();
                                                    }
                                                    for r_i in lo..=hi {
                                                        if let Some(&e_i) = self.panes[pane_idx]
                                                            .filtered_indices
                                                            .get(r_i)
                                                        {
                                                            if let Some(p_clone) = self.panes[pane_idx]
                                                                .entries
                                                                .get(e_i)
                                                                .map(|e| e.path.clone())
                                                            {
                                                                self.panes[pane_idx]
                                                                    .selected_paths
                                                                    .insert(p_clone);
                                                            }
                                                        }
                                                    }
                                                }
                                            } else {
                                                if !ctrl {
                                                    self.panes[pane_idx].selected_paths.clear();
                                                }
                                                if is_selected && ctrl {
                                                    self.panes[pane_idx]
                                                        .selected_paths
                                                        .remove(&entry.path);
                                                } else {
                                                    self.panes[pane_idx]
                                                        .selected_paths
                                                        .insert(entry.path.clone());
                                                }
                                                self.panes[pane_idx].last_clicked_idx =
                                                    Some(row_idx);
                                            }
                                            preview_req = Some(entry.path.clone());
                                        }

                                        if resp.double_clicked() && !pointer_occluded {
                                            newly_activated_id = Some(pane_id);
                                            self.context_menu = None;
                                            if entry.is_dir {
                                                nav_dir = Some(entry.path.clone());
                                            } else {
                                                open_file = Some(entry.path.clone());
                                            }
                                        }

                                        // Start Left-Click Drag-and-Drop
                                        if (resp.drag_started() || resp.dragged())
                                            && !pointer_occluded
                                            && primary_down
                                            && !rmb_down
                                            && self.drag_payload.is_none()
                                        {
                                            newly_activated_id = Some(pane_id);
                                            self.context_menu = None;
                                            for (i, p) in self.panes.iter_mut().enumerate() {
                                                if i != pane_idx {
                                                    p.selected_paths.clear();
                                                    p.last_clicked_idx = None;
                                                }
                                            }
                                            if !self.panes[pane_idx]
                                                .selected_paths
                                                .contains(&entry.path)
                                            {
                                                self.panes[pane_idx].selected_paths.clear();
                                                self.panes[pane_idx]
                                                    .selected_paths
                                                    .insert(entry.path.clone());
                                            }
                                            let list: Vec<PathBuf> = self.panes[pane_idx]
                                                .selected_paths
                                                .iter()
                                                .cloned()
                                                .collect();
                                            if !list.is_empty() {
                                                self.drag_payload = Some((pane_id, list));
                                            }
                                        }
                                    }
                                });

                                if let Some(d) = nav_dir {
                                    if self.panes[pane_idx].is_search_results {
                                        self.panes[pane_idx].is_search_results = false;
                                    }
                                    self.panes[pane_idx].navigate_to(d, true);
                                    self.sync_config_paths();
                                }
                                if let Some(f) = open_file {
                                    preview_req = Some(f.clone());
                                    let _ = open::that(&f);
                                }
                            });

                    if let Some(src) = new_drag_source {
                        self.drag_col_source = Some(src);
                    }
                    if let Some((src, target, insert_after)) = drag_swap {
                        if src != target {
                            if let Some(src_idx) = self.config.column_order.iter().position(|&c| c == src) {
                                self.config.column_order.remove(src_idx);
                                let target_idx = self
                                    .config
                                    .column_order
                                    .iter()
                                    .position(|&c| c == target)
                                    .unwrap_or(self.config.column_order.len());
                                let final_idx = if insert_after {
                                    (target_idx + 1).min(self.config.column_order.len())
                                } else {
                                    target_idx
                                };
                                self.config.column_order.insert(final_idx, src);
                                let _ = self.config.save();
                            }
                        }
                        self.drag_col_source = None;
                    } else if ui.input(|i| i.pointer.any_released()) {
                        self.drag_col_source = None;
                    }

                    if let Some(col) = sort_target {
                        newly_activated_id = Some(pane_id);
                        toggle_sort(&mut self.panes[pane_idx], col.sort_column(), show_hidden);
                    }
                });
                    } // end Details

                    if slider_h > 0.0 {
                        let slider_rect = Rect::from_min_max(
                            Pos2::new(table_rect.min.x, content_rect.max.y),
                            table_rect.max,
                        );
                        let mut s_ui = table_ui.new_child(
                            egui::UiBuilder::new()
                                .max_rect(slider_rect)
                                .layout(egui::Layout::left_to_right(egui::Align::Center)),
                        );
                        s_ui.set_clip_rect(slider_rect.intersect(table_clip));
                        let is_zh = self.config.language == Language::ZhTw;
                        s_ui.add_space(6.0);
                        s_ui.label(
                            RichText::new(if is_zh { "🖼 縮圖大小:" } else { "🖼 Thumb Size:" })
                                .small()
                                .weak(),
                        );
                        let mut sz = self.panes[pane_idx].thumbnail_size;
                        if s_ui
                            .add(
                                egui::Slider::new(&mut sz, 48.0..=220.0)
                                    .step_by(4.0)
                                    .suffix("px")
                                    .show_value(true),
                            )
                            .changed()
                        {
                            self.panes[pane_idx].thumbnail_size = sz;
                            self.config.thumbnail_size = sz;
                            let _ = self.config.save();
                        }
                        if (self.panes[pane_idx].thumbnail_size - 96.0).abs() > 1.0
                            && s_ui.small_button("↺").clicked()
                        {
                            self.panes[pane_idx].thumbnail_size = 96.0;
                            self.config.thumbnail_size = 96.0;
                            let _ = self.config.save();
                        }
                    }
                } // end !is_this_pc

                if !is_this_pc && self.panes[pane_idx].filtered_indices.is_empty() {
                    let is_zh = self.config.language == Language::ZhTw;
                    let empty_rect = Rect::from_min_size(
                        Pos2::new(table_rect.min.x, table_top + 35.0),
                        Vec2::new(table_rect.width(), 40.0),
                    );
                    let painter = table_ui.painter().with_clip_rect(table_clip);
                    if self.panes[pane_idx].is_loading || (is_search && self.deep_search_running) {
                        painter.text(
                            empty_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            if is_zh { "⚡ 正在搜尋相符項目中..." } else { "⚡ Searching for matches..." },
                            egui::FontId::proportional(14.0),
                            Color32::from_rgb(0, 120, 215),
                        );
                    } else if is_search {
                        painter.text(
                            empty_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            if is_zh { "（查無相符搜尋結果，可至側邊欄調整條件）" } else { "(No matching search results)" },
                            egui::FontId::proportional(13.5),
                            Color32::from_gray(140),
                        );
                    } else {
                        painter.text(
                            empty_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            if is_zh { "（此資料夾為空）" } else { "(This folder is empty)" },
                            egui::FontId::proportional(13.5),
                            Color32::from_gray(140),
                        );
                    }
                }

                if pointer_occluded && saved_scroll_delta != Vec2::ZERO {
                    ctx.input_mut(|i| {
                        i.smooth_scroll_delta = saved_scroll_delta;
                    });
                }
            });

            // Paint the pane border strictly around `rect` (never inflated by inner widgets!)
            child_ui
                .painter()
                .with_clip_rect(clip_rect)
                .rect_stroke(
                    rect,
                    3.0,
                    Stroke::new(
                        if is_drop_pane_target {
                            2.5
                        } else if is_active {
                            2.0
                        } else {
                            1.0
                        },
                        border_color,
                    ),
                );

            // 6. MDIE 8-Direction Window Border & Corner Resize Handles (works on every child window!)
            if self.config.layout_mode != WindowLayoutMode::TabbedMaximized {
                let c_sz = 7.0;
                let e_sz = 3.5;
                // (dir_tag, rect, cursor_icon, left, right, top, bottom)
                let handles: [(&str, Rect, egui::CursorIcon, bool, bool, bool, bool); 8] = [
                    (
                        "nw",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x - e_sz, rect.min.y - e_sz),
                            Pos2::new(rect.min.x + c_sz, rect.min.y + c_sz),
                        ),
                        egui::CursorIcon::ResizeNwSe,
                        true,
                        false,
                        true,
                        false,
                    ),
                    (
                        "ne",
                        Rect::from_min_max(
                            Pos2::new(rect.max.x - c_sz, rect.min.y - e_sz),
                            Pos2::new(rect.max.x + e_sz, rect.min.y + c_sz),
                        ),
                        egui::CursorIcon::ResizeNeSw,
                        false,
                        true,
                        true,
                        false,
                    ),
                    (
                        "sw",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x - e_sz, rect.max.y - c_sz),
                            Pos2::new(rect.min.x + c_sz, rect.max.y + e_sz),
                        ),
                        egui::CursorIcon::ResizeNeSw,
                        true,
                        false,
                        false,
                        true,
                    ),
                    (
                        "se",
                        Rect::from_min_max(
                            Pos2::new(rect.max.x - c_sz - 2.0, rect.max.y - c_sz - 2.0),
                            Pos2::new(rect.max.x + e_sz, rect.max.y + e_sz),
                        ),
                        egui::CursorIcon::ResizeNwSe,
                        false,
                        true,
                        false,
                        true,
                    ),
                    (
                        "w",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x - e_sz, rect.min.y + c_sz),
                            Pos2::new(rect.min.x + e_sz, rect.max.y - c_sz),
                        ),
                        egui::CursorIcon::ResizeHorizontal,
                        true,
                        false,
                        false,
                        false,
                    ),
                    (
                        "e",
                        Rect::from_min_max(
                            Pos2::new(rect.max.x - e_sz, rect.min.y + c_sz),
                            Pos2::new(rect.max.x + e_sz, rect.max.y - c_sz),
                        ),
                        egui::CursorIcon::ResizeHorizontal,
                        false,
                        true,
                        false,
                        false,
                    ),
                    (
                        "n",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x + c_sz, rect.min.y - e_sz),
                            Pos2::new(rect.max.x - c_sz, rect.min.y + e_sz),
                        ),
                        egui::CursorIcon::ResizeVertical,
                        false,
                        false,
                        true,
                        false,
                    ),
                    (
                        "s",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x + c_sz, rect.max.y - e_sz),
                            Pos2::new(rect.max.x - c_sz, rect.max.y + e_sz),
                        ),
                        egui::CursorIcon::ResizeVertical,
                        false,
                        false,
                        false,
                        true,
                    ),
                ];

                // Draw classic MDIE bottom-right corner resize grip visual on the pane's layer
                child_ui.painter().with_clip_rect(clip_rect).text(
                    Pos2::new(rect.max.x - 3.0, rect.max.y - 2.0),
                    egui::Align2::RIGHT_BOTTOM,
                    "◢",
                    egui::FontId::proportional(11.0),
                    Color32::from_gray(145),
                );

                for (tag, h_rect, cursor, is_l, is_r, is_t, is_b) in handles {
                    let h_clipped = h_rect.intersect(workspace_rect);
                    if !h_clipped.is_positive() {
                        continue;
                    }
                    let h_resp = child_ui
                        .interact(
                            h_clipped,
                            egui::Id::new(("mdi_border_resize", pane_id, tag)),
                            Sense::drag(),
                        )
                        .on_hover_cursor(cursor);

                    if (h_resp.drag_started() || h_resp.dragged()) && !pointer_occluded {
                        newly_activated_id = Some(pane_id);
                        switch_to_free_mode = true;
                        let d = h_resp.drag_delta();
                        if let Some(ref mut r) = self.panes[pane_idx].float_rect {
                            let min_w = 220.0_f32.min(workspace_rect.width());
                            let min_h = 140.0_f32.min(workspace_rect.height());
                            if is_l {
                                r.min.x = (r.min.x + d.x)
                                    .max(workspace_rect.min.x)
                                    .min(r.max.x - min_w);
                            }
                            if is_r {
                                r.max.x = (r.max.x + d.x)
                                    .min(workspace_rect.max.x)
                                    .max(r.min.x + min_w);
                            }
                            if is_t {
                                r.min.y = (r.min.y + d.y)
                                    .max(workspace_rect.min.y)
                                    .min(r.max.y - min_h);
                            }
                            if is_b {
                                r.max.y = (r.max.y + d.y)
                                    .min(workspace_rect.max.y)
                                    .max(r.min.y + min_h);
                            }
                        }
                    }
                }
            }
        }

        if switch_to_free_mode {
            self.config.layout_mode = WindowLayoutMode::MdiFree;
        }

        // Right-Click press / drag / release handling (Context Menu vs Mouse Gestures)
        if rmb_pressed {
            self.context_menu = None;
            if let Some(pos) = pointer_pos {
                self.gesture_tracker.start(pos);
            }
            if let Some((p_id, ref maybe_entry)) = hovered_rmb_target {
                if let Some(fid) = ctx.memory(|m| m.focused()) {
                    ctx.memory_mut(|m| m.surrender_focus(fid));
                }
                newly_activated_id = Some(p_id);
                if let Some(entry) = maybe_entry {
                    for p in &mut self.panes {
                        if p.id == p_id {
                            if !p.selected_paths.contains(&entry.path) {
                                p.selected_paths.clear();
                                p.selected_paths.insert(entry.path.clone());
                            }
                        } else {
                            p.selected_paths.clear();
                            p.last_clicked_idx = None;
                        }
                    }
                }
                self.rmb_press_target = hovered_rmb_target.clone();
            } else {
                self.rmb_press_target = None;
            }
        }
        if rmb_down && self.gesture_tracker.is_tracking {
            if let Some(pos) = pointer_pos {
                self.gesture_tracker.update_pos(pos);
                ctx.request_repaint();
            }
        }
        if rmb_released && self.gesture_tracker.is_tracking {
            let (was_drag, matched) = self.gesture_tracker.finish();
            if was_drag {
                if let Some((seq, action)) = matched {
                    self.execute_gesture_action(action);
                    self.status_toast = format!(
                        "🖱 MDIE 手勢 [{}] -> {}",
                        GestureTracker::format_arrows(&seq),
                        action.label(self.config.language)
                    );
                }
            } else if let Some(pos) = pointer_pos {
                // Stationary Right-Click -> Open Context Menu!
                let target = self.rmb_press_target.take().or(hovered_rmb_target);
                if let Some((p_id, maybe_entry)) = target {
                    newly_activated_id = Some(p_id);
                    self.context_menu = Some(ContextMenuState {
                        pos,
                        pane_id: p_id,
                        target_entry: maybe_entry,
                        view_submenu_open: false,
                    });
                }
            }
        }

        // Left-Click Drag-and-Drop live tooltip & mouse release drop execution
        if let Some((_, ref dragged_paths)) = self.drag_payload.clone() {
            if primary_down {
                if let Some(pos) = pointer_pos {
                    let is_copy = ctx.input(|i| i.modifiers.ctrl || i.modifiers.alt);
                    let painter = ctx.layer_painter(egui::LayerId::new(
                        egui::Order::Tooltip,
                        egui::Id::new("mine_dnd_ghost"),
                    ));
                    let badge_text = if let Some((_, ref target_name)) = hovered_drop_target {
                        format!(
                            "{} {} 個項目 ➡ 「{}」\n(放開左鍵: {} | 按住 Ctrl/Alt: 複製)",
                            if is_copy { "📋 複製" } else { "✂ 移動" },
                            dragged_paths.len(),
                            target_name,
                            if is_copy { "複製" } else { "移動" }
                        )
                    } else {
                        format!(
                            "📦 正在拖曳 {} 個項目\n(拖曳至其他視窗或子資料夾上放開左鍵即可移動/複製)",
                            dragged_paths.len()
                        )
                    };
                    let badge_rect =
                        Rect::from_min_size(pos + Vec2::new(14.0, 14.0), Vec2::new(330.0, 44.0));
                    painter.rect_filled(badge_rect, 6.0, Color32::from_black_alpha(215));
                    painter.rect_stroke(
                        badge_rect,
                        6.0,
                        Stroke::new(
                            1.5,
                            if hovered_drop_target.is_some() {
                                Color32::from_rgb(0, 210, 100)
                            } else {
                                Color32::from_rgb(0, 170, 255)
                            },
                        ),
                    );
                    painter.text(
                        Pos2::new(badge_rect.min.x + 10.0, badge_rect.center().y),
                        egui::Align2::LEFT_CENTER,
                        badge_text,
                        egui::FontId::proportional(12.5),
                        Color32::WHITE,
                    );
                }
            } else if primary_released || !primary_down {
                if let Some((target_dir, _)) = hovered_drop_target {
                    let is_copy = ctx.input(|i| i.modifiers.ctrl || i.modifiers.alt);
                    drop_transfer = Some((dragged_paths.clone(), target_dir, !is_copy));
                }
                self.drag_payload = None;
            }
        }

        if !is_any_overlay_open {
            if let Some(id) = newly_activated_id {
                if self.active_pane_id != id {
                    self.active_pane_id = id;
                    for p in &mut self.panes {
                        if p.id != id {
                            p.selected_paths.clear();
                            p.last_clicked_idx = None;
                        }
                    }
                }
            }
        }
        if let Some(p) = preview_req {
            self.trigger_preview(p);
        }
        if let Some((srcs, dst, is_cut)) = drop_transfer {
            self.perform_file_transfer(&srcs, &dst, is_cut);
            self.drag_payload = None;
        }
        if let Some(path) = pane_to_clone {
            self.spawn_new_pane(path);
        }
        if let Some(id) = pane_to_maximize {
            self.active_pane_id = id;
            self.config.layout_mode =
                if self.config.layout_mode == WindowLayoutMode::TabbedMaximized {
                    WindowLayoutMode::TileHorizontally
                } else {
                    WindowLayoutMode::TabbedMaximized
                };
        }
        if let Some(id) = pane_to_close {
            self.close_pane_by_id(id);
        }
    }

    fn render_context_menu(&mut self, ctx: &egui::Context, t: &crate::i18n::Texts) {
        let Some(menu) = self.context_menu.clone() else {
            return;
        };

        let mut close_menu = false;
        let is_zh = self.config.language == Language::ZhTw;
        let mut view_row_rect: Option<Rect> = None;
        let pointer_pos = ctx.input(|i| i.pointer.latest_pos());

        let area_resp = egui::Area::new(egui::Id::new("mine_right_click_context_menu"))
            .order(egui::Order::Foreground)
            .fixed_pos(menu.pos)
            .show(ctx, |ui| {
                egui::Frame::popup(ui.style())
                    .inner_margin(egui::Margin::symmetric(8.0, 6.0))
                    .show(ui, |ui| {
                        ui.set_min_width(210.0);
                        let pane_idx = self
                            .panes
                            .iter()
                            .position(|p| p.id == menu.pane_id)
                            .unwrap_or(0);
                        let current_dir = self
                            .panes
                            .get(pane_idx)
                            .map(|p| p.current_path.clone())
                            .unwrap_or_else(|| PathBuf::from("."));
                        let selected_list: Vec<PathBuf> = self
                            .panes
                            .get(pane_idx)
                            .map(|p| p.selected_paths.iter().cloned().collect())
                            .unwrap_or_default();

                        if let Some(ref entry) = menu.target_entry {
                            let is_dark_bg = self.config.theme == AppTheme::ModernDark;
                            ui.horizontal(|ui| {
                                if entry.is_dir {
                                    draw_finder_folder_widget(ui, 13.5, false, false);
                                } else {
                                    draw_finder_file_widget(ui, 13.5, &entry.extension, false, is_dark_bg);
                                }
                                ui.label(
                                    RichText::new(&entry.display_name)
                                        .strong()
                                        .color(Color32::from_rgb(0, 102, 204)),
                                );
                            });
                            ui.separator();

                            if ui
                                .button(if is_zh {
                                    "📂 開啟 (Open)"
                                } else {
                                    "📂 Open"
                                })
                                .clicked()
                            {
                                if entry.is_dir {
                                    if let Some(p) = self.panes.get_mut(pane_idx) {
                                        p.navigate_to(entry.path.clone(), true);
                                    }
                                    self.sync_config_paths();
                                } else {
                                    let _ = open::that(&entry.path);
                                }
                                close_menu = true;
                            }

                            if entry.is_dir
                                && ui
                                    .button(if is_zh {
                                        "➕ 在新並排視窗開啟此資料夾"
                                    } else {
                                        "➕ Open Folder in New Window"
                                    })
                                    .clicked()
                            {
                                self.spawn_new_pane(entry.path.clone());
                                close_menu = true;
                            }

                            if entry.is_dir
                                && ui
                                    .button(if is_zh {
                                        "⭐ 加到常用資料夾 (Pin to Quick Access)"
                                    } else {
                                        "⭐ Pin to Quick Access"
                                    })
                                    .clicked()
                            {
                                let name = entry.display_name.clone();
                                let path = entry.path.to_string_lossy().into_owned();
                                self.add_quick_access_item(name, path);
                                close_menu = true;
                            }

                            if let Some(parent) = entry.path.parent() {
                                let parent_buf = parent.to_path_buf();
                                if ui
                                    .button(if is_zh {
                                        "📁 開啟所在資料夾 (定位檔案)"
                                    } else {
                                        "📁 Open Containing Folder"
                                    })
                                    .clicked()
                                {
                                    let mut target_pane_id = None;
                                    for p in &mut self.panes {
                                        if !p.is_search_results {
                                            p.navigate_to(parent_buf.clone(), true);
                                            p.selected_paths.clear();
                                            p.selected_paths.insert(entry.path.clone());
                                            target_pane_id = Some(p.id);
                                            break;
                                        }
                                    }
                                    if target_pane_id.is_none() {
                                        let new_id = self.next_pane_id;
                                        self.next_pane_id += 1;
                                        let mut np = MdiChildPane::new(new_id, parent_buf);
                                        np.selected_paths.insert(entry.path.clone());
                                        self.panes.push(np);
                                        target_pane_id = Some(new_id);
                                    }
                                    if let Some(tid) = target_pane_id {
                                        self.active_pane_id = tid;
                                    }
                                    self.trigger_preview(entry.path.clone());
                                    close_menu = true;
                                }
                            }

                            ui.separator();

                            if ui.button(t.edit_copy).clicked() {
                                let targets = if selected_list.is_empty() {
                                    vec![entry.path.clone()]
                                } else {
                                    selected_list.clone()
                                };
                                self.copy_or_cut_paths(targets, false);
                                close_menu = true;
                            }

                            if ui.button(t.edit_cut).clicked() {
                                let targets = if selected_list.is_empty() {
                                    vec![entry.path.clone()]
                                } else {
                                    selected_list.clone()
                                };
                                self.copy_or_cut_paths(targets, true);
                                close_menu = true;
                            }

                            if self.has_pasteable_clipboard() {
                                let paste_dest = if entry.is_dir {
                                    entry.path.clone()
                                } else {
                                    current_dir.clone()
                                };
                                let paste_lbl = if entry.is_dir {
                                    if is_zh {
                                        format!("📥 貼上至「{}」資料夾內", entry.display_name)
                                    } else {
                                        format!("📥 Paste into '{}'", entry.display_name)
                                    }
                                } else {
                                    t.edit_paste.to_string()
                                };
                                if ui.button(paste_lbl).clicked() {
                                    self.paste_clipboard_into(&paste_dest);
                                    close_menu = true;
                                }
                            }

                            ui.separator();

                            if ui.button(t.edit_rename).clicked() {
                                self.rename_modal =
                                    Some((entry.path.clone(), entry.display_name.clone()));
                                close_menu = true;
                            }

                            if ui.button(t.edit_copy_path).clicked() {
                                if let Ok(mut cb) = arboard::Clipboard::new() {
                                    let _ = cb.set_text(entry.path.to_string_lossy().into_owned());
                                    self.status_toast = format!(
                                        "🔗 已複製完整路徑: {}",
                                        entry.path.to_string_lossy()
                                    );
                                }
                                close_menu = true;
                            }

                            if entry.is_dir
                                && ui
                                    .button(if is_zh {
                                        "⭐ 加入我的最愛書籤"
                                    } else {
                                        "⭐ Add to Favorites"
                                    })
                                    .clicked()
                            {
                                self.config.favorite_folders.push((
                                    entry.display_name.clone(),
                                    entry.path.to_string_lossy().into_owned(),
                                ));
                                let _ = self.config.save();
                                close_menu = true;
                            }

                            ui.separator();

                            if ui
                                .button(
                                    RichText::new(t.edit_delete)
                                        .color(Color32::from_rgb(200, 40, 40)),
                                )
                                .clicked()
                            {
                                let targets = if selected_list.is_empty() {
                                    vec![entry.path.clone()]
                                } else {
                                    selected_list.clone()
                                };
                                self.move_paths_to_trash(&targets);
                                close_menu = true;
                            }

                            let perm_del_lbl = if is_zh {
                                "🔥 永久刪除 (Shift+Del)"
                            } else {
                                "🔥 Permanent Delete (Shift+Del)"
                            };
                            if ui
                                .button(
                                    RichText::new(perm_del_lbl)
                                        .color(Color32::from_rgb(220, 45, 45)),
                                )
                                .clicked()
                            {
                                let raw_targets = if selected_list.is_empty() {
                                    vec![entry.path.clone()]
                                } else {
                                    selected_list.clone()
                                };
                                let targets: Vec<PathBuf> = raw_targets
                                    .into_iter()
                                    .filter(|p| p.parent().is_some() && !crate::fs_ops::is_this_pc_path(p))
                                    .collect();
                                if !targets.is_empty() {
                                    self.perm_delete_modal = Some(targets);
                                }
                                close_menu = true;
                            }

                            if ui
                                .button(if is_zh {
                                    "📋 內容 / 屬性 (Properties)"
                                } else {
                                    "📋 Properties"
                                })
                                .clicked()
                            {
                                self.open_properties_for(&entry.path);
                                close_menu = true;
                            }

                            ui.separator();
                        } else {
                            ui.horizontal(|ui| {
                                draw_finder_folder_widget(ui, 13.5, true, false);
                                ui.label(
                                    RichText::new(current_dir.to_string_lossy().as_ref())
                                        .strong()
                                        .color(Color32::from_rgb(0, 102, 204)),
                                );
                            });
                            ui.separator();

                            let row_w = ui.available_width().max(195.0);
                            let (r_rect, r_resp) = ui.allocate_exact_size(Vec2::new(row_w, 22.0), Sense::click());
                            let row_hov = r_resp.hovered() || menu.view_submenu_open;
                            if row_hov {
                                ui.painter().rect_filled(r_rect, 3.0, Color32::from_rgb(0, 120, 215));
                            }
                            let txt_col = if row_hov {
                                Color32::WHITE
                            } else {
                                ui.visuals().text_color()
                            };
                            ui.painter().text(
                                Pos2::new(r_rect.min.x + 6.0, r_rect.center().y),
                                egui::Align2::LEFT_CENTER,
                                if is_zh { "👁 檢視 (V)" } else { "👁 View (V)" },
                                egui::FontId::proportional(13.0),
                                txt_col,
                            );
                            ui.painter().text(
                                Pos2::new(r_rect.max.x - 6.0, r_rect.center().y),
                                egui::Align2::RIGHT_CENTER,
                                "▶",
                                egui::FontId::proportional(10.0),
                                txt_col,
                            );
                            view_row_rect = Some(r_rect);

                            if self.has_pasteable_clipboard()
                                && ui.button(t.edit_paste).clicked()
                            {
                                self.paste_clipboard_into(&current_dir);
                                close_menu = true;
                            }
                        }

                        // Folder-level actions always available at bottom of right-click menu
                        if ui.button(t.file_new_folder).clicked() {
                            self.create_item_modal =
                                Some((current_dir.clone(), true, "New_Folder".into()));
                            close_menu = true;
                        }
                        if ui.button(t.file_new_file).clicked() {
                            self.create_item_modal =
                                Some((current_dir.clone(), false, "note.txt".into()));
                            close_menu = true;
                        }
                        if ui.button(t.view_refresh).clicked() {
                            if let Some(p) = self.panes.get_mut(pane_idx) {
                                p.trigger_reload();
                            }
                            close_menu = true;
                        }
                        if ui.button(t.file_open_terminal).clicked() {
                            open_terminal_at(&current_dir);
                            close_menu = true;
                        }
                        if ui.button(t.file_open_native).clicked() {
                            let _ = open::that(&current_dir);
                            close_menu = true;
                        }
                        if !crate::fs_ops::is_this_pc_path(&current_dir) {
                            ui.separator();
                            if ui
                                .button(if is_zh {
                                    "📋 資料夾內容 / 屬性 (Properties)"
                                } else {
                                    "📋 Folder Properties"
                                })
                                .clicked()
                            {
                                self.open_properties_for(&current_dir);
                                close_menu = true;
                            }
                        }
                    });
            });

        let main_rect = area_resp.response.rect;
        let mut submenu_open = menu.view_submenu_open;
        let mut submenu_rect: Option<Rect> = None;

        if let Some(vr) = view_row_rect {
            if let Some(ppos) = pointer_pos {
                if vr.contains(ppos) {
                    submenu_open = true;
                }
            }
            if submenu_open {
                let screen = ctx.screen_rect();
                let sub_w = 195.0;
                let sub_x = if main_rect.max.x + sub_w + 8.0 <= screen.max.x {
                    main_rect.max.x - 2.0
                } else {
                    (main_rect.min.x - sub_w + 2.0).max(screen.min.x + 4.0)
                };
                let sub_y = vr.min.y.min((screen.max.y - 160.0).max(screen.min.y + 4.0));
                let sub_resp = egui::Area::new(egui::Id::new("mine_right_click_view_submenu"))
                    .order(egui::Order::Foreground)
                    .fixed_pos(Pos2::new(sub_x, sub_y))
                    .show(ctx, |ui| {
                        egui::Frame::popup(ui.style())
                            .inner_margin(egui::Margin::symmetric(6.0, 5.0))
                            .show(ui, |ui| {
                                ui.set_min_width(175.0);
                                if self.render_view_mode_menu_items(ui, menu.pane_id) {
                                    close_menu = true;
                                }
                            });
                    });
                let sr = sub_resp.response.rect;
                submenu_rect = Some(sr);

                if let Some(ppos) = pointer_pos {
                    let row_zone = Rect::from_min_max(
                        Pos2::new(vr.min.x - 16.0, vr.min.y - 4.0),
                        Pos2::new(vr.max.x + 16.0, vr.max.y + 4.0),
                    );
                    let sub_zone = sr.expand(12.0);
                    if !row_zone.contains(ppos) && !sub_zone.contains(ppos) {
                        submenu_open = false;
                    }
                }
            }
        } else {
            submenu_open = false;
        }

        if let Some(ref mut cm) = self.context_menu {
            cm.view_submenu_open = submenu_open;
        }

        // Close context menu if user clicked outside of it
        if ctx.input(|i| i.pointer.button_pressed(egui::PointerButton::Primary)) {
            if let Some(pos) = ctx.input(|i| i.pointer.interact_pos()) {
                let in_sub = submenu_rect.map(|r| r.contains(pos)).unwrap_or(false);
                if !main_rect.contains(pos) && !in_sub {
                    close_menu = true;
                }
            }
        }
        if close_menu {
            self.context_menu = None;
        }
    }

    fn render_gesture_overlay(&self, ctx: &egui::Context) {
        if !self.gesture_tracker.is_tracking
            || self.gesture_tracker.trail.len() < 2
            || self.gesture_tracker.max_distance < 22.0
        {
            return;
        }
        let painter = ctx.layer_painter(egui::LayerId::new(
            egui::Order::Foreground,
            egui::Id::new("mdie_gesture_overlay"),
        ));

        // Draw glowing cyan-blue gesture trail
        painter.add(egui::Shape::line(
            self.gesture_tracker.trail.clone(),
            Stroke::new(4.0, Color32::from_rgb(0, 190, 255)),
        ));

        // Draw HUD badge at center of screen showing current arrows + matched command
        let screen = ctx.screen_rect();
        let center = screen.center();
        let arrows = GestureTracker::format_arrows(&self.gesture_tracker.current_directions);
        let action_label = self
            .gesture_tracker
            .current_matched_action()
            .map(|a| a.label(self.config.language))
            .unwrap_or(if self.config.language == Language::ZhTw {
                "(繼續拖曳以匹配手勢...)"
            } else {
                "(Keep dragging to match gesture...)"
            });

        let hud_rect = Rect::from_center_size(center, Vec2::new(360.0, 74.0));
        painter.rect_filled(hud_rect, 10.0, Color32::from_black_alpha(210));
        painter.rect_stroke(
            hud_rect,
            10.0,
            Stroke::new(2.0, Color32::from_rgb(0, 190, 255)),
        );
        painter.text(
            Pos2::new(center.x, center.y - 14.0),
            egui::Align2::CENTER_CENTER,
            format!("🖱 {}", if arrows.is_empty() { "•" } else { &arrows }),
            egui::FontId::proportional(22.0),
            Color32::from_rgb(0, 220, 255),
        );
        painter.text(
            Pos2::new(center.x, center.y + 16.0),
            egui::Align2::CENTER_CENTER,
            action_label,
            egui::FontId::proportional(15.0),
            Color32::WHITE,
        );
    }

    fn render_dialogs(&mut self, ctx: &egui::Context, t: &crate::i18n::Texts) {
        // (MDIE search is now integrated in the Left Sidebar without blocking MDI windows)

        // 2. Mouse Gesture Settings & Cheat Sheet Dialog
        if self.show_gesture_dialog {
            let mut open = self.show_gesture_dialog;
            egui::Window::new(t.dlg_gesture_title)
                .order(egui::Order::Foreground)
                .open(&mut open)
                .default_size(Vec2::new(560.0, 440.0))
                .show(ctx, |ui| {
                    let is_zh = self.config.language == Language::ZhTw;
                    ui.label(
                        if is_zh {
                            "按住滑鼠右鍵並在畫面任意處拖曳即可觸發手勢（支援 L=左, R=右, U=上, D=下 組合）："
                        } else {
                            "Hold Right-Click and drag anywhere to trigger gestures (supports L=Left, R=Right, U=Up, D=Down):"
                        },
                    );
                    ui.separator();

                    ui.horizontal(|ui| {
                        ui.label(if is_zh { "新增/修改手勢序列 (如 L, DR, ULR):" } else { "Add/Edit gesture sequence (e.g. L, DR, ULR):" });
                        ui.add(
                            egui::TextEdit::singleline(&mut self.new_gesture_seq)
                                .desired_width(70.0),
                        );
                        egui::ComboBox::from_id_salt("gesture_act_combo")
                            .selected_text(self.new_gesture_action.label(self.config.language))
                            .show_ui(ui, |ui| {
                                for &act in GestureAction::all() {
                                    ui.selectable_value(
                                        &mut self.new_gesture_action,
                                        act,
                                        act.label(self.config.language),
                                    );
                                }
                            });
                        let bind_text = if is_zh { "➕ 綁定手勢" } else { "➕ Bind Gesture" };
                        if ui.button(bind_text).clicked() {
                            let cleaned: String = self
                                .new_gesture_seq
                                .to_uppercase()
                                .chars()
                                .filter(|c| matches!(c, 'L' | 'R' | 'U' | 'D'))
                                .collect();
                            if !cleaned.is_empty() {
                                self.gesture_tracker
                                    .bindings
                                    .insert(cleaned, self.new_gesture_action);
                                self.sync_config_paths();
                            }
                        }
                    });
                    ui.separator();

                    egui::ScrollArea::vertical().show(ui, |ui| {
                        let mut keys: Vec<String> =
                            self.gesture_tracker.bindings.keys().cloned().collect();
                        keys.sort();
                        let mut to_remove = None;
                        for k in keys {
                            if let Some(&act) = self.gesture_tracker.bindings.get(&k) {
                                ui.horizontal(|ui| {
                                    ui.label(
                                        RichText::new(format!(
                                            "🖱 {:<6} ({})",
                                            k,
                                            GestureTracker::format_arrows(&k)
                                        ))
                                        .monospace()
                                        .strong(),
                                    );
                                    ui.label("➡");
                                    ui.label(act.label(self.config.language));
                                    if ui.small_button("🗑").clicked() {
                                        to_remove = Some(k.clone());
                                    }
                                });
                            }
                        }
                        if let Some(k) = to_remove {
                            self.gesture_tracker.bindings.remove(&k);
                            self.sync_config_paths();
                        }
                    });
                });
            self.show_gesture_dialog = open;
        }

        // 3. Network Shares & Remote Folder Manager Dialog
        if self.show_network_shares_manager || self.show_smb_dialog {
            let mut open = self.show_network_shares_manager || self.show_smb_dialog;
            let mut do_close = false;
            let is_zh = self.config.language == Language::ZhTw;
            egui::Window::new(if is_zh { "⚙ 管理網路磁碟與共用 (Network Shares Manager)" } else { "⚙ Network Shares Manager" })
                .order(egui::Order::Foreground)
                .open(&mut open)
                .default_size(Vec2::new(600.0, 440.0))
                .show(ctx, |ui| {
                    ui.label(if is_zh {
                        "💡 勾選項目以決定是否在側邊欄顯示。可隨意選擇顯示或隱藏個別磁碟、重新偵測連線或新增自訂網路位置。"
                    } else {
                        "💡 Check/uncheck items to show/hide in the sidebar. Re-probe connection or add custom remote folders."
                    });
                    ui.separator();

                    // Global filters & quick actions
                    ui.horizontal(|ui| {
                        if ui.checkbox(&mut self.config.show_sidebar_network, if is_zh { "🌐 啟用側邊欄網路磁碟區塊" } else { "Show Network Section" }).changed() {
                            let _ = self.config.save();
                        }
                        if ui.checkbox(&mut self.config.hide_offline_network_shares, if is_zh { "🛡 隱藏離線磁碟 ([✖ 無法連線])" } else { "Hide Offline Shares" }).changed() {
                            let _ = self.config.save();
                        }
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ui.button(if is_zh { "🔄 重新整理所有連線" } else { "🔄 Refresh & Probe All" }).clicked() {
                                self.refresh_system_remote_folders();
                                self.probe_all_smb();
                            }
                        });
                    });
                    ui.separator();

                    let sys_smbs = self.system_smb_shares.clone();
                    let usr_smbs = self.config.smb_bookmarks.clone();
                    let all_smbs: Vec<_> = sys_smbs.iter().map(|s| (s, false)).chain(usr_smbs.iter().map(|s| (s, true))).collect();

                    let mut config_changed = false;
                    let mut delete_bookmark_unc = None;
                    let mut open_target_now = None;
                    let mut spawn_target_now = None;

                    egui::ScrollArea::vertical().max_height(230.0).show(ui, |ui| {
                        if all_smbs.is_empty() {
                            ui.add_space(10.0);
                            ui.label(RichText::new(if is_zh { "目前尚未偵測到任何網路磁碟或遠端位置。" } else { "No network shares found." }).color(Color32::GRAY));
                        }
                        for (smb, is_custom) in &all_smbs {
                            let unc = &smb.unc_or_mount_path;
                            let is_hidden = self.config.hidden_network_shares.contains(unc);
                            let mut is_visible = !is_hidden;

                            ui.horizontal(|ui| {
                                // 1. Checkbox for visibility
                                if ui.checkbox(&mut is_visible, "").on_hover_text(if is_zh { "勾選以在側邊欄顯示此磁碟" } else { "Toggle visibility" }).changed() {
                                    if is_visible {
                                        self.config.hidden_network_shares.retain(|p| p != unc);
                                    } else {
                                        if !self.config.hidden_network_shares.contains(unc) {
                                            self.config.hidden_network_shares.push(unc.clone());
                                        }
                                    }
                                    config_changed = true;
                                }

                                // 2. Status icon
                                draw_smb_status_icon(ui, &smb.status);

                                // 3. Name & Path
                                let name_color = if !is_visible {
                                    Color32::from_gray(120)
                                } else if matches!(smb.status, SmbStatus::Offline(_)) {
                                    Color32::from_rgb(230, 90, 90)
                                } else {
                                    Color32::WHITE
                                };
                                ui.label(RichText::new(&smb.name).color(name_color).strong());
                                ui.label(RichText::new(unc).small().color(Color32::GRAY));

                                if !is_visible {
                                    ui.label(RichText::new(if is_zh { "[已隱藏]" } else { "[Hidden]" }).small().color(Color32::from_rgb(200, 150, 50)));
                                } else if matches!(smb.status, SmbStatus::Offline(_)) {
                                    ui.label(RichText::new(if is_zh { "[✖ 無法連線]" } else { "[Offline]" }).small().color(Color32::from_rgb(240, 90, 90)));
                                }

                                // 4. Action buttons on the right
                                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                                    if *is_custom {
                                        if ui.small_button("🗑").on_hover_text(if is_zh { "刪除此自訂書籤" } else { "Delete" }).clicked() {
                                            delete_bookmark_unc = Some(unc.clone());
                                        }
                                    }
                                    if is_visible {
                                        if ui.small_button(if is_zh { "👁 隱藏" } else { "Hide" }).clicked() {
                                            if !self.config.hidden_network_shares.contains(unc) {
                                                self.config.hidden_network_shares.push(unc.clone());
                                                config_changed = true;
                                            }
                                        }
                                    } else {
                                        if ui.small_button(if is_zh { "👁 顯示" } else { "Show" }).clicked() {
                                            self.config.hidden_network_shares.retain(|p| p != unc);
                                            config_changed = true;
                                        }
                                    }
                                    if !matches!(smb.status, SmbStatus::Offline(_)) {
                                        if ui.small_button(if is_zh { "➕ 新視窗" } else { "New Win" }).clicked() {
                                            spawn_target_now = Some(PathBuf::from(unc));
                                        }
                                        if ui.small_button(if is_zh { "📂 開啟" } else { "Open" }).clicked() {
                                            open_target_now = Some(PathBuf::from(unc));
                                        }
                                    }
                                });
                            });
                            ui.separator();
                        }
                    });

                    if let Some(unc_del) = delete_bookmark_unc {
                        self.config.smb_bookmarks.retain(|b| &b.unc_or_mount_path != &unc_del);
                        config_changed = true;
                    }
                    if let Some(target) = open_target_now {
                        let idx = self.active_pane_index();
                        if let Some(p) = self.panes.get_mut(idx) {
                            p.navigate_to(target, true);
                        }
                        do_close = true;
                    }
                    if let Some(target) = spawn_target_now {
                        self.spawn_new_pane(target);
                        do_close = true;
                    }
                    if config_changed {
                        let _ = self.config.save();
                    }

                    // Add Custom Remote Folder Section
                    ui.add_space(4.0);
                    ui.collapsing(if is_zh { "📌 新增自訂遠端書籤 (NAS / SMB / 網路共用)" } else { "➕ Add Custom Remote Bookmark" }, |ui| {
                        ui.horizontal(|ui| {
                            ui.label(if is_zh { "名稱:" } else { "Name:" });
                            ui.add(
                                egui::TextEdit::singleline(&mut self.new_smb_name)
                                    .hint_text(if is_zh { "例如: 公司 NAS" } else { "e.g. Office NAS" })
                                    .desired_width(100.0),
                            );
                            ui.label("IP/Host:");
                            ui.add(
                                egui::TextEdit::singleline(&mut self.new_smb_host)
                                    .hint_text("192.168.x.x")
                                    .desired_width(105.0),
                            );
                            ui.label(if is_zh { "UNC/路徑:" } else { "UNC / Path:" });
                            ui.add(
                                egui::TextEdit::singleline(&mut self.new_smb_unc)
                                    .hint_text("\\\\IP\\share")
                                    .desired_width(150.0),
                            );
                            let add_label = if is_zh { "➕ 新增" } else { "➕ Add" };
                            if ui.button(add_label).clicked() {
                                let name_trimmed = self.new_smb_name.trim().to_string();
                                let unc_trimmed = self.new_smb_unc.trim().to_string();
                                let host_trimmed = self.new_smb_host.trim().to_string();
                                if !name_trimmed.is_empty() && !unc_trimmed.is_empty() {
                                    let auto_host = if host_trimmed.is_empty() {
                                        crate::fs_ops::extract_host_from_remote_path(&unc_trimmed)
                                    } else {
                                        host_trimmed
                                    };
                                    self.config.smb_bookmarks.push(
                                        crate::fs_ops::SmbShareBookmark {
                                            name: name_trimmed,
                                            unc_or_mount_path: unc_trimmed,
                                            host_ip: auto_host,
                                            port: self.new_smb_port.parse().unwrap_or(445),
                                            status: SmbStatus::Unknown,
                                        },
                                    );
                                    self.new_smb_name.clear();
                                    self.new_smb_unc.clear();
                                    self.new_smb_host.clear();
                                    let _ = self.config.save();
                                    self.probe_all_smb();
                                }
                            }
                        });
                    });

                    ui.add_space(8.0);
                    ui.separator();
                    ui.horizontal(|ui| {
                        if !self.config.hidden_network_shares.is_empty() {
                            let reset_txt = if is_zh {
                                format!("🔄 恢復顯示所有隱藏磁碟 (共 {} 個)", self.config.hidden_network_shares.len())
                            } else {
                                format!("🔄 Unhide All Shares ({})", self.config.hidden_network_shares.len())
                            };
                            if ui.button(reset_txt).clicked() {
                                self.config.hidden_network_shares.clear();
                                let _ = self.config.save();
                            }
                        }
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ui.button(if is_zh { "關閉" } else { "Close" }).clicked() {
                                do_close = true;
                            }
                        });
                    });
                });
            if do_close {
                open = false;
            }
            self.show_network_shares_manager = open;
            self.show_smb_dialog = open;
        }

        // 4. Save Workspace Group Modal
        if self.show_save_group_modal {
            let is_zh = self.config.language == Language::ZhTw;
            let group_modal_title = if is_zh { "💾 儲存多視窗並排工作群組 (Workspace Group)" } else { "💾 Save Multi-Window Workspace Group" };
            egui::Window::new(group_modal_title)
                .order(egui::Order::Foreground)
                .collapsible(false)
                .show(ctx, |ui| {
                    let desc = if is_zh {
                        format!("將目前開啟的 {} 個子視窗路徑與排列模式存為群組，隨時一鍵展開：", self.panes.len())
                    } else {
                        format!("Save current {} open window paths & layout as a group for 1-click restore:", self.panes.len())
                    };
                    ui.label(desc);
                    ui.text_edit_singleline(&mut self.new_group_name);
                    ui.horizontal(|ui| {
                        if ui.button(t.btn_save).clicked() {
                            let paths = self
                                .panes
                                .iter()
                                .map(|p| p.current_path.to_string_lossy().into_owned())
                                .collect();
                            self.config.workspace_groups.push(WorkspaceGroupBookmark {
                                name: self.new_group_name.clone(),
                                layout: self.config.layout_mode,
                                paths,
                            });
                            let _ = self.config.save();
                            self.show_save_group_modal = false;
                        }
                        if ui.button(t.btn_cancel).clicked() {
                            self.show_save_group_modal = false;
                        }
                    });
                });
        }

        // 5. Create Folder / File Modal
        if let Some((dir_path, is_folder, ref mut name_buf)) = self.create_item_modal.clone() {
            let mut close = false;
            let mut current_name = name_buf.clone();
            let title = if is_folder {
                t.file_new_folder
            } else {
                t.file_new_file
            };
            egui::Window::new(title)
                .order(egui::Order::Foreground)
                .collapsible(false)
                .show(ctx, |ui| {
                    ui.text_edit_singleline(&mut current_name);
                    ui.horizontal(|ui| {
                        if ui.button(t.btn_create).clicked() {
                            let target = dir_path.join(&current_name);
                            let _ = if is_folder {
                                std::fs::create_dir_all(&target)
                            } else {
                                std::fs::File::create(&target).map(|_| ())
                            };
                            for p in &mut self.panes {
                                p.trigger_reload();
                            }
                            close = true;
                        }
                        if ui.button(t.btn_cancel).clicked() {
                            close = true;
                        }
                    });
                });
            if close {
                self.create_item_modal = None;
            } else if let Some((_, _, ref mut n)) = self.create_item_modal {
                *n = current_name;
            }
        }

        // 6. Rename Item Modal (F2)
        if let Some((orig_path, ref name_buf)) = self.rename_modal.clone() {
            let mut close = false;
            let mut new_name = name_buf.clone();
            egui::Window::new(t.edit_rename)
                .order(egui::Order::Foreground)
                .collapsible(false)
                .show(ctx, |ui| {
                    ui.text_edit_singleline(&mut new_name);
                    ui.horizontal(|ui| {
                        let confirm_rename_btn = if self.config.language == Language::ZhTw { "✅ 確認重新命名" } else { "✅ Rename" };
                        if ui.button(confirm_rename_btn).clicked() {
                            if let Some(parent) = orig_path.parent() {
                                let dst = parent.join(&new_name);
                                let _ = std::fs::rename(&orig_path, &dst);
                                for p in &mut self.panes {
                                    p.trigger_reload();
                                }
                            }
                            close = true;
                        }
                        if ui.button(t.btn_cancel).clicked() {
                            close = true;
                        }
                    });
                });
            if close {
                self.rename_modal = None;
            } else if let Some((_, ref mut n)) = self.rename_modal {
                *n = new_name;
            }
        }

        // 7. About Dialog
        if self.show_about_dialog {
            let mut open = self.show_about_dialog;
            egui::Window::new(t.dlg_about_title)
                .order(egui::Order::Foreground)
                .open(&mut open)
                .show(ctx, |ui| {
                    ui.horizontal(|ui| {
                        if let Some(ref tex) = self.app_icon_tex {
                            ui.add(
                                egui::Image::new(tex)
                                    .fit_to_exact_size(Vec2::new(48.0, 48.0))
                                    .rounding(10.0),
                            );
                        }
                        ui.vertical(|ui| {
                            ui.heading(t.about_heading);
                            ui.label(t.about_tagline);
                        });
                    });
                    ui.separator();
                    ui.label(t.about_f1);
                    ui.label(t.about_f2);
                    ui.label(t.about_f3);
                    ui.label(t.about_f4);
                    ui.label(t.about_f5);
                    ui.label(t.about_f6);
                    ui.separator();
                    ui.horizontal(|ui| {
                        ui.label(t.about_support_prompt);
                        if ui
                            .button(
                                RichText::new(t.about_support_btn)
                                    .color(Color32::from_rgb(255, 94, 91))
                                    .strong(),
                            )
                            .clicked()
                        {
                            let _ = open::that("https://ko-fi.com/aiohlala");
                        }
                    });
                });
            self.show_about_dialog = open;
        }

        // 8. Quick Access Manager Window
        if self.show_quick_access_manager {
            let mut open = self.show_quick_access_manager;
            let mut do_close = false;
            let is_zh = self.config.language == Language::ZhTw;
            egui::Window::new(if is_zh { "⚙ 管理常用資料夾 (Quick Access Manager)" } else { "⚙ Quick Access Manager" })
                .order(egui::Order::Foreground)
                .open(&mut open)
                .default_size([540.0, 420.0])
                .show(ctx, |ui| {
                    ui.label(if is_zh {
                        "💡 勾選項目以決定是否在側邊欄顯示。可隨意新增、刪除、重新命名或排序。"
                    } else {
                        "💡 Check/uncheck items to show/hide in the sidebar. Add, delete, or reorder custom folders."
                    });
                    ui.separator();

                    let mut item_to_remove = None;
                    let mut move_up_idx = None;
                    let mut move_down_idx = None;
                    let mut config_changed = false;

                    egui::ScrollArea::vertical().max_height(280.0).show(ui, |ui| {
                        let len = self.config.quick_access_items.len();
                        for (idx, item) in self.config.quick_access_items.iter_mut().enumerate() {
                            ui.horizontal(|ui| {
                                if ui.checkbox(&mut item.is_visible, "").on_hover_text(if is_zh { "勾選以在側邊欄顯示" } else { "Toggle visibility" }).changed() {
                                    config_changed = true;
                                }
                                ui.label(&item.icon);
                                if ui.add(egui::TextEdit::singleline(&mut item.name).desired_width(130.0)).changed() {
                                    config_changed = true;
                                }
                                ui.label(RichText::new(&item.path).small().color(Color32::GRAY));

                                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                                    if !item.is_builtin {
                                        if ui.small_button("🗑").on_hover_text(if is_zh { "刪除此資料夾" } else { "Delete" }).clicked() {
                                            item_to_remove = Some(item.id.clone());
                                        }
                                    } else {
                                        if !item.is_visible {
                                            if ui.small_button(if is_zh { "👁 顯示" } else { "Show" }).clicked() {
                                                item.is_visible = true;
                                                config_changed = true;
                                            }
                                        }
                                    }
                                    if idx < len - 1 && ui.small_button("▼").on_hover_text(if is_zh { "下移" } else { "Move Down" }).clicked() {
                                        move_down_idx = Some(idx);
                                    }
                                    if idx > 0 && ui.small_button("▲").on_hover_text(if is_zh { "上移" } else { "Move Up" }).clicked() {
                                        move_up_idx = Some(idx);
                                    }
                                });
                            });
                            ui.separator();
                        }
                    });

                    if let Some(id) = item_to_remove {
                        self.remove_quick_access_item(&id);
                    }
                    if let Some(idx) = move_up_idx {
                        self.config.quick_access_items.swap(idx, idx - 1);
                        config_changed = true;
                    }
                    if let Some(idx) = move_down_idx {
                        self.config.quick_access_items.swap(idx, idx + 1);
                        config_changed = true;
                    }

                    if config_changed {
                        let _ = self.config.save();
                    }

                    ui.add_space(8.0);
                    ui.separator();
                    ui.horizontal(|ui| {
                        if ui.button(if is_zh { "➕ 新增自訂資料夾..." } else { "➕ Add Folder..." }).clicked() {
                            let active_p = self.panes.get(self.active_pane_index()).map(|p| p.current_path.to_string_lossy().into_owned()).unwrap_or_default();
                            self.new_qa_path = active_p.clone();
                            self.new_qa_name = PathBuf::from(&active_p).file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
                            self.show_add_quick_access_modal = true;
                        }
                        if ui.button(if is_zh { "🔄 恢復預設項目" } else { "🔄 Reset Defaults" }).clicked() {
                            self.reset_quick_access_items();
                        }
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ui.button(if is_zh { "關閉" } else { "Close" }).clicked() {
                                do_close = true;
                            }
                        });
                    });
                });
            if do_close {
                open = false;
            }
            self.show_quick_access_manager = open;
        }

        // 9. Add Quick Access Modal
        if self.show_add_quick_access_modal {
            let mut open = self.show_add_quick_access_modal;
            let mut do_close = false;
            let is_zh = self.config.language == Language::ZhTw;
            egui::Window::new(if is_zh { "➕ 新增常用資料夾" } else { "➕ Add Quick Access Folder" })
                .order(egui::Order::Foreground)
                .open(&mut open)
                .default_size([440.0, 160.0])
                .show(ctx, |ui| {
                    ui.horizontal(|ui| {
                        ui.label(if is_zh { "名稱 (Name):" } else { "Name:" });
                        ui.text_edit_singleline(&mut self.new_qa_name);
                    });
                    ui.horizontal(|ui| {
                        ui.label(if is_zh { "路徑 (Path):" } else { "Path:" });
                        ui.text_edit_singleline(&mut self.new_qa_path);
                    });
                    ui.add_space(8.0);
                    ui.horizontal(|ui| {
                        if ui.button(if is_zh { "✅ 確定新增" } else { "✅ Add" }).clicked() {
                            let n = self.new_qa_name.clone();
                            let p = self.new_qa_path.clone();
                            self.add_quick_access_item(n, p);
                            do_close = true;
                        }
                        if ui.button(if is_zh { "取消" } else { "Cancel" }).clicked() {
                            do_close = true;
                        }
                    });
                });
            if do_close {
                open = false;
            }
            self.show_add_quick_access_modal = open;
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn render_this_pc_pane_view(
        &mut self,
        ui: &mut egui::Ui,
        pane_idx: usize,
        pane_id: usize,
        table_rect: Rect,
        table_clip: Rect,
        pointer_occluded: bool,
        newly_activated_id: &mut Option<usize>,
        hovered_rmb_target: &mut Option<(usize, Option<crate::fs_ops::FileEntry>)>,
    ) {
        let is_zh = self.config.language == Language::ZhTw;
        let is_dark = self.config.theme == AppTheme::ModernDark;
        let list_font = self.config.file_list_font_size;
        let mut nav_target: Option<PathBuf> = None;
        let mut spawn_target: Option<PathBuf> = None;
        let mut props_target: Option<PathBuf> = None;

        let mut sc_ui = ui.new_child(
            egui::UiBuilder::new()
                .max_rect(table_rect)
                .layout(egui::Layout::top_down(egui::Align::Min)),
        );
        sc_ui.set_clip_rect(table_clip);

        egui::ScrollArea::vertical()
            .id_salt(("this_pc_scroll", pane_id))
            .auto_shrink([false, false])
            .show(&mut sc_ui, |ui| {
                ui.add_space(6.0);

                // 1. System Folders
                ui.horizontal(|ui| {
                    ui.add_space(8.0);
                    ui.label(
                        RichText::new(if is_zh {
                            "📂 系統資料夾 (Folders)"
                        } else {
                            "📂 Folders"
                        })
                        .strong()
                        .size((list_font + 0.5).min(18.0))
                        .color(Color32::from_rgb(0, 120, 215)),
                    );
                });
                ui.add_space(4.0);

                let sys_folders: Vec<(&str, Option<PathBuf>)> = vec![
                    (if is_zh { "🖥 桌面 (Desktop)" } else { "🖥 Desktop" }, dirs::desktop_dir()),
                    (if is_zh { "📄 文件 (Documents)" } else { "📄 Documents" }, dirs::document_dir()),
                    (if is_zh { "⬇ 下載 (Downloads)" } else { "⬇ Downloads" }, dirs::download_dir()),
                    (if is_zh { "🖼 圖片 (Pictures)" } else { "🖼 Pictures" }, dirs::picture_dir()),
                    (if is_zh { "🎵 音樂 (Music)" } else { "🎵 Music" }, dirs::audio_dir()),
                    (if is_zh { "🎬 影片 (Videos)" } else { "🎬 Videos" }, dirs::video_dir()),
                ];

                let card_bg = if is_dark {
                    Color32::from_rgb(38, 42, 52)
                } else {
                    Color32::from_rgb(245, 248, 252)
                };
                let card_stroke = if is_dark {
                    Color32::from_rgb(65, 72, 88)
                } else {
                    Color32::from_rgb(210, 220, 232)
                };

                ui.horizontal_wrapped(|ui| {
                    ui.add_space(8.0);
                    for (label, maybe_p) in sys_folders {
                        let Some(p) = maybe_p else { continue; };
                        if !p.exists() {
                            continue;
                        }
                        let resp = ui.add(
                            egui::Button::new(RichText::new(label).size(list_font))
                                .fill(card_bg)
                                .stroke(Stroke::new(1.0, card_stroke))
                                .min_size(Vec2::new(155.0, 28.0)),
                        );
                        if resp.clicked() && !pointer_occluded {
                            *newly_activated_id = Some(pane_id);
                        }
                        if resp.double_clicked() && !pointer_occluded {
                            nav_target = Some(p.clone());
                        }
                        resp.context_menu(|ui| {
                            if ui.button(if is_zh { "📂 開啟" } else { "📂 Open" }).clicked() {
                                nav_target = Some(p.clone());
                                ui.close_menu();
                            }
                            if ui.button(if is_zh { "🗔 在新視窗開啟" } else { "🗔 Open in New Window" }).clicked() {
                                spawn_target = Some(p.clone());
                                ui.close_menu();
                            }
                            ui.separator();
                            if ui.button(if is_zh { "📋 內容 / 屬性 (Properties)" } else { "📋 Properties" }).clicked() {
                                props_target = Some(p.clone());
                                ui.close_menu();
                            }
                        });
                    }
                });

                ui.add_space(12.0);

                // 2. Local Disks with Total & Free Space
                ui.horizontal(|ui| {
                    ui.add_space(8.0);
                    ui.label(
                        RichText::new(if is_zh {
                            "🖴 裝置與磁碟機 (Devices and drives)"
                        } else {
                            "🖴 Devices and drives"
                        })
                        .strong()
                        .size((list_font + 0.5).min(18.0))
                        .color(Color32::from_rgb(0, 120, 215)),
                    );
                });
                ui.add_space(4.0);

                let disks = self.sys_disks.clone();
                if disks.is_empty() {
                    ui.horizontal(|ui| {
                        ui.add_space(14.0);
                        ui.label(RichText::new(if is_zh { "⏳ 正在偵測磁碟容量..." } else { "⏳ Detecting drives..." }).weak());
                    });
                } else {
                    for (label, mount, avail, total) in &disks {
                        let used = total.saturating_sub(*avail);
                        let frac = if *total > 0 {
                            (used as f32 / *total as f32).clamp(0.0, 1.0)
                        } else {
                            0.0
                        };
                        let bar_col = if frac > 0.90 {
                            Color32::from_rgb(215, 45, 45)
                        } else {
                            Color32::from_rgb(30, 136, 229)
                        };

                        ui.horizontal(|ui| {
                            ui.add_space(8.0);
                            let row_w = (table_rect.width() - 28.0).max(240.0);
                            let (r_rect, resp) = ui.allocate_exact_size(Vec2::new(row_w, 50.0), Sense::click());
                            let is_hov = resp.hovered();
                            let bg = if is_hov {
                                if is_dark { Color32::from_rgb(48, 56, 72) } else { Color32::from_rgb(228, 239, 252) }
                            } else {
                                card_bg
                            };
                            ui.painter().rect_filled(r_rect, 4.0, bg);
                            ui.painter().rect_stroke(r_rect, 4.0, Stroke::new(1.0, card_stroke));

                            // Icon + Label + Type
                            ui.painter().text(
                                Pos2::new(r_rect.min.x + 12.0, r_rect.min.y + 16.0),
                                egui::Align2::LEFT_CENTER,
                                format!("🖴  {}", label),
                                egui::FontId::proportional(list_font),
                                if is_dark { Color32::from_gray(235) } else { Color32::from_gray(25) },
                            );

                            let cap_txt = if *total > 0 {
                                if is_zh {
                                    format!(
                                        "可用 {} / 總容量 {} ({:.0}% 已使用)",
                                        format_size(*avail),
                                        format_size(*total),
                                        frac * 100.0
                                    )
                                } else {
                                    format!(
                                        "{} free of {} ({:.0}% used)",
                                        format_size(*avail),
                                        format_size(*total),
                                        frac * 100.0
                                    )
                                }
                            } else {
                                if is_zh { "本機磁碟 (容量偵測中...)" } else { "Local Disk" }.to_string()
                            };
                            ui.painter().text(
                                Pos2::new(r_rect.max.x - 12.0, r_rect.min.y + 16.0),
                                egui::Align2::RIGHT_CENTER,
                                cap_txt,
                                egui::FontId::proportional((list_font - 1.0).max(10.5)),
                                if is_dark { Color32::from_gray(180) } else { Color32::from_gray(90) },
                            );

                            // Capacity bar
                            let bar_rect = Rect::from_min_max(
                                Pos2::new(r_rect.min.x + 12.0, r_rect.min.y + 32.0),
                                Pos2::new(r_rect.max.x - 12.0, r_rect.min.y + 41.0),
                            );
                            ui.painter().rect_filled(
                                bar_rect,
                                3.0,
                                if is_dark { Color32::from_rgb(26, 28, 34) } else { Color32::from_rgb(220, 226, 234) },
                            );
                            if *total > 0 && frac > 0.0 {
                                let fill_w = (bar_rect.width() * frac).max(3.0);
                                let fill_rect = Rect::from_min_size(bar_rect.min, Vec2::new(fill_w, bar_rect.height()));
                                ui.painter().rect_filled(fill_rect, 3.0, bar_col);
                            }

                            if resp.clicked() && !pointer_occluded {
                                *newly_activated_id = Some(pane_id);
                            }
                            if resp.double_clicked() && !pointer_occluded {
                                nav_target = Some(mount.clone());
                            }
                            resp.context_menu(|ui| {
                                if ui.button(if is_zh { "📂 開啟磁碟機" } else { "📂 Open Drive" }).clicked() {
                                    nav_target = Some(mount.clone());
                                    ui.close_menu();
                                }
                                if ui.button(if is_zh { "🗔 在新視窗開啟" } else { "🗔 Open in New Window" }).clicked() {
                                    spawn_target = Some(mount.clone());
                                    ui.close_menu();
                                }
                                ui.separator();
                                if ui.button(if is_zh { "📋 內容 / 屬性 (Properties)" } else { "📋 Properties" }).clicked() {
                                    props_target = Some(mount.clone());
                                    ui.close_menu();
                                }
                            });
                        });
                        ui.add_space(4.0);
                    }
                }

                // 3. Network Locations
                let mut all_shares = self.system_smb_shares.clone();
                all_shares.extend(self.config.smb_bookmarks.clone());
                if !all_shares.is_empty() {
                    ui.add_space(10.0);
                    ui.horizontal(|ui| {
                        ui.add_space(8.0);
                        ui.label(
                            RichText::new(if is_zh {
                                "🌐 網路位置 (Network locations)"
                            } else {
                                "🌐 Network locations"
                            })
                            .strong()
                            .size((list_font + 0.5).min(18.0))
                            .color(Color32::from_rgb(0, 120, 215)),
                        );
                    });
                    ui.add_space(4.0);

                    for smb in all_shares {
                        if self.config.hidden_network_shares.contains(&smb.unc_or_mount_path) {
                            continue;
                        }
                        ui.horizontal(|ui| {
                            ui.add_space(12.0);
                            draw_smb_status_icon(ui, &smb.status);
                            let status_lbl = match &smb.status {
                                SmbStatus::Online(_) => if is_zh { "已連線" } else { "Connected" },
                                SmbStatus::Offline(_) => if is_zh { "已中斷連線的網路磁碟機" } else { "Disconnected Network Drive" },
                                _ => if is_zh { "偵測中..." } else { "Probing..." },
                            };
                            let btn_txt = format!("{}  ({}) — {}", smb.name, smb.unc_or_mount_path, status_lbl);
                            let resp = ui.selectable_label(false, RichText::new(btn_txt).size(list_font));
                            if resp.clicked() && !pointer_occluded {
                                *newly_activated_id = Some(pane_id);
                            }
                            if resp.double_clicked() && !pointer_occluded {
                                nav_target = Some(PathBuf::from(&smb.unc_or_mount_path));
                            }
                        });
                    }
                }

                // Background right-click support
                let bg_rem = ui.allocate_rect(ui.available_rect_before_wrap(), Sense::click());
                if bg_rem.hovered() && !pointer_occluded {
                    *hovered_rmb_target = Some((pane_id, None));
                }
            });

        if let Some(target) = nav_target {
            if let Some(p) = self.panes.get_mut(pane_idx) {
                p.navigate_to(target, true);
            }
        }
        if let Some(target) = spawn_target {
            self.spawn_new_pane(target);
        }
        if let Some(target) = props_target {
            self.open_properties_for(&target);
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn render_pane_alt_view(
        &mut self,
        ui: &mut egui::Ui,
        pane_idx: usize,
        pane_id: usize,
        content_rect: Rect,
        table_clip: Rect,
        pointer_occluded: bool,
        newly_activated_id: &mut Option<usize>,
        hovered_rmb_target: &mut Option<(usize, Option<crate::fs_ops::FileEntry>)>,
        preview_req: &mut Option<PathBuf>,
    ) {
        let view_mode = self.panes[pane_idx].view_mode;
        let is_dark = self.config.theme == AppTheme::ModernDark;
        let list_font = self.config.file_list_font_size;
        let thumb_sz = self.panes[pane_idx].thumbnail_size.clamp(48.0, 220.0);

        let (cell_w, cell_h, icon_sz) = match view_mode {
            PaneViewMode::List => (220.0, (list_font * 1.65).clamp(22.0, 34.0), 16.0),
            PaneViewMode::SmallIcons => (150.0, 28.0, 18.0),
            PaneViewMode::LargeIcons => (112.0, 92.0, 44.0),
            PaneViewMode::Thumbnails => (thumb_sz + 20.0, thumb_sz + 36.0, thumb_sz * 0.55),
            PaneViewMode::Details => (200.0, 24.0, 16.0),
        };

        let mut view_ui = ui.new_child(
            egui::UiBuilder::new()
                .max_rect(content_rect)
                .layout(egui::Layout::top_down(egui::Align::Min)),
        );
        let view_clip = content_rect.intersect(table_clip);
        view_ui.set_clip_rect(view_clip);

        let ctx = ui.ctx().clone();
        let filtered_len = self.panes[pane_idx].filtered_indices.len();
        let mut double_clicked_nav: Option<PathBuf> = None;
        let mut double_clicked_open: Option<PathBuf> = None;

        egui::ScrollArea::vertical()
            .id_salt(("alt_view_scroll", pane_id, format!("{:?}", view_mode)))
            .auto_shrink([false, false])
            .show(&mut view_ui, |ui| {
                let avail_w = (content_rect.width() - 18.0).max(cell_w);
                let cols = ((avail_w / (cell_w + 6.0)).floor() as usize).max(1);
                let total_rows = (filtered_len + cols - 1) / cols;

                for r in 0..total_rows {
                    ui.horizontal(|ui| {
                        ui.add_space(4.0);
                        for c in 0..cols {
                            let row_idx = r * cols + c;
                            if row_idx >= filtered_len {
                                break;
                            }
                            let entry_idx = self.panes[pane_idx].filtered_indices[row_idx];
                            let entry = self.panes[pane_idx].entries[entry_idx].clone();
                            let is_selected = self.panes[pane_idx].selected_paths.contains(&entry.path);

                            let (rect, resp) = ui.allocate_exact_size(
                                Vec2::new(cell_w, cell_h),
                                Sense::click_and_drag(),
                            );
                            let is_hov = resp.hovered() && !pointer_occluded;
                            if is_hov {
                                *hovered_rmb_target = Some((pane_id, Some(entry.clone())));
                            }

                            let cell_painter = ui.painter().with_clip_rect(rect.intersect(view_clip));
                            let bg_col = if is_selected {
                                if is_dark { Color32::from_rgb(38, 82, 138) } else { Color32::from_rgb(204, 232, 255) }
                            } else if is_hov {
                                if is_dark { Color32::from_rgb(44, 50, 62) } else { Color32::from_rgb(232, 242, 252) }
                            } else {
                                Color32::TRANSPARENT
                            };
                            if bg_col != Color32::TRANSPARENT {
                                cell_painter.rect_filled(rect, 4.0, bg_col);
                            }
                            if is_selected {
                                cell_painter.rect_stroke(
                                    rect,
                                    4.0,
                                    Stroke::new(1.2, Color32::from_rgb(0, 120, 215)),
                                );
                            }

                            let text_col = if is_dark {
                                Color32::from_gray(235)
                            } else {
                                Color32::from_gray(25)
                            };
                            match view_mode {
                                PaneViewMode::List | PaneViewMode::SmallIcons => {
                                    let v_sz = icon_sz.clamp(13.0, 20.0);
                                    let v_w = (v_sz * 1.18).ceil();
                                    let icon_rect = Rect::from_center_size(
                                        Pos2::new(rect.min.x + 6.0 + v_w * 0.5, rect.center().y),
                                        Vec2::new(v_w, v_sz),
                                    );
                                    paint_entry_vector_icon(
                                        &cell_painter,
                                        icon_rect,
                                        entry.is_dir,
                                        &entry.extension,
                                        is_dark && is_selected,
                                        is_dark,
                                    );
                                    let disp = truncate_str_display_width(
                                        &entry.display_name,
                                        (cell_w - 34.0).max(24.0),
                                        list_font,
                                    );
                                    cell_painter.text(
                                        Pos2::new(rect.min.x + 28.0, rect.center().y),
                                        egui::Align2::LEFT_CENTER,
                                        disp,
                                        egui::FontId::proportional(list_font),
                                        text_col,
                                    );
                                }
                                PaneViewMode::LargeIcons | PaneViewMode::Thumbnails => {
                                    let box_h = if view_mode == PaneViewMode::Thumbnails {
                                        thumb_sz
                                    } else {
                                        52.0
                                    };
                                    let preview_rect = Rect::from_min_size(
                                        Pos2::new(rect.min.x + 6.0, rect.min.y + 4.0),
                                        Vec2::new(rect.width() - 12.0, box_h),
                                    );

                                    let is_img = !entry.is_dir
                                        && matches!(
                                            entry.extension.as_str(),
                                            "png" | "jpg" | "jpeg" | "gif" | "bmp" | "webp" | "ico" | "tiff" | "tif"
                                        );

                                    let mut drew_tex = false;
                                    if view_mode == PaneViewMode::Thumbnails && is_img {
                                        if let Some(tex) = self.thumb_textures.get(&entry.path) {
                                            let [tw, th] = tex.size();
                                            if tw > 0 && th > 0 {
                                                let scale = (preview_rect.width() / tw as f32)
                                                    .min(preview_rect.height() / th as f32)
                                                    .min(1.0);
                                                let draw_sz = Vec2::new(tw as f32 * scale, th as f32 * scale);
                                                let draw_rect = Rect::from_center_size(preview_rect.center(), draw_sz);
                                                cell_painter.image(
                                                    tex.id(),
                                                    draw_rect,
                                                    Rect::from_min_max(Pos2::ZERO, Pos2::new(1.0, 1.0)),
                                                    Color32::WHITE,
                                                );
                                                drew_tex = true;
                                            }
                                        } else {
                                            self.request_thumbnail(&entry.path);
                                        }
                                    }

                                    if !drew_tex {
                                        let max_h = (preview_rect.height() - 4.0).max(24.0);
                                        let max_w = (preview_rect.width() - 4.0).max(24.0);
                                        let v_h = icon_sz.clamp(28.0, 84.0).min(max_h);
                                        let v_w = (v_h * 1.18).min(max_w);
                                        let icon_rect = Rect::from_center_size(
                                            preview_rect.center(),
                                            Vec2::new(v_w, v_h),
                                        );
                                        paint_entry_vector_icon(
                                            &cell_painter,
                                            icon_rect,
                                            entry.is_dir,
                                            &entry.extension,
                                            is_dark && is_selected,
                                            is_dark,
                                        );
                                    }

                                    let lbl_font = (list_font - 1.0).clamp(10.5, 14.5);
                                    let disp = truncate_str_display_width(
                                        &entry.display_name,
                                        (rect.width() - 10.0).max(24.0),
                                        lbl_font,
                                    );
                                    cell_painter.text(
                                        Pos2::new(rect.center().x, rect.max.y - 14.0),
                                        egui::Align2::CENTER_CENTER,
                                        disp,
                                        egui::FontId::proportional(lbl_font),
                                        text_col,
                                    );
                                }
                                PaneViewMode::Details => {}
                            }

                            if (resp.clicked() || resp.drag_started() || resp.is_pointer_button_down_on())
                                && !pointer_occluded
                            {
                                *newly_activated_id = Some(pane_id);
                            }
                            if resp.clicked() && !pointer_occluded {
                                self.context_menu = None;
                                for (i, p) in self.panes.iter_mut().enumerate() {
                                    if i != pane_idx {
                                        p.selected_paths.clear();
                                        p.last_clicked_idx = None;
                                    }
                                }
                                let ctrl = ctx.input(|i| i.modifiers.command || i.modifiers.ctrl);
                                let shift = ctx.input(|i| i.modifiers.shift);
                                if shift {
                                    if let Some(anchor) = self.panes[pane_idx].last_clicked_idx {
                                        let lo = anchor.min(row_idx);
                                        let hi = anchor.max(row_idx);
                                        if !ctrl {
                                            self.panes[pane_idx].selected_paths.clear();
                                        }
                                        for r_i in lo..=hi {
                                            if let Some(&e_i) = self.panes[pane_idx].filtered_indices.get(r_i) {
                                                if let Some(p_clone) = self.panes[pane_idx].entries.get(e_i).map(|e| e.path.clone()) {
                                                    self.panes[pane_idx].selected_paths.insert(p_clone);
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    if !ctrl {
                                        self.panes[pane_idx].selected_paths.clear();
                                        self.panes[pane_idx].selected_paths.insert(entry.path.clone());
                                    } else if !self.panes[pane_idx].selected_paths.remove(&entry.path) {
                                        self.panes[pane_idx].selected_paths.insert(entry.path.clone());
                                    }
                                    self.panes[pane_idx].last_clicked_idx = Some(row_idx);
                                }
                                *preview_req = Some(entry.path.clone());
                            }
                            if resp.double_clicked() && !pointer_occluded {
                                *preview_req = Some(entry.path.clone());
                                if entry.is_dir {
                                    double_clicked_nav = Some(entry.path.clone());
                                } else {
                                    double_clicked_open = Some(entry.path.clone());
                                }
                            }
                        }
                    });
                    ui.add_space(4.0);
                }

                let rem_rect = ui.available_rect_before_wrap();
                if rem_rect.height() > 0.0 && rem_rect.width() > 0.0 {
                    let bg_resp = ui.allocate_rect(rem_rect, Sense::click());
                    if bg_resp.hovered() && !pointer_occluded && hovered_rmb_target.is_none() {
                        *hovered_rmb_target = Some((pane_id, None));
                    }
                    if bg_resp.clicked() && !pointer_occluded {
                        *newly_activated_id = Some(pane_id);
                        self.panes[pane_idx].selected_paths.clear();
                    }
                }
            });

        if !pointer_occluded && hovered_rmb_target.is_none() {
            if let Some(ppos) = ctx.input(|i| i.pointer.latest_pos()) {
                if view_clip.contains(ppos) {
                    *hovered_rmb_target = Some((pane_id, None));
                }
            }
        }

        if let Some(nav_p) = double_clicked_nav {
            if let Some(p) = self.panes.get_mut(pane_idx) {
                p.navigate_to(nav_p, true);
            }
        }
        if let Some(open_p) = double_clicked_open {
            let _ = open::that(&open_p);
        }
    }

    fn render_properties_modal(&mut self, ctx: &egui::Context) {
        let Some(ref modal) = self.properties_modal else {
            return;
        };
        let is_zh = self.config.language == Language::ZhTw;
        let title = if is_zh {
            format!("📋 內容 (Properties) - {}", modal.display_name)
        } else {
            format!("📋 Properties - {}", modal.display_name)
        };
        let mut open = true;
        let mut close_clicked = false;
        let mut mac_get_info_path: Option<PathBuf> = None;

        egui::Window::new(title)
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .default_width(380.0)
            .anchor(egui::Align2::CENTER_CENTER, Vec2::ZERO)
            .show(ctx, |ui| {
                ui.add_space(4.0);
                ui.label(RichText::new(&modal.display_name).strong().size(15.0));
                ui.separator();

                egui::Grid::new("props_grid")
                    .num_columns(2)
                    .spacing([14.0, 6.0])
                    .show(ui, |ui| {
                        ui.label(RichText::new(if is_zh { "類型:" } else { "Type:" }).weak());
                        ui.label(&modal.item_type);
                        ui.end_row();

                        ui.label(RichText::new(if is_zh { "位置:" } else { "Location:" }).weak());
                        ui.label(&modal.location);
                        ui.end_row();

                        if let Some((total, avail)) = modal.disk_total_avail {
                            let used = total.saturating_sub(avail);
                            ui.label(RichText::new(if is_zh { "總容量:" } else { "Capacity:" }).weak());
                            ui.label(format!("{} ({} bytes)", format_size(total), total));
                            ui.end_row();

                            ui.label(RichText::new(if is_zh { "已使用空間:" } else { "Used space:" }).weak());
                            ui.label(format!("{} ({} bytes)", format_size(used), used));
                            ui.end_row();

                            ui.label(RichText::new(if is_zh { "可用空間:" } else { "Free space:" }).weak());
                            ui.label(format!("{} ({} bytes)", format_size(avail), avail));
                            ui.end_row();
                        } else {
                            ui.label(RichText::new(if is_zh { "大小:" } else { "Size:" }).weak());
                            let sz_txt = if modal.stats.is_complete {
                                format!("{} ({} bytes)", format_size(modal.stats.total_bytes), modal.stats.total_bytes)
                            } else {
                                format!("{} (⏳ 計算中...)", format_size(modal.stats.total_bytes))
                            };
                            ui.label(sz_txt);
                            ui.end_row();

                            if modal.stats.folder_count > 0 || modal.stats.file_count > 1 || !modal.stats.is_complete {
                                ui.label(RichText::new(if is_zh { "包含:" } else { "Contains:" }).weak());
                                ui.label(if is_zh {
                                    format!("{} 個檔案, {} 個資料夾", modal.stats.file_count, modal.stats.folder_count)
                                } else {
                                    format!("{} Files, {} Folders", modal.stats.file_count, modal.stats.folder_count)
                                });
                                ui.end_row();
                            }
                        }

                        ui.label(RichText::new(if is_zh { "建立時間:" } else { "Created:" }).weak());
                        ui.label(&modal.created_str);
                        ui.end_row();

                        ui.label(RichText::new(if is_zh { "修改時間:" } else { "Modified:" }).weak());
                        ui.label(&modal.modified_str);
                        ui.end_row();

                        ui.label(RichText::new(if is_zh { "屬性:" } else { "Attributes:" }).weak());
                        ui.horizontal(|ui| {
                            let mut ro = modal.is_readonly;
                            let mut hd = modal.is_hidden;
                            ui.add_enabled(false, egui::Checkbox::new(&mut ro, if is_zh { "唯讀" } else { "Read-only" }));
                            ui.add_enabled(false, egui::Checkbox::new(&mut hd, if is_zh { "隱藏" } else { "Hidden" }));
                        });
                        ui.end_row();
                    });

                ui.add_space(10.0);
                ui.separator();
                ui.horizontal(|ui| {
                    #[cfg(target_os = "macos")]
                    if ui
                        .button(if is_zh { "🔍 開啟 Finder 簡介" } else { "🔍 Finder Get Info" })
                        .clicked()
                    {
                        mac_get_info_path = Some(modal.path.clone());
                    }
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.button(if is_zh { "確定" } else { "OK" }).clicked() {
                            close_clicked = true;
                        }
                    });
                });
            });

        if let Some(p) = mac_get_info_path {
            crate::fs_ops::open_macos_get_info(&p);
        }
        if !open || close_clicked {
            self.properties_modal = None;
        }
    }

    fn render_perm_delete_modal(&mut self, ctx: &egui::Context) {
        let Some(targets) = self.perm_delete_modal.clone() else {
            return;
        };
        if targets.is_empty() {
            self.perm_delete_modal = None;
            return;
        }
        let is_zh = self.config.language == Language::ZhTw;
        let title = if is_zh {
            "⚠ 永久刪除確認 (Shift+Del)"
        } else {
            "⚠ Confirm Permanent Delete (Shift+Del)"
        };
        let mut open = true;
        let mut confirm = false;
        let mut cancel = false;

        if ctx.input(|i| i.key_pressed(egui::Key::Escape)) {
            cancel = true;
        } else if ctx.input(|i| i.key_pressed(egui::Key::Enter)) {
            confirm = true;
        }

        egui::Window::new(title)
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
            .order(egui::Order::Foreground)
            .default_width(420.0)
            .show(ctx, |ui| {
                let cnt = targets.len();
                let header = if is_zh {
                    format!(
                        "確定要永久刪除這 {} 個項目嗎？此操作將略過資源回收桶，無法還原！",
                        cnt
                    )
                } else {
                    format!(
                        "Are you sure you want to permanently delete {} item(s)? This bypasses Trash/Recycle Bin and cannot be undone!",
                        cnt
                    )
                };
                ui.label(
                    RichText::new(header)
                        .strong()
                        .color(Color32::from_rgb(220, 60, 60)),
                );
                ui.add_space(6.0);
                egui::Frame::group(ui.style()).show(ui, |ui| {
                    ui.set_min_width(380.0);
                    let is_dark_bg = self.config.theme == AppTheme::ModernDark;
                    for p in targets.iter().take(8) {
                        let name = p
                            .file_name()
                            .map(|n| n.to_string_lossy().into_owned())
                            .unwrap_or_else(|| p.to_string_lossy().into_owned());
                        let is_d = p.is_dir();
                        let ext = p
                            .extension()
                            .and_then(|e| e.to_str())
                            .unwrap_or_default()
                            .to_ascii_lowercase();
                        ui.horizontal(|ui| {
                            if is_d {
                                draw_finder_folder_widget(ui, 13.5, false, false);
                            } else {
                                draw_finder_file_widget(ui, 13.5, &ext, false, is_dark_bg);
                            }
                            ui.label(name);
                        });
                    }
                    if cnt > 8 {
                        ui.weak(if is_zh {
                            format!("... 以及其他 {} 個項目", cnt - 8)
                        } else {
                            format!("... and {} more item(s)", cnt - 8)
                        });
                    }
                });
                ui.add_space(10.0);
                ui.horizontal(|ui| {
                    let confirm_lbl = if is_zh {
                        "🔥 確認永久刪除 (Enter)"
                    } else {
                        "🔥 Permanently Delete (Enter)"
                    };
                    if ui
                        .button(
                            RichText::new(confirm_lbl)
                                .strong()
                                .color(Color32::from_rgb(220, 45, 45)),
                        )
                        .clicked()
                    {
                        confirm = true;
                    }
                    let cancel_lbl = if is_zh { "取消 (Esc)" } else { "Cancel (Esc)" };
                    if ui.button(cancel_lbl).clicked() {
                        cancel = true;
                    }
                });
            });

        if confirm {
            self.perm_delete_modal = None;
            self.execute_permanent_delete(&targets);
        } else if cancel || !open {
            self.perm_delete_modal = None;
        }
    }
}

fn truncate_str_display_width(s: &str, max_px: f32, font_px: f32) -> String {
    let ellipsis_w = font_px * 0.9;
    let total_w: f32 = s
        .chars()
        .map(|c| if c.is_ascii() { font_px * 0.56 } else { font_px * 1.02 })
        .sum();
    if total_w <= max_px {
        return s.to_string();
    }
    let budget = (max_px - ellipsis_w).max(font_px);
    let mut acc = 0.0f32;
    let mut out = String::new();
    for c in s.chars() {
        let cw = if c.is_ascii() { font_px * 0.56 } else { font_px * 1.02 };
        if acc + cw > budget {
            break;
        }
        acc += cw;
        out.push(c);
    }
    out.push('…');
    out
}

fn toggle_sort(pane: &mut MdiChildPane, col: SortColumn, show_hidden: bool) {
    if pane.sort_col == col {
        pane.sort_asc = !pane.sort_asc;
    } else {
        pane.sort_col = col;
        pane.sort_asc = true;
    }
    pane.apply_sort_and_filter(show_hidden);
}

fn expand_env_vars(input: &str) -> String {
    if input.starts_with('~') {
        if let Some(h) = dirs::home_dir() {
            return input.replacen('~', &h.to_string_lossy(), 1);
        }
    }
    input.to_string()
}

fn open_terminal_at(dir: & std::path::Path) {
    #[cfg(target_os = "windows")]
    {
        let _ = std::process::Command::new("cmd")
            .args(["/C", "start", "cmd"])
            .current_dir(dir)
            .spawn();
    }
    #[cfg(target_os = "macos")]
    {
        let _ = std::process::Command::new("open")
            .args(["-a", "Terminal", &dir.to_string_lossy()])
            .spawn();
    }
    #[cfg(target_os = "linux")]
    {
        let _ = std::process::Command::new("x-terminal-emulator")
            .current_dir(dir)
            .spawn();
    }
}

fn open_system_folder_options() {
    #[cfg(target_os = "windows")]
    {
        // 1. Universal Windows File Explorer Options dialog ("control folders")
        if std::process::Command::new("control")
            .arg("folders")
            .spawn()
            .is_err()
        {
            // 2. Direct fallback to shell32 Options_RunDLL
            let _ = std::process::Command::new("rundll32.exe")
                .args(["shell32.dll,Options_RunDLL", "0"])
                .spawn();
        }
    }
    #[cfg(target_os = "macos")]
    {
        let _ = std::process::Command::new("osascript")
            .args([
                "-e",
                "tell application \"Finder\" to activate",
                "-e",
                "tell application \"System Events\" to tell process \"Finder\" to keystroke \",\" using command down",
            ])
            .spawn();
    }
    #[cfg(target_os = "linux")]
    {
        let _ = std::process::Command::new("nautilus")
            .arg("--preferences")
            .spawn();
    }
}

fn export_windows_shell_reg() -> Result<PathBuf, String> {
    let out_path = std::env::current_dir()
        .unwrap_or_else(|_| PathBuf::from("."))
        .join("mine_windows_shell_context_menu.reg");
    let reg_content = r#"Windows Registry Editor Version 5.00

; MINE (Multiple Interface Next-gen Explorer) - MDIE Successor
; Adds "Open in MINE" to Windows 10 / 11 Folder Context Menu

[HKEY_CURRENT_USER\Software\Classes\Directory\shell\MINE]
@="Open in MINE File Manager (以 MINE 開啟)"
"Icon"="mine.exe"

[HKEY_CURRENT_USER\Software\Classes\Directory\shell\MINE\command]
@="\"mine.exe\" \"%1\""

[HKEY_CURRENT_USER\Software\Classes\Directory\Background\shell\MINE]
@="Open in MINE File Manager (以 MINE 開啟)"
"Icon"="mine.exe"

[HKEY_CURRENT_USER\Software\Classes\Directory\Background\shell\MINE\command]
@="\"mine.exe\" \"%V\""
"#;
    std::fs::write(&out_path, reg_content).map_err(|e| e.to_string())?;
    Ok(out_path)
}

/// Paints a crisp, font-independent vector status badge:
/// - Online: Vivid green glowing circle
/// - Offline: Vivid red circle with a crisp white 'X' cross (like Windows Explorer disconnected network drive)
/// - Probing/Unknown: Amber circle
fn draw_smb_status_icon(ui: &mut egui::Ui, status: &SmbStatus) {
    let (rect, _) = ui.allocate_exact_size(Vec2::new(14.0, 14.0), Sense::hover());
    let center = rect.center();
    let painter = ui.painter();
    match status {
        SmbStatus::Online(_) => {
            painter.circle_filled(center, 5.8, Color32::from_rgb(30, 215, 90));
            painter.circle_stroke(center, 5.8, Stroke::new(1.0, Color32::from_rgb(15, 130, 50)));
            // Subtle glossy highlight dot
            painter.circle_filled(
                center - Vec2::new(1.8, 1.8),
                1.6,
                Color32::from_rgb(170, 255, 195),
            );
        }
        SmbStatus::Offline(_) => {
            painter.circle_filled(center, 6.2, Color32::from_rgb(230, 45, 45));
            painter.circle_stroke(center, 6.2, Stroke::new(1.0, Color32::from_rgb(150, 20, 20)));
            let d = 2.8;
            let white_stroke = Stroke::new(1.8, Color32::WHITE);
            painter.line_segment(
                [center - Vec2::new(d, d), center + Vec2::new(d, d)],
                white_stroke,
            );
            painter.line_segment(
                [center + Vec2::new(-d, d), center + Vec2::new(d, -d)],
                white_stroke,
            );
        }
        SmbStatus::Probing | SmbStatus::Unknown => {
            painter.circle_filled(center, 5.2, Color32::from_rgb(235, 175, 35));
            painter.circle_stroke(center, 5.2, Stroke::new(1.0, Color32::from_rgb(160, 110, 15)));
        }
    }
}

/// Paints a crisp macOS Finder-style two-tone solid blue folder vector icon.
fn paint_finder_folder_icon(
    painter: &egui::Painter,
    rect: Rect,
    is_open: bool,
    light_border: bool,
) {
    let h = rect.height().min(rect.width() / 1.2).max(8.0);
    let w = (h * 1.2).min(rect.width());
    let r = Rect::from_center_size(rect.center(), Vec2::new(w, h));

    let back_col = if light_border {
        Color32::from_rgb(22, 108, 198)
    } else {
        Color32::from_rgb(28, 132, 224)
    };
    let front_col = Color32::from_rgb(92, 198, 255);
    let front_bottom_col = Color32::from_rgb(56, 174, 245);
    let bevel_col = Color32::from_rgb(172, 232, 255);
    let outline_col = if light_border {
        Color32::from_rgb(225, 245, 255)
    } else {
        Color32::from_rgb(20, 102, 182)
    };
    let cr = (w * 0.11).clamp(1.5, 6.0);
    let stroke_w = (w * 0.05).clamp(0.8, 1.5);

    let tab_r = Rect::from_min_max(r.min, Pos2::new(r.min.x + w * 0.44, r.min.y + h * 0.36));
    let back_r = Rect::from_min_max(
        Pos2::new(r.min.x, r.min.y + h * 0.13),
        Pos2::new(r.max.x, r.max.y - h * 0.08),
    );
    painter.rect_filled(tab_r, cr * 0.85, back_col);
    painter.rect_filled(back_r, cr, back_col);
    painter.rect_stroke(tab_r, cr * 0.85, Stroke::new(stroke_w * 0.75, outline_col));
    painter.rect_stroke(back_r, cr, Stroke::new(stroke_w * 0.75, outline_col));
    let inner_fill = Rect::from_min_max(
        Pos2::new(tab_r.min.x + stroke_w, tab_r.min.y + stroke_w),
        Pos2::new(tab_r.max.x - stroke_w, back_r.min.y + h * 0.14),
    );
    painter.rect_filled(inner_fill, 0.0, back_col);

    if is_open {
        let sheet_r = Rect::from_min_max(
            Pos2::new(r.min.x + w * 0.10, r.min.y + h * 0.21),
            Pos2::new(r.max.x - w * 0.10, r.max.y - h * 0.15),
        );
        painter.rect_filled(sheet_r, (cr * 0.4).max(1.0), Color32::from_rgb(244, 249, 255));

        let skew = w * 0.09;
        let top_y = r.min.y + h * 0.34;
        let pts = vec![
            Pos2::new(r.min.x + skew * 0.5, top_y),
            Pos2::new(r.max.x + skew * 0.4, top_y),
            Pos2::new(r.max.x - skew * 0.4, r.max.y),
            Pos2::new(r.min.x, r.max.y),
        ];
        painter.add(egui::Shape::convex_polygon(
            pts,
            front_col,
            Stroke::new(stroke_w, outline_col),
        ));
        painter.line_segment(
            [
                Pos2::new(r.min.x + skew * 0.65, top_y + stroke_w),
                Pos2::new(r.max.x + skew * 0.25, top_y + stroke_w),
            ],
            Stroke::new((stroke_w * 0.9).max(0.8), bevel_col),
        );
    } else {
        let front_r = Rect::from_min_max(Pos2::new(r.min.x, r.min.y + h * 0.25), r.max);
        painter.rect_filled(front_r, cr, front_col);
        let lower_r = Rect::from_min_max(
            Pos2::new(front_r.min.x + stroke_w * 0.5, front_r.center().y),
            Pos2::new(front_r.max.x - stroke_w * 0.5, front_r.max.y - stroke_w * 0.5),
        );
        painter.rect_filled(lower_r, cr * 0.7, front_bottom_col);
        painter.line_segment(
            [
                Pos2::new(front_r.min.x + cr * 0.55, front_r.min.y + stroke_w * 0.9),
                Pos2::new(front_r.max.x - cr * 0.55, front_r.min.y + stroke_w * 0.9),
            ],
            Stroke::new((stroke_w * 0.9).max(0.8), bevel_col),
        );
        painter.rect_stroke(front_r, cr, Stroke::new(stroke_w, outline_col));
    }
}

/// Paints a crisp solid dog-eared document icon for non-directory files so files and folders never look ambiguous.
fn paint_finder_file_icon(
    painter: &egui::Painter,
    rect: Rect,
    ext: &str,
    light_border: bool,
    is_dark: bool,
) {
    let h = rect.height().min(rect.width() / 0.80).max(8.0);
    let w = (h * 0.80).min(rect.width());
    let r = Rect::from_center_size(rect.center(), Vec2::new(w, h));

    let page_fill = if is_dark && !light_border {
        Color32::from_rgb(232, 238, 246)
    } else {
        Color32::from_rgb(250, 252, 255)
    };
    let page_stroke = if light_border {
        Color32::from_rgb(210, 232, 255)
    } else if is_dark {
        Color32::from_rgb(125, 138, 158)
    } else {
        Color32::from_rgb(150, 162, 178)
    };
    let fold = (w * 0.30).max(3.0);
    let sw = (w * 0.06).clamp(0.8, 1.4);

    let pts = vec![
        r.min,
        Pos2::new(r.max.x - fold, r.min.y),
        Pos2::new(r.max.x, r.min.y + fold),
        r.max,
        Pos2::new(r.min.x, r.max.y),
    ];
    painter.add(egui::Shape::convex_polygon(
        pts,
        page_fill,
        Stroke::new(sw, page_stroke),
    ));

    let fold_pts = vec![
        Pos2::new(r.max.x - fold, r.min.y),
        Pos2::new(r.max.x - fold, r.min.y + fold),
        Pos2::new(r.max.x, r.min.y + fold),
    ];
    painter.add(egui::Shape::convex_polygon(
        fold_pts,
        Color32::from_rgb(212, 222, 235),
        Stroke::new(sw * 0.8, page_stroke),
    ));

    match ext {
        "png" | "jpg" | "jpeg" | "gif" | "bmp" | "webp" | "ico" | "tiff" | "tif" | "avif" | "svg" => {
            let box_r = Rect::from_min_max(
                Pos2::new(r.min.x + w * 0.18, r.min.y + h * 0.42),
                Pos2::new(r.max.x - w * 0.18, r.max.y - h * 0.18),
            );
            painter.rect_filled(box_r, 1.0, Color32::from_rgb(46, 178, 138));
        }
        "mp4" | "mkv" | "avi" | "mov" | "webm" => {
            let cy = r.min.y + h * 0.62;
            let tri = vec![
                Pos2::new(r.center().x - w * 0.14, cy - h * 0.16),
                Pos2::new(r.center().x + w * 0.22, cy),
                Pos2::new(r.center().x - w * 0.14, cy + h * 0.16),
            ];
            painter.add(egui::Shape::convex_polygon(
                tri,
                Color32::from_rgb(138, 92, 235),
                Stroke::NONE,
            ));
        }
        "mp3" | "wav" | "flac" | "ogg" | "m4a" => {
            let col = Color32::from_rgb(232, 90, 118);
            for (k, frac) in [0.35f32, 0.58, 0.42].iter().enumerate() {
                let x = r.min.x + w * (0.28 + k as f32 * 0.20);
                painter.line_segment(
                    [
                        Pos2::new(x, r.max.y - h * 0.22),
                        Pos2::new(x, r.max.y - h * (0.22 + *frac * 0.45)),
                    ],
                    Stroke::new((w * 0.11).max(1.4), col),
                );
            }
        }
        "zip" | "rar" | "7z" | "tar" | "gz" | "bz2" | "xz" => {
            let band = Rect::from_min_max(
                Pos2::new(r.min.x + w * 0.18, r.min.y + h * 0.48),
                Pos2::new(r.max.x - w * 0.18, r.min.y + h * 0.72),
            );
            painter.rect_filled(band, 1.0, Color32::from_rgb(218, 150, 35));
        }
        "pdf" => {
            let band = Rect::from_min_max(
                Pos2::new(r.min.x + w * 0.18, r.min.y + h * 0.48),
                Pos2::new(r.max.x - w * 0.18, r.min.y + h * 0.74),
            );
            painter.rect_filled(band, 1.0, Color32::from_rgb(215, 58, 58));
        }
        "exe" | "msi" | "bat" | "sh" | "cmd" | "ps1" => {
            let band = Rect::from_min_max(
                Pos2::new(r.min.x + w * 0.22, r.min.y + h * 0.46),
                Pos2::new(r.max.x - w * 0.22, r.max.y - h * 0.22),
            );
            painter.rect_filled(band, 1.2, Color32::from_rgb(78, 96, 122));
        }
        _ => {
            let line_col = Color32::from_rgb(168, 178, 192);
            let lw = (h * 0.06).max(1.0);
            for (i, right_frac) in [0.58f32, 0.78, 0.65].iter().enumerate() {
                let y = r.min.y + h * (0.42 + i as f32 * 0.17);
                painter.line_segment(
                    [
                        Pos2::new(r.min.x + w * 0.20, y),
                        Pos2::new(r.min.x + w * *right_frac, y),
                    ],
                    Stroke::new(lw, line_col),
                );
            }
        }
    }
}

fn paint_entry_vector_icon(
    painter: &egui::Painter,
    rect: Rect,
    is_dir: bool,
    ext: &str,
    light_border: bool,
    is_dark: bool,
) {
    if is_dir {
        paint_finder_folder_icon(painter, rect, false, light_border);
    } else {
        paint_finder_file_icon(painter, rect, ext, light_border, is_dark);
    }
}

fn draw_finder_folder_widget(ui: &mut egui::Ui, size_px: f32, is_open: bool, light_border: bool) {
    let w = (size_px * 1.18).max(14.0);
    let h = size_px.max(12.0);
    let (rect, _) = ui.allocate_exact_size(Vec2::new(w, h), Sense::hover());
    paint_finder_folder_icon(ui.painter(), rect, is_open, light_border);
}

fn draw_finder_file_widget(
    ui: &mut egui::Ui,
    size_px: f32,
    ext: &str,
    light_border: bool,
    is_dark: bool,
) {
    let w = (size_px * 1.18).max(14.0);
    let h = size_px.max(12.0);
    let (rect, _) = ui.allocate_exact_size(Vec2::new(w, h), Sense::hover());
    paint_finder_file_icon(ui.painter(), rect, ext, light_border, is_dark);
}
