use egui::IconData;

/// Generates a Japanese Minimalist Cute (日式簡潔可愛風格) Cat-Ear Multi-Window Folder Icon
/// using smooth SDF anti-aliasing at any requested pixel resolution.
pub fn build_kawaii_japanese_icon(size: u32) -> IconData {
    let rgba = render_kawaii_icon_rgba(size);
    IconData {
        rgba,
        width: size,
        height: size,
    }
}

pub fn render_kawaii_icon_rgba(size: u32) -> Vec<u8> {
    let mut buf = vec![0u8; (size * size * 4) as usize];
    let s = size as f32;
    let aa = 1.35 / s;

    for py in 0..size {
        for px in 0..size {
            let u = (px as f32 + 0.5) / s;
            let v = (py as f32 + 0.5) / s;

            let mut col = [0.0_f32; 4]; // premultiplied or straight RGBA [0..1]

            // Helper to alpha-blend an RGBA color over `col`
            let blend = |dst: &mut [f32; 4], src: [f32; 3], alpha: f32| {
                let a = alpha.clamp(0.0, 1.0);
                if a <= 0.0 {
                    return;
                }
                let out_a = a + dst[3] * (1.0 - a);
                if out_a > 0.0 {
                    dst[0] = (src[0] * a + dst[0] * dst[3] * (1.0 - a)) / out_a;
                    dst[1] = (src[1] * a + dst[1] * dst[3] * (1.0 - a)) / out_a;
                    dst[2] = (src[2] * a + dst[2] * dst[3] * (1.0 - a)) / out_a;
                    dst[3] = out_a;
                }
            };

            let outline_col = rgb(43, 45, 66); // Warm Japanese dark indigo-cocoa #2B2D42
            let stroke_w = 0.028;

            // 1. Rounded Squircle Background Badge (Soft Japanese Pastel Sky-Cream)
            let d_bg = sd_rounded_box(u - 0.5, v - 0.5, 0.44, 0.44, 0.21);
            let bg_fill_alpha = smoothstep(aa, -aa, d_bg);
            if bg_fill_alpha > 0.0 {
                // Soft vertical gradient from #F0F9FF to #BAE6FD
                let r = lerp(240.0 / 255.0, 186.0 / 255.0, v);
                let g = lerp(249.0 / 255.0, 230.0 / 255.0, v);
                let b = lerp(255.0 / 255.0, 253.0 / 255.0, v);
                blend(&mut col, [r, g, b], bg_fill_alpha);

                // Subtle inner white rim
                let d_rim = (d_bg + 0.025).abs() - 0.012;
                let rim_a = smoothstep(aa, -aa, d_rim) * 0.55;
                blend(&mut col, [1.0, 1.0, 1.0], rim_a);

                // Outer squircle border
                let d_bg_border = d_bg.abs() - 0.018;
                let border_a = smoothstep(aa, -aa, d_bg_border);
                blend(&mut col, outline_col, border_a);
            }

            // 2. Back MDI Sub-Window (Pastel Sakura Pink #FBCFE8 peeking out top-right)
            let d_back_win = sd_rounded_box(u - 0.56, v - 0.34, 0.24, 0.16, 0.055);
            let back_outer_a = smoothstep(aa, -aa, d_back_win - stroke_w);
            if back_outer_a > 0.0 {
                blend(&mut col, outline_col, back_outer_a);
                let back_inner_a = smoothstep(aa, -aa, d_back_win);
                // Pastel sakura pink fill
                blend(&mut col, rgb(252, 213, 235), back_inner_a);
                // Top white stripe on back window
                if v < 0.26 {
                    blend(&mut col, rgb(255, 240, 248), back_inner_a * 0.85);
                }
                // Tiny cute window button dots on back window
                for (dx, dot_c) in [
                    (0.67, rgb(251, 113, 133)),
                    (0.72, rgb(250, 204, 21)),
                ] {
                    let d_dot = sd_circle(u - dx, v - 0.235, 0.016);
                    blend(&mut col, dot_c, smoothstep(aa, -aa, d_dot));
                }
            }

            // 3. Cute Cat-Ear Folder (`猫耳フォルダ`)
            // Left Cat Ear & Right Cat Ear + Main Folder Body combined via smooth union
            let d_ear_l = sd_equilateral_triangle((u - 0.29) / 0.14, (v - 0.36) / 0.14) * 0.14 - 0.022;
            let d_ear_r = sd_equilateral_triangle((u - 0.63) / 0.14, (v - 0.36) / 0.14) * 0.14 - 0.022;
            let d_body = sd_rounded_box(u - 0.46, v - 0.58, 0.31, 0.21, 0.085);
            let d_ears = d_ear_l.min(d_ear_r);
            let d_cat_folder = smin(d_body, d_ears, 0.025);

            // Drop shadow under cat folder
            let d_shadow = sd_rounded_box(u - 0.47, v - 0.60, 0.31, 0.21, 0.085);
            blend(&mut col, rgb(14, 116, 144), smoothstep(aa * 2.0, -aa * 2.0, d_shadow) * 0.18);

            // Folder Dark Outline
            let folder_outline_a = smoothstep(aa, -aa, d_cat_folder - stroke_w);
            if folder_outline_a > 0.0 {
                blend(&mut col, outline_col, folder_outline_a);

                // Folder Warm Custard-Yellow Fill (#FEF08A -> #FDE047)
                let folder_fill_a = smoothstep(aa, -aa, d_cat_folder);
                let fy = ((v - 0.35) / 0.45).clamp(0.0, 1.0);
                let fr = lerp(254.0 / 255.0, 250.0 / 255.0, fy);
                let fg = lerp(243.0 / 255.0, 204.0 / 255.0, fy);
                let fb = lerp(138.0 / 255.0, 45.0 / 255.0, fy);
                blend(&mut col, [fr, fg, fb], folder_fill_a);

                // Cream top highlight inside folder
                let d_highlight = sd_rounded_box(u - 0.46, v - 0.43, 0.26, 0.025, 0.012);
                blend(
                    &mut col,
                    [1.0, 1.0, 1.0],
                    smoothstep(aa, -aa, d_highlight) * folder_fill_a * 0.55,
                );

                // Cute Pink Inner Cat Ears (#FDA4AF)
                let d_inner_l =
                    sd_equilateral_triangle((u - 0.29) / 0.075, (v - 0.37) / 0.075) * 0.075 - 0.01;
                let d_inner_r =
                    sd_equilateral_triangle((u - 0.63) / 0.075, (v - 0.37) / 0.075) * 0.075 - 0.01;
                let inner_ear_a = smoothstep(aa, -aa, d_inner_l.min(d_inner_r)) * folder_fill_a;
                blend(&mut col, rgb(251, 113, 133), inner_ear_a);
            }

            // 4. Kawaii Minimalist Face (Eyes `• •`, Rosy Cheeks, and Cat Smile `ω`)
            // Rosy Pink Blush Cheeks
            let d_cheek_l = sd_ellipse(u - 0.275, v - 0.625, 0.045, 0.026);
            let d_cheek_r = sd_ellipse(u - 0.645, v - 0.625, 0.045, 0.026);
            blend(
                &mut col,
                rgb(251, 113, 133),
                smoothstep(aa * 1.5, -aa * 1.5, d_cheek_l.min(d_cheek_r)) * 0.78,
            );

            // Dark Cocoa Oval Eyes
            let d_eye_l = sd_circle(u - 0.345, v - 0.565, 0.036);
            let d_eye_r = sd_circle(u - 0.575, v - 0.565, 0.036);
            blend(&mut col, outline_col, smoothstep(aa, -aa, d_eye_l.min(d_eye_r)));

            // White Eye Catchlight Sparkles
            let d_spark_l = sd_circle(u - 0.333, v - 0.577, 0.014);
            let d_spark_r = sd_circle(u - 0.563, v - 0.577, 0.014);
            blend(
                &mut col,
                [1.0, 1.0, 1.0],
                smoothstep(aa, -aa, d_spark_l.min(d_spark_r)),
            );

            // Cute Cat `ω` Mouth (two small upward-opening arcs meeting at x = 0.46)
            let d_mouth = sd_cat_mouth(u - 0.46, v - 0.605);
            blend(&mut col, outline_col, smoothstep(aa, -aa, d_mouth));

            // 5. Cute 4-Point Sparkle Star `✦` at Top-Left (representing Mouse Gesture Trail)
            let d_star = sd_sparkle_star(u - 0.20, v - 0.21, 0.065);
            blend(&mut col, rgb(14, 165, 233), smoothstep(aa, -aa, d_star - 0.012));
            blend(&mut col, [1.0, 1.0, 1.0], smoothstep(aa, -aa, d_star));

            let idx = ((py * size + px) * 4) as usize;
            buf[idx] = (col[0].clamp(0.0, 1.0) * 255.0).round() as u8;
            buf[idx + 1] = (col[1].clamp(0.0, 1.0) * 255.0).round() as u8;
            buf[idx + 2] = (col[2].clamp(0.0, 1.0) * 255.0).round() as u8;
            buf[idx + 3] = (col[3].clamp(0.0, 1.0) * 255.0).round() as u8;
        }
    }
    buf
}

fn rgb(r: u8, g: u8, b: u8) -> [f32; 3] {
    [r as f32 / 255.0, g as f32 / 255.0, b as f32 / 255.0]
}

fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t.clamp(0.0, 1.0)
}

fn smoothstep(edge0: f32, edge1: f32, x: f32) -> f32 {
    let t = ((x - edge0) / (edge1 - edge0)).clamp(0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

fn smin(a: f32, b: f32, k: f32) -> f32 {
    let h = (0.5 + 0.5 * (b - a) / k).clamp(0.0, 1.0);
    b * (1.0 - h) + a * h - k * h * (1.0 - h)
}

fn sd_circle(x: f32, y: f32, r: f32) -> f32 {
    (x * x + y * y).sqrt() - r
}

fn sd_ellipse(x: f32, y: f32, rx: f32, ry: f32) -> f32 {
    (((x / rx).powi(2) + (y / ry).powi(2)).sqrt() - 1.0) * rx.min(ry)
}

fn sd_rounded_box(x: f32, y: f32, bx: f32, by: f32, r: f32) -> f32 {
    let qx = x.abs() - bx + r;
    let qy = y.abs() - by + r;
    let out = (qx.max(0.0).powi(2) + qy.max(0.0).powi(2)).sqrt();
    let inn = qx.max(qy).min(0.0);
    out + inn - r
}

fn sd_equilateral_triangle(mut px: f32, mut py: f32) -> f32 {
    // Flip y so apex points UP (negative y)
    py = -py;
    let k = 3.0_f32.sqrt();
    px = px.abs() - 1.0;
    py = py + 1.0 / k;
    if px + k * py > 0.0 {
        let nx = (px - k * py) / 2.0;
        let ny = (-k * px - py) / 2.0;
        px = nx;
        py = ny;
    }
    px -= px.clamp(-2.0, 0.0);
    -(px * px + py * py).sqrt() * py.signum()
}

fn sd_cat_mouth(x: f32, y: f32) -> f32 {
    // Two little semi-circles side-by-side forming `ω`
    let r = 0.028;
    let cx = x.abs() - r;
    let cy = y;
    let ring = ((cx * cx + cy * cy).sqrt() - r).abs() - 0.011;
    // Only keep bottom half (y >= -0.004) and within width
    if y < -0.004 || x.abs() > r * 2.15 {
        // Round cap at endpoints
        let cap_top_mid = (x * x + (y + 0.004).powi(2)).sqrt() - 0.011;
        let cap_outer = ((x.abs() - r * 2.0).powi(2) + (y + 0.004).powi(2)).sqrt() - 0.011;
        cap_top_mid.min(cap_outer)
    } else {
        ring
    }
}

fn sd_sparkle_star(x: f32, y: f32, size: f32) -> f32 {
    let ax = x.abs() / size;
    let ay = y.abs() / size;
    (ax.sqrt() + ay.sqrt() - 1.0) * size * 0.55
}

pub fn export_icon_assets(out_dir: &std::path::Path) -> std::io::Result<()> {
    std::fs::create_dir_all(out_dir)?;

    // 1. Export PNGs for macOS .iconset
    let iconset_dir = out_dir.join("AppIcon.iconset");
    std::fs::create_dir_all(&iconset_dir)?;
    let sizes = [
        (16, "icon_16x16.png"),
        (32, "icon_16x16@2x.png"),
        (32, "icon_32x32.png"),
        (64, "icon_32x32@2x.png"),
        (128, "icon_128x128.png"),
        (256, "icon_128x128@2x.png"),
        (256, "icon_256x256.png"),
        (512, "icon_256x256@2x.png"),
        (512, "icon_512x512.png"),
    ];
    for (sz, filename) in sizes {
        let rgba = render_kawaii_icon_rgba(sz);
        if let Some(img) = image::RgbaImage::from_raw(sz, sz, rgba) {
            let _ = img.save(iconset_dir.join(filename));
        }
    }

    // 2. Export Windows .ico (containing 256x256 PNG payload inside standard ICO header)
    let rgba_256 = render_kawaii_icon_rgba(256);
    if let Some(img_256) = image::RgbaImage::from_raw(256, 256, rgba_256) {
        let mut png_bytes: Vec<u8> = Vec::new();
        let mut cursor = std::io::Cursor::new(&mut png_bytes);
        let _ = img_256.write_to(&mut cursor, image::ImageFormat::Png);

        let mut ico: Vec<u8> = Vec::with_capacity(22 + png_bytes.len());
        // ICONDIR (6 bytes): reserved=0, type=1 (ICO), count=1
        ico.extend_from_slice(&0u16.to_le_bytes());
        ico.extend_from_slice(&1u16.to_le_bytes());
        ico.extend_from_slice(&1u16.to_le_bytes());
        // ICONDIRENTRY (16 bytes): width=0 (256), height=0 (256), colors=0, reserved=0, planes=1, bpp=32, size, offset=22
        ico.push(0);
        ico.push(0);
        ico.push(0);
        ico.push(0);
        ico.extend_from_slice(&1u16.to_le_bytes());
        ico.extend_from_slice(&32u16.to_le_bytes());
        ico.extend_from_slice(&(png_bytes.len() as u32).to_le_bytes());
        ico.extend_from_slice(&22u32.to_le_bytes());
        ico.extend_from_slice(&png_bytes);
        std::fs::write(out_dir.join("mine.ico"), ico)?;
    }

    Ok(())
}

