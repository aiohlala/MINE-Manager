use std::env;
use std::path::PathBuf;
use std::process::Command;

fn main() {
    println!("cargo:rerun-if-changed=src/macos_media.m");
    println!("cargo:rerun-if-changed=src/macos_dnd.m");
    println!("cargo:rerun-if-changed=src/macos_watch.c");

    let target_os = env::var("CARGO_CFG_TARGET_OS").unwrap_or_default();
    if target_os != "macos" {
        return;
    }

    let out_dir = PathBuf::from(env::var("OUT_DIR").expect("OUT_DIR not set"));
    let obj_path = out_dir.join("macos_media.o");
    let lib_path = out_dir.join("libmacos_media.a");
    let dnd_obj_path = out_dir.join("macos_dnd.o");
    let dnd_lib_path = out_dir.join("libmacos_dnd.a");
    let watch_obj_path = out_dir.join("macos_watch.o");
    let watch_lib_path = out_dir.join("libmacos_watch.a");

    let target_arch = env::var("CARGO_CFG_TARGET_ARCH").unwrap_or_else(|_| "aarch64".into());
    let clang_arch = match target_arch.as_str() {
        "aarch64" => "arm64",
        "x86_64" => "x86_64",
        other => other,
    };

    let status = Command::new("clang")
        .args([
            "-c",
            "-fobjc-arc",
            "-O2",
            "-arch",
            clang_arch,
            "src/macos_media.m",
            "-o",
        ])
        .arg(&obj_path)
        .status()
        .expect("Failed to invoke clang for src/macos_media.m");
    assert!(status.success(), "clang failed to compile src/macos_media.m");

    let ar_status = Command::new("ar")
        .arg("rcs")
        .arg(&lib_path)
        .arg(&obj_path)
        .status()
        .expect("Failed to invoke ar for libmacos_media.a");
    assert!(ar_status.success(), "ar failed to create libmacos_media.a");

    let dnd_status = Command::new("clang")
        .args([
            "-c",
            "-fobjc-arc",
            "-O2",
            "-arch",
            clang_arch,
            "src/macos_dnd.m",
            "-o",
        ])
        .arg(&dnd_obj_path)
        .status()
        .expect("Failed to invoke clang for src/macos_dnd.m");
    assert!(dnd_status.success(), "clang failed to compile src/macos_dnd.m");

    let dnd_ar_status = Command::new("ar")
        .arg("rcs")
        .arg(&dnd_lib_path)
        .arg(&dnd_obj_path)
        .status()
        .expect("Failed to invoke ar for libmacos_dnd.a");
    assert!(dnd_ar_status.success(), "ar failed to create libmacos_dnd.a");

    println!("cargo:rustc-link-search=native={}", out_dir.display());
    println!("cargo:rustc-link-lib=static=macos_media");
    println!("cargo:rustc-link-lib=static=macos_dnd");

    let watch_status = Command::new("clang")
        .args([
            "-c",
            "-O2",
            "-arch",
            clang_arch,
            "src/macos_watch.c",
            "-o",
        ])
        .arg(&watch_obj_path)
        .status()
        .expect("Failed to invoke clang for src/macos_watch.c");
    assert!(watch_status.success(), "clang failed to compile src/macos_watch.c");

    let watch_ar_status = Command::new("ar")
        .arg("rcs")
        .arg(&watch_lib_path)
        .arg(&watch_obj_path)
        .status()
        .expect("Failed to invoke ar for libmacos_watch.a");
    assert!(watch_ar_status.success(), "ar failed to create libmacos_watch.a");

    println!("cargo:rustc-link-lib=static=macos_watch");
    println!("cargo:rustc-link-lib=framework=AppKit");
    println!("cargo:rustc-link-lib=framework=AVFoundation");
    println!("cargo:rustc-link-lib=framework=CoreMedia");
    println!("cargo:rustc-link-lib=framework=CoreVideo");
    println!("cargo:rustc-link-lib=framework=CoreGraphics");
    println!("cargo:rustc-link-lib=framework=ImageIO");
    println!("cargo:rustc-link-lib=framework=QuartzCore");
    println!("cargo:rustc-link-lib=framework=Foundation");
}
