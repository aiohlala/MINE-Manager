@echo off
chcp 65001 >nul
title MINE File Manager - Uninstaller
echo 正在移除 MINE 右鍵選單與安裝目錄 (不會影響綠色版資料夾)...
reg delete "HKCU\Software\Classes\Directory\shell\MINE" /f 2>nul
reg delete "HKCU\Software\Classes\Directory\Background\shell\MINE" /f 2>nul
echo ✅ 已清除註冊表項目！(如同原版 MDIE 的 uninst.exe 乾淨移除)
pause
