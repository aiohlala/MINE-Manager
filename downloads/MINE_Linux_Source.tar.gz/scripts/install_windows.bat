@echo off
chcp 65001 >nul
title MINE File Manager - Windows 10/11 Installer & Shell Integration
echo ============================================================================
echo   🗂️ MINE (Multiple Interface Next-gen Explorer) - Windows 10/11 Setup
echo   致敬經典 MDIE 的新世代超輕量級多視窗/滑鼠手勢檔案管理程式
echo ============================================================================
echo.
echo [1] 綠色免安裝模式 (Portable Mode):
echo     直接執行同目錄下的 mine.exe 即可！設定檔將自動儲存於 mine_config.json。
echo.
echo [2] 安裝至系統並加入「以 MINE 開啟資料夾」滑鼠右鍵選單 (Install ^& Context Menu):
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\MINE"
echo     目標安裝路徑: %INSTALL_DIR%
echo.
choice /C YN /M "是否要安裝至系統並註冊資料夾右鍵選單 (Y=安裝 / N=僅使用綠色免安裝版)?"
if errorlevel 2 goto :EOF

mkdir "%INSTALL_DIR%" 2>nul
copy /Y "%~dp0mine.exe" "%INSTALL_DIR%\mine.exe" >nul
if exist "%~dp0mine_config.json" copy /Y "%~dp0mine_config.json" "%INSTALL_DIR%\mine_config.json" >nul

reg add "HKCU\Software\Classes\Directory\shell\MINE" /ve /d "Open in MINE File Manager (以 MINE 開啟)" /f >nul
reg add "HKCU\Software\Classes\Directory\shell\MINE" /v "Icon" /d "\"%INSTALL_DIR%\mine.exe\"" /f >nul
reg add "HKCU\Software\Classes\Directory\shell\MINE\command" /ve /d "\"%INSTALL_DIR%\mine.exe\" \"%%1\"" /f >nul

reg add "HKCU\Software\Classes\Directory\Background\shell\MINE" /ve /d "Open in MINE File Manager (以 MINE 開啟)" /f >nul
reg add "HKCU\Software\Classes\Directory\Background\shell\MINE" /v "Icon" /d "\"%INSTALL_DIR%\mine.exe\"" /f >nul
reg add "HKCU\Software\Classes\Directory\Background\shell\MINE\command" /ve /d "\"%INSTALL_DIR%\mine.exe\" \"%%V\"" /f >nul

echo.
echo ✅ 安裝與右鍵選單註冊完成！
pause
