use crate::app::{ClipboardOp, ContextMenuState, MineApp, SidebarTab};
use crate::fs_ops::{format_size, PreviewPayload, SmbStatus};
use crate::gesture::{GestureAction, GestureTracker};
use crate::i18n::Language;
use crate::search::{spawn_deep_search, PaneSearchMode, SearchProgressMsg};
use crate::state::{
    AppTheme, MdiChildPane, ScrollRequest, SortColumn, WindowLayoutMode, WorkspaceGroupBookmark,
};
use egui::{Color32, Pos2, Rect, RichText, Sense, Stroke, Vec2};
use egui_extras::{Column, TableBuilder};
use std::path::PathBuf;
use std::sync::atomic::Ordering;
use sysinfo::{ProcessesToUpdate, System};

impl eframe::App for MineApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.apply_theme(ctx);
        self.poll_background_channels(ctx);
        self.handle_global_shortcuts_and_gestures(ctx);

        let t = self.config.language.texts();

        // 1. Top Menu Bar + MDIE Quick Toolbar + Multi-Window Tab Strip
        egui::TopBottomPanel::top("mine_top_header").show(ctx, |ui| {
            self.render_menu_bar(ui, t);
            ui.separator();
            self.render_quick_toolbar(ui, t);
            ui.separator();
            self.render_mdi_tab_bar(ui, t);
        });

        // 2. Bottom Status Bar (shows RAM footprint, Portable status, and Gesture hint)
        egui::TopBottomPanel::bottom("mine_status_bar").show(ctx, |ui| {
            ui.horizontal(|ui| {
                let active_idx = self.active_pane_index();
                if let Some(p) = self.panes.get(active_idx) {
                    ui.label(
                        RichText::new(format!(
                            "📂 {} {} | ☑ {} {}",
                            p.filtered_indices.len(),
                            t.status_items,
                            p.selected_paths.len(),
                            t.status_selected
                        ))
                        .strong(),
                    );
                }
                ui.separator();
                ui.label(RichText::new(&self.status_toast).color(Color32::from_rgb(0, 120, 215)));
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.label(
                        RichText::new(format!(
                            "⚡ RAM: {:.1} MB ({} MDI Windows)",
                            self.process_ram_mb,
                            self.panes.len()
                        ))
                        .color(Color32::from_rgb(20, 140, 60))
                        .strong(),
                    );
                    ui.separator();
                    ui.label(RichText::new(t.status_portable_mode).small());
                    ui.separator();
                    ui.label(RichText::new(t.status_gesture_hint).small());
                });
            });
        });

        // 3. Left Sidebar (Drives, Favorites & Workspace Groups, Non-blocking SMB, Closed Tabs)
        if self.config.show_sidebar {
            egui::SidePanel::left("mine_left_sidebar")
                .default_width(245.0)
                .width_range(180.0..=380.0)
                .resizable(true)
                .show(ctx, |ui| {
                    self.render_left_sidebar(ui, t);
                });
        }

        // 4. Right Safe Sandbox Preview Panel (Crash-proof HEIC / Image / Text / Encoding)
        if self.config.show_preview {
            egui::SidePanel::right("mine_right_preview")
                .default_width(290.0)
                .width_range(210.0..=480.0)
                .resizable(true)
                .show(ctx, |ui| {
                    self.render_right_preview(ui, t);
                });
        }

        // 5. Central MDI Multi-Window Workspace
        egui::CentralPanel::default()
            .frame(
                egui::Frame::central_panel(&ctx.style())
                    .fill(if self.config.theme == AppTheme::ModernDark {
                        Color32::from_rgb(16, 18, 22)
                    } else {
                        Color32::from_rgb(171, 178, 191) // Classic MDIE MDI Workspace gray-blue backdrop
                    })
                    .inner_margin(4.0),
            )
            .show(ctx, |ui| {
                self.render_mdi_workspace(ui, t);
            });

        // 6. Floating Right-Click Context Menu
        self.render_context_menu(ctx, t);

        // 7. Floating Modals & Dialogs (Global Search, SMB Manager, Gesture Customizer, Rename, About)
        self.render_dialogs(ctx, t);

        // 8. Render Live Mouse Gesture Neon Trail & HUD Overlay on top of everything
        self.render_gesture_overlay(ctx);
    }
}

impl MineApp {
    fn poll_background_channels(&mut self, ctx: &egui::Context) {
        let show_hidden = self.config.show_hidden;
        let mut any_loading = false;
        for pane in &mut self.panes {
            if pane.poll_async_load(show_hidden) {
                ctx.request_repaint();
            }
            if pane.is_loading {
                any_loading = true;
            }
        }

        // Poll asynchronous background OS remote folder discovery
        let mut trigger_smb_probes = false;
        if let Some(ref rx) = self.remote_discovery_rx {
            match rx.try_recv() {
                Ok(remotes) => {
                    self.system_smb_shares = remotes;
                    self.is_discovering_remotes = false;
                    self.remote_discovery_rx = None;
                    trigger_smb_probes = true;
                    ctx.request_repaint();
                }
                Err(std::sync::mpsc::TryRecvError::Empty) => {
                    any_loading = true;
                }
                Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                    self.is_discovering_remotes = false;
                    self.remote_discovery_rx = None;
                }
            }
        }
        if trigger_smb_probes {
            self.probe_all_smb();
        }

        // Poll asynchronous background local disk capacity discovery
        if let Some(ref rx) = self.disks_discovery_rx {
            match rx.try_recv() {
                Ok(disks) => {
                    if !disks.is_empty() {
                        self.sys_disks = disks;
                    }
                    self.disks_discovery_rx = None;
                    ctx.request_repaint();
                }
                Err(std::sync::mpsc::TryRecvError::Empty) => {
                    any_loading = true;
                }
                Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                    self.disks_discovery_rx = None;
                }
            }
        }

        // Poll auto-discovered OS remote folders non-blocking probes
        self.system_smb_probes
            .retain(|(idx, rx)| match rx.try_recv() {
                Ok(status) => {
                    if let Some(smb) = self.system_smb_shares.get_mut(*idx) {
                        smb.status = status;
                    }
                    ctx.request_repaint();
                    false
                }
                Err(std::sync::mpsc::TryRecvError::Empty) => {
                    any_loading = true;
                    true
                }
                Err(std::sync::mpsc::TryRecvError::Disconnected) => false,
            });

        // Poll custom SMB non-blocking probes
        self.smb_probes.retain(|(idx, rx)| match rx.try_recv() {
            Ok(status) => {
                if let Some(smb) = self.config.smb_bookmarks.get_mut(*idx) {
                    smb.status = status;
                }
                ctx.request_repaint();
                false
            }
            Err(std::sync::mpsc::TryRecvError::Empty) => {
                any_loading = true;
                true
            }
            Err(std::sync::mpsc::TryRecvError::Disconnected) => false,
        });

        // Poll Sandboxed Preview
        if let Some(ref rx) = self.preview_rx {
            if let Ok(payload) = rx.try_recv() {
                if let PreviewPayload::Image {
                    width,
                    height,
                    ref rgba,
                    ..
                } = payload
                {
                    let color_img = egui::ColorImage::from_rgba_unmultiplied([width, height], rgba);
                    self.preview_texture = Some(ctx.load_texture(
                        "sandbox_preview_tex",
                        color_img,
                        egui::TextureOptions::LINEAR,
                    ));
                }
                self.preview_state = payload;
                self.preview_rx = None;
                ctx.request_repaint();
            } else {
                any_loading = true;
            }
        }

        // Poll Multi-threaded Deep Search
        if let Some(ref rx) = self.deep_search_rx {
            while let Ok(msg) = rx.try_recv() {
                match msg {
                    SearchProgressMsg::Batch(mut batch, scanned) => {
                        self.deep_search_results.append(&mut batch);
                        self.deep_search_scanned = scanned;
                        ctx.request_repaint();
                    }
                    SearchProgressMsg::Finished(scanned, elapsed_ms) => {
                        self.deep_search_scanned = scanned;
                        self.deep_search_elapsed_ms = elapsed_ms;
                        self.deep_search_running = false;
                        self.deep_search_rx = None;
                        self.deep_search_results
                            .sort_by(|a, b| b.score.cmp(&a.score));
                        ctx.request_repaint();
                        break;
                    }
                }
            }
            if self.deep_search_running {
                any_loading = true;
            }
        }

        // Refresh process memory telemetry every 4 seconds
        if self.last_telemetry_tick.elapsed() > std::time::Duration::from_secs(4) {
            self.last_telemetry_tick = std::time::Instant::now();
            if let Ok(pid) = sysinfo::get_current_pid() {
                let mut sys = System::new();
                sys.refresh_processes(ProcessesToUpdate::Some(&[pid]), true);
                if let Some(proc_info) = sys.process(pid) {
                    self.process_ram_mb = (proc_info.memory() as f64) / (1024.0 * 1024.0);
                }
            }
        }

        // Automatically re-probe remote folders every 5 seconds in the background so Tailscale/VPN/NAS state changes update live
        if !self.is_discovering_remotes
            && self.system_smb_probes.is_empty()
            && self.smb_probes.is_empty()
            && self.last_smb_probe_tick.elapsed() > std::time::Duration::from_secs(5)
        {
            self.probe_all_smb();
        }

        if any_loading {
            ctx.request_repaint_after(std::time::Duration::from_millis(40));
        }
    }

    fn handle_global_shortcuts_and_gestures(&mut self, ctx: &egui::Context) {
        // Right-click + Mouse Wheel -> MDIE fast scroll to top/bottom
        let rmb_down = ctx.input(|i| i.pointer.secondary_down());
        let scroll_y = ctx.input(|i| i.smooth_scroll_delta.y);
        if rmb_down && scroll_y.abs() > 8.0 {
            let idx = self.active_pane_index();
            if let Some(p) = self.panes.get_mut(idx) {
                if scroll_y > 0.0 {
                    p.scroll_request = ScrollRequest::Top;
                    self.status_toast = "🖱 Right-Click + Wheel Up -> 捲動至列表開頭 (Top)".into();
                } else {
                    p.scroll_request = ScrollRequest::Bottom;
                    self.status_toast =
                        "🖱 Right-Click + Wheel Down -> 捲動至列表結尾 (Bottom)".into();
                }
            }
            self.gesture_tracker.is_tracking = false;
            return;
        }

        // Keyboard shortcuts when not typing in a text box
        if !ctx.wants_keyboard_input() {
            let mut open_search = false;
            let mut refresh = false;
            let mut go_up = false;
            let mut new_win = false;
            let mut close_win = false;
            let mut rename_f2 = false;
            let mut do_copy = false;
            let mut do_cut = false;
            let mut do_paste = false;
            let mut do_select_all = false;
            let mut do_delete = false;

            ctx.input(|i| {
                let cmd = i.modifiers.command || i.modifiers.ctrl;
                if cmd && i.key_pressed(egui::Key::F) {
                    open_search = true;
                }
                if cmd && i.key_pressed(egui::Key::N) {
                    new_win = true;
                }
                if cmd && i.key_pressed(egui::Key::W) {
                    close_win = true;
                }
                if cmd && i.key_pressed(egui::Key::C) {
                    do_copy = true;
                }
                if cmd && i.key_pressed(egui::Key::X) {
                    do_cut = true;
                }
                if cmd && i.key_pressed(egui::Key::V) {
                    do_paste = true;
                }
                if cmd && i.key_pressed(egui::Key::A) {
                    do_select_all = true;
                }
                if i.key_pressed(egui::Key::Delete) || (cmd && i.key_pressed(egui::Key::Backspace)) {
                    do_delete = true;
                } else if i.key_pressed(egui::Key::Backspace) {
                    go_up = true;
                }
                if i.key_pressed(egui::Key::F5) {
                    refresh = true;
                }
                if i.key_pressed(egui::Key::F2) {
                    rename_f2 = true;
                }
                if i.key_pressed(egui::Key::Escape) {
                    self.context_menu = None;
                    self.drag_payload = None;
                }
            });

            if open_search {
                self.show_search_dialog = true;
            }
            if new_win {
                self.execute_gesture_action(GestureAction::NewMdiWindow);
            }
            if close_win {
                self.execute_gesture_action(GestureAction::CloseActiveWindow);
            }
            if refresh {
                self.execute_gesture_action(GestureAction::RefreshActiveWindow);
            }
            if do_copy {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get(idx) {
                    let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                    if !list.is_empty() {
                        let cnt = list.len();
                        self.clipboard = ClipboardOp::Copy(list);
                        self.status_toast = format!("📋 已複製 {} 個項目至剪貼簿 (Ctrl+V 貼上)", cnt);
                    }
                }
            }
            if do_cut {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get(idx) {
                    let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                    if !list.is_empty() {
                        let cnt = list.len();
                        self.clipboard = ClipboardOp::Cut(list);
                        self.status_toast = format!("✂ 已剪下 {} 個項目 (Ctrl+V 移動至此)", cnt);
                    }
                }
            }
            if do_paste {
                let idx = self.active_pane_index();
                if let Some(dest) = self.panes.get(idx).map(|p| p.current_path.clone()) {
                    match self.clipboard.clone() {
                        ClipboardOp::Copy(srcs) => {
                            self.perform_file_transfer(&srcs, &dest, false);
                        }
                        ClipboardOp::Cut(srcs) => {
                            self.perform_file_transfer(&srcs, &dest, true);
                            self.clipboard = ClipboardOp::None;
                        }
                        ClipboardOp::None => {}
                    }
                }
            }
            if do_select_all {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get_mut(idx) {
                    for &i in &p.filtered_indices {
                        if let Some(e) = p.entries.get(i) {
                            p.selected_paths.insert(e.path.clone());
                        }
                    }
                }
            }
            if do_delete {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get_mut(idx) {
                    let targets: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                    if !targets.is_empty() {
                        let cnt = targets.len();
                        for t_path in targets {
                            let _ = trash::delete(&t_path);
                        }
                        p.selected_paths.clear();
                        p.trigger_reload();
                        self.status_toast = format!("🗑 已將 {} 個項目移至資源回收桶", cnt);
                    }
                }
            }
            if rename_f2 {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get(idx) {
                    if let Some(first) = p.selected_paths.iter().next() {
                        let cur_name = first
                            .file_name()
                            .unwrap_or_default()
                            .to_string_lossy()
                            .into_owned();
                        self.rename_modal = Some((first.clone(), cur_name));
                    }
                }
            }
            if go_up {
                self.execute_gesture_action(GestureAction::NavigateUp);
            }
        }
    }

    fn render_menu_bar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        egui::menu::bar(ui, |ui| {
            // App Branding Badge with Japanese Minimalist Cute Icon
            if let Some(ref tex) = self.app_icon_tex {
                ui.add(egui::Image::new((tex.id(), Vec2::new(20.0, 20.0))).rounding(4.0));
            }
            ui.label(
                RichText::new("MINE")
                    .strong()
                    .color(Color32::from_rgb(0, 102, 204)),
            );
            ui.separator();

            // 1. File(F)
            ui.menu_button(t.menu_file, |ui| {
                if ui.button(t.file_new_pane).clicked() {
                    self.execute_gesture_action(GestureAction::NewMdiWindow);
                    ui.close_menu();
                }
                if ui.button(t.file_clone_pane).clicked() {
                    self.execute_gesture_action(GestureAction::CloneActiveWindow);
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.file_new_folder).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        self.create_item_modal =
                            Some((p.current_path.clone(), true, "New_Folder".into()));
                    }
                    ui.close_menu();
                }
                if ui.button(t.file_new_file).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        self.create_item_modal =
                            Some((p.current_path.clone(), false, "note.txt".into()));
                    }
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.file_open_terminal).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        open_terminal_at(&p.current_path);
                    }
                    ui.close_menu();
                }
                if ui.button(t.file_open_native).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let _ = open::that(&p.current_path);
                    }
                    ui.close_menu();
                }
                if ui.button(t.file_restore_closed).clicked() {
                    self.restore_last_closed_pane();
                    ui.close_menu();
                }
                if ui.button(t.file_close_pane).clicked() {
                    let id = self.active_pane_id;
                    self.close_pane_by_id(id);
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.file_exit).clicked() {
                    let _ = self.config.save();
                    std::process::exit(0);
                }
            });

            // 2. Edit(E)
            ui.menu_button(t.menu_edit, |ui| {
                if ui.button(t.edit_copy).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                        if !list.is_empty() {
                            self.clipboard = ClipboardOp::Copy(list);
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_cut).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                        if !list.is_empty() {
                            self.clipboard = ClipboardOp::Cut(list);
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_paste).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(dest) = self.panes.get(idx).map(|p| p.current_path.clone()) {
                        match self.clipboard.clone() {
                            ClipboardOp::Copy(srcs) => {
                                self.perform_file_transfer(&srcs, &dest, false);
                            }
                            ClipboardOp::Cut(srcs) => {
                                self.perform_file_transfer(&srcs, &dest, true);
                                self.clipboard = ClipboardOp::None;
                            }
                            ClipboardOp::None => {}
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_rename).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        if let Some(first) = p.selected_paths.iter().next() {
                            let cur_name = first
                                .file_name()
                                .unwrap_or_default()
                                .to_string_lossy()
                                .into_owned();
                            self.rename_modal = Some((first.clone(), cur_name));
                        }
                    }
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.edit_copy_path).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let target = p
                            .selected_paths
                            .iter()
                            .next()
                            .cloned()
                            .unwrap_or_else(|| p.current_path.clone());
                        if let Ok(mut cb) = arboard::Clipboard::new() {
                            let _ = cb.set_text(target.to_string_lossy().into_owned());
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_select_all).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get_mut(idx) {
                        for &i in &p.filtered_indices {
                            if let Some(e) = p.entries.get(i) {
                                p.selected_paths.insert(e.path.clone());
                            }
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_invert_selection).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get_mut(idx) {
                        let mut next_set = std::collections::HashSet::new();
                        for &i in &p.filtered_indices {
                            if let Some(e) = p.entries.get(i) {
                                if !p.selected_paths.contains(&e.path) {
                                    next_set.insert(e.path.clone());
                                }
                            }
                        }
                        p.selected_paths = next_set;
                    }
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.edit_delete).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get_mut(idx) {
                        let targets: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                        for t_path in targets {
                            let _ = trash::delete(&t_path);
                        }
                        p.trigger_reload();
                    }
                    ui.close_menu();
                }
            });

            // 3. View(V)
            ui.menu_button(t.menu_view, |ui| {
                if ui
                    .checkbox(&mut self.config.show_sidebar, t.view_sidebar)
                    .changed()
                {
                    let _ = self.config.save();
                }
                if ui
                    .checkbox(&mut self.config.show_preview, t.view_preview)
                    .changed()
                {
                    let _ = self.config.save();
                }
                if ui
                    .checkbox(&mut self.config.show_hidden, t.view_hidden_files)
                    .changed()
                {
                    let show_hidden = self.config.show_hidden;
                    for p in &mut self.panes {
                        p.apply_sort_and_filter(show_hidden);
                    }
                    let _ = self.config.save();
                }
                ui.separator();
                if ui
                    .selectable_value(&mut self.config.theme, AppTheme::ClassicMdie, t.view_theme_classic_mdie)
                    .clicked()
                    || ui
                        .selectable_value(&mut self.config.theme, AppTheme::ModernDark, t.view_theme_dark)
                        .clicked()
                    || ui
                        .selectable_value(&mut self.config.theme, AppTheme::CleanLight, t.view_theme_light)
                        .clicked()
                {
                    let _ = self.config.save();
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.view_refresh).clicked() {
                    for p in &mut self.panes {
                        p.trigger_reload();
                    }
                    ui.close_menu();
                }
            });

            // 4. Favorites(A) - Including MDIE Multi-Window Workspace Groups!
            ui.menu_button(t.menu_favorites, |ui| {
                if self.panes.len() > 1 {
                    let active_idx = self.active_pane_index();
                    let target_title = self.panes.get(active_idx).map(|p| p.title.as_str()).unwrap_or("1");
                    let target_hint = if self.config.language == Language::ZhTw {
                        format!("🎯 目標視窗：[{}] {}", active_idx + 1, target_title)
                    } else {
                        format!("🎯 Target Window: [{}] {}", active_idx + 1, target_title)
                    };
                    ui.label(RichText::new(target_hint).small().color(Color32::from_rgb(0, 120, 215)).strong());
                    ui.separator();
                }
                if ui.button(t.fav_add_current_folder).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let name = p.title.clone();
                        let path_s = p.current_path.to_string_lossy().into_owned();
                        self.config.favorite_folders.push((name, path_s));
                        let _ = self.config.save();
                    }
                    ui.close_menu();
                }
                if ui.button(t.fav_save_workspace_group).clicked() {
                    self.show_save_group_modal = true;
                    ui.close_menu();
                }
                ui.separator();
                ui.label(RichText::new(t.fav_groups_header).strong());
                let groups = self.config.workspace_groups.clone();
                for grp in groups {
                    if ui
                        .button(format!("📦 {} ({} 視窗)", grp.name, grp.paths.len()))
                        .clicked()
                    {
                        self.panes.clear();
                        for (i, ps) in grp.paths.iter().enumerate() {
                            self.panes.push(MdiChildPane::new(i + 1, PathBuf::from(ps)));
                        }
                        self.next_pane_id = self.panes.len() + 1;
                        self.active_pane_id = 1;
                        self.config.layout_mode = grp.layout;
                        self.sync_config_paths();
                        ui.close_menu();
                    }
                }
                ui.separator();
                ui.label(RichText::new(t.fav_folders_header).strong());
                let favs = self.config.favorite_folders.clone();
                for (name, path_s) in favs {
                    if ui.button(format!("⭐ {}", name)).clicked() {
                        let idx = self.active_pane_index();
                        if let Some(p) = self.panes.get_mut(idx) {
                            p.navigate_to(PathBuf::from(path_s), true);
                        }
                        ui.close_menu();
                    }
                }
            });

            // 5. Tools(T)
            ui.menu_button(t.menu_tools, |ui| {
                if ui.button(t.tools_global_search).clicked() {
                    self.show_search_dialog = true;
                    ui.close_menu();
                }
                if ui.button(t.tools_smb_manager).clicked() {
                    self.show_smb_dialog = true;
                    ui.close_menu();
                }
                if ui.button(t.tools_gesture_settings).clicked() {
                    self.show_gesture_dialog = true;
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.tools_save_portable).clicked() {
                    if let Ok(p) = self.config.save() {
                        self.status_toast = format!("💾 Saved portable config: {}", p.to_string_lossy());
                    }
                    ui.close_menu();
                }
                if ui.button(t.tools_export_reg_script).clicked() {
                    if let Ok(reg_path) = export_windows_shell_reg() {
                        self.status_toast = format!("🛠 已匯出 Windows 登錄檔: {}", reg_path.to_string_lossy());
                    }
                    ui.close_menu();
                }
            });

            // 6. Window(W) - Exact replica of MDIE's iconic Window menu from the screenshot!
            ui.menu_button(t.menu_window, |ui| {
                ui.label(RichText::new(t.win_mode_title).strong());
                if ui
                    .selectable_value(
                        &mut self.config.layout_mode,
                        WindowLayoutMode::TileHorizontally,
                        t.win_mode_tile_horiz,
                    )
                    .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::TileVertically,
                            t.win_mode_tile_vert,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::TileGrid,
                            t.win_mode_tile_grid,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::Cascade,
                            t.win_mode_cascade,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::MdiFree,
                            t.win_mode_mdi_free,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::TabbedMaximized,
                            t.win_mode_tabbed,
                        )
                        .clicked()
                {
                    if self.config.layout_mode == WindowLayoutMode::Cascade {
                        self.needs_cascade_recalc = true;
                    }
                    let _ = self.config.save();
                    ui.close_menu();
                }

                ui.separator();
                if ui.button(t.win_scroll_top).clicked() {
                    self.execute_gesture_action(GestureAction::ScrollToTop);
                    ui.close_menu();
                }
                if ui.button(t.win_scroll_bottom).clicked() {
                    self.execute_gesture_action(GestureAction::ScrollToBottom);
                    ui.close_menu();
                }
                ui.checkbox(&mut self.config.sync_scroll, t.win_sync_scroll);
                if ui.button(t.win_close_all_except_active).clicked() {
                    let active_id = self.active_pane_id;
                    self.panes.retain(|p| p.id == active_id);
                    self.sync_config_paths();
                    ui.close_menu();
                }

                ui.separator();
                // Numbered window list just like MDIE's Window menu (1 This PC, 2 DarkTable, 3 Style...)
                for (i, pane) in self.panes.iter().enumerate() {
                    let checked = pane.id == self.active_pane_id;
                    if ui
                        .selectable_label(checked, format!("{} {}", i + 1, pane.title))
                        .clicked()
                    {
                        self.active_pane_id = pane.id;
                        ui.close_menu();
                    }
                }
            });

            // 7. Help(H)
            ui.menu_button(t.menu_help, |ui| {
                if ui.button("ℹ 關於 MINE (About MINE)").clicked() {
                    self.show_about_dialog = true;
                    ui.close_menu();
                }
                ui.separator();
                let sponsor_label = if self.config.language == Language::ZhTw {
                    "☕ 贊助鼓勵作者 (Ko-fi)"
                } else {
                    "☕ Support the Author on Ko-fi"
                };
                if ui
                    .button(
                        RichText::new(sponsor_label)
                            .color(Color32::from_rgb(255, 94, 91))
                            .strong(),
                    )
                    .on_hover_text("https://ko-fi.com/aiohlala")
                    .clicked()
                {
                    let _ = open::that("https://ko-fi.com/aiohlala");
                    ui.close_menu();
                }
            });

            // Right-aligned Language Switcher (繁體中文 / English) & Quick Layout Pills
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui
                    .selectable_label(self.config.language == Language::En, "🌐 EN")
                    .clicked()
                {
                    self.config.language = Language::En;
                    let _ = self.config.save();
                }
                if ui
                    .selectable_label(self.config.language == Language::ZhTw, "🌐 繁中")
                    .clicked()
                {
                    self.config.language = Language::ZhTw;
                    let _ = self.config.save();
                }
                ui.separator();
                if ui.button(t.top_deep_search).clicked() {
                    self.show_search_dialog = true;
                }
                if ui.button(t.top_gestures).clicked() {
                    self.show_gesture_dialog = true;
                }
            });
        });
    }

    fn render_quick_toolbar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.horizontal_wrapped(|ui| {
            // Navigation controls for active pane
            if ui.button(t.btn_back).clicked() {
                self.execute_gesture_action(GestureAction::NavigateBack);
            }
            if ui.button(t.btn_forward).clicked() {
                self.execute_gesture_action(GestureAction::NavigateForward);
            }
            if ui.button(t.btn_up).clicked() {
                self.execute_gesture_action(GestureAction::NavigateUp);
            }
            if ui.button(t.btn_refresh).clicked() {
                self.execute_gesture_action(GestureAction::RefreshActiveWindow);
            }

            ui.separator();

            // One-click Unlimited MDI Window Spawner & Layout Switcher
            if ui
                .button(RichText::new(t.quick_new_window).strong())
                .on_hover_text(t.quick_new_window_tip)
                .clicked()
            {
                self.execute_gesture_action(GestureAction::NewMdiWindow);
            }
            if ui
                .button(t.quick_clone_window)
                .on_hover_text(t.quick_clone_window_tip)
                .clicked()
            {
                self.execute_gesture_action(GestureAction::CloneActiveWindow);
            }

            ui.separator();
            ui.label(RichText::new(t.quick_layout_label).strong());
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TileHorizontally,
                    t.quick_layout_horiz,
                )
                .on_hover_text(t.quick_layout_horiz_tip)
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TileHorizontally;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TileVertically,
                    t.quick_layout_vert,
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TileVertically;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TileGrid,
                    t.quick_layout_grid,
                )
                .on_hover_text(t.quick_layout_grid_tip)
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TileGrid;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::Cascade,
                    t.quick_layout_cascade,
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::Cascade;
                self.needs_cascade_recalc = true;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::MdiFree,
                    t.quick_layout_free,
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::MdiFree;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TabbedMaximized,
                    t.quick_layout_tabbed,
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TabbedMaximized;
            }

            ui.separator();

            // Quick toggle buttons for Left Sidebar and Right Preview Panel
            if ui
                .selectable_label(self.config.show_sidebar, t.quick_sidebar)
                .on_hover_text(t.view_sidebar)
                .clicked()
            {
                self.config.show_sidebar = !self.config.show_sidebar;
                let _ = self.config.save();
            }

            if ui
                .selectable_label(self.config.show_preview, t.quick_preview)
                .on_hover_text(t.view_preview)
                .clicked()
            {
                self.config.show_preview = !self.config.show_preview;
                let _ = self.config.save();
            }

            // Quick Dropdown for OS Auto-Discovered Remote Folders & Local Drives (even when Sidebar is hidden!)
            let remote_menu_label = if self.config.language == Language::ZhTw {
                format!(
                    "🌐 遠端與磁碟 ({})",
                    self.system_smb_shares.len() + self.config.smb_bookmarks.len()
                )
            } else {
                format!(
                    "🌐 Drives & Remote ({})",
                    self.system_smb_shares.len() + self.config.smb_bookmarks.len()
                )
            };
            ui.menu_button(remote_menu_label, |ui| {
                ui.set_min_width(270.0);
                if self.panes.len() > 1 {
                    let active_idx = self.active_pane_index();
                    let target_title = self.panes.get(active_idx).map(|p| p.title.as_str()).unwrap_or("1");
                    let target_hint = if self.config.language == Language::ZhTw {
                        format!("🎯 目標視窗：[{}] {}", active_idx + 1, target_title)
                    } else {
                        format!("🎯 Target Window: [{}] {}", active_idx + 1, target_title)
                    };
                    ui.label(RichText::new(target_hint).small().color(Color32::from_rgb(0, 120, 215)).strong());
                    ui.separator();
                }
                ui.horizontal(|ui| {
                    ui.label(RichText::new(t.side_remote_header).strong());
                    let refresh_btn_text = if self.config.language == Language::ZhTw { "🔄 重新抓取" } else { "🔄 Refresh" };
                    if ui
                        .small_button(refresh_btn_text)
                        .on_hover_text(t.side_refresh_tip)
                        .clicked()
                    {
                        self.refresh_system_remote_folders();
                    }
                    let manage_btn_text = if self.config.language == Language::ZhTw { "⚙ 管理" } else { "⚙ Manage" };
                    if ui.small_button(manage_btn_text).clicked() {
                        self.show_smb_dialog = true;
                        ui.close_menu();
                    }
                });
                ui.separator();

                let sys_smbs = self.system_smb_shares.clone();
                let usr_smbs = self.config.smb_bookmarks.clone();
                if sys_smbs.is_empty() && usr_smbs.is_empty() {
                    ui.label(
                        RichText::new(if self.config.language == Language::ZhTw {
                            "目前未偵測到系統已設定的遠端資料夾"
                        } else {
                            "No OS remote folders detected"
                        })
                        .small()
                        .color(Color32::GRAY),
                    );
                }
                for smb in sys_smbs.iter().chain(usr_smbs.iter()) {
                    let is_offline = matches!(smb.status, SmbStatus::Offline(_));
                    let btn_label = match &smb.status {
                        SmbStatus::Online(_) => RichText::new(&smb.name),
                        SmbStatus::Offline(_) => RichText::new(format!(
                            "{} {}",
                            smb.name,
                            if self.config.language == Language::ZhTw {
                                "[✖ 無法連線]"
                            } else {
                                "[✖ Disconnected]"
                            }
                        ))
                        .color(Color32::from_rgb(240, 100, 100)),
                        SmbStatus::Probing | SmbStatus::Unknown => RichText::new(format!(
                            "{} {}",
                            smb.name,
                            if self.config.language == Language::ZhTw {
                                "[偵測中...]"
                            } else {
                                "[Checking...]"
                            }
                        )),
                    };
                    let is_zh = self.config.language == Language::ZhTw;
                    let hover_tip = match &smb.status {
                        SmbStatus::Online(ms) => {
                            if is_zh {
                                format!("● 已連線 ({} ms)\n{}", ms, smb.unc_or_mount_path)
                            } else {
                                format!("● Online ({} ms)\n{}", ms, smb.unc_or_mount_path)
                            }
                        }
                        SmbStatus::Offline(err) => {
                            if is_zh {
                                format!("✖ 無法連線 ({})\n{}", err, smb.unc_or_mount_path)
                            } else {
                                format!("✖ Disconnected ({})\n{}", err, smb.unc_or_mount_path)
                            }
                        }
                        SmbStatus::Probing | SmbStatus::Unknown => {
                            if is_zh {
                                format!("⏳ 正在偵測連線狀態...\n{}", smb.unc_or_mount_path)
                            } else {
                                format!("⏳ Probing connection...\n{}", smb.unc_or_mount_path)
                            }
                        }
                    };
                    ui.horizontal(|ui| {
                        draw_smb_status_icon(ui, &smb.status);
                        if ui.button(btn_label).on_hover_text(&hover_tip).clicked() {
                            let idx = self.active_pane_index();
                            if is_offline {
                                self.status_toast = if is_zh {
                                    format!(
                                        "✖ 無法連線至遠端資料夾「{}」— 請確認網路或 Tailscale/VPN 是否已連線",
                                        smb.name
                                    )
                                } else {
                                    format!(
                                        "✖ Unable to connect to remote folder '{}' - check network or Tailscale/VPN",
                                        smb.name
                                    )
                                };
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.error_banner = Some(if is_zh {
                                        format!(
                                            "✖ 無法連線至「{}」({}) — 請確認網路或 Tailscale/VPN 是否已開啟 (已維持目前資料夾「{}」)",
                                            smb.name, smb.unc_or_mount_path, p.title
                                        )
                                    } else {
                                        format!(
                                            "✖ Cannot connect to '{}' ({}) - please verify network or VPN (kept current folder '{}')",
                                            smb.name, smb.unc_or_mount_path, p.title
                                        )
                                    });
                                }
                                self.probe_all_smb();
                            }
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(PathBuf::from(&smb.unc_or_mount_path), true);
                            }
                            ui.close_menu();
                        }
                        if ui
                            .small_button("➕")
                            .on_hover_text(t.side_add_window_tip)
                            .clicked()
                        {
                            if is_offline {
                                self.status_toast = format!(
                                    "✖ 無法連線至遠端資料夾「{}」— 請確認網路或 Tailscale/VPN 是否已連線",
                                    smb.name
                                );
                                let idx = self.active_pane_index();
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.error_banner = Some(format!(
                                        "✖ 無法連線至「{}」({}) — 請確認網路或 Tailscale/VPN 是否已開啟",
                                        smb.name, smb.unc_or_mount_path
                                    ));
                                }
                                self.probe_all_smb();
                            } else {
                                self.spawn_new_pane(PathBuf::from(&smb.unc_or_mount_path));
                            }
                            ui.close_menu();
                        }
                    });
                }

                ui.separator();
                ui.label(
                    RichText::new(if self.config.language == Language::ZhTw {
                        "💽 本機磁碟"
                    } else {
                        "💽 Local Drives"
                    })
                    .strong(),
                );
                let disks = self.sys_disks.clone();
                for (label, mount, _, _) in disks {
                    ui.horizontal(|ui| {
                        if ui.button(format!("🖴 {}", label)).clicked() {
                            let idx = self.active_pane_index();
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(mount.clone(), true);
                            }
                            ui.close_menu();
                        }
                        if ui.small_button("➕").clicked() {
                            self.spawn_new_pane(mount);
                            ui.close_menu();
                        }
                    });
                }
            });

            ui.separator();

            // Quick Theme Switcher Buttons (Dark / Light / Classic MDIE)
            if ui
                .selectable_label(self.config.theme == AppTheme::ModernDark, t.quick_theme_dark)
                .on_hover_text(t.view_theme_dark)
                .clicked()
            {
                self.config.theme = AppTheme::ModernDark;
                let _ = self.config.save();
            }

            if ui
                .selectable_label(self.config.theme == AppTheme::CleanLight, t.quick_theme_light)
                .on_hover_text(t.view_theme_light)
                .clicked()
            {
                self.config.theme = AppTheme::CleanLight;
                let _ = self.config.save();
            }

            if ui
                .selectable_label(self.config.theme == AppTheme::ClassicMdie, t.quick_theme_classic)
                .on_hover_text(t.view_theme_classic_mdie)
                .clicked()
            {
                self.config.theme = AppTheme::ClassicMdie;
                let _ = self.config.save();
            }
        });
    }

    fn render_mdi_tab_bar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.horizontal_wrapped(|ui| {
            let mut close_id = None;
            let mut activate_id = None;

            for (idx, pane) in self.panes.iter().enumerate() {
                let is_active = pane.id == self.active_pane_id;
                let frame_bg = if is_active {
                    Color32::from_rgb(0, 110, 210)
                } else {
                    Color32::from_gray(215)
                };
                let text_col = if is_active {
                    Color32::WHITE
                } else {
                    Color32::BLACK
                };

                let frame_resp = egui::Frame::none()
                    .fill(frame_bg)
                    .rounding(egui::Rounding {
                        nw: 4.0,
                        ne: 4.0,
                        sw: 0.0,
                        se: 0.0,
                    })
                    .inner_margin(egui::Margin::symmetric(8.0, 3.0))
                    .show(ui, |ui| {
                        let resp = ui.add(
                            egui::Label::new(
                                RichText::new(format!("📁 {}: {}", idx + 1, pane.title))
                                    .color(text_col)
                                    .strong(),
                            )
                            .sense(Sense::click()),
                        );
                        if resp.clicked() {
                            activate_id = Some(pane.id);
                        }
                        if resp.middle_clicked() {
                            close_id = Some(pane.id);
                        }
                        if ui
                            .add(
                                egui::Button::new(RichText::new("×").color(text_col).small())
                                    .frame(false),
                            )
                            .clicked()
                        {
                            close_id = Some(pane.id);
                        }
                    });
                if ui
                    .interact(
                        frame_resp.response.rect,
                        egui::Id::new(("tab_pill_hit", pane.id)),
                        Sense::click(),
                    )
                    .clicked()
                {
                    activate_id = Some(pane.id);
                }
            }

            if ui
                .button("➕")
                .on_hover_text(t.file_new_pane)
                .clicked()
            {
                self.execute_gesture_action(GestureAction::NewMdiWindow);
            }

            if let Some(id) = activate_id {
                if self.active_pane_id != id {
                    self.active_pane_id = id;
                    for p in &mut self.panes {
                        if p.id != id {
                            p.selected_paths.clear();
                            p.last_clicked_idx = None;
                        }
                    }
                }
            }
            if let Some(id) = close_id {
                self.close_pane_by_id(id);
            }
        });
    }

    fn render_left_sidebar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.horizontal(|ui| {
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::DrivesAndTree, t.side_tree);
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::Favorites, t.side_favorites);
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::SmbNetwork, t.side_smb);
            ui.selectable_value(
                &mut self.sidebar_tab,
                SidebarTab::ClosedHistory,
                t.side_closed_history,
            );
        });
        ui.separator();

        // When multiple sub-windows exist, clearly display the target active window at the top of the sidebar
        // and allow switching target sub-window with a single click!
        if self.panes.len() > 1 {
            let active_idx = self.active_pane_index();
            let mut switch_active_id = None;
            ui.horizontal_wrapped(|ui| {
                let target_hint = if self.config.language == Language::ZhTw {
                    "🎯 目標視窗："
                } else {
                    "🎯 Target Window:"
                };
                ui.label(RichText::new(target_hint).small().strong());
                for (idx, p) in self.panes.iter().enumerate() {
                    let is_target = idx == active_idx;
                    let pill_txt = format!("[{}] {}", idx + 1, p.title);
                    if ui.selectable_label(is_target, pill_txt).clicked() {
                        switch_active_id = Some(p.id);
                    }
                }
            });
            if let Some(id) = switch_active_id {
                self.active_pane_id = id;
                for op in &mut self.panes {
                    if op.id != id {
                        op.selected_paths.clear();
                        op.last_clicked_idx = None;
                    }
                }
            }
            ui.separator();
        }

        egui::ScrollArea::vertical().show(ui, |ui| match self.sidebar_tab {
            SidebarTab::DrivesAndTree => {
                ui.label(RichText::new(t.side_drives_header).strong());
                let disks = self.sys_disks.clone();
                for (label, mount, avail, total) in disks {
                    let used_ratio = if total > 0 {
                        1.0 - (avail as f32 / total as f32)
                    } else {
                        0.0
                    };
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            if ui.button(format!("🖴 {}", label)).clicked() {
                                let idx = self.active_pane_index();
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.navigate_to(mount.clone(), true);
                                }
                            }
                            if ui
                                .small_button(t.side_add_window)
                                .on_hover_text(t.side_add_window_tip)
                                .clicked()
                            {
                                self.spawn_new_pane(mount.clone());
                            }
                        });
                        let free_total_str = if self.config.language == Language::ZhTw {
                            format!("可用 {} / 共 {}", format_size(avail), format_size(total))
                        } else {
                            format!("Free {} / Total {}", format_size(avail), format_size(total))
                        };
                        ui.add(egui::ProgressBar::new(used_ratio).text(free_total_str));
                    });
                }

                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    ui.label(RichText::new(t.side_remote_header).strong());
                    if ui
                        .small_button("🔄")
                        .on_hover_text(t.side_refresh_tip)
                        .clicked()
                    {
                        self.refresh_system_remote_folders();
                    }
                });
                if self.is_discovering_remotes {
                    ui.label(
                        RichText::new(t.side_reading_remotes)
                            .small()
                            .color(Color32::from_rgb(200, 140, 0)),
                    );
                }
                let sys_smbs = self.system_smb_shares.clone();
                let usr_smbs = self.config.smb_bookmarks.clone();
                for smb in sys_smbs.iter().chain(usr_smbs.iter()) {
                    let is_offline = matches!(smb.status, SmbStatus::Offline(_));
                    let btn_label = match &smb.status {
                        SmbStatus::Online(_) => RichText::new(&smb.name),
                        SmbStatus::Offline(_) => {
                            RichText::new(format!("{} {}", smb.name, t.side_disconnected))
                                .color(Color32::from_rgb(240, 100, 100))
                        }
                        SmbStatus::Probing | SmbStatus::Unknown => {
                            RichText::new(format!("{} {}", smb.name, t.side_probing))
                        }
                    };
                    ui.horizontal(|ui| {
                        draw_smb_status_icon(ui, &smb.status);
                        if ui
                            .button(btn_label)
                            .on_hover_text(&smb.unc_or_mount_path)
                            .clicked()
                        {
                            let idx = self.active_pane_index();
                            if is_offline {
                                self.status_toast = format!(
                                    "✖ 無法連線至遠端資料夾「{}」— 請確認網路或 Tailscale/VPN 是否已連線",
                                    smb.name
                                );
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.error_banner = Some(format!(
                                        "✖ 無法連線至「{}」({}) — 請確認網路或 Tailscale/VPN 是否已開啟 (已維持目前資料夾「{}」)",
                                        smb.name, smb.unc_or_mount_path, p.title
                                    ));
                                }
                                self.probe_all_smb();
                            }
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(PathBuf::from(&smb.unc_or_mount_path), true);
                            }
                        }
                        if ui.small_button("➕").clicked() {
                            if is_offline {
                                self.status_toast = format!(
                                    "✖ 無法連線至遠端資料夾「{}」— 請確認網路或 Tailscale/VPN 是否已連線",
                                    smb.name
                                );
                            } else {
                                self.spawn_new_pane(PathBuf::from(&smb.unc_or_mount_path));
                            }
                        }
                    });
                }

                ui.add_space(8.0);
                ui.label(RichText::new(t.side_system_folders).strong());
                let mut quick_dirs = Vec::new();
                if let Some(h) = dirs::home_dir() {
                    quick_dirs.push((t.dir_home, h));
                }
                if let Some(d) = dirs::desktop_dir() {
                    quick_dirs.push((t.dir_desktop, d));
                }
                if let Some(dl) = dirs::download_dir() {
                    quick_dirs.push((t.dir_downloads, dl));
                }
                if let Some(doc) = dirs::document_dir() {
                    quick_dirs.push((t.dir_documents, doc));
                }
                if let Some(pic) = dirs::picture_dir() {
                    quick_dirs.push((t.dir_pictures, pic));
                }

                for (name, path) in quick_dirs {
                    ui.horizontal(|ui| {
                        if ui.button(name).clicked() {
                            let idx = self.active_pane_index();
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(path.clone(), true);
                            }
                        }
                        if ui.small_button("➕").clicked() {
                            self.spawn_new_pane(path);
                        }
                    });
                }
            }
            SidebarTab::Favorites => {
                ui.label(RichText::new(t.fav_groups_header).strong());
                if ui.button(t.fav_save_workspace_group).clicked() {
                    self.show_save_group_modal = true;
                }
                let groups = self.config.workspace_groups.clone();
                let mut remove_grp = None;
                for (gi, grp) in groups.iter().enumerate() {
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            if ui
                                .button(RichText::new(format!("📦 {}", grp.name)).strong())
                                .clicked()
                            {
                                self.panes.clear();
                                for (i, ps) in grp.paths.iter().enumerate() {
                                    self.panes
                                        .push(MdiChildPane::new(i + 1, PathBuf::from(ps)));
                                }
                                self.next_pane_id = self.panes.len() + 1;
                                self.active_pane_id = 1;
                                self.config.layout_mode = grp.layout;
                                self.sync_config_paths();
                            }
                            if ui.small_button("🗑").clicked() {
                                remove_grp = Some(gi);
                            }
                        });
                        ui.label(
                            RichText::new(format!("包含 {} 個並排視窗", grp.paths.len())).small(),
                        );
                    });
                }
                if let Some(gi) = remove_grp {
                    self.config.workspace_groups.remove(gi);
                    let _ = self.config.save();
                }

                ui.separator();
                ui.label(RichText::new(t.fav_folders_header).strong());
                if ui.button(t.fav_add_current_folder).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        self.config.favorite_folders.push((
                            p.title.clone(),
                            p.current_path.to_string_lossy().into_owned(),
                        ));
                        let _ = self.config.save();
                    }
                }
                let favs = self.config.favorite_folders.clone();
                let mut remove_fav = None;
                for (fi, (name, path_s)) in favs.iter().enumerate() {
                    ui.horizontal(|ui| {
                        if ui.button(format!("⭐ {}", name)).clicked() {
                            let idx = self.active_pane_index();
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(PathBuf::from(path_s), true);
                            }
                        }
                        if ui.small_button("➕").clicked() {
                            self.spawn_new_pane(PathBuf::from(path_s));
                        }
                        if ui.small_button("×").clicked() {
                            remove_fav = Some(fi);
                        }
                    });
                }
                if let Some(fi) = remove_fav {
                    self.config.favorite_folders.remove(fi);
                    let _ = self.config.save();
                }
            }
            SidebarTab::SmbNetwork => {
                ui.label(RichText::new(t.smb_explorer_header).strong());
                ui.label(
                    RichText::new(t.smb_safe_note)
                        .small()
                        .color(Color32::from_rgb(0, 130, 80)),
                );
                ui.horizontal(|ui| {
                    if ui.button(t.smb_refresh_btn).clicked() {
                        self.refresh_system_remote_folders();
                    }
                    if ui.button(t.smb_custom_add_btn).clicked() {
                        self.show_smb_dialog = true;
                    }
                });
                ui.separator();

                if self.is_discovering_remotes {
                    ui.label(
                        RichText::new(t.smb_reading_bg)
                            .small()
                            .color(Color32::from_rgb(200, 140, 0)),
                    );
                }
                let sys_smbs = self.system_smb_shares.clone();
                if sys_smbs.is_empty() && !self.is_discovering_remotes {
                    ui.label(
                        RichText::new(t.smb_none_found)
                            .small()
                            .color(Color32::GRAY),
                    );
                }
                for smb in &sys_smbs {
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            draw_smb_status_icon(ui, &smb.status);
                            ui.label(RichText::new(&smb.name).strong());
                        });
                        ui.label(RichText::new(&smb.unc_or_mount_path).small().color(Color32::GRAY));
                        let is_zh = self.config.language == Language::ZhTw;
                        let (badge, col) = match &smb.status {
                            SmbStatus::Unknown => ((if is_zh { "⏳ 偵測中..." } else { "⏳ Checking..." }).to_string(), Color32::GRAY),
                            SmbStatus::Probing => (
                                (if is_zh { "⏳ 背景連線檢測中..." } else { "⏳ Probing connection..." }).to_string(),
                                Color32::from_rgb(220, 160, 20),
                            ),
                            SmbStatus::Online(ms) => (
                                if is_zh { format!("● 已連線 ({} ms)", ms) } else { format!("● Online ({} ms)", ms) },
                                Color32::from_rgb(35, 205, 90),
                            ),
                            SmbStatus::Offline(reason) => (
                                if is_zh { format!("✖ 無法連線: {}", reason) } else { format!("✖ Disconnected: {}", reason) },
                                Color32::from_rgb(240, 80, 80),
                            ),
                        };
                        ui.label(RichText::new(badge).color(col).small());
                        ui.horizontal(|ui| {
                            if ui.small_button(t.smb_btn_open).clicked() {
                                let idx = self.active_pane_index();
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.navigate_to(PathBuf::from(&smb.unc_or_mount_path), true);
                                }
                            }
                            if ui.small_button(t.smb_btn_new_window).clicked() {
                                self.spawn_new_pane(PathBuf::from(&smb.unc_or_mount_path));
                            }
                        });
                    });
                }

                if !self.config.smb_bookmarks.is_empty() {
                    ui.separator();
                    ui.label(RichText::new(t.smb_custom_header).strong());
                }
                let smbs = self.config.smb_bookmarks.clone();
                let mut remove_smb_idx = None;
                for (si, smb) in smbs.iter().enumerate() {
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            draw_smb_status_icon(ui, &smb.status);
                            ui.label(RichText::new(&smb.name).strong());
                            ui.with_layout(
                                egui::Layout::right_to_left(egui::Align::Center),
                                |ui| {
                                    if ui
                                        .small_button("×")
                                        .on_hover_text(if self.config.language == Language::ZhTw { "刪除此自訂連線書籤" } else { "Delete this bookmark" })
                                        .clicked()
                                    {
                                        remove_smb_idx = Some(si);
                                    }
                                },
                            );
                        });
                        ui.label(RichText::new(&smb.unc_or_mount_path).small().color(Color32::GRAY));
                        let is_zh = self.config.language == Language::ZhTw;
                        let (badge, col) = match &smb.status {
                            SmbStatus::Unknown => ((if is_zh { "⏳ 偵測中..." } else { "⏳ Checking..." }).to_string(), Color32::GRAY),
                            SmbStatus::Probing => (
                                (if is_zh { "⏳ 背景連線檢測中..." } else { "⏳ Probing connection..." }).to_string(),
                                Color32::from_rgb(220, 160, 20),
                            ),
                            SmbStatus::Online(ms) => (
                                if is_zh { format!("● 已連線 ({} ms)", ms) } else { format!("● Online ({} ms)", ms) },
                                Color32::from_rgb(35, 205, 90),
                            ),
                            SmbStatus::Offline(reason) => (
                                if is_zh { format!("✖ 無法連線: {}", reason) } else { format!("✖ Disconnected: {}", reason) },
                                Color32::from_rgb(240, 80, 80),
                            ),
                        };
                        ui.label(RichText::new(badge).color(col).small());
                        ui.horizontal(|ui| {
                            if ui.small_button(t.smb_btn_open).clicked() {
                                let idx = self.active_pane_index();
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.navigate_to(PathBuf::from(&smb.unc_or_mount_path), true);
                                }
                            }
                            if ui.small_button(t.smb_btn_new_window).clicked() {
                                self.spawn_new_pane(PathBuf::from(&smb.unc_or_mount_path));
                            }
                        });
                    });
                }
                if let Some(si) = remove_smb_idx {
                    self.config.smb_bookmarks.remove(si);
                    let _ = self.config.save();
                }
            }
            SidebarTab::ClosedHistory => {
                let hist_header = if self.config.language == Language::ZhTw { "🕒 已關閉視窗恢復列表" } else { "🕒 Closed Windows History" };
                ui.label(RichText::new(hist_header).strong());
                let hist = self.config.closed_history.clone();
                if hist.is_empty() {
                    ui.label(t.fav_empty);
                }
                for path_s in hist {
                    if ui.button(format!("🔄 {}", path_s)).clicked() {
                        self.spawn_new_pane(PathBuf::from(path_s));
                    }
                }
            }
        });
    }

    fn render_right_preview(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.heading(t.preview_title);
        ui.label(
            RichText::new(t.preview_heic_sandboxed)
                .small()
                .color(Color32::from_rgb(20, 140, 70)),
        );
        ui.separator();

        egui::ScrollArea::vertical().show(ui, |ui| match &self.preview_state {
            PreviewPayload::None => {
                ui.label(t.preview_no_selection);
            }
            PreviewPayload::Loading(p) => {
                ui.spinner();
                ui.label(format!("沙盒非同步讀取中: {}", p.to_string_lossy()));
            }
            PreviewPayload::Image {
                path,
                width,
                height,
                format_note,
                ..
            } => {
                ui.label(RichText::new(path.file_name().unwrap_or_default().to_string_lossy()).strong());
                ui.label(RichText::new(format_note).small().color(Color32::from_rgb(0, 120, 215)));
                ui.label(format!("預覽解析度: {} × {}", width, height));
                if let Some(ref tex) = self.preview_texture {
                    let avail_w = ui.available_width().max(120.0);
                    let aspect = (*height as f32) / ((*width as f32).max(1.0));
                    let disp_size = Vec2::new(avail_w, (avail_w * aspect).min(360.0));
                    ui.image((tex.id(), disp_size));
                }
            }
            PreviewPayload::Text {
                path,
                content,
                encoding_note,
            } => {
                ui.label(RichText::new(path.file_name().unwrap_or_default().to_string_lossy()).strong());
                ui.label(
                    RichText::new(encoding_note)
                        .small()
                        .color(Color32::from_rgb(20, 140, 70)),
                );
                ui.separator();
                ui.add(
                    egui::TextEdit::multiline(&mut content.as_str())
                        .font(egui::TextStyle::Monospace)
                        .desired_width(f32::INFINITY),
                );
            }
            PreviewPayload::MetadataOnly { path, summary } => {
                ui.label(RichText::new(path.to_string_lossy()).strong());
                ui.separator();
                ui.label(summary);
            }
        });
    }

    fn render_mdi_workspace(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        let workspace_rect = ui.available_rect_before_wrap();
        let n = self.panes.len().max(1);

        // If workspace_rect shifted (e.g. Left Sidebar or Right Preview toggled), keep floating windows aligned inside workspace!
        if let Some(prev_ws) = self.last_workspace_rect {
            let delta_min = workspace_rect.min - prev_ws.min;
            let size_diff = (workspace_rect.size() - prev_ws.size()).length_sq();
            if delta_min.length_sq() > 1.0 || size_diff > 4.0 {
                if self.config.layout_mode == WindowLayoutMode::Cascade {
                    self.needs_cascade_recalc = true;
                } else if self.config.layout_mode == WindowLayoutMode::MdiFree {
                    for p in &mut self.panes {
                        if let Some(r) = p.float_rect {
                            p.float_rect = Some(r.translate(delta_min));
                        }
                    }
                }
            }
        }
        self.last_workspace_rect = Some(workspace_rect);

        if self.needs_cascade_recalc && self.config.layout_mode == WindowLayoutMode::Cascade {
            self.recalculate_cascade_rects(workspace_rect);
        }

        // Calculate target rectangles for each MDI child window based on active layout mode
        let mut calculated_rects: Vec<(usize, Rect)> = Vec::with_capacity(n);

        match self.config.layout_mode {
            WindowLayoutMode::TabbedMaximized => {
                let active_idx = self.active_pane_index();
                calculated_rects.push((active_idx, workspace_rect));
            }
            WindowLayoutMode::TileHorizontally => {
                let col_w = workspace_rect.width() / (n as f32);
                for i in 0..n {
                    let r = Rect::from_min_size(
                        Pos2::new(
                            workspace_rect.min.x + (i as f32) * col_w,
                            workspace_rect.min.y,
                        ),
                        Vec2::new((col_w - 3.0).max(180.0), workspace_rect.height()),
                    );
                    self.panes[i].float_rect = Some(r);
                    calculated_rects.push((i, r));
                }
            }
            WindowLayoutMode::TileVertically => {
                let row_h = workspace_rect.height() / (n as f32);
                for i in 0..n {
                    let r = Rect::from_min_size(
                        Pos2::new(
                            workspace_rect.min.x,
                            workspace_rect.min.y + (i as f32) * row_h,
                        ),
                        Vec2::new(workspace_rect.width(), (row_h - 3.0).max(140.0)),
                    );
                    self.panes[i].float_rect = Some(r);
                    calculated_rects.push((i, r));
                }
            }
            WindowLayoutMode::TileGrid => {
                let cols = (n as f32).sqrt().ceil() as usize;
                let rows = (n + cols - 1) / cols;
                let cell_h = workspace_rect.height() / (rows as f32);
                for i in 0..n {
                    let r_idx = i / cols;
                    let c = i % cols;
                    let row_start = r_idx * cols;
                    let cols_in_this_row = (n - row_start).min(cols).max(1);
                    let cell_w = workspace_rect.width() / (cols_in_this_row as f32);
                    let r = Rect::from_min_size(
                        Pos2::new(
                            workspace_rect.min.x + (c as f32) * cell_w,
                            workspace_rect.min.y + (r_idx as f32) * cell_h,
                        ),
                        Vec2::new((cell_w - 3.0).max(120.0), (cell_h - 3.0).max(100.0)),
                    );
                    self.panes[i].float_rect = Some(r);
                    calculated_rects.push((i, r));
                }
            }
            WindowLayoutMode::Cascade | WindowLayoutMode::MdiFree => {
                let max_w = (workspace_rect.width() - 8.0).max(200.0);
                let max_h = (workspace_rect.height() - 8.0).max(140.0);
                for i in 0..n {
                    let default_offset = (i as f32) * 30.0;
                    let raw_rect = self.panes[i].float_rect.unwrap_or_else(|| {
                        Rect::from_min_size(
                            Pos2::new(
                                workspace_rect.min.x + 12.0 + default_offset,
                                workspace_rect.min.y + 12.0 + default_offset,
                            ),
                            Vec2::new(
                                (workspace_rect.width() * 0.72).max(320.0),
                                (workspace_rect.height() * 0.76).max(240.0),
                            ),
                        )
                    });
                    // Strictly clamp rect inside workspace_rect so it NEVER overlaps Sidebar or Top Toolbar!
                    let w = raw_rect.width().clamp(260.0_f32.min(max_w), max_w);
                    let h = raw_rect.height().clamp(180.0_f32.min(max_h), max_h);
                    let x = raw_rect.min.x.clamp(
                        workspace_rect.min.x + 4.0,
                        (workspace_rect.max.x - w - 4.0).max(workspace_rect.min.x + 4.0),
                    );
                    let y = raw_rect.min.y.clamp(
                        workspace_rect.min.y + 4.0,
                        (workspace_rect.max.y - h - 4.0).max(workspace_rect.min.y + 4.0),
                    );
                    let rect = Rect::from_min_size(Pos2::new(x, y), Vec2::new(w, h));
                    self.panes[i].float_rect = Some(rect);
                    calculated_rects.push((i, rect));
                }
                // In overlapping mode, render active window last so it appears on top!
                let active_id = self.active_pane_id;
                calculated_rects.sort_by_key(|(idx, _)| self.panes[*idx].id == active_id);
            }
        }

        let ctx = ui.ctx().clone();
        let pointer_pos = ctx.input(|i| i.pointer.latest_pos());
        let primary_down = ctx.input(|i| i.pointer.primary_down());
        let primary_released = ctx.input(|i| i.pointer.button_released(egui::PointerButton::Primary));
        let rmb_pressed = ctx.input(|i| i.pointer.button_pressed(egui::PointerButton::Secondary));
        let rmb_down = ctx.input(|i| i.pointer.secondary_down());
        let rmb_released = ctx.input(|i| i.pointer.button_released(egui::PointerButton::Secondary));

        let is_any_overlay_open = ctx.memory(|m| m.any_popup_open())
            || self.context_menu.is_some()
            || self.show_search_dialog
            || self.show_smb_dialog
            || self.show_gesture_dialog
            || self.show_about_dialog
            || self.show_save_group_modal
            || self.create_item_modal.is_some()
            || self.rename_modal.is_some();

        let mut pane_to_close = None;
        let mut pane_to_clone = None;
        let mut pane_to_maximize = None;
        let mut newly_activated_id = None;
        let mut preview_req = None;
        let mut drop_transfer: Option<(Vec<PathBuf>, PathBuf, bool)> = None;
        let mut hovered_drop_target: Option<(PathBuf, String)> = None;
        let mut hovered_rmb_target: Option<(usize, Option<crate::fs_ops::FileEntry>)> = None;
        let mut switch_to_free_mode = false;

        for (order_idx, (pane_idx, rect)) in calculated_rects.iter().copied().enumerate() {
            let pane_id = self.panes[pane_idx].id;
            let is_active = pane_id == self.active_pane_id;
            let clip_rect = rect.intersect(workspace_rect);

            // Check if the mouse pointer is currently inside a window that is in front of this pane
            let pointer_occluded = pointer_pos
                .map(|pos| {
                    calculated_rects[order_idx + 1..]
                        .iter()
                        .any(|(_, front_r)| front_r.intersect(workspace_rect).contains(pos))
                })
                .unwrap_or(false);

            if let Some(pos) = pointer_pos {
                if clip_rect.contains(pos) && !pointer_occluded {
                    hovered_rmb_target = Some((pane_id, None));
                    if let Some((src_pane_id, _)) = &self.drag_payload {
                        if *src_pane_id != pane_id {
                            hovered_drop_target = Some((
                                self.panes[pane_idx].current_path.clone(),
                                self.panes[pane_idx].title.clone(),
                            ));
                        }
                    }
                }
            }

            // Use a child_ui on CentralPanel's registered LayerId so `ctx.layer_id_at(pointer_pos)`
            // matches `child_ui.layer_id()`, enabling mouse wheel scrolling and scrollbar dragging!
            let mut child_ui = ui.new_child(
                egui::UiBuilder::new()
                    .max_rect(rect)
                    .layout(egui::Layout::top_down(egui::Align::Min)),
            );
            child_ui.set_clip_rect(clip_rect);
            child_ui.set_max_size(rect.size());

            // Subtle drop shadow in Cascade / MdiFree mode
            if matches!(
                self.config.layout_mode,
                WindowLayoutMode::Cascade | WindowLayoutMode::MdiFree
            ) {
                child_ui
                    .painter()
                    .with_clip_rect(workspace_rect)
                    .rect_filled(
                        rect.translate(Vec2::new(4.0, 4.0)),
                        4.0,
                        Color32::from_black_alpha(55),
                    );
            }

            // Activate this pane when clicking anywhere inside its visible rect (if not occluded by a higher pane or popup overlay)
            let is_pointer_in_pane = !is_any_overlay_open
                && !pointer_occluded
                && pointer_pos
                    .map(|p| {
                        workspace_rect.contains(p)
                            && clip_rect.contains(p)
                            && ctx.layer_id_at(p) == Some(ui.layer_id())
                    })
                    .unwrap_or(false);
            if is_pointer_in_pane && ctx.input(|i| i.pointer.primary_pressed()) {
                newly_activated_id = Some(pane_id);
            }

            let is_drop_pane_target = !pointer_occluded
                && self
                    .drag_payload
                    .as_ref()
                    .map(|(src_id, _)| {
                        *src_id != pane_id
                            && pointer_pos.map(|p| clip_rect.contains(p)).unwrap_or(false)
                    })
                    .unwrap_or(false);

            let border_color = if is_drop_pane_target {
                Color32::from_rgb(0, 185, 90)
            } else if is_active {
                Color32::from_rgb(0, 120, 215)
            } else {
                Color32::from_gray(140)
            };

            let bg_fill = if self.config.theme == AppTheme::ModernDark {
                Color32::from_rgb(28, 30, 36)
            } else {
                Color32::WHITE
            };

            // Paint the pane background strictly inside `rect` (clipped to `clip_rect`) so it NEVER
            // stretches beyond `rect` even if inner table columns are wide!
            child_ui
                .painter()
                .with_clip_rect(clip_rect)
                .rect_filled(rect, 3.0, bg_fill);

            child_ui.scope(|ui| {
                ui.set_clip_rect(clip_rect);
                ui.set_max_size(rect.size());

                // 1. Classic MDIE Sub-Window Title Bar (draggable anywhere across the full bar to move window!)
                let title_bg = if is_active {
                    if self.config.theme == AppTheme::ClassicMdie {
                        Color32::from_rgb(185, 209, 234)
                    } else {
                        Color32::from_rgb(0, 102, 204)
                    }
                } else {
                    Color32::from_gray(215)
                };
                let title_fg = if is_active && self.config.theme != AppTheme::ClassicMdie {
                    Color32::WHITE
                } else {
                    Color32::BLACK
                };

                let title_bar_rect =
                    Rect::from_min_size(rect.min, Vec2::new(rect.width(), 25.0));
                let title_bar_clipped = title_bar_rect.intersect(clip_rect);
                ui.painter()
                    .with_clip_rect(clip_rect)
                    .rect_filled(title_bar_rect, 2.0, title_bg);

                // Make the ENTIRE 25px title bar interactable so clicking anywhere on it activates the window
                // and dragging anywhere on it moves the window (in Free/Cascade mode)!
                let title_bar_hit = ui.interact(
                    title_bar_clipped,
                    egui::Id::new(("pane_title_bar_hit", pane_id)),
                    Sense::click_and_drag(),
                );
                if !is_any_overlay_open && !pointer_occluded {
                    if title_bar_hit.clicked() || title_bar_hit.drag_started() {
                        newly_activated_id = Some(pane_id);
                    }
                }
                if title_bar_hit.dragged()
                    && !pointer_occluded
                    && self.config.layout_mode != WindowLayoutMode::TabbedMaximized
                {
                    newly_activated_id = Some(pane_id);
                    switch_to_free_mode = true;
                    let delta = title_bar_hit.drag_delta();
                    if let Some(ref mut r) = self.panes[pane_idx].float_rect {
                        let mut moved = r.translate(delta);
                        let w = moved.width();
                        let h = moved.height();
                        let max_x =
                            (workspace_rect.max.x - w).max(workspace_rect.min.x);
                        let max_y =
                            (workspace_rect.max.y - h).max(workspace_rect.min.y);
                        let nx = moved.min.x.clamp(workspace_rect.min.x, max_x);
                        let ny = moved.min.y.clamp(workspace_rect.min.y, max_y);
                        moved =
                            Rect::from_min_size(Pos2::new(nx, ny), Vec2::new(w, h));
                        *r = moved;
                    }
                }

                egui::Frame::none()
                    .inner_margin(egui::Margin::symmetric(6.0, 3.0))
                    .show(ui, |ui| {
                        ui.set_max_width((rect.width() - 12.0).max(60.0));
                        ui.horizontal(|ui| {
                            let title_text = if rect.width() >= 480.0 {
                                format!(
                                    "📁 [{}] {}  {}",
                                    pane_idx + 1,
                                    self.panes[pane_idx].title,
                                    t.win_drag_hint
                                )
                            } else {
                                format!("📁 [{}] {}", pane_idx + 1, self.panes[pane_idx].title)
                            };
                            let title_resp = ui
                                .add(
                                    egui::Label::new(
                                        RichText::new(title_text).color(title_fg).strong(),
                                    )
                                    .truncate()
                                    .selectable(false)
                                    .sense(Sense::click_and_drag()),
                                )
                                .on_hover_cursor(egui::CursorIcon::Default)
                                .on_hover_text(t.win_drag_tip);

                            if (title_resp.clicked() || title_resp.drag_started())
                                && !pointer_occluded
                            {
                                newly_activated_id = Some(pane_id);
                            }

                            ui.with_layout(
                                egui::Layout::right_to_left(egui::Align::Center),
                                |ui| {
                                    if ui
                                        .button(RichText::new("✕").small())
                                        .on_hover_text(t.win_close_tip)
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        pane_to_close = Some(pane_id);
                                    }
                                    if ui
                                        .button(RichText::new("🗖").small())
                                        .on_hover_text(t.win_max_restore_tip)
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        pane_to_maximize = Some(pane_id);
                                    }
                                    if ui
                                        .button(RichText::new("📑").small())
                                        .on_hover_text(t.win_clone_tip)
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        pane_to_clone =
                                            Some(self.panes[pane_idx].current_path.clone());
                                    }
                                },
                            );
                        });
                    });

                // 2. Sub-Window Address Bar + Breadcrumb + Instant MDIE Search Bar
                ui.horizontal(|ui| {
                    ui.set_max_width((rect.width() - 8.0).max(80.0));
                    if ui.small_button("⬅").clicked() && !pointer_occluded {
                        newly_activated_id = Some(pane_id);
                        self.panes[pane_idx].go_back();
                    }
                    if ui.small_button("➡").clicked() && !pointer_occluded {
                        newly_activated_id = Some(pane_id);
                        self.panes[pane_idx].go_forward();
                    }
                    if ui.small_button("⬆").clicked() && !pointer_occluded {
                        newly_activated_id = Some(pane_id);
                        self.panes[pane_idx].go_up();
                    }
                    let rem_bar_w = (ui.available_width() - 78.0).max(80.0);
                    let addr_w = (rem_bar_w * 0.56).max(50.0);
                    let search_w = (rem_bar_w * 0.40).max(36.0);
                    let addr_resp = ui.add(
                        egui::TextEdit::singleline(&mut self.panes[pane_idx].address_input)
                            .desired_width(addr_w),
                    );
                    if (addr_resp.has_focus() || addr_resp.gained_focus() || addr_resp.clicked())
                        && !pointer_occluded
                    {
                        newly_activated_id = Some(pane_id);
                    }
                    if addr_resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                        let raw_in = self.panes[pane_idx].address_input.trim().to_string();
                        let expanded = expand_env_vars(&raw_in);
                        self.panes[pane_idx].navigate_to(PathBuf::from(expanded), true);
                    }

                    // Per-pane MDIE Search Box + 3 Search Modes (Filter / Best Match / Select Match)
                    let search_resp = ui.add(
                        egui::TextEdit::singleline(&mut self.panes[pane_idx].search_query)
                            .hint_text(t.search_placeholder)
                            .desired_width(search_w),
                    );
                    if (search_resp.has_focus()
                        || search_resp.gained_focus()
                        || search_resp.changed()
                        || search_resp.clicked())
                        && !pointer_occluded
                    {
                        newly_activated_id = Some(pane_id);
                    }
                    if search_resp.changed() {
                        let show_hidden = self.config.show_hidden;
                        self.panes[pane_idx].apply_sort_and_filter(show_hidden);
                    }
                    if search_resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                        let count = self.panes[pane_idx].execute_mdie_select_matching();
                        self.status_toast =
                            format!("☑ MDIE 條件選取完成：已自動勾選 {} 個相符項目", count);
                    }

                    egui::ComboBox::from_id_salt(format!("smode_{}", pane_id))
                        .width(64.0)
                        .selected_text(match self.panes[pane_idx].search_mode {
                            PaneSearchMode::InstantFilter => t.search_mode_filter,
                            PaneSearchMode::BestMatchJump => t.search_mode_best_match,
                            PaneSearchMode::SelectMatching => t.search_mode_select,
                        })
                        .show_ui(ui, |ui| {
                            let show_hidden = self.config.show_hidden;
                            if ui
                                .selectable_value(
                                    &mut self.panes[pane_idx].search_mode,
                                    PaneSearchMode::InstantFilter,
                                    t.search_mode_filter,
                                )
                                .clicked()
                                || ui
                                    .selectable_value(
                                        &mut self.panes[pane_idx].search_mode,
                                        PaneSearchMode::BestMatchJump,
                                        t.search_mode_best_match,
                                    )
                                    .clicked()
                                || ui
                                    .selectable_value(
                                        &mut self.panes[pane_idx].search_mode,
                                        PaneSearchMode::SelectMatching,
                                        t.search_mode_select,
                                    )
                                    .clicked()
                            {
                                self.panes[pane_idx].apply_sort_and_filter(show_hidden);
                            }
                        });
                });

                // 3. Error / Disconnected SMB Protection Banner (if any)
                if let Some(ref err) = self.panes[pane_idx].error_banner.clone() {
                    egui::Frame::none()
                        .fill(if self.config.theme == AppTheme::ModernDark {
                            Color32::from_rgb(70, 24, 28)
                        } else {
                            Color32::from_rgb(255, 232, 232)
                        })
                        .inner_margin(egui::Margin::symmetric(6.0, 4.0))
                        .show(ui, |ui| {
                            ui.set_max_width((rect.width() - 12.0).max(80.0));
                            ui.horizontal_wrapped(|ui| {
                                draw_smb_status_icon(ui, &SmbStatus::Offline(String::new()));
                                ui.label(
                                    RichText::new(err)
                                        .color(if self.config.theme == AppTheme::ModernDark {
                                            Color32::from_rgb(255, 165, 165)
                                        } else {
                                            Color32::from_rgb(185, 20, 20)
                                        })
                                        .strong(),
                                );
                                if ui.small_button("✕ 關閉提示").clicked() {
                                    self.panes[pane_idx].error_banner = None;
                                }
                            });
                        });
                }

                // 4. Drop Target Zone for Cross-Window File Comparison & Move/Copy
                if let Some((src_pane_id, dragged_paths)) = self.drag_payload.clone() {
                    if src_pane_id != pane_id {
                        egui::Frame::none()
                            .fill(Color32::from_rgb(220, 242, 255))
                            .inner_margin(3.0)
                            .show(ui, |ui| {
                                ui.horizontal(|ui| {
                                    ui.label(
                                        RichText::new(format!(
                                            "📥 放開滑鼠左鍵直接移動至此 (按住 Ctrl/Alt 放開為複製) [{} 個項目]:",
                                            dragged_paths.len()
                                        ))
                                        .color(Color32::from_rgb(0, 90, 180))
                                        .strong(),
                                    );
                                    if ui.small_button("📋 複製到此處").clicked() {
                                        drop_transfer = Some((
                                            dragged_paths.clone(),
                                            self.panes[pane_idx].current_path.clone(),
                                            false,
                                        ));
                                    }
                                    if ui.small_button("✂ 移動到此處").clicked() {
                                        drop_transfer = Some((
                                            dragged_paths.clone(),
                                            self.panes[pane_idx].current_path.clone(),
                                            true,
                                        ));
                                    }
                                });
                            });
                    }
                }

                // 5. High-Speed Virtualized File Table (handles 100,000+ files with zero lag)
                let show_hidden = self.config.show_hidden;
                let scroll_req = self.panes[pane_idx].scroll_request;
                self.panes[pane_idx].scroll_request = ScrollRequest::None;

                // Temporarily suppress scroll delta for occluded background windows so only the topmost window scrolls
                let saved_scroll_delta = if pointer_occluded {
                    ctx.input_mut(|i| {
                        let d = i.smooth_scroll_delta;
                        i.smooth_scroll_delta = Vec2::ZERO;
                        d
                    })
                } else {
                    Vec2::ZERO
                };

                // Progress / Loading banner while reading directory contents
                if self.panes[pane_idx].is_loading {
                    egui::Frame::none()
                        .fill(if self.config.theme == AppTheme::ModernDark {
                            Color32::from_rgb(22, 32, 48)
                        } else {
                            Color32::from_rgb(230, 242, 255)
                        })
                        .inner_margin(egui::Margin::symmetric(8.0, 4.0))
                        .show(ui, |ui| {
                            ui.horizontal(|ui| {
                                ui.spinner();
                                let is_zh = self.config.language == Language::ZhTw;
                                let load_txt = if is_zh {
                                    "⚡ 正在極速載入目錄清單中..."
                                } else {
                                    "⚡ Loading directory contents..."
                                };
                                ui.label(RichText::new(load_txt).strong().color(Color32::from_rgb(0, 120, 215)));
                            });
                        });
                }

                let table_top = (ui.cursor().min.y + 2.0).min(rect.max.y - 30.0);
                let table_rect = Rect::from_min_max(
                    Pos2::new(rect.min.x + 4.0, table_top),
                    Pos2::new(rect.max.x - 5.0, (rect.max.y - 6.0).max(table_top + 30.0)),
                );
                let table_clip = table_rect.intersect(clip_rect);
                let avail_w = table_rect.width().max(160.0);
                let avail_h = table_rect.height().max(40.0);
                let body_h = (avail_h - 22.0).max(24.0);
                let col_avail_w = (avail_w - 18.0).max(140.0);
                let width_bucket = (avail_w / 60.0) as i32;

                let mut table_ui = ui.new_child(
                    egui::UiBuilder::new()
                        .max_rect(table_rect)
                        .layout(egui::Layout::top_down(egui::Align::Min)),
                );
                table_ui.set_clip_rect(table_clip);
                table_ui.set_max_size(Vec2::new(avail_w, avail_h));

                // Ensure high-contrast, always-visible right scrollbar track and draggable thumb
                {
                    let vis = table_ui.visuals_mut();
                    if self.config.theme == AppTheme::ModernDark {
                        vis.extreme_bg_color = Color32::from_rgb(18, 20, 26);
                        vis.widgets.inactive.bg_fill = Color32::from_rgb(95, 105, 125);
                        vis.widgets.hovered.bg_fill = Color32::from_rgb(135, 150, 180);
                        vis.widgets.active.bg_fill = Color32::from_rgb(60, 150, 240);
                    } else {
                        vis.extreme_bg_color = Color32::from_rgb(232, 236, 244);
                        vis.widgets.inactive.bg_fill = Color32::from_rgb(165, 176, 194);
                        vis.widgets.hovered.bg_fill = Color32::from_rgb(110, 145, 195);
                        vis.widgets.active.bg_fill = Color32::from_rgb(0, 115, 215);
                    }
                }

                table_ui.push_id(("pane_table", pane_id, width_bucket), |ui| {
                    ui.set_clip_rect(table_clip);
                    ui.set_max_size(Vec2::new(avail_w, avail_h));
                    let c1_w = (col_avail_w * 0.43).clamp(70.0, 260.0);
                    let c2_w = (col_avail_w * 0.16).clamp(42.0, 95.0);
                    let c3_w = (col_avail_w * 0.17).clamp(45.0, 110.0);
                    let mut table = TableBuilder::new(ui)
                        .striped(true)
                        .resizable(true)
                        .vscroll(true)
                        .auto_shrink([false, false])
                        .drag_to_scroll(false)
                        .cell_layout(egui::Layout::left_to_right(egui::Align::Center))
                        .column(Column::initial(c1_w).at_least(60.0).clip(true))
                        .column(Column::initial(c2_w).at_least(40.0).clip(true))
                        .column(Column::initial(c3_w).at_least(42.0).clip(true))
                        .column(Column::remainder().at_least(50.0).clip(true))
                        .min_scrolled_height(body_h)
                        .max_scroll_height(body_h);

                        match scroll_req {
                            ScrollRequest::Top => {
                                table = table.scroll_to_row(0, Some(egui::Align::TOP));
                            }
                            ScrollRequest::Bottom => {
                                let last = self.panes[pane_idx]
                                    .filtered_indices
                                    .len()
                                    .saturating_sub(1);
                                table = table.scroll_to_row(last, Some(egui::Align::BOTTOM));
                            }
                            ScrollRequest::Row(r) => {
                                table = table.scroll_to_row(r, Some(egui::Align::Center));
                            }
                            ScrollRequest::None => {}
                        }

                        table
                            .header(20.0, |mut header| {
                                let cur_col = self.panes[pane_idx].sort_col;
                                let cur_asc = self.panes[pane_idx].sort_asc;
                                let arrow = |col: SortColumn| {
                                    if cur_col == col {
                                        if cur_asc { " ▲" } else { " ▼" }
                                    } else {
                                        ""
                                    }
                                };

                                header.col(|ui| {
                                    if ui
                                        .button(
                                            RichText::new(format!(
                                                "{}{}",
                                                t.col_name,
                                                arrow(SortColumn::Name)
                                            ))
                                            .strong(),
                                        )
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        newly_activated_id = Some(pane_id);
                                        toggle_sort(&mut self.panes[pane_idx], SortColumn::Name, show_hidden);
                                    }
                                });
                                header.col(|ui| {
                                    if ui
                                        .button(
                                            RichText::new(format!(
                                                "{}{}",
                                                t.col_size,
                                                arrow(SortColumn::Size)
                                            ))
                                            .strong(),
                                        )
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        newly_activated_id = Some(pane_id);
                                        toggle_sort(&mut self.panes[pane_idx], SortColumn::Size, show_hidden);
                                    }
                                });
                                header.col(|ui| {
                                    if ui
                                        .button(
                                            RichText::new(format!(
                                                "{}{}",
                                                t.col_type,
                                                arrow(SortColumn::Type)
                                            ))
                                            .strong(),
                                        )
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        newly_activated_id = Some(pane_id);
                                        toggle_sort(&mut self.panes[pane_idx], SortColumn::Type, show_hidden);
                                    }
                                });
                                header.col(|ui| {
                                    if ui
                                        .button(
                                            RichText::new(format!(
                                                "{}{}",
                                                t.col_modified,
                                                arrow(SortColumn::Modified)
                                            ))
                                            .strong(),
                                        )
                                        .clicked()
                                        && !pointer_occluded
                                    {
                                        newly_activated_id = Some(pane_id);
                                        toggle_sort(
                                            &mut self.panes[pane_idx],
                                            SortColumn::Modified,
                                            show_hidden,
                                        );
                                    }
                                });
                            })
                            .body(|body| {
                                let total_rows = self.panes[pane_idx].filtered_indices.len();
                                let is_zh = self.config.language == Language::ZhTw;
                                let mut nav_dir = None;
                                let mut open_file = None;

                                body.rows(22.0, total_rows, |mut row| {
                                    let row_idx = row.index();
                                    let entry_idx = self.panes[pane_idx].filtered_indices[row_idx];
                                    let entry = self.panes[pane_idx].entries[entry_idx].clone();
                                    let is_selected = is_active
                                        && self.panes[pane_idx].selected_paths.contains(&entry.path);
                                    row.set_selected(is_selected);

                                    let row_bg_col = if is_selected {
                                        Color32::from_rgb(0, 120, 215)
                                    } else if self.config.theme == AppTheme::ModernDark {
                                        if row_idx % 2 == 0 {
                                            Color32::from_rgb(28, 30, 36)
                                        } else {
                                            Color32::from_rgb(35, 38, 45)
                                        }
                                    } else if row_idx % 2 == 0 {
                                        Color32::WHITE
                                    } else {
                                        Color32::from_rgb(245, 248, 252)
                                    };

                                    let text_col = if is_selected {
                                        Color32::WHITE
                                    } else if self.config.theme == AppTheme::ModernDark {
                                        Color32::from_gray(230)
                                    } else {
                                        Color32::from_gray(20)
                                    };

                                    let mut r_rects: Vec<Rect> = Vec::with_capacity(4);
                                    let mut combined_resp: Option<egui::Response> = None;

                                    row.col(|ui| {
                                        let label_str = if entry.had_special_encoding {
                                            format!("{} {} [🛡UTF8]", entry.icon(), entry.display_name)
                                        } else {
                                            format!("{} {}", entry.icon(), entry.display_name)
                                        };
                                        let desired = Vec2::new(ui.available_width().max(40.0), 20.0);
                                        let (c_rect, resp) =
                                            ui.allocate_exact_size(desired, Sense::click_and_drag());
                                        let resp = resp.on_hover_cursor(egui::CursorIcon::Default);
                                        let cell_clip = c_rect.intersect(clip_rect);
                                        ui.painter().with_clip_rect(cell_clip).rect_filled(
                                            c_rect,
                                            if is_selected { 2.0 } else { 0.0 },
                                            row_bg_col,
                                        );
                                        ui.painter().with_clip_rect(cell_clip).text(
                                            Pos2::new(c_rect.min.x + 3.0, c_rect.center().y),
                                            egui::Align2::LEFT_CENTER,
                                            &label_str,
                                            egui::FontId::proportional(13.5),
                                            text_col,
                                        );
                                        r_rects.push(c_rect);
                                        combined_resp = Some(resp);
                                    });

                                    row.col(|ui| {
                                        let desired = Vec2::new(ui.available_width().max(20.0), 20.0);
                                        let (c_rect, resp) =
                                            ui.allocate_exact_size(desired, Sense::click_and_drag());
                                        let resp = resp.on_hover_cursor(egui::CursorIcon::Default);
                                        let cell_clip = c_rect.intersect(clip_rect);
                                        ui.painter().with_clip_rect(cell_clip).rect_filled(
                                            c_rect,
                                            if is_selected { 2.0 } else { 0.0 },
                                            row_bg_col,
                                        );
                                        if !entry.is_dir {
                                            ui.painter().with_clip_rect(cell_clip).text(
                                                Pos2::new(c_rect.min.x + 2.0, c_rect.center().y),
                                                egui::Align2::LEFT_CENTER,
                                                format_size(entry.size),
                                                egui::FontId::proportional(13.0),
                                                text_col,
                                            );
                                        }
                                        r_rects.push(c_rect);
                                        combined_resp = Some(match combined_resp.take() {
                                            Some(prev) => prev.union(resp),
                                            None => resp,
                                        });
                                    });

                                    row.col(|ui| {
                                        let desired = Vec2::new(ui.available_width().max(20.0), 20.0);
                                        let (c_rect, resp) =
                                            ui.allocate_exact_size(desired, Sense::click_and_drag());
                                        let resp = resp.on_hover_cursor(egui::CursorIcon::Default);
                                        let cell_clip = c_rect.intersect(clip_rect);
                                        ui.painter().with_clip_rect(cell_clip).rect_filled(
                                            c_rect,
                                            if is_selected { 2.0 } else { 0.0 },
                                            row_bg_col,
                                        );
                                        ui.painter().with_clip_rect(cell_clip).text(
                                            Pos2::new(c_rect.min.x + 2.0, c_rect.center().y),
                                            egui::Align2::LEFT_CENTER,
                                            entry.type_label(is_zh),
                                            egui::FontId::proportional(13.0),
                                            text_col,
                                        );
                                        r_rects.push(c_rect);
                                        combined_resp = Some(match combined_resp.take() {
                                            Some(prev) => prev.union(resp),
                                            None => resp,
                                        });
                                    });

                                    row.col(|ui| {
                                        let desired = Vec2::new(ui.available_width().max(20.0), 20.0);
                                        let (c_rect, resp) =
                                            ui.allocate_exact_size(desired, Sense::click_and_drag());
                                        let resp = resp.on_hover_cursor(egui::CursorIcon::Default);
                                        let cell_clip = c_rect.intersect(clip_rect);
                                        ui.painter().with_clip_rect(cell_clip).rect_filled(
                                            c_rect,
                                            if is_selected { 2.0 } else { 0.0 },
                                            row_bg_col,
                                        );
                                        ui.painter().with_clip_rect(cell_clip).text(
                                            Pos2::new(c_rect.min.x + 2.0, c_rect.center().y),
                                            egui::Align2::LEFT_CENTER,
                                            &entry.modified_str,
                                            egui::FontId::proportional(13.0),
                                            text_col,
                                        );
                                        r_rects.push(c_rect);
                                        combined_resp = Some(match combined_resp.take() {
                                            Some(prev) => prev.union(resp),
                                            None => resp,
                                        });
                                    });

                                    let full_row_rect = r_rects
                                        .iter()
                                        .copied()
                                        .reduce(|a, b| a.union(b))
                                        .unwrap_or(Rect::NOTHING);

                                    // Check if pointer is inside this row (for right-click menu & folder drop target)
                                    if !pointer_occluded {
                                        if let Some(pos) = pointer_pos {
                                            if full_row_rect.contains(pos) && clip_rect.contains(pos) {
                                                hovered_rmb_target =
                                                    Some((pane_id, Some(entry.clone())));

                                                if let Some((_, ref dragged_paths)) = self.drag_payload {
                                                    if entry.is_dir
                                                        && !dragged_paths.contains(&entry.path)
                                                    {
                                                        hovered_drop_target = Some((
                                                            entry.path.clone(),
                                                            entry.display_name.clone(),
                                                        ));
                                                        if let Some(first_r) = r_rects.first() {
                                                            ctx.layer_painter(egui::LayerId::new(
                                                                egui::Order::Foreground,
                                                                egui::Id::new("row_drop_hl"),
                                                            ))
                                                            .rect_stroke(
                                                                full_row_rect.intersect(clip_rect),
                                                                3.0,
                                                                Stroke::new(
                                                                    2.0,
                                                                    Color32::from_rgb(0, 185, 80),
                                                                ),
                                                            );
                                                            let _ = first_r;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if let Some(resp) = combined_resp {
                                        if (resp.clicked() || resp.drag_started() || resp.is_pointer_button_down_on()) && !pointer_occluded {
                                            newly_activated_id = Some(pane_id);
                                        }
                                        if resp.clicked() && !pointer_occluded {
                                            self.context_menu = None;
                                            for (i, p) in self.panes.iter_mut().enumerate() {
                                                if i != pane_idx {
                                                    p.selected_paths.clear();
                                                    p.last_clicked_idx = None;
                                                }
                                            }
                                            let ctrl =
                                                ctx.input(|i| i.modifiers.command || i.modifiers.ctrl);
                                            let shift = ctx.input(|i| i.modifiers.shift);
                                            if shift {
                                                if let Some(anchor) =
                                                    self.panes[pane_idx].last_clicked_idx
                                                {
                                                    let lo = anchor.min(row_idx);
                                                    let hi = anchor.max(row_idx);
                                                    if !ctrl {
                                                        self.panes[pane_idx].selected_paths.clear();
                                                    }
                                                    for r_i in lo..=hi {
                                                        if let Some(&e_i) = self.panes[pane_idx]
                                                            .filtered_indices
                                                            .get(r_i)
                                                        {
                                                            if let Some(p_clone) = self.panes[pane_idx]
                                                                .entries
                                                                .get(e_i)
                                                                .map(|e| e.path.clone())
                                                            {
                                                                self.panes[pane_idx]
                                                                    .selected_paths
                                                                    .insert(p_clone);
                                                            }
                                                        }
                                                    }
                                                }
                                            } else {
                                                if !ctrl {
                                                    self.panes[pane_idx].selected_paths.clear();
                                                }
                                                if is_selected && ctrl {
                                                    self.panes[pane_idx]
                                                        .selected_paths
                                                        .remove(&entry.path);
                                                } else {
                                                    self.panes[pane_idx]
                                                        .selected_paths
                                                        .insert(entry.path.clone());
                                                }
                                                self.panes[pane_idx].last_clicked_idx =
                                                    Some(row_idx);
                                            }
                                            preview_req = Some(entry.path.clone());
                                        }

                                        if resp.double_clicked() && !pointer_occluded {
                                            newly_activated_id = Some(pane_id);
                                            self.context_menu = None;
                                            if entry.is_dir {
                                                nav_dir = Some(entry.path.clone());
                                            } else {
                                                open_file = Some(entry.path.clone());
                                            }
                                        }

                                        // Start Left-Click Drag-and-Drop
                                        if (resp.drag_started() || resp.dragged())
                                            && !pointer_occluded
                                            && primary_down
                                            && !rmb_down
                                            && self.drag_payload.is_none()
                                        {
                                            newly_activated_id = Some(pane_id);
                                            self.context_menu = None;
                                            for (i, p) in self.panes.iter_mut().enumerate() {
                                                if i != pane_idx {
                                                    p.selected_paths.clear();
                                                    p.last_clicked_idx = None;
                                                }
                                            }
                                            if !self.panes[pane_idx]
                                                .selected_paths
                                                .contains(&entry.path)
                                            {
                                                self.panes[pane_idx].selected_paths.clear();
                                                self.panes[pane_idx]
                                                    .selected_paths
                                                    .insert(entry.path.clone());
                                            }
                                            let list: Vec<PathBuf> = self.panes[pane_idx]
                                                .selected_paths
                                                .iter()
                                                .cloned()
                                                .collect();
                                            if !list.is_empty() {
                                                self.drag_payload = Some((pane_id, list));
                                            }
                                        }
                                    }
                                });

                                if let Some(d) = nav_dir {
                                    self.panes[pane_idx].navigate_to(d, true);
                                    self.sync_config_paths();
                                }
                                if let Some(f) = open_file {
                                    preview_req = Some(f.clone());
                                    let _ = open::that(&f);
                                }
                            });
                    });

                if self.panes[pane_idx].filtered_indices.is_empty() {
                    let is_zh = self.config.language == Language::ZhTw;
                    let empty_rect = Rect::from_min_size(
                        Pos2::new(table_rect.min.x, table_top + 35.0),
                        Vec2::new(table_rect.width(), 40.0),
                    );
                    let painter = table_ui.painter().with_clip_rect(table_clip);
                    if self.panes[pane_idx].is_loading {
                        painter.text(
                            empty_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            if is_zh { "⚡ 正在載入檔案清單中..." } else { "⚡ Loading file list..." },
                            egui::FontId::proportional(14.0),
                            Color32::from_rgb(0, 120, 215),
                        );
                    } else {
                        painter.text(
                            empty_rect.center(),
                            egui::Align2::CENTER_CENTER,
                            if is_zh { "（此資料夾為空）" } else { "(This folder is empty)" },
                            egui::FontId::proportional(13.5),
                            Color32::from_gray(140),
                        );
                    }
                }

                if pointer_occluded && saved_scroll_delta != Vec2::ZERO {
                    ctx.input_mut(|i| {
                        i.smooth_scroll_delta = saved_scroll_delta;
                    });
                }
            });

            // Paint the pane border strictly around `rect` (never inflated by inner widgets!)
            child_ui
                .painter()
                .with_clip_rect(clip_rect)
                .rect_stroke(
                    rect,
                    3.0,
                    Stroke::new(
                        if is_drop_pane_target {
                            2.5
                        } else if is_active {
                            2.0
                        } else {
                            1.0
                        },
                        border_color,
                    ),
                );

            // 6. MDIE 8-Direction Window Border & Corner Resize Handles (works on every child window!)
            if self.config.layout_mode != WindowLayoutMode::TabbedMaximized {
                let c_sz = 7.0;
                let e_sz = 3.5;
                // (dir_tag, rect, cursor_icon, left, right, top, bottom)
                let handles: [(&str, Rect, egui::CursorIcon, bool, bool, bool, bool); 8] = [
                    (
                        "nw",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x - e_sz, rect.min.y - e_sz),
                            Pos2::new(rect.min.x + c_sz, rect.min.y + c_sz),
                        ),
                        egui::CursorIcon::ResizeNwSe,
                        true,
                        false,
                        true,
                        false,
                    ),
                    (
                        "ne",
                        Rect::from_min_max(
                            Pos2::new(rect.max.x - c_sz, rect.min.y - e_sz),
                            Pos2::new(rect.max.x + e_sz, rect.min.y + c_sz),
                        ),
                        egui::CursorIcon::ResizeNeSw,
                        false,
                        true,
                        true,
                        false,
                    ),
                    (
                        "sw",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x - e_sz, rect.max.y - c_sz),
                            Pos2::new(rect.min.x + c_sz, rect.max.y + e_sz),
                        ),
                        egui::CursorIcon::ResizeNeSw,
                        true,
                        false,
                        false,
                        true,
                    ),
                    (
                        "se",
                        Rect::from_min_max(
                            Pos2::new(rect.max.x - c_sz - 2.0, rect.max.y - c_sz - 2.0),
                            Pos2::new(rect.max.x + e_sz, rect.max.y + e_sz),
                        ),
                        egui::CursorIcon::ResizeNwSe,
                        false,
                        true,
                        false,
                        true,
                    ),
                    (
                        "w",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x - e_sz, rect.min.y + c_sz),
                            Pos2::new(rect.min.x + e_sz, rect.max.y - c_sz),
                        ),
                        egui::CursorIcon::ResizeHorizontal,
                        true,
                        false,
                        false,
                        false,
                    ),
                    (
                        "e",
                        Rect::from_min_max(
                            Pos2::new(rect.max.x - e_sz, rect.min.y + c_sz),
                            Pos2::new(rect.max.x + e_sz, rect.max.y - c_sz),
                        ),
                        egui::CursorIcon::ResizeHorizontal,
                        false,
                        true,
                        false,
                        false,
                    ),
                    (
                        "n",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x + c_sz, rect.min.y - e_sz),
                            Pos2::new(rect.max.x - c_sz, rect.min.y + e_sz),
                        ),
                        egui::CursorIcon::ResizeVertical,
                        false,
                        false,
                        true,
                        false,
                    ),
                    (
                        "s",
                        Rect::from_min_max(
                            Pos2::new(rect.min.x + c_sz, rect.max.y - e_sz),
                            Pos2::new(rect.max.x - c_sz, rect.max.y + e_sz),
                        ),
                        egui::CursorIcon::ResizeVertical,
                        false,
                        false,
                        false,
                        true,
                    ),
                ];

                // Draw classic MDIE bottom-right corner resize grip visual on the pane's layer
                child_ui.painter().with_clip_rect(clip_rect).text(
                    Pos2::new(rect.max.x - 3.0, rect.max.y - 2.0),
                    egui::Align2::RIGHT_BOTTOM,
                    "◢",
                    egui::FontId::proportional(11.0),
                    Color32::from_gray(145),
                );

                for (tag, h_rect, cursor, is_l, is_r, is_t, is_b) in handles {
                    let h_clipped = h_rect.intersect(workspace_rect);
                    if !h_clipped.is_positive() {
                        continue;
                    }
                    let h_resp = child_ui
                        .interact(
                            h_clipped,
                            egui::Id::new(("mdi_border_resize", pane_id, tag)),
                            Sense::drag(),
                        )
                        .on_hover_cursor(cursor);

                    if (h_resp.drag_started() || h_resp.dragged()) && !pointer_occluded {
                        newly_activated_id = Some(pane_id);
                        switch_to_free_mode = true;
                        let d = h_resp.drag_delta();
                        if let Some(ref mut r) = self.panes[pane_idx].float_rect {
                            let min_w = 220.0_f32.min(workspace_rect.width());
                            let min_h = 140.0_f32.min(workspace_rect.height());
                            if is_l {
                                r.min.x = (r.min.x + d.x)
                                    .max(workspace_rect.min.x)
                                    .min(r.max.x - min_w);
                            }
                            if is_r {
                                r.max.x = (r.max.x + d.x)
                                    .min(workspace_rect.max.x)
                                    .max(r.min.x + min_w);
                            }
                            if is_t {
                                r.min.y = (r.min.y + d.y)
                                    .max(workspace_rect.min.y)
                                    .min(r.max.y - min_h);
                            }
                            if is_b {
                                r.max.y = (r.max.y + d.y)
                                    .min(workspace_rect.max.y)
                                    .max(r.min.y + min_h);
                            }
                        }
                    }
                }
            }
        }

        if switch_to_free_mode {
            self.config.layout_mode = WindowLayoutMode::MdiFree;
        }

        // Right-Click press / drag / release handling (Context Menu vs Mouse Gestures)
        if rmb_pressed {
            self.context_menu = None;
            if let Some(pos) = pointer_pos {
                self.gesture_tracker.start(pos);
            }
            if let Some((p_id, ref maybe_entry)) = hovered_rmb_target {
                newly_activated_id = Some(p_id);
                if let Some(entry) = maybe_entry {
                    for p in &mut self.panes {
                        if p.id == p_id {
                            if !p.selected_paths.contains(&entry.path) {
                                p.selected_paths.clear();
                                p.selected_paths.insert(entry.path.clone());
                            }
                        } else {
                            p.selected_paths.clear();
                            p.last_clicked_idx = None;
                        }
                    }
                }
                self.rmb_press_target = hovered_rmb_target.clone();
            } else {
                self.rmb_press_target = None;
            }
        }
        if rmb_down && self.gesture_tracker.is_tracking {
            if let Some(pos) = pointer_pos {
                self.gesture_tracker.update_pos(pos);
                ctx.request_repaint();
            }
        }
        if rmb_released && self.gesture_tracker.is_tracking {
            let (was_drag, matched) = self.gesture_tracker.finish();
            if was_drag {
                if let Some((seq, action)) = matched {
                    self.execute_gesture_action(action);
                    self.status_toast = format!(
                        "🖱 MDIE 手勢 [{}] -> {}",
                        GestureTracker::format_arrows(&seq),
                        action.label(self.config.language)
                    );
                }
            } else if let Some(pos) = pointer_pos {
                // Stationary Right-Click -> Open Context Menu!
                let target = self.rmb_press_target.take().or(hovered_rmb_target);
                if let Some((p_id, maybe_entry)) = target {
                    newly_activated_id = Some(p_id);
                    self.context_menu = Some(ContextMenuState {
                        pos,
                        pane_id: p_id,
                        target_entry: maybe_entry,
                    });
                }
            }
        }

        // Left-Click Drag-and-Drop live tooltip & mouse release drop execution
        if let Some((_, ref dragged_paths)) = self.drag_payload.clone() {
            if primary_down {
                if let Some(pos) = pointer_pos {
                    let is_copy = ctx.input(|i| i.modifiers.ctrl || i.modifiers.alt);
                    let painter = ctx.layer_painter(egui::LayerId::new(
                        egui::Order::Tooltip,
                        egui::Id::new("mine_dnd_ghost"),
                    ));
                    let badge_text = if let Some((_, ref target_name)) = hovered_drop_target {
                        format!(
                            "{} {} 個項目 ➡ 「{}」\n(放開左鍵: {} | 按住 Ctrl/Alt: 複製)",
                            if is_copy { "📋 複製" } else { "✂ 移動" },
                            dragged_paths.len(),
                            target_name,
                            if is_copy { "複製" } else { "移動" }
                        )
                    } else {
                        format!(
                            "📦 正在拖曳 {} 個項目\n(拖曳至其他視窗或子資料夾上放開左鍵即可移動/複製)",
                            dragged_paths.len()
                        )
                    };
                    let badge_rect =
                        Rect::from_min_size(pos + Vec2::new(14.0, 14.0), Vec2::new(330.0, 44.0));
                    painter.rect_filled(badge_rect, 6.0, Color32::from_black_alpha(215));
                    painter.rect_stroke(
                        badge_rect,
                        6.0,
                        Stroke::new(
                            1.5,
                            if hovered_drop_target.is_some() {
                                Color32::from_rgb(0, 210, 100)
                            } else {
                                Color32::from_rgb(0, 170, 255)
                            },
                        ),
                    );
                    painter.text(
                        Pos2::new(badge_rect.min.x + 10.0, badge_rect.center().y),
                        egui::Align2::LEFT_CENTER,
                        badge_text,
                        egui::FontId::proportional(12.5),
                        Color32::WHITE,
                    );
                }
            } else if primary_released || !primary_down {
                if let Some((target_dir, _)) = hovered_drop_target {
                    let is_copy = ctx.input(|i| i.modifiers.ctrl || i.modifiers.alt);
                    drop_transfer = Some((dragged_paths.clone(), target_dir, !is_copy));
                }
                self.drag_payload = None;
            }
        }

        if !is_any_overlay_open {
            if let Some(id) = newly_activated_id {
                if self.active_pane_id != id {
                    self.active_pane_id = id;
                    for p in &mut self.panes {
                        if p.id != id {
                            p.selected_paths.clear();
                            p.last_clicked_idx = None;
                        }
                    }
                }
            }
        }
        if let Some(p) = preview_req {
            self.trigger_preview(p);
        }
        if let Some((srcs, dst, is_cut)) = drop_transfer {
            self.perform_file_transfer(&srcs, &dst, is_cut);
            self.drag_payload = None;
        }
        if let Some(path) = pane_to_clone {
            self.spawn_new_pane(path);
        }
        if let Some(id) = pane_to_maximize {
            self.active_pane_id = id;
            self.config.layout_mode =
                if self.config.layout_mode == WindowLayoutMode::TabbedMaximized {
                    WindowLayoutMode::TileHorizontally
                } else {
                    WindowLayoutMode::TabbedMaximized
                };
        }
        if let Some(id) = pane_to_close {
            self.close_pane_by_id(id);
        }
    }

    fn render_context_menu(&mut self, ctx: &egui::Context, t: &crate::i18n::Texts) {
        let Some(menu) = self.context_menu.clone() else {
            return;
        };

        let mut close_menu = false;
        let is_zh = self.config.language == Language::ZhTw;

        let area_resp = egui::Area::new(egui::Id::new("mine_right_click_context_menu"))
            .order(egui::Order::Foreground)
            .fixed_pos(menu.pos)
            .show(ctx, |ui| {
                egui::Frame::popup(ui.style())
                    .inner_margin(egui::Margin::symmetric(8.0, 6.0))
                    .show(ui, |ui| {
                        ui.set_min_width(210.0);
                        let pane_idx = self
                            .panes
                            .iter()
                            .position(|p| p.id == menu.pane_id)
                            .unwrap_or(0);
                        let current_dir = self
                            .panes
                            .get(pane_idx)
                            .map(|p| p.current_path.clone())
                            .unwrap_or_else(|| PathBuf::from("."));
                        let selected_list: Vec<PathBuf> = self
                            .panes
                            .get(pane_idx)
                            .map(|p| p.selected_paths.iter().cloned().collect())
                            .unwrap_or_default();

                        if let Some(ref entry) = menu.target_entry {
                            ui.label(
                                RichText::new(format!("{} {}", entry.icon(), entry.display_name))
                                    .strong()
                                    .color(Color32::from_rgb(0, 102, 204)),
                            );
                            ui.separator();

                            if ui
                                .button(if is_zh {
                                    "📂 開啟 (Open)"
                                } else {
                                    "📂 Open"
                                })
                                .clicked()
                            {
                                if entry.is_dir {
                                    if let Some(p) = self.panes.get_mut(pane_idx) {
                                        p.navigate_to(entry.path.clone(), true);
                                    }
                                    self.sync_config_paths();
                                } else {
                                    let _ = open::that(&entry.path);
                                }
                                close_menu = true;
                            }

                            if entry.is_dir
                                && ui
                                    .button(if is_zh {
                                        "➕ 在新並排視窗開啟此資料夾"
                                    } else {
                                        "➕ Open Folder in New Window"
                                    })
                                    .clicked()
                            {
                                self.spawn_new_pane(entry.path.clone());
                                close_menu = true;
                            }

                            ui.separator();

                            if ui.button(t.edit_copy).clicked() {
                                let targets = if selected_list.is_empty() {
                                    vec![entry.path.clone()]
                                } else {
                                    selected_list.clone()
                                };
                                let cnt = targets.len();
                                self.clipboard = ClipboardOp::Copy(targets);
                                self.status_toast =
                                    format!("📋 已複製 {} 個項目 (可至目標視窗按右鍵貼上)", cnt);
                                close_menu = true;
                            }

                            if ui.button(t.edit_cut).clicked() {
                                let targets = if selected_list.is_empty() {
                                    vec![entry.path.clone()]
                                } else {
                                    selected_list.clone()
                                };
                                let cnt = targets.len();
                                self.clipboard = ClipboardOp::Cut(targets);
                                self.status_toast =
                                    format!("✂ 已剪下 {} 個項目 (可至目標視窗按右鍵貼上移動)", cnt);
                                close_menu = true;
                            }

                            let has_clip = !matches!(self.clipboard, ClipboardOp::None);
                            if has_clip {
                                let paste_dest = if entry.is_dir {
                                    entry.path.clone()
                                } else {
                                    current_dir.clone()
                                };
                                let paste_lbl = if entry.is_dir {
                                    if is_zh {
                                        format!("📥 貼上至「{}」資料夾內", entry.display_name)
                                    } else {
                                        format!("📥 Paste into '{}'", entry.display_name)
                                    }
                                } else {
                                    t.edit_paste.to_string()
                                };
                                if ui.button(paste_lbl).clicked() {
                                    match self.clipboard.clone() {
                                        ClipboardOp::Copy(srcs) => {
                                            self.perform_file_transfer(&srcs, &paste_dest, false);
                                        }
                                        ClipboardOp::Cut(srcs) => {
                                            self.perform_file_transfer(&srcs, &paste_dest, true);
                                            self.clipboard = ClipboardOp::None;
                                        }
                                        ClipboardOp::None => {}
                                    }
                                    close_menu = true;
                                }
                            }

                            ui.separator();

                            if ui.button(t.edit_rename).clicked() {
                                self.rename_modal =
                                    Some((entry.path.clone(), entry.display_name.clone()));
                                close_menu = true;
                            }

                            if ui.button(t.edit_copy_path).clicked() {
                                if let Ok(mut cb) = arboard::Clipboard::new() {
                                    let _ = cb.set_text(entry.path.to_string_lossy().into_owned());
                                    self.status_toast = format!(
                                        "🔗 已複製完整路徑: {}",
                                        entry.path.to_string_lossy()
                                    );
                                }
                                close_menu = true;
                            }

                            if entry.is_dir
                                && ui
                                    .button(if is_zh {
                                        "⭐ 加入我的最愛書籤"
                                    } else {
                                        "⭐ Add to Favorites"
                                    })
                                    .clicked()
                            {
                                self.config.favorite_folders.push((
                                    entry.display_name.clone(),
                                    entry.path.to_string_lossy().into_owned(),
                                ));
                                let _ = self.config.save();
                                close_menu = true;
                            }

                            ui.separator();

                            if ui
                                .button(
                                    RichText::new(t.edit_delete)
                                        .color(Color32::from_rgb(200, 40, 40)),
                                )
                                .clicked()
                            {
                                let targets = if selected_list.is_empty() {
                                    vec![entry.path.clone()]
                                } else {
                                    selected_list.clone()
                                };
                                let cnt = targets.len();
                                for p_del in targets {
                                    let _ = trash::delete(&p_del);
                                }
                                if let Some(p) = self.panes.get_mut(pane_idx) {
                                    p.selected_paths.clear();
                                    p.trigger_reload();
                                }
                                self.status_toast =
                                    format!("🗑 已將 {} 個項目移至資源回收桶", cnt);
                                close_menu = true;
                            }

                            ui.separator();
                        } else {
                            ui.label(
                                RichText::new(format!(
                                    "📁 {}",
                                    current_dir.to_string_lossy()
                                ))
                                .strong()
                                .color(Color32::from_rgb(0, 102, 204)),
                            );
                            ui.separator();

                            if !matches!(self.clipboard, ClipboardOp::None)
                                && ui.button(t.edit_paste).clicked()
                            {
                                match self.clipboard.clone() {
                                    ClipboardOp::Copy(srcs) => {
                                        self.perform_file_transfer(&srcs, &current_dir, false);
                                    }
                                    ClipboardOp::Cut(srcs) => {
                                        self.perform_file_transfer(&srcs, &current_dir, true);
                                        self.clipboard = ClipboardOp::None;
                                    }
                                    ClipboardOp::None => {}
                                }
                                close_menu = true;
                            }
                        }

                        // Folder-level actions always available at bottom of right-click menu
                        if ui.button(t.file_new_folder).clicked() {
                            self.create_item_modal =
                                Some((current_dir.clone(), true, "New_Folder".into()));
                            close_menu = true;
                        }
                        if ui.button(t.file_new_file).clicked() {
                            self.create_item_modal =
                                Some((current_dir.clone(), false, "note.txt".into()));
                            close_menu = true;
                        }
                        if ui.button(t.view_refresh).clicked() {
                            if let Some(p) = self.panes.get_mut(pane_idx) {
                                p.trigger_reload();
                            }
                            close_menu = true;
                        }
                        if ui.button(t.file_open_terminal).clicked() {
                            open_terminal_at(&current_dir);
                            close_menu = true;
                        }
                        if ui.button(t.file_open_native).clicked() {
                            let _ = open::that(&current_dir);
                            close_menu = true;
                        }
                    });
            });

        // Close context menu if user clicked outside of it
        if ctx.input(|i| i.pointer.button_pressed(egui::PointerButton::Primary)) {
            if let Some(pos) = ctx.input(|i| i.pointer.interact_pos()) {
                if !area_resp.response.rect.contains(pos) {
                    close_menu = true;
                }
            }
        }
        if close_menu {
            self.context_menu = None;
        }
    }

    fn render_gesture_overlay(&self, ctx: &egui::Context) {
        if !self.gesture_tracker.is_tracking
            || self.gesture_tracker.trail.len() < 2
            || self.gesture_tracker.max_distance < 22.0
        {
            return;
        }
        let painter = ctx.layer_painter(egui::LayerId::new(
            egui::Order::Foreground,
            egui::Id::new("mdie_gesture_overlay"),
        ));

        // Draw glowing cyan-blue gesture trail
        painter.add(egui::Shape::line(
            self.gesture_tracker.trail.clone(),
            Stroke::new(4.0, Color32::from_rgb(0, 190, 255)),
        ));

        // Draw HUD badge at center of screen showing current arrows + matched command
        let screen = ctx.screen_rect();
        let center = screen.center();
        let arrows = GestureTracker::format_arrows(&self.gesture_tracker.current_directions);
        let action_label = self
            .gesture_tracker
            .current_matched_action()
            .map(|a| a.label(self.config.language))
            .unwrap_or(if self.config.language == Language::ZhTw {
                "(繼續拖曳以匹配手勢...)"
            } else {
                "(Keep dragging to match gesture...)"
            });

        let hud_rect = Rect::from_center_size(center, Vec2::new(360.0, 74.0));
        painter.rect_filled(hud_rect, 10.0, Color32::from_black_alpha(210));
        painter.rect_stroke(
            hud_rect,
            10.0,
            Stroke::new(2.0, Color32::from_rgb(0, 190, 255)),
        );
        painter.text(
            Pos2::new(center.x, center.y - 14.0),
            egui::Align2::CENTER_CENTER,
            format!("🖱 {}", if arrows.is_empty() { "•" } else { &arrows }),
            egui::FontId::proportional(22.0),
            Color32::from_rgb(0, 220, 255),
        );
        painter.text(
            Pos2::new(center.x, center.y + 16.0),
            egui::Align2::CENTER_CENTER,
            action_label,
            egui::FontId::proportional(15.0),
            Color32::WHITE,
        );
    }

    fn render_dialogs(&mut self, ctx: &egui::Context, t: &crate::i18n::Texts) {
        // 1. Next-Gen Ultra-Fast Deep Search Engine Dialog
        if self.show_search_dialog {
            let mut open = self.show_search_dialog;
            egui::Window::new(t.dlg_search_title)
                .order(egui::Order::Foreground)
                .open(&mut open)
                .default_size(Vec2::new(760.0, 520.0))
                .resizable(true)
                .show(ctx, |ui| {
                    let is_zh = self.config.language == Language::ZhTw;
                    ui.label(
                        RichText::new(
                            if is_zh {
                                "💡 支援智慧語法：模糊拼字、>10MB (檔案大小)、ext:heic,jpg,rs (副檔名)、type:dir、re:正則表達式、以及內文關鍵字搜尋"
                            } else {
                                "💡 Smart query syntax: fuzzy spell, >10MB (file size), ext:heic,jpg,rs (extensions), type:dir, re:regex, and full-text grep"
                            },
                        )
                        .small()
                        .color(Color32::from_rgb(0, 110, 200)),
                    );
                    ui.horizontal(|ui| {
                        ui.label(if is_zh { "🔍 檔名/條件:" } else { "🔍 Name / Query:" });
                        let q_resp = ui.add(
                            egui::TextEdit::singleline(&mut self.deep_search_query)
                                .hint_text(if is_zh { "例如: report >1MB 或 ext:jpg,png 或 screenshot" } else { "e.g.: report >1MB or ext:jpg,png or screenshot" })
                                .desired_width(260.0),
                        );
                        ui.label(if is_zh { "📄 內文包含:" } else { "📄 Content grep:" });
                        ui.add(
                            egui::TextEdit::singleline(&mut self.deep_search_grep)
                                .hint_text(if is_zh { "(選填) 搜尋檔案內部文字" } else { "(Optional) Search inside file text" })
                                .desired_width(150.0),
                        );
                        let scope_label = if is_zh { "搜尋所有並排視窗目錄" } else { "Search all open pane directories" };
                        ui.checkbox(&mut self.deep_search_scope_all_panes, scope_label);

                        let search_btn_text = if is_zh { "🚀 開始極速搜尋" } else { "🚀 Search Now" };
                        let trigger = (q_resp.lost_focus()
                            && ui.input(|i| i.key_pressed(egui::Key::Enter)))
                            || ui.button(search_btn_text).clicked();
                        if trigger {
                            self.deep_search_cancel.store(true, Ordering::Relaxed);
                            self.deep_search_cancel =
                                std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
                            self.deep_search_results.clear();
                            self.deep_search_selected.clear();
                            self.deep_search_scanned = 0;
                            self.deep_search_running = true;

                            let roots: Vec<PathBuf> = if self.deep_search_scope_all_panes {
                                self.panes.iter().map(|p| p.current_path.clone()).collect()
                            } else {
                                let idx = self.active_pane_index();
                                self.panes
                                    .get(idx)
                                    .map(|p| vec![p.current_path.clone()])
                                    .unwrap_or_default()
                            };
                            self.deep_search_rx = Some(spawn_deep_search(
                                roots,
                                self.deep_search_query.clone(),
                                self.deep_search_grep.clone(),
                                2000,
                                self.deep_search_cancel.clone(),
                            ));
                        }
                        let stop_btn_text = if is_zh { "⏹ 停止" } else { "⏹ Stop" };
                        if self.deep_search_running && ui.button(stop_btn_text).clicked() {
                            self.deep_search_cancel.store(true, Ordering::Relaxed);
                            self.deep_search_running = false;
                        }
                    });

                    ui.horizontal(|ui| {
                        let summary_str = if is_zh {
                            format!(
                                "已掃描: {} 個項目 | 找到: {} 筆結果 | 耗時: {} ms",
                                self.deep_search_scanned,
                                self.deep_search_results.len(),
                                self.deep_search_elapsed_ms
                            )
                        } else {
                            format!(
                                "Scanned: {} items | Found: {} results | Elapsed: {} ms",
                                self.deep_search_scanned,
                                self.deep_search_results.len(),
                                self.deep_search_elapsed_ms
                            )
                        };
                        ui.label(summary_str);
                        ui.separator();
                        let select_all_btn = if is_zh { "☑ 全選結果" } else { "☑ Select All" };
                        if ui.small_button(select_all_btn).clicked() {
                            for r in &self.deep_search_results {
                                self.deep_search_selected.insert(r.entry.path.clone());
                            }
                        }
                        let open_dirs_btn = if is_zh { "➕ 將所選檔案所在目錄開啟為新並排視窗" } else { "➕ Open selected directories in new panes" };
                        if ui
                            .small_button(open_dirs_btn)
                            .clicked()
                        {
                            let mut dirs = std::collections::HashSet::new();
                            for p in &self.deep_search_selected {
                                if let Some(parent) = p.parent() {
                                    dirs.insert(parent.to_path_buf());
                                }
                            }
                            for d in dirs.into_iter().take(6) {
                                self.spawn_new_pane(d);
                            }
                        }
                    });
                    ui.separator();

                    let results_snapshot = self.deep_search_results.clone();
                    let mut jump_to_dir = None;
                    let mut spawn_dir = None;

                    TableBuilder::new(ui)
                        .striped(true)
                        .resizable(true)
                        .column(Column::initial(220.0).clip(true))
                        .column(Column::initial(75.0))
                        .column(Column::initial(260.0).clip(true))
                        .column(Column::remainder())
                        .header(20.0, |mut h| {
                            h.col(|ui| {
                                ui.strong(if is_zh { "檔案名稱 (Name)" } else { "File Name" });
                            });
                            h.col(|ui| {
                                ui.strong(if is_zh { "大小" } else { "Size" });
                            });
                            h.col(|ui| {
                                ui.strong(if is_zh { "所在目錄 (Directory)" } else { "Directory" });
                            });
                            h.col(|ui| {
                                ui.strong(if is_zh { "快速動作 / 內文預覽" } else { "Quick Action / Preview" });
                            });
                        })
                        .body(|body| {
                            body.rows(23.0, results_snapshot.len(), |mut row| {
                                let item = &results_snapshot[row.index()];
                                let checked =
                                    self.deep_search_selected.contains(&item.entry.path);
                                row.col(|ui| {
                                    let mut c = checked;
                                    if ui
                                        .checkbox(
                                            &mut c,
                                            format!(
                                                "{} {}",
                                                item.entry.icon(),
                                                item.entry.display_name
                                            ),
                                        )
                                        .changed()
                                    {
                                        if c {
                                            self.deep_search_selected
                                                .insert(item.entry.path.clone());
                                        } else {
                                            self.deep_search_selected.remove(&item.entry.path);
                                        }
                                    }
                                });
                                row.col(|ui| {
                                    ui.label(format_size(item.entry.size));
                                });
                                row.col(|ui| {
                                    ui.label(item.parent_dir.to_string_lossy());
                                });
                                row.col(|ui| {
                                    let open_act = if is_zh { "📂 在目前視窗開啟" } else { "📂 Open in Active Window" };
                                    if ui.small_button(open_act).clicked() {
                                        jump_to_dir =
                                            Some((item.parent_dir.clone(), item.entry.path.clone()));
                                    }
                                    let spawn_act = if is_zh { "➕ 新視窗並排" } else { "➕ Open in New Pane" };
                                    if ui.small_button(spawn_act).clicked() {
                                        spawn_dir = Some(item.parent_dir.clone());
                                    }
                                    if let Some(ref snip) = item.matched_content_snippet {
                                        ui.label(
                                            RichText::new(snip)
                                                .small()
                                                .color(Color32::from_rgb(0, 120, 80)),
                                        );
                                    }
                                });
                            });
                        });

                    if let Some((dir, file_p)) = jump_to_dir {
                        let idx = self.active_pane_index();
                        if let Some(p) = self.panes.get_mut(idx) {
                            p.navigate_to(dir, true);
                            p.selected_paths.insert(file_p.clone());
                        }
                        self.trigger_preview(file_p);
                    }
                    if let Some(dir) = spawn_dir {
                        self.spawn_new_pane(dir);
                    }
                });
            self.show_search_dialog = open;
        }

        // 2. Mouse Gesture Settings & Cheat Sheet Dialog
        if self.show_gesture_dialog {
            let mut open = self.show_gesture_dialog;
            egui::Window::new(t.dlg_gesture_title)
                .order(egui::Order::Foreground)
                .open(&mut open)
                .default_size(Vec2::new(560.0, 440.0))
                .show(ctx, |ui| {
                    let is_zh = self.config.language == Language::ZhTw;
                    ui.label(
                        if is_zh {
                            "按住滑鼠右鍵並在畫面任意處拖曳即可觸發手勢（支援 L=左, R=右, U=上, D=下 組合）："
                        } else {
                            "Hold Right-Click and drag anywhere to trigger gestures (supports L=Left, R=Right, U=Up, D=Down):"
                        },
                    );
                    ui.separator();

                    ui.horizontal(|ui| {
                        ui.label(if is_zh { "新增/修改手勢序列 (如 L, DR, ULR):" } else { "Add/Edit gesture sequence (e.g. L, DR, ULR):" });
                        ui.add(
                            egui::TextEdit::singleline(&mut self.new_gesture_seq)
                                .desired_width(70.0),
                        );
                        egui::ComboBox::from_id_salt("gesture_act_combo")
                            .selected_text(self.new_gesture_action.label(self.config.language))
                            .show_ui(ui, |ui| {
                                for &act in GestureAction::all() {
                                    ui.selectable_value(
                                        &mut self.new_gesture_action,
                                        act,
                                        act.label(self.config.language),
                                    );
                                }
                            });
                        let bind_text = if is_zh { "➕ 綁定手勢" } else { "➕ Bind Gesture" };
                        if ui.button(bind_text).clicked() {
                            let cleaned: String = self
                                .new_gesture_seq
                                .to_uppercase()
                                .chars()
                                .filter(|c| matches!(c, 'L' | 'R' | 'U' | 'D'))
                                .collect();
                            if !cleaned.is_empty() {
                                self.gesture_tracker
                                    .bindings
                                    .insert(cleaned, self.new_gesture_action);
                                self.sync_config_paths();
                            }
                        }
                    });
                    ui.separator();

                    egui::ScrollArea::vertical().show(ui, |ui| {
                        let mut keys: Vec<String> =
                            self.gesture_tracker.bindings.keys().cloned().collect();
                        keys.sort();
                        let mut to_remove = None;
                        for k in keys {
                            if let Some(&act) = self.gesture_tracker.bindings.get(&k) {
                                ui.horizontal(|ui| {
                                    ui.label(
                                        RichText::new(format!(
                                            "🖱 {:<6} ({})",
                                            k,
                                            GestureTracker::format_arrows(&k)
                                        ))
                                        .monospace()
                                        .strong(),
                                    );
                                    ui.label("➡");
                                    ui.label(act.label(self.config.language));
                                    if ui.small_button("🗑").clicked() {
                                        to_remove = Some(k.clone());
                                    }
                                });
                            }
                        }
                        if let Some(k) = to_remove {
                            self.gesture_tracker.bindings.remove(&k);
                            self.sync_config_paths();
                        }
                    });
                });
            self.show_gesture_dialog = open;
        }

        // 3. Non-Blocking SMB Manager Dialog
        if self.show_smb_dialog {
            let mut open = self.show_smb_dialog;
            egui::Window::new(t.dlg_smb_title)
                .order(egui::Order::Foreground)
                .open(&mut open)
                .default_size(Vec2::new(580.0, 420.0))
                .show(ctx, |ui| {
                    let is_zh = self.config.language == Language::ZhTw;
                    ui.label(
                        if is_zh {
                            "MINE 啟動時會自動讀取您在作業系統（Windows 檔案總管 / macOS Finder）中已設定的網路磁碟與遠端資料夾，並以非阻塞執行緒進行連線探測。"
                        } else {
                            "MINE automatically reads OS network drives and remote folders at startup and probes connectivity asynchronously."
                        },
                    );
                    ui.horizontal(|ui| {
                        let refresh_btn = if is_zh { "🔄 重新抓取系統檔案總管遠端設定" } else { "🔄 Refresh OS Explorer Shares" };
                        if ui
                            .button(refresh_btn)
                            .clicked()
                        {
                            self.refresh_system_remote_folders();
                        }
                        if ui.button(t.dlg_smb_test_async).clicked() {
                            self.probe_all_smb();
                        }
                    });
                    ui.separator();

                    ui.label(RichText::new(if is_zh { "🌐 系統檔案總管已設定之遠端資料夾 (自動偵測):" } else { "🌐 Explorer Configured Remote Folders (Auto-Detected):" }).strong());
                    let sys_smbs = self.system_smb_shares.clone();
                    if sys_smbs.is_empty() {
                        ui.label(
                            RichText::new(t.smb_none_found)
                                .small()
                                .color(Color32::GRAY),
                        );
                    }
                    let mut open_target_now = None;
                    let mut spawn_target_now = None;
                    for smb in &sys_smbs {
                        ui.horizontal(|ui| {
                            ui.strong(&smb.name);
                            ui.label(RichText::new(&smb.unc_or_mount_path).small().color(Color32::GRAY));
                            ui.label(format!("{:?}", smb.status));
                            if ui.small_button(t.smb_btn_open).clicked() {
                                open_target_now = Some(PathBuf::from(&smb.unc_or_mount_path));
                            }
                            if ui.small_button(t.smb_btn_new_window).clicked() {
                                spawn_target_now = Some(PathBuf::from(&smb.unc_or_mount_path));
                            }
                        });
                    }

                    ui.separator();
                    ui.label(RichText::new(if is_zh { "📌 額外自訂遠端書籤 (選填):" } else { "📌 Custom Remote Bookmarks (Optional):" }).strong());
                    ui.horizontal(|ui| {
                        ui.label(if is_zh { "名稱:" } else { "Name:" });
                        ui.add(
                            egui::TextEdit::singleline(&mut self.new_smb_name)
                                .hint_text(if is_zh { "例如: 公司 NAS" } else { "e.g. Office NAS" })
                                .desired_width(95.0),
                        );
                        ui.label("IP/Host:");
                        ui.add(
                            egui::TextEdit::singleline(&mut self.new_smb_host)
                                .hint_text("192.168.x.x")
                                .desired_width(105.0),
                        );
                        ui.label(if is_zh { "UNC/掛載路徑:" } else { "UNC / Mount Path:" });
                        ui.add(
                            egui::TextEdit::singleline(&mut self.new_smb_unc)
                                .hint_text("\\\\IP\\share or /Volumes/...")
                                .desired_width(150.0),
                        );
                        let add_label = if is_zh { "➕ 新增" } else { "➕ Add" };
                        if ui.button(add_label).clicked() {
                            let name_trimmed = self.new_smb_name.trim().to_string();
                            let unc_trimmed = self.new_smb_unc.trim().to_string();
                            let host_trimmed = self.new_smb_host.trim().to_string();
                            if !name_trimmed.is_empty() && !unc_trimmed.is_empty() {
                                let auto_host = if host_trimmed.is_empty() {
                                    crate::fs_ops::extract_host_from_remote_path(&unc_trimmed)
                                } else {
                                    host_trimmed
                                };
                                self.config.smb_bookmarks.push(
                                    crate::fs_ops::SmbShareBookmark {
                                        name: name_trimmed,
                                        unc_or_mount_path: unc_trimmed,
                                        host_ip: auto_host,
                                        port: self.new_smb_port.parse().unwrap_or(445),
                                        status: SmbStatus::Unknown,
                                    },
                                );
                                self.new_smb_name.clear();
                                self.new_smb_unc.clear();
                                self.new_smb_host.clear();
                                let _ = self.config.save();
                                self.probe_all_smb();
                            }
                        }
                    });
                    let mut remove_idx = None;
                    for (i, smb) in self.config.smb_bookmarks.iter().enumerate() {
                        ui.horizontal(|ui| {
                            ui.strong(&smb.name);
                            ui.label(&smb.unc_or_mount_path);
                            ui.label(format!("{:?}", smb.status));
                            if ui.small_button(t.smb_btn_open).clicked() {
                                open_target_now = Some(PathBuf::from(&smb.unc_or_mount_path));
                            }
                            if ui.small_button("🗑").clicked() {
                                remove_idx = Some(i);
                            }
                        });
                    }
                    if let Some(i) = remove_idx {
                        self.config.smb_bookmarks.remove(i);
                        let _ = self.config.save();
                    }
                    if let Some(p_open) = open_target_now {
                        let idx = self.active_pane_index();
                        if let Some(p) = self.panes.get_mut(idx) {
                            p.navigate_to(p_open, true);
                        }
                    }
                    if let Some(p_spawn) = spawn_target_now {
                        self.spawn_new_pane(p_spawn);
                    }
                });
            self.show_smb_dialog = open;
        }

        // 4. Save Workspace Group Modal
        if self.show_save_group_modal {
            let is_zh = self.config.language == Language::ZhTw;
            let group_modal_title = if is_zh { "💾 儲存多視窗並排工作群組 (Workspace Group)" } else { "💾 Save Multi-Window Workspace Group" };
            egui::Window::new(group_modal_title)
                .order(egui::Order::Foreground)
                .collapsible(false)
                .show(ctx, |ui| {
                    let desc = if is_zh {
                        format!("將目前開啟的 {} 個子視窗路徑與排列模式存為群組，隨時一鍵展開：", self.panes.len())
                    } else {
                        format!("Save current {} open window paths & layout as a group for 1-click restore:", self.panes.len())
                    };
                    ui.label(desc);
                    ui.text_edit_singleline(&mut self.new_group_name);
                    ui.horizontal(|ui| {
                        if ui.button(t.btn_save).clicked() {
                            let paths = self
                                .panes
                                .iter()
                                .map(|p| p.current_path.to_string_lossy().into_owned())
                                .collect();
                            self.config.workspace_groups.push(WorkspaceGroupBookmark {
                                name: self.new_group_name.clone(),
                                layout: self.config.layout_mode,
                                paths,
                            });
                            let _ = self.config.save();
                            self.show_save_group_modal = false;
                        }
                        if ui.button(t.btn_cancel).clicked() {
                            self.show_save_group_modal = false;
                        }
                    });
                });
        }

        // 5. Create Folder / File Modal
        if let Some((dir_path, is_folder, ref mut name_buf)) = self.create_item_modal.clone() {
            let mut close = false;
            let mut current_name = name_buf.clone();
            let title = if is_folder {
                t.file_new_folder
            } else {
                t.file_new_file
            };
            egui::Window::new(title)
                .order(egui::Order::Foreground)
                .collapsible(false)
                .show(ctx, |ui| {
                    ui.text_edit_singleline(&mut current_name);
                    ui.horizontal(|ui| {
                        if ui.button(t.btn_create).clicked() {
                            let target = dir_path.join(&current_name);
                            let _ = if is_folder {
                                std::fs::create_dir_all(&target)
                            } else {
                                std::fs::File::create(&target).map(|_| ())
                            };
                            for p in &mut self.panes {
                                p.trigger_reload();
                            }
                            close = true;
                        }
                        if ui.button(t.btn_cancel).clicked() {
                            close = true;
                        }
                    });
                });
            if close {
                self.create_item_modal = None;
            } else if let Some((_, _, ref mut n)) = self.create_item_modal {
                *n = current_name;
            }
        }

        // 6. Rename Item Modal (F2)
        if let Some((orig_path, ref name_buf)) = self.rename_modal.clone() {
            let mut close = false;
            let mut new_name = name_buf.clone();
            egui::Window::new(t.edit_rename)
                .order(egui::Order::Foreground)
                .collapsible(false)
                .show(ctx, |ui| {
                    ui.text_edit_singleline(&mut new_name);
                    ui.horizontal(|ui| {
                        let confirm_rename_btn = if self.config.language == Language::ZhTw { "✅ 確認重新命名" } else { "✅ Rename" };
                        if ui.button(confirm_rename_btn).clicked() {
                            if let Some(parent) = orig_path.parent() {
                                let dst = parent.join(&new_name);
                                let _ = std::fs::rename(&orig_path, &dst);
                                for p in &mut self.panes {
                                    p.trigger_reload();
                                }
                            }
                            close = true;
                        }
                        if ui.button(t.btn_cancel).clicked() {
                            close = true;
                        }
                    });
                });
            if close {
                self.rename_modal = None;
            } else if let Some((_, ref mut n)) = self.rename_modal {
                *n = new_name;
            }
        }

        // 7. About Dialog
        if self.show_about_dialog {
            let mut open = self.show_about_dialog;
            egui::Window::new(t.dlg_about_title)
                .order(egui::Order::Foreground)
                .open(&mut open)
                .show(ctx, |ui| {
                    ui.horizontal(|ui| {
                        if let Some(ref tex) = self.app_icon_tex {
                            ui.add(
                                egui::Image::new(tex)
                                    .fit_to_exact_size(Vec2::new(48.0, 48.0))
                                    .rounding(10.0),
                            );
                        }
                        ui.vertical(|ui| {
                            ui.heading(t.about_heading);
                            ui.label(t.about_tagline);
                        });
                    });
                    ui.separator();
                    ui.label(t.about_f1);
                    ui.label(t.about_f2);
                    ui.label(t.about_f3);
                    ui.label(t.about_f4);
                    ui.label(t.about_f5);
                    ui.label(t.about_f6);
                    ui.separator();
                    ui.horizontal(|ui| {
                        ui.label(t.about_support_prompt);
                        if ui
                            .button(
                                RichText::new(t.about_support_btn)
                                    .color(Color32::from_rgb(255, 94, 91))
                                    .strong(),
                            )
                            .clicked()
                        {
                            let _ = open::that("https://ko-fi.com/aiohlala");
                        }
                    });
                });
            self.show_about_dialog = open;
        }
    }
}

fn toggle_sort(pane: &mut MdiChildPane, col: SortColumn, show_hidden: bool) {
    if pane.sort_col == col {
        pane.sort_asc = !pane.sort_asc;
    } else {
        pane.sort_col = col;
        pane.sort_asc = true;
    }
    pane.apply_sort_and_filter(show_hidden);
}

fn expand_env_vars(input: &str) -> String {
    if input.starts_with('~') {
        if let Some(h) = dirs::home_dir() {
            return input.replacen('~', &h.to_string_lossy(), 1);
        }
    }
    input.to_string()
}

fn open_terminal_at(dir: & std::path::Path) {
    #[cfg(target_os = "windows")]
    {
        let _ = std::process::Command::new("cmd")
            .args(["/C", "start", "cmd"])
            .current_dir(dir)
            .spawn();
    }
    #[cfg(target_os = "macos")]
    {
        let _ = std::process::Command::new("open")
            .args(["-a", "Terminal", &dir.to_string_lossy()])
            .spawn();
    }
    #[cfg(target_os = "linux")]
    {
        let _ = std::process::Command::new("x-terminal-emulator")
            .current_dir(dir)
            .spawn();
    }
}

fn export_windows_shell_reg() -> Result<PathBuf, String> {
    let out_path = std::env::current_dir()
        .unwrap_or_else(|_| PathBuf::from("."))
        .join("mine_windows_shell_context_menu.reg");
    let reg_content = r#"Windows Registry Editor Version 5.00

; MINE (Multiple Interface Next-gen Explorer) - MDIE Successor
; Adds "Open in MINE" to Windows 10 / 11 Folder Context Menu

[HKEY_CURRENT_USER\Software\Classes\Directory\shell\MINE]
@="Open in MINE File Manager (以 MINE 開啟)"
"Icon"="mine.exe"

[HKEY_CURRENT_USER\Software\Classes\Directory\shell\MINE\command]
@="\"mine.exe\" \"%1\""

[HKEY_CURRENT_USER\Software\Classes\Directory\Background\shell\MINE]
@="Open in MINE File Manager (以 MINE 開啟)"
"Icon"="mine.exe"

[HKEY_CURRENT_USER\Software\Classes\Directory\Background\shell\MINE\command]
@="\"mine.exe\" \"%V\""
"#;
    std::fs::write(&out_path, reg_content).map_err(|e| e.to_string())?;
    Ok(out_path)
}

/// Paints a crisp, font-independent vector status badge:
/// - Online: Vivid green glowing circle
/// - Offline: Vivid red circle with a crisp white 'X' cross (like Windows Explorer disconnected network drive)
/// - Probing/Unknown: Amber circle
fn draw_smb_status_icon(ui: &mut egui::Ui, status: &SmbStatus) {
    let (rect, _) = ui.allocate_exact_size(Vec2::new(14.0, 14.0), Sense::hover());
    let center = rect.center();
    let painter = ui.painter();
    match status {
        SmbStatus::Online(_) => {
            painter.circle_filled(center, 5.8, Color32::from_rgb(30, 215, 90));
            painter.circle_stroke(center, 5.8, Stroke::new(1.0, Color32::from_rgb(15, 130, 50)));
            // Subtle glossy highlight dot
            painter.circle_filled(
                center - Vec2::new(1.8, 1.8),
                1.6,
                Color32::from_rgb(170, 255, 195),
            );
        }
        SmbStatus::Offline(_) => {
            painter.circle_filled(center, 6.2, Color32::from_rgb(230, 45, 45));
            painter.circle_stroke(center, 6.2, Stroke::new(1.0, Color32::from_rgb(150, 20, 20)));
            let d = 2.8;
            let white_stroke = Stroke::new(1.8, Color32::WHITE);
            painter.line_segment(
                [center - Vec2::new(d, d), center + Vec2::new(d, d)],
                white_stroke,
            );
            painter.line_segment(
                [center + Vec2::new(-d, d), center + Vec2::new(d, -d)],
                white_stroke,
            );
        }
        SmbStatus::Probing | SmbStatus::Unknown => {
            painter.circle_filled(center, 5.2, Color32::from_rgb(235, 175, 35));
            painter.circle_stroke(center, 5.2, Stroke::new(1.0, Color32::from_rgb(160, 110, 15)));
        }
    }
}
