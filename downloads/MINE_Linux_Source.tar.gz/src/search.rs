use crate::fs_ops::FileEntry;
use regex::Regex;
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Receiver};
use std::sync::Arc;
use std::thread;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PaneSearchMode {
    /// Real-time instant filter (hides non-matching rows)
    InstantFilter,
    /// MDIE Classic: "搜尋最符合" (Jumps to and highlights the single best fuzzy match as you type)
    BestMatchJump,
    /// MDIE Classic: "選擇檔案" (Pressing Enter selects/checks all matching files for batch copy/delete)
    SelectMatching,
}

impl Default for PaneSearchMode {
    fn default() -> Self {
        Self::InstantFilter
    }
}

/// Parsed smart query supporting:
/// - `>10MB`, `<500KB` size filters
/// - `ext:jpg,png,heic` extension filters
/// - `type:dir` or `type:file`
/// - `re:...` regex pattern
/// - multi-token fuzzy/substring matching
#[derive(Debug, Clone, Default)]
pub struct SmartQuery {
    pub raw: String,
    pub text_tokens: Vec<String>,
    pub min_size: Option<u64>,
    pub max_size: Option<u64>,
    pub extensions: Vec<String>,
    pub only_dirs: bool,
    pub only_files: bool,
    pub regex: Option<Regex>,
}

impl SmartQuery {
    pub fn parse(input: &str) -> Self {
        let mut q = SmartQuery {
            raw: input.trim().to_string(),
            ..Default::default()
        };
        if q.raw.is_empty() {
            return q;
        }

        if let Some(re_str) = q.raw.strip_prefix("re:") {
            if let Ok(re) = Regex::new(re_str.trim()) {
                q.regex = Some(re);
            }
            return q;
        }

        for part in q.raw.split_whitespace() {
            let lower = part.to_lowercase();
            if let Some(sz_str) = lower.strip_prefix('>') {
                if let Some(bytes) = parse_size_token(sz_str) {
                    q.min_size = Some(bytes);
                    continue;
                }
            }
            if let Some(sz_str) = lower.strip_prefix('<') {
                if let Some(bytes) = parse_size_token(sz_str) {
                    q.max_size = Some(bytes);
                    continue;
                }
            }
            if let Some(exts) = lower.strip_prefix("ext:") {
                for e in exts.split(',').filter(|s| !s.is_empty()) {
                    q.extensions.push(e.trim_start_matches('.').to_string());
                }
                continue;
            }
            if lower == "type:dir" || lower == "is:dir" || lower == "folder" {
                q.only_dirs = true;
                continue;
            }
            if lower == "type:file" || lower == "is:file" {
                q.only_files = true;
                continue;
            }
            // Handle wildcard *.ext
            if let Some(ext) = lower.strip_prefix("*.") {
                if !ext.contains('*') && !ext.is_empty() {
                    q.extensions.push(ext.to_string());
                    continue;
                }
            }
            q.text_tokens.push(lower);
        }
        q
    }

    pub fn is_empty(&self) -> bool {
        self.raw.is_empty()
    }

    /// Returns Option<score> where higher is better match (None = does not match)
    pub fn score_entry(&self, entry: &FileEntry) -> Option<i64> {
        if self.raw.is_empty() {
            return Some(1);
        }
        if self.only_dirs && !entry.is_dir {
            return None;
        }
        if self.only_files && entry.is_dir {
            return None;
        }
        if let Some(min_s) = self.min_size {
            if entry.size < min_s {
                return None;
            }
        }
        if let Some(max_s) = self.max_size {
            if entry.size > max_s {
                return None;
            }
        }
        if !self.extensions.is_empty()
            && !self
                .extensions
                .iter()
                .any(|e| e.eq_ignore_ascii_case(&entry.extension))
        {
            return None;
        }
        if let Some(ref re) = self.regex {
            return if re.is_match(&entry.display_name) {
                Some(100)
            } else {
                None
            };
        }

        let mut total_score = 10i64;
        for tok in &self.text_tokens {
            if entry.lower_name == *tok {
                total_score += 200;
            } else if entry.lower_name.starts_with(tok) {
                total_score += 120;
            } else if let Some(idx) = entry.lower_name.find(tok) {
                total_score += 80 - (idx.min(40) as i64);
            } else if let Some(fuzzy_s) = subsequence_fuzzy_score(&entry.lower_name, tok) {
                total_score += fuzzy_s;
            } else {
                return None;
            }
        }
        Some(total_score)
    }
}

fn subsequence_fuzzy_score(haystack: &str, needle: &str) -> Option<i64> {
    let mut h_chars = haystack.chars().enumerate();
    let mut score = 30i64;
    let mut last_idx = 0usize;
    for nc in needle.chars() {
        let mut found = false;
        for (idx, hc) in h_chars.by_ref() {
            if hc == nc {
                if idx == last_idx + 1 {
                    score += 8; // consecutive bonus
                }
                last_idx = idx;
                found = true;
                break;
            }
        }
        if !found {
            return None;
        }
    }
    Some(score.max(1))
}

fn parse_size_token(s: &str) -> Option<u64> {
    let s = s.trim();
    if let Some(num) = s.strip_suffix("gb").or_else(|| s.strip_suffix('g')) {
        num.trim()
            .parse::<f64>()
            .ok()
            .map(|v| (v * 1024.0 * 1024.0 * 1024.0) as u64)
    } else if let Some(num) = s.strip_suffix("mb").or_else(|| s.strip_suffix('m')) {
        num.trim()
            .parse::<f64>()
            .ok()
            .map(|v| (v * 1024.0 * 1024.0) as u64)
    } else if let Some(num) = s.strip_suffix("kb").or_else(|| s.strip_suffix('k')) {
        num.trim().parse::<f64>().ok().map(|v| (v * 1024.0) as u64)
    } else if let Some(num) = s.strip_suffix('b') {
        num.trim().parse::<u64>().ok()
    } else {
        s.parse::<u64>().ok()
    }
}

#[derive(Debug, Clone)]
pub struct DeepSearchResult {
    pub entry: FileEntry,
    pub parent_dir: PathBuf,
    pub score: i64,
    pub matched_content_snippet: Option<String>,
}

pub enum SearchProgressMsg {
    Batch(Vec<DeepSearchResult>, usize), // new matches, scanned count
    Finished(usize, u128),               // total scanned, elapsed ms
}

pub fn spawn_deep_search(
    roots: Vec<PathBuf>,
    query_str: String,
    content_grep: String,
    max_results: usize,
    cancel_flag: Arc<AtomicBool>,
) -> Receiver<SearchProgressMsg> {
    let (tx, rx) = mpsc::channel();
    let smart_q = SmartQuery::parse(&query_str);
    let grep_lower = content_grep.trim().to_lowercase();

    thread::spawn(move || {
        let start = std::time::Instant::now();
        let mut scanned = 0usize;
        let mut total_found = 0usize;
        let mut batch = Vec::with_capacity(64);

        for root in roots {
            if cancel_flag.load(Ordering::Relaxed) {
                break;
            }
            for dir_entry_res in walkdir::WalkDir::new(&root)
                .follow_links(false)
                .max_depth(12)
            {
                if cancel_flag.load(Ordering::Relaxed) || total_found >= max_results {
                    break;
                }
                let Ok(dir_entry) = dir_entry_res else {
                    continue;
                };
                if dir_entry.depth() == 0 {
                    continue;
                }
                scanned += 1;

                let path = dir_entry.path();
                let raw_name = dir_entry.file_name();
                let had_special_encoding = raw_name.to_str().is_none();
                let display_name = raw_name.to_string_lossy().into_owned();
                let lower_name = display_name.to_lowercase();
                let is_dir = dir_entry.file_type().is_dir();
                let meta = dir_entry.metadata().ok();
                let size = if is_dir {
                    0
                } else {
                    meta.as_ref().map(|m| m.len()).unwrap_or(0)
                };
                let extension = if is_dir {
                    String::new()
                } else {
                    path.extension()
                        .map(|e| e.to_string_lossy().to_lowercase())
                        .unwrap_or_default()
                };
                let (modified_str, modified_ts) = meta
                    .and_then(|m| m.modified().ok())
                    .map(crate::fs_ops::format_system_time)
                    .unwrap_or_else(|| ("-".to_string(), 0));

                let fe = FileEntry {
                    path: path.to_path_buf(),
                    display_name,
                    lower_name,
                    is_dir,
                    is_symlink: dir_entry.file_type().is_symlink(),
                    is_hidden: false,
                    size,
                    extension,
                    modified_str,
                    modified_ts,
                    had_special_encoding,
                };

                if let Some(score) = smart_q.score_entry(&fe) {
                    let mut snippet = None;
                    if !grep_lower.is_empty() {
                        if fe.is_dir || fe.size > 4 * 1024 * 1024 {
                            continue;
                        }
                        if let Some(s) = search_file_content(path, &grep_lower) {
                            snippet = Some(s);
                        } else {
                            continue;
                        }
                    }

                    let parent_dir = path
                        .parent()
                        .map(|p| p.to_path_buf())
                        .unwrap_or_else(|| root.clone());
                    batch.push(DeepSearchResult {
                        entry: fe,
                        parent_dir,
                        score,
                        matched_content_snippet: snippet,
                    });
                    total_found += 1;

                    if batch.len() >= 50 {
                        let send_batch = std::mem::take(&mut batch);
                        let _ = tx.send(SearchProgressMsg::Batch(send_batch, scanned));
                    }
                } else if scanned % 400 == 0 {
                    let _ = tx.send(SearchProgressMsg::Batch(Vec::new(), scanned));
                }
            }
        }

        if !batch.is_empty() {
            let _ = tx.send(SearchProgressMsg::Batch(batch, scanned));
        }
        let _ = tx.send(SearchProgressMsg::Finished(
            scanned,
            start.elapsed().as_millis(),
        ));
    });

    rx
}

fn search_file_content(path: &Path, needle_lower: &str) -> Option<String> {
    let bytes = std::fs::read(path).ok()?;
    let text = String::from_utf8_lossy(&bytes);
    for (idx, line) in text.lines().enumerate() {
        if line.to_lowercase().contains(needle_lower) {
            let trimmed = line.trim();
            let preview: String = trimmed.chars().take(90).collect();
            return Some(format!("L{}: {}", idx + 1, preview));
        }
    }
    None
}
