use crate::app::{ClipboardOp, MineApp, SidebarTab};
use crate::fs_ops::{format_size, PreviewPayload, SmbStatus};
use crate::gesture::{GestureAction, GestureTracker};
use crate::i18n::Language;
use crate::search::{spawn_deep_search, PaneSearchMode, SearchProgressMsg};
use crate::state::{
    AppTheme, MdiChildPane, ScrollRequest, SortColumn, WindowLayoutMode, WorkspaceGroupBookmark,
};
use egui::{Color32, Pos2, Rect, RichText, Sense, Stroke, Vec2};
use egui_extras::{Column, TableBuilder};
use std::path::PathBuf;
use std::sync::atomic::Ordering;
use sysinfo::{ProcessesToUpdate, System};

impl eframe::App for MineApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.apply_theme(ctx);
        self.poll_background_channels(ctx);
        self.handle_global_shortcuts_and_gestures(ctx);

        let t = self.config.language.texts();

        // 1. Top Menu Bar + MDIE Quick Toolbar + Multi-Window Tab Strip
        egui::TopBottomPanel::top("mine_top_header").show(ctx, |ui| {
            self.render_menu_bar(ui, t);
            ui.separator();
            self.render_quick_toolbar(ui, t);
            ui.separator();
            self.render_mdi_tab_bar(ui, t);
        });

        // 2. Bottom Status Bar (shows RAM footprint, Portable status, and Gesture hint)
        egui::TopBottomPanel::bottom("mine_status_bar").show(ctx, |ui| {
            ui.horizontal(|ui| {
                let active_idx = self.active_pane_index();
                if let Some(p) = self.panes.get(active_idx) {
                    ui.label(
                        RichText::new(format!(
                            "📂 {} {} | ☑️ {} {}",
                            p.filtered_indices.len(),
                            t.status_items,
                            p.selected_paths.len(),
                            t.status_selected
                        ))
                        .strong(),
                    );
                }
                ui.separator();
                ui.label(RichText::new(&self.status_toast).color(Color32::from_rgb(0, 120, 215)));
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.label(
                        RichText::new(format!(
                            "⚡ RAM: {:.1} MB ({} MDI Windows)",
                            self.process_ram_mb,
                            self.panes.len()
                        ))
                        .color(Color32::from_rgb(20, 140, 60))
                        .strong(),
                    );
                    ui.separator();
                    ui.label(RichText::new(t.status_portable_mode).small());
                    ui.separator();
                    ui.label(RichText::new(t.status_gesture_hint).small());
                });
            });
        });

        // 3. Left Sidebar (Drives, Favorites & Workspace Groups, Non-blocking SMB, Closed Tabs)
        if self.config.show_sidebar {
            egui::SidePanel::left("mine_left_sidebar")
                .default_width(245.0)
                .width_range(180.0..=380.0)
                .resizable(true)
                .show(ctx, |ui| {
                    self.render_left_sidebar(ui, t);
                });
        }

        // 4. Right Safe Sandbox Preview Panel (Crash-proof HEIC / Image / Text / Encoding)
        if self.config.show_preview {
            egui::SidePanel::right("mine_right_preview")
                .default_width(290.0)
                .width_range(210.0..=480.0)
                .resizable(true)
                .show(ctx, |ui| {
                    self.render_right_preview(ui, t);
                });
        }

        // 5. Central MDI Multi-Window Workspace
        egui::CentralPanel::default()
            .frame(
                egui::Frame::central_panel(&ctx.style())
                    .fill(if self.config.theme == AppTheme::ModernDark {
                        Color32::from_rgb(16, 18, 22)
                    } else {
                        Color32::from_rgb(171, 178, 191) // Classic MDIE MDI Workspace gray-blue backdrop
                    })
                    .inner_margin(4.0),
            )
            .show(ctx, |ui| {
                self.render_mdi_workspace(ui, t);
            });

        // 6. Floating Modals & Dialogs (Global Search, SMB Manager, Gesture Customizer, Rename, About)
        self.render_dialogs(ctx, t);

        // 7. Render Live Mouse Gesture Neon Trail & HUD Overlay on top of everything
        self.render_gesture_overlay(ctx);
    }
}

impl MineApp {
    fn poll_background_channels(&mut self, ctx: &egui::Context) {
        let show_hidden = self.config.show_hidden;
        let mut any_loading = false;
        for pane in &mut self.panes {
            if pane.poll_async_load(show_hidden) {
                ctx.request_repaint();
            }
            if pane.is_loading {
                any_loading = true;
            }
        }

        // Poll SMB non-blocking probes
        self.smb_probes.retain(|(idx, rx)| match rx.try_recv() {
            Ok(status) => {
                if let Some(smb) = self.config.smb_bookmarks.get_mut(*idx) {
                    smb.status = status;
                }
                ctx.request_repaint();
                false
            }
            Err(std::sync::mpsc::TryRecvError::Empty) => {
                any_loading = true;
                true
            }
            Err(std::sync::mpsc::TryRecvError::Disconnected) => false,
        });

        // Poll Sandboxed Preview
        if let Some(ref rx) = self.preview_rx {
            if let Ok(payload) = rx.try_recv() {
                if let PreviewPayload::Image {
                    width,
                    height,
                    ref rgba,
                    ..
                } = payload
                {
                    let color_img = egui::ColorImage::from_rgba_unmultiplied([width, height], rgba);
                    self.preview_texture = Some(ctx.load_texture(
                        "sandbox_preview_tex",
                        color_img,
                        egui::TextureOptions::LINEAR,
                    ));
                }
                self.preview_state = payload;
                self.preview_rx = None;
                ctx.request_repaint();
            } else {
                any_loading = true;
            }
        }

        // Poll Multi-threaded Deep Search
        if let Some(ref rx) = self.deep_search_rx {
            while let Ok(msg) = rx.try_recv() {
                match msg {
                    SearchProgressMsg::Batch(mut batch, scanned) => {
                        self.deep_search_results.append(&mut batch);
                        self.deep_search_scanned = scanned;
                        ctx.request_repaint();
                    }
                    SearchProgressMsg::Finished(scanned, elapsed_ms) => {
                        self.deep_search_scanned = scanned;
                        self.deep_search_elapsed_ms = elapsed_ms;
                        self.deep_search_running = false;
                        self.deep_search_rx = None;
                        self.deep_search_results
                            .sort_by(|a, b| b.score.cmp(&a.score));
                        ctx.request_repaint();
                        break;
                    }
                }
            }
            if self.deep_search_running {
                any_loading = true;
            }
        }

        // Refresh process memory telemetry every 4 seconds
        if self.last_telemetry_tick.elapsed() > std::time::Duration::from_secs(4) {
            self.last_telemetry_tick = std::time::Instant::now();
            if let Ok(pid) = sysinfo::get_current_pid() {
                let mut sys = System::new();
                sys.refresh_processes(ProcessesToUpdate::Some(&[pid]), true);
                if let Some(proc_info) = sys.process(pid) {
                    self.process_ram_mb = (proc_info.memory() as f64) / (1024.0 * 1024.0);
                }
            }
        }

        if any_loading {
            ctx.request_repaint_after(std::time::Duration::from_millis(40));
        }
    }

    fn handle_global_shortcuts_and_gestures(&mut self, ctx: &egui::Context) {
        // Right-click + Mouse Wheel -> MDIE fast scroll to top/bottom
        let rmb_down = ctx.input(|i| i.pointer.secondary_down());
        let scroll_y = ctx.input(|i| i.smooth_scroll_delta.y);
        if rmb_down && scroll_y.abs() > 8.0 {
            let idx = self.active_pane_index();
            if let Some(p) = self.panes.get_mut(idx) {
                if scroll_y > 0.0 {
                    p.scroll_request = ScrollRequest::Top;
                    self.status_toast = "🖱️ Right-Click + Wheel Up -> 捲動至列表開頭 (Top)".into();
                } else {
                    p.scroll_request = ScrollRequest::Bottom;
                    self.status_toast =
                        "🖱️ Right-Click + Wheel Down -> 捲動至列表結尾 (Bottom)".into();
                }
            }
            self.gesture_tracker.is_tracking = false;
            return;
        }

        // Right-click drag gesture tracking
        let rmb_pressed = ctx.input(|i| i.pointer.button_pressed(egui::PointerButton::Secondary));
        let rmb_released = ctx.input(|i| i.pointer.button_released(egui::PointerButton::Secondary));
        let pointer_pos = ctx.input(|i| i.pointer.interact_pos());

        if rmb_pressed {
            if let Some(pos) = pointer_pos {
                self.gesture_tracker.start(pos);
            }
        } else if rmb_down && self.gesture_tracker.is_tracking {
            if let Some(pos) = pointer_pos {
                self.gesture_tracker.update_pos(pos);
                ctx.request_repaint();
            }
        } else if rmb_released && self.gesture_tracker.is_tracking {
            if let Some((seq, action)) = self.gesture_tracker.finish() {
                self.execute_gesture_action(action);
                self.status_toast = format!(
                    "🖱️ MDIE 手勢 [{}] -> {}",
                    GestureTracker::format_arrows(&seq),
                    action.label(self.config.language)
                );
            }
        }

        // Keyboard shortcuts when not typing in a text box
        if !ctx.wants_keyboard_input() {
            let mut open_search = false;
            let mut refresh = false;
            let mut go_up = false;
            let mut new_win = false;
            let mut close_win = false;
            let mut rename_f2 = false;

            ctx.input(|i| {
                if (i.modifiers.command || i.modifiers.ctrl) && i.key_pressed(egui::Key::F) {
                    open_search = true;
                }
                if (i.modifiers.command || i.modifiers.ctrl) && i.key_pressed(egui::Key::N) {
                    new_win = true;
                }
                if (i.modifiers.command || i.modifiers.ctrl) && i.key_pressed(egui::Key::W) {
                    close_win = true;
                }
                if i.key_pressed(egui::Key::F5) {
                    refresh = true;
                }
                if i.key_pressed(egui::Key::F2) {
                    rename_f2 = true;
                }
                if i.key_pressed(egui::Key::Backspace) {
                    go_up = true;
                }
            });

            if open_search {
                self.show_search_dialog = true;
            }
            if new_win {
                self.execute_gesture_action(GestureAction::NewMdiWindow);
            }
            if close_win {
                self.execute_gesture_action(GestureAction::CloseActiveWindow);
            }
            if refresh {
                self.execute_gesture_action(GestureAction::RefreshActiveWindow);
            }
            if rename_f2 {
                let idx = self.active_pane_index();
                if let Some(p) = self.panes.get(idx) {
                    if let Some(first) = p.selected_paths.iter().next() {
                        let cur_name = first
                            .file_name()
                            .unwrap_or_default()
                            .to_string_lossy()
                            .into_owned();
                        self.rename_modal = Some((first.clone(), cur_name));
                    }
                }
            }
            if go_up {
                self.execute_gesture_action(GestureAction::NavigateUp);
            }
        }
    }

    fn render_menu_bar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        egui::menu::bar(ui, |ui| {
            // App Branding Badge
            ui.label(
                RichText::new("🗂️ MINE")
                    .strong()
                    .color(Color32::from_rgb(0, 102, 204)),
            );
            ui.separator();

            // 1. File(F)
            ui.menu_button(t.menu_file, |ui| {
                if ui.button(t.file_new_pane).clicked() {
                    self.execute_gesture_action(GestureAction::NewMdiWindow);
                    ui.close_menu();
                }
                if ui.button(t.file_clone_pane).clicked() {
                    self.execute_gesture_action(GestureAction::CloneActiveWindow);
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.file_new_folder).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        self.create_item_modal =
                            Some((p.current_path.clone(), true, "New_Folder".into()));
                    }
                    ui.close_menu();
                }
                if ui.button(t.file_new_file).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        self.create_item_modal =
                            Some((p.current_path.clone(), false, "note.txt".into()));
                    }
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.file_open_terminal).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        open_terminal_at(&p.current_path);
                    }
                    ui.close_menu();
                }
                if ui.button(t.file_open_native).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let _ = open::that(&p.current_path);
                    }
                    ui.close_menu();
                }
                if ui.button(t.file_restore_closed).clicked() {
                    self.restore_last_closed_pane();
                    ui.close_menu();
                }
                if ui.button(t.file_close_pane).clicked() {
                    let id = self.active_pane_id;
                    self.close_pane_by_id(id);
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.file_exit).clicked() {
                    let _ = self.config.save();
                    std::process::exit(0);
                }
            });

            // 2. Edit(E)
            ui.menu_button(t.menu_edit, |ui| {
                if ui.button(t.edit_copy).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                        if !list.is_empty() {
                            self.clipboard = ClipboardOp::Copy(list);
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_cut).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let list: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                        if !list.is_empty() {
                            self.clipboard = ClipboardOp::Cut(list);
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_paste).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(dest) = self.panes.get(idx).map(|p| p.current_path.clone()) {
                        match self.clipboard.clone() {
                            ClipboardOp::Copy(srcs) => {
                                self.perform_file_transfer(&srcs, &dest, false);
                            }
                            ClipboardOp::Cut(srcs) => {
                                self.perform_file_transfer(&srcs, &dest, true);
                                self.clipboard = ClipboardOp::None;
                            }
                            ClipboardOp::None => {}
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_rename).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        if let Some(first) = p.selected_paths.iter().next() {
                            let cur_name = first
                                .file_name()
                                .unwrap_or_default()
                                .to_string_lossy()
                                .into_owned();
                            self.rename_modal = Some((first.clone(), cur_name));
                        }
                    }
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.edit_copy_path).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let target = p
                            .selected_paths
                            .iter()
                            .next()
                            .cloned()
                            .unwrap_or_else(|| p.current_path.clone());
                        if let Ok(mut cb) = arboard::Clipboard::new() {
                            let _ = cb.set_text(target.to_string_lossy().into_owned());
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_select_all).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get_mut(idx) {
                        for &i in &p.filtered_indices {
                            if let Some(e) = p.entries.get(i) {
                                p.selected_paths.insert(e.path.clone());
                            }
                        }
                    }
                    ui.close_menu();
                }
                if ui.button(t.edit_invert_selection).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get_mut(idx) {
                        let mut next_set = std::collections::HashSet::new();
                        for &i in &p.filtered_indices {
                            if let Some(e) = p.entries.get(i) {
                                if !p.selected_paths.contains(&e.path) {
                                    next_set.insert(e.path.clone());
                                }
                            }
                        }
                        p.selected_paths = next_set;
                    }
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.edit_delete).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get_mut(idx) {
                        let targets: Vec<PathBuf> = p.selected_paths.iter().cloned().collect();
                        for t_path in targets {
                            let _ = trash::delete(&t_path);
                        }
                        p.trigger_reload();
                    }
                    ui.close_menu();
                }
            });

            // 3. View(V)
            ui.menu_button(t.menu_view, |ui| {
                if ui
                    .checkbox(&mut self.config.show_sidebar, t.view_sidebar)
                    .changed()
                {
                    let _ = self.config.save();
                }
                if ui
                    .checkbox(&mut self.config.show_preview, t.view_preview)
                    .changed()
                {
                    let _ = self.config.save();
                }
                if ui
                    .checkbox(&mut self.config.show_hidden, t.view_hidden_files)
                    .changed()
                {
                    let show_hidden = self.config.show_hidden;
                    for p in &mut self.panes {
                        p.apply_sort_and_filter(show_hidden);
                    }
                    let _ = self.config.save();
                }
                ui.separator();
                if ui
                    .selectable_value(&mut self.config.theme, AppTheme::ClassicMdie, t.view_theme_classic_mdie)
                    .clicked()
                    || ui
                        .selectable_value(&mut self.config.theme, AppTheme::ModernDark, t.view_theme_dark)
                        .clicked()
                    || ui
                        .selectable_value(&mut self.config.theme, AppTheme::CleanLight, t.view_theme_light)
                        .clicked()
                {
                    let _ = self.config.save();
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.view_refresh).clicked() {
                    for p in &mut self.panes {
                        p.trigger_reload();
                    }
                    ui.close_menu();
                }
            });

            // 4. Favorites(A) - Including MDIE Multi-Window Workspace Groups!
            ui.menu_button(t.menu_favorites, |ui| {
                if ui.button(t.fav_add_current_folder).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        let name = p.title.clone();
                        let path_s = p.current_path.to_string_lossy().into_owned();
                        self.config.favorite_folders.push((name, path_s));
                        let _ = self.config.save();
                    }
                    ui.close_menu();
                }
                if ui.button(t.fav_save_workspace_group).clicked() {
                    self.show_save_group_modal = true;
                    ui.close_menu();
                }
                ui.separator();
                ui.label(RichText::new(t.fav_groups_header).strong());
                let groups = self.config.workspace_groups.clone();
                for grp in groups {
                    if ui
                        .button(format!("📦 {} ({} 視窗)", grp.name, grp.paths.len()))
                        .clicked()
                    {
                        self.panes.clear();
                        for (i, ps) in grp.paths.iter().enumerate() {
                            self.panes.push(MdiChildPane::new(i + 1, PathBuf::from(ps)));
                        }
                        self.next_pane_id = self.panes.len() + 1;
                        self.active_pane_id = 1;
                        self.config.layout_mode = grp.layout;
                        self.sync_config_paths();
                        ui.close_menu();
                    }
                }
                ui.separator();
                ui.label(RichText::new(t.fav_folders_header).strong());
                let favs = self.config.favorite_folders.clone();
                for (name, path_s) in favs {
                    if ui.button(format!("⭐ {}", name)).clicked() {
                        let idx = self.active_pane_index();
                        if let Some(p) = self.panes.get_mut(idx) {
                            p.navigate_to(PathBuf::from(path_s), true);
                        }
                        ui.close_menu();
                    }
                }
            });

            // 5. Tools(T)
            ui.menu_button(t.menu_tools, |ui| {
                if ui.button(t.tools_global_search).clicked() {
                    self.show_search_dialog = true;
                    ui.close_menu();
                }
                if ui.button(t.tools_smb_manager).clicked() {
                    self.show_smb_dialog = true;
                    ui.close_menu();
                }
                if ui.button(t.tools_gesture_settings).clicked() {
                    self.show_gesture_dialog = true;
                    ui.close_menu();
                }
                ui.separator();
                if ui.button(t.tools_save_portable).clicked() {
                    if let Ok(p) = self.config.save() {
                        self.status_toast = format!("💾 Saved portable config: {}", p.to_string_lossy());
                    }
                    ui.close_menu();
                }
                if ui.button(t.tools_export_reg_script).clicked() {
                    if let Ok(reg_path) = export_windows_shell_reg() {
                        self.status_toast = format!("🛠️ 已匯出 Windows 登錄檔: {}", reg_path.to_string_lossy());
                    }
                    ui.close_menu();
                }
            });

            // 6. Window(W) - Exact replica of MDIE's iconic Window menu from the screenshot!
            ui.menu_button(t.menu_window, |ui| {
                ui.label(RichText::new(t.win_mode_title).strong());
                if ui
                    .selectable_value(
                        &mut self.config.layout_mode,
                        WindowLayoutMode::TileHorizontally,
                        t.win_mode_tile_horiz,
                    )
                    .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::TileVertically,
                            t.win_mode_tile_vert,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::TileGrid,
                            t.win_mode_tile_grid,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::Cascade,
                            t.win_mode_cascade,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::MdiFree,
                            t.win_mode_mdi_free,
                        )
                        .clicked()
                    || ui
                        .selectable_value(
                            &mut self.config.layout_mode,
                            WindowLayoutMode::TabbedMaximized,
                            t.win_mode_tabbed,
                        )
                        .clicked()
                {
                    if self.config.layout_mode == WindowLayoutMode::Cascade {
                        self.recalculate_cascade_rects(Rect::from_min_size(
                            Pos2::new(0.0, 0.0),
                            Vec2::new(1100.0, 700.0),
                        ));
                    }
                    let _ = self.config.save();
                    ui.close_menu();
                }

                ui.separator();
                if ui.button(t.win_scroll_top).clicked() {
                    self.execute_gesture_action(GestureAction::ScrollToTop);
                    ui.close_menu();
                }
                if ui.button(t.win_scroll_bottom).clicked() {
                    self.execute_gesture_action(GestureAction::ScrollToBottom);
                    ui.close_menu();
                }
                ui.checkbox(&mut self.config.sync_scroll, t.win_sync_scroll);
                if ui.button(t.win_close_all_except_active).clicked() {
                    let active_id = self.active_pane_id;
                    self.panes.retain(|p| p.id == active_id);
                    self.sync_config_paths();
                    ui.close_menu();
                }

                ui.separator();
                // Numbered window list just like MDIE's Window menu (1 This PC, 2 DarkTable, 3 Style...)
                for (i, pane) in self.panes.iter().enumerate() {
                    let checked = pane.id == self.active_pane_id;
                    if ui
                        .selectable_label(checked, format!("{} {}", i + 1, pane.title))
                        .clicked()
                    {
                        self.active_pane_id = pane.id;
                        ui.close_menu();
                    }
                }
            });

            // 7. Help(H)
            ui.menu_button(t.menu_help, |ui| {
                if ui.button("ℹ️ About MINE / MDIE 進化對照表").clicked() {
                    self.show_about_dialog = true;
                    ui.close_menu();
                }
            });

            // Right-aligned Language Switcher (繁體中文 / English) & Quick Layout Pills
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui
                    .selectable_label(self.config.language == Language::En, "🌐 EN")
                    .clicked()
                {
                    self.config.language = Language::En;
                    let _ = self.config.save();
                }
                if ui
                    .selectable_label(self.config.language == Language::ZhTw, "🌐 繁中")
                    .clicked()
                {
                    self.config.language = Language::ZhTw;
                    let _ = self.config.save();
                }
                ui.separator();
                if ui.button("🔍 強化搜尋").clicked() {
                    self.show_search_dialog = true;
                }
                if ui.button("🖱️ 手勢").clicked() {
                    self.show_gesture_dialog = true;
                }
            });
        });
    }

    fn render_quick_toolbar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.horizontal_wrapped(|ui| {
            // Navigation controls for active pane
            if ui.button(t.btn_back).clicked() {
                self.execute_gesture_action(GestureAction::NavigateBack);
            }
            if ui.button(t.btn_forward).clicked() {
                self.execute_gesture_action(GestureAction::NavigateForward);
            }
            if ui.button(t.btn_up).clicked() {
                self.execute_gesture_action(GestureAction::NavigateUp);
            }
            if ui.button(t.btn_refresh).clicked() {
                self.execute_gesture_action(GestureAction::RefreshActiveWindow);
            }

            ui.separator();

            // One-click Unlimited MDI Window Spawner & Layout Switcher
            if ui
                .button(RichText::new("➕ 開新視窗").strong())
                .on_hover_text("新增一個並排/重疊子視窗 (Right-Click Drag Down)")
                .clicked()
            {
                self.execute_gesture_action(GestureAction::NewMdiWindow);
            }
            if ui
                .button("📑 複製視窗")
                .on_hover_text("複製目前視窗以進行檔案比對或移動")
                .clicked()
            {
                self.execute_gesture_action(GestureAction::CloneActiveWindow);
            }

            ui.separator();
            ui.label(RichText::new("視窗排列:").strong());
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TileHorizontally,
                    "⬌ 左右並排",
                )
                .on_hover_text("無論 2、3、4、5 個視窗皆自動左右並排顯示")
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TileHorizontally;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TileVertically,
                    "⬍ 上下並排",
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TileVertically;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TileGrid,
                    "田 智慧網格",
                )
                .on_hover_text("自動計算 2x2, 3x2, 3x3 網格並排，支援無限視窗！")
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TileGrid;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::Cascade,
                    "🗗 重疊層疊",
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::Cascade;
                self.recalculate_cascade_rects(Rect::from_min_size(
                    Pos2::new(0.0, 0.0),
                    Vec2::new(1100.0, 700.0),
                ));
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::MdiFree,
                    "🪟 自由拖放",
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::MdiFree;
            }
            if ui
                .selectable_label(
                    self.config.layout_mode == WindowLayoutMode::TabbedMaximized,
                    "🗂️ 單視窗分頁",
                )
                .clicked()
            {
                self.config.layout_mode = WindowLayoutMode::TabbedMaximized;
            }
        });
    }

    fn render_mdi_tab_bar(&mut self, ui: &mut egui::Ui, _t: &crate::i18n::Texts) {
        ui.horizontal_wrapped(|ui| {
            let mut close_id = None;
            let mut activate_id = None;

            for (idx, pane) in self.panes.iter().enumerate() {
                let is_active = pane.id == self.active_pane_id;
                let frame_bg = if is_active {
                    Color32::from_rgb(0, 110, 210)
                } else {
                    Color32::from_gray(215)
                };
                let text_col = if is_active {
                    Color32::WHITE
                } else {
                    Color32::BLACK
                };

                egui::Frame::none()
                    .fill(frame_bg)
                    .rounding(egui::Rounding {
                        nw: 4.0,
                        ne: 4.0,
                        sw: 0.0,
                        se: 0.0,
                    })
                    .inner_margin(egui::Margin::symmetric(8.0, 3.0))
                    .show(ui, |ui| {
                        let resp = ui.add(
                            egui::Label::new(
                                RichText::new(format!("📁 {}: {}", idx + 1, pane.title))
                                    .color(text_col)
                                    .strong(),
                            )
                            .sense(Sense::click()),
                        );
                        if resp.clicked() {
                            activate_id = Some(pane.id);
                        }
                        if resp.middle_clicked() {
                            close_id = Some(pane.id);
                        }
                        if ui
                            .add(
                                egui::Button::new(RichText::new("×").color(text_col).small())
                                    .frame(false),
                            )
                            .clicked()
                        {
                            close_id = Some(pane.id);
                        }
                    });
            }

            if ui
                .button("➕")
                .on_hover_text("新增子視窗 (New MDI Tab/Window)")
                .clicked()
            {
                self.execute_gesture_action(GestureAction::NewMdiWindow);
            }

            if let Some(id) = activate_id {
                self.active_pane_id = id;
            }
            if let Some(id) = close_id {
                self.close_pane_by_id(id);
            }
        });
    }

    fn render_left_sidebar(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.horizontal(|ui| {
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::DrivesAndTree, t.side_tree);
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::Favorites, t.side_favorites);
            ui.selectable_value(&mut self.sidebar_tab, SidebarTab::SmbNetwork, t.side_smb);
            ui.selectable_value(
                &mut self.sidebar_tab,
                SidebarTab::ClosedHistory,
                t.side_closed_history,
            );
        });
        ui.separator();

        egui::ScrollArea::vertical().show(ui, |ui| match self.sidebar_tab {
            SidebarTab::DrivesAndTree => {
                ui.label(RichText::new("💽 本機磁碟與分割區 (Local Drives)").strong());
                let disks = self.sys_disks.clone();
                for (label, mount, avail, total) in disks {
                    let used_ratio = if total > 0 {
                        1.0 - (avail as f32 / total as f32)
                    } else {
                        0.0
                    };
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            if ui.button(format!("🖴 {}", label)).clicked() {
                                let idx = self.active_pane_index();
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.navigate_to(mount.clone(), true);
                                }
                            }
                            if ui
                                .small_button("➕視窗")
                                .on_hover_text("在新並排子視窗開啟")
                                .clicked()
                            {
                                self.spawn_new_pane(mount.clone());
                            }
                        });
                        ui.add(
                            egui::ProgressBar::new(used_ratio).text(format!(
                                "可用 {} / 共 {}",
                                format_size(avail),
                                format_size(total)
                            )),
                        );
                    });
                }

                ui.add_space(8.0);
                ui.label(RichText::new("⚡ 系統常用資料夾").strong());
                let mut quick_dirs = Vec::new();
                if let Some(h) = dirs::home_dir() {
                    quick_dirs.push(("🏠 Home 主目錄", h));
                }
                if let Some(d) = dirs::desktop_dir() {
                    quick_dirs.push(("🖥️ Desktop 桌面", d));
                }
                if let Some(dl) = dirs::download_dir() {
                    quick_dirs.push(("📥 Downloads 下載", dl));
                }
                if let Some(doc) = dirs::document_dir() {
                    quick_dirs.push(("📄 Documents 文件", doc));
                }
                if let Some(pic) = dirs::picture_dir() {
                    quick_dirs.push(("🖼️ Pictures 圖片", pic));
                }

                for (name, path) in quick_dirs {
                    ui.horizontal(|ui| {
                        if ui.button(name).clicked() {
                            let idx = self.active_pane_index();
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(path.clone(), true);
                            }
                        }
                        if ui.small_button("➕").clicked() {
                            self.spawn_new_pane(path);
                        }
                    });
                }
            }
            SidebarTab::Favorites => {
                ui.label(RichText::new(t.fav_groups_header).strong());
                if ui.button(t.fav_save_workspace_group).clicked() {
                    self.show_save_group_modal = true;
                }
                let groups = self.config.workspace_groups.clone();
                let mut remove_grp = None;
                for (gi, grp) in groups.iter().enumerate() {
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            if ui
                                .button(RichText::new(format!("📦 {}", grp.name)).strong())
                                .clicked()
                            {
                                self.panes.clear();
                                for (i, ps) in grp.paths.iter().enumerate() {
                                    self.panes
                                        .push(MdiChildPane::new(i + 1, PathBuf::from(ps)));
                                }
                                self.next_pane_id = self.panes.len() + 1;
                                self.active_pane_id = 1;
                                self.config.layout_mode = grp.layout;
                                self.sync_config_paths();
                            }
                            if ui.small_button("🗑️").clicked() {
                                remove_grp = Some(gi);
                            }
                        });
                        ui.label(
                            RichText::new(format!("包含 {} 個並排視窗", grp.paths.len())).small(),
                        );
                    });
                }
                if let Some(gi) = remove_grp {
                    self.config.workspace_groups.remove(gi);
                    let _ = self.config.save();
                }

                ui.separator();
                ui.label(RichText::new(t.fav_folders_header).strong());
                if ui.button(t.fav_add_current_folder).clicked() {
                    let idx = self.active_pane_index();
                    if let Some(p) = self.panes.get(idx) {
                        self.config.favorite_folders.push((
                            p.title.clone(),
                            p.current_path.to_string_lossy().into_owned(),
                        ));
                        let _ = self.config.save();
                    }
                }
                let favs = self.config.favorite_folders.clone();
                let mut remove_fav = None;
                for (fi, (name, path_s)) in favs.iter().enumerate() {
                    ui.horizontal(|ui| {
                        if ui.button(format!("⭐ {}", name)).clicked() {
                            let idx = self.active_pane_index();
                            if let Some(p) = self.panes.get_mut(idx) {
                                p.navigate_to(PathBuf::from(path_s), true);
                            }
                        }
                        if ui.small_button("➕").clicked() {
                            self.spawn_new_pane(PathBuf::from(path_s));
                        }
                        if ui.small_button("×").clicked() {
                            remove_fav = Some(fi);
                        }
                    });
                }
                if let Some(fi) = remove_fav {
                    self.config.favorite_folders.remove(fi);
                    let _ = self.config.save();
                }
            }
            SidebarTab::SmbNetwork => {
                ui.label(RichText::new("🌐 非阻塞式 SMB 網路磁碟").strong());
                ui.label(
                    RichText::new("🛡️ 離線網域自動 1.2 秒逾時隔離，絕不卡住主視窗！")
                        .small()
                        .color(Color32::from_rgb(0, 130, 80)),
                );
                ui.horizontal(|ui| {
                    if ui.button(t.dlg_smb_test_async).clicked() {
                        self.probe_all_smb();
                    }
                    if ui.button("⚙️ 管理").clicked() {
                        self.show_smb_dialog = true;
                    }
                });
                ui.separator();

                let smbs = self.config.smb_bookmarks.clone();
                for smb in smbs {
                    ui.group(|ui| {
                        ui.label(RichText::new(&smb.name).strong());
                        let (badge, col) = match &smb.status {
                            SmbStatus::Unknown => ("⚪ 未檢測".to_string(), Color32::GRAY),
                            SmbStatus::Probing => {
                                ("⏳ 背景連線檢測中...".to_string(), Color32::from_rgb(200, 140, 0))
                            }
                            SmbStatus::Online(ms) => (
                                format!("🟢 線上 ({} ms)", ms),
                                Color32::from_rgb(20, 150, 60),
                            ),
                            SmbStatus::Offline(reason) => (
                                format!("🔴 離線保護中: {}", reason),
                                Color32::from_rgb(200, 50, 50),
                            ),
                        };
                        ui.label(RichText::new(badge).color(col).small());
                        ui.horizontal(|ui| {
                            if ui.small_button("📂 非同步開啟").clicked() {
                                let idx = self.active_pane_index();
                                if let Some(p) = self.panes.get_mut(idx) {
                                    p.navigate_to(PathBuf::from(&smb.unc_or_mount_path), true);
                                }
                            }
                            if ui.small_button("➕ 新視窗").clicked() {
                                self.spawn_new_pane(PathBuf::from(&smb.unc_or_mount_path));
                            }
                        });
                    });
                }
            }
            SidebarTab::ClosedHistory => {
                ui.label(RichText::new("🕒 已關閉視窗恢復列表").strong());
                let hist = self.config.closed_history.clone();
                if hist.is_empty() {
                    ui.label(t.fav_empty);
                }
                for path_s in hist {
                    if ui.button(format!("🔄 {}", path_s)).clicked() {
                        self.spawn_new_pane(PathBuf::from(path_s));
                    }
                }
            }
        });
    }

    fn render_right_preview(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        ui.heading(t.preview_title);
        ui.label(
            RichText::new(t.preview_heic_sandboxed)
                .small()
                .color(Color32::from_rgb(20, 140, 70)),
        );
        ui.separator();

        egui::ScrollArea::vertical().show(ui, |ui| match &self.preview_state {
            PreviewPayload::None => {
                ui.label(t.preview_no_selection);
            }
            PreviewPayload::Loading(p) => {
                ui.spinner();
                ui.label(format!("沙盒非同步讀取中: {}", p.to_string_lossy()));
            }
            PreviewPayload::Image {
                path,
                width,
                height,
                format_note,
                ..
            } => {
                ui.label(RichText::new(path.file_name().unwrap_or_default().to_string_lossy()).strong());
                ui.label(RichText::new(format_note).small().color(Color32::from_rgb(0, 120, 215)));
                ui.label(format!("預覽解析度: {} × {}", width, height));
                if let Some(ref tex) = self.preview_texture {
                    let avail_w = ui.available_width().max(120.0);
                    let aspect = (*height as f32) / ((*width as f32).max(1.0));
                    let disp_size = Vec2::new(avail_w, (avail_w * aspect).min(360.0));
                    ui.image((tex.id(), disp_size));
                }
            }
            PreviewPayload::Text {
                path,
                content,
                encoding_note,
            } => {
                ui.label(RichText::new(path.file_name().unwrap_or_default().to_string_lossy()).strong());
                ui.label(
                    RichText::new(encoding_note)
                        .small()
                        .color(Color32::from_rgb(20, 140, 70)),
                );
                ui.separator();
                ui.add(
                    egui::TextEdit::multiline(&mut content.as_str())
                        .font(egui::TextStyle::Monospace)
                        .desired_width(f32::INFINITY),
                );
            }
            PreviewPayload::MetadataOnly { path, summary } => {
                ui.label(RichText::new(path.to_string_lossy()).strong());
                ui.separator();
                ui.label(summary);
            }
        });
    }

    fn render_mdi_workspace(&mut self, ui: &mut egui::Ui, t: &crate::i18n::Texts) {
        let workspace_rect = ui.available_rect_before_wrap();
        let n = self.panes.len().max(1);

        // Calculate target rectangles for each MDI child window based on active layout mode
        let mut calculated_rects: Vec<(usize, Rect)> = Vec::with_capacity(n);

        match self.config.layout_mode {
            WindowLayoutMode::TabbedMaximized => {
                let active_idx = self.active_pane_index();
                calculated_rects.push((active_idx, workspace_rect));
            }
            WindowLayoutMode::TileHorizontally => {
                let col_w = workspace_rect.width() / (n as f32);
                for i in 0..n {
                    let r = Rect::from_min_size(
                        Pos2::new(
                            workspace_rect.min.x + (i as f32) * col_w,
                            workspace_rect.min.y,
                        ),
                        Vec2::new(col_w - 2.0, workspace_rect.height()),
                    );
                    calculated_rects.push((i, r));
                }
            }
            WindowLayoutMode::TileVertically => {
                let row_h = workspace_rect.height() / (n as f32);
                for i in 0..n {
                    let r = Rect::from_min_size(
                        Pos2::new(
                            workspace_rect.min.x,
                            workspace_rect.min.y + (i as f32) * row_h,
                        ),
                        Vec2::new(workspace_rect.width(), row_h - 2.0),
                    );
                    calculated_rects.push((i, r));
                }
            }
            WindowLayoutMode::TileGrid => {
                let cols = (n as f32).sqrt().ceil() as usize;
                let rows = (n + cols - 1) / cols;
                let cell_w = workspace_rect.width() / (cols as f32);
                let cell_h = workspace_rect.height() / (rows as f32);
                for i in 0..n {
                    let c = i % cols;
                    let r_idx = i / cols;
                    let r = Rect::from_min_size(
                        Pos2::new(
                            workspace_rect.min.x + (c as f32) * cell_w,
                            workspace_rect.min.y + (r_idx as f32) * cell_h,
                        ),
                        Vec2::new(cell_w - 2.0, cell_h - 2.0),
                    );
                    calculated_rects.push((i, r));
                }
            }
            WindowLayoutMode::Cascade | WindowLayoutMode::MdiFree => {
                for i in 0..n {
                    let default_offset = (i as f32) * 32.0;
                    let rect = self.panes[i].float_rect.unwrap_or_else(|| {
                        Rect::from_min_size(
                            Pos2::new(
                                workspace_rect.min.x + 16.0 + default_offset,
                                workspace_rect.min.y + 16.0 + default_offset,
                            ),
                            Vec2::new(
                                (workspace_rect.width() * 0.58).max(340.0),
                                (workspace_rect.height() * 0.65).max(260.0),
                            ),
                        )
                    });
                    self.panes[i].float_rect = Some(rect);
                    calculated_rects.push((i, rect));
                }
                // In overlapping mode, render active window last so it appears on top!
                let active_id = self.active_pane_id;
                calculated_rects.sort_by_key(|(idx, _)| self.panes[*idx].id == active_id);
            }
        }

        let mut pane_to_close = None;
        let mut pane_to_clone = None;
        let mut pane_to_maximize = None;
        let mut newly_activated_id = None;
        let mut preview_req = None;
        let mut drop_transfer: Option<(Vec<PathBuf>, PathBuf, bool)> = None;

        for (pane_idx, rect) in calculated_rects {
            let pane_id = self.panes[pane_idx].id;
            let is_active = pane_id == self.active_pane_id;
            let is_free_mode = matches!(
                self.config.layout_mode,
                WindowLayoutMode::Cascade | WindowLayoutMode::MdiFree
            );

            let mut child_ui = ui.new_child(
                egui::UiBuilder::new()
                    .max_rect(rect)
                    .layout(egui::Layout::top_down(egui::Align::Min)),
            );

            let border_color = if is_active {
                Color32::from_rgb(0, 120, 215)
            } else {
                Color32::from_gray(140)
            };

            let bg_fill = if self.config.theme == AppTheme::ModernDark {
                Color32::from_rgb(28, 30, 36)
            } else {
                Color32::WHITE
            };

            egui::Frame::none()
                .fill(bg_fill)
                .stroke(Stroke::new(if is_active { 2.0 } else { 1.0 }, border_color))
                .rounding(3.0)
                .show(&mut child_ui, |ui| {
                    ui.set_clip_rect(rect);

                    // 1. Classic MDIE Sub-Window Title Bar (with Minimize / Maximize / Close buttons & drag move)
                    let title_bg = if is_active {
                        if self.config.theme == AppTheme::ClassicMdie {
                            Color32::from_rgb(185, 209, 234) // Classic Win7/Aero/MDIE active caption blue!
                        } else {
                            Color32::from_rgb(0, 102, 204)
                        }
                    } else {
                        Color32::from_gray(215)
                    };
                    let title_fg = if is_active && self.config.theme != AppTheme::ClassicMdie {
                        Color32::WHITE
                    } else {
                        Color32::BLACK
                    };

                    egui::Frame::none()
                        .fill(title_bg)
                        .inner_margin(egui::Margin::symmetric(6.0, 3.0))
                        .show(ui, |ui| {
                            ui.horizontal(|ui| {
                                let title_resp = ui.add(
                                    egui::Label::new(
                                        RichText::new(format!(
                                            "📁 [{}] {}",
                                            pane_idx + 1,
                                            self.panes[pane_idx].title
                                        ))
                                        .color(title_fg)
                                        .strong(),
                                    )
                                    .sense(Sense::click_and_drag()),
                                );

                                if title_resp.clicked() || title_resp.drag_started() {
                                    newly_activated_id = Some(pane_id);
                                }
                                if title_resp.dragged() && is_free_mode {
                                    let delta = title_resp.drag_delta();
                                    if let Some(ref mut r) = self.panes[pane_idx].float_rect {
                                        *r = r.translate(delta);
                                    }
                                }

                                ui.with_layout(
                                    egui::Layout::right_to_left(egui::Align::Center),
                                    |ui| {
                                        if ui
                                            .button(RichText::new("✕").small())
                                            .on_hover_text("關閉此視窗")
                                            .clicked()
                                        {
                                            pane_to_close = Some(pane_id);
                                        }
                                        if ui
                                            .button(RichText::new("🗖").small())
                                            .on_hover_text("最大化/還原此視窗")
                                            .clicked()
                                        {
                                            pane_to_maximize = Some(pane_id);
                                        }
                                        if ui
                                            .button(RichText::new("📑").small())
                                            .on_hover_text("複製此視窗並排比對")
                                            .clicked()
                                        {
                                            pane_to_clone = Some(
                                                self.panes[pane_idx].current_path.clone(),
                                            );
                                        }
                                    },
                                );
                            });
                        });

                    // 2. Sub-Window Address Bar + Breadcrumb + Instant MDIE Search Bar
                    ui.horizontal(|ui| {
                        if ui.small_button("⬅").clicked() {
                            newly_activated_id = Some(pane_id);
                            self.panes[pane_idx].go_back();
                        }
                        if ui.small_button("➡").clicked() {
                            newly_activated_id = Some(pane_id);
                            self.panes[pane_idx].go_forward();
                        }
                        if ui.small_button("⬆").clicked() {
                            newly_activated_id = Some(pane_id);
                            self.panes[pane_idx].go_up();
                        }
                        let addr_resp = ui.add(
                            egui::TextEdit::singleline(&mut self.panes[pane_idx].address_input)
                                .desired_width((ui.available_width() * 0.52).max(90.0)),
                        );
                        if addr_resp.clicked() {
                            newly_activated_id = Some(pane_id);
                        }
                        if addr_resp.lost_focus()
                            && ui.input(|i| i.key_pressed(egui::Key::Enter))
                        {
                            let raw_in = self.panes[pane_idx].address_input.trim().to_string();
                            let expanded = expand_env_vars(&raw_in);
                            self.panes[pane_idx].navigate_to(PathBuf::from(expanded), true);
                        }

                        // Per-pane MDIE Search Box + 3 Search Modes (Filter / Best Match / Select Match)
                        let search_resp = ui.add(
                            egui::TextEdit::singleline(&mut self.panes[pane_idx].search_query)
                                .hint_text(t.search_placeholder)
                                .desired_width(ui.available_width().max(65.0) - 72.0),
                        );
                        if search_resp.changed() {
                            newly_activated_id = Some(pane_id);
                            let show_hidden = self.config.show_hidden;
                            self.panes[pane_idx].apply_sort_and_filter(show_hidden);
                        }
                        if search_resp.lost_focus()
                            && ui.input(|i| i.key_pressed(egui::Key::Enter))
                        {
                            let count = self.panes[pane_idx].execute_mdie_select_matching();
                            self.status_toast =
                                format!("☑️ MDIE 條件選取完成：已自動勾選 {} 個相符項目", count);
                        }

                        egui::ComboBox::from_id_salt(format!("smode_{}", pane_id))
                            .width(64.0)
                            .selected_text(match self.panes[pane_idx].search_mode {
                                PaneSearchMode::InstantFilter => t.search_mode_filter,
                                PaneSearchMode::BestMatchJump => t.search_mode_best_match,
                                PaneSearchMode::SelectMatching => t.search_mode_select,
                            })
                            .show_ui(ui, |ui| {
                                let show_hidden = self.config.show_hidden;
                                if ui
                                    .selectable_value(
                                        &mut self.panes[pane_idx].search_mode,
                                        PaneSearchMode::InstantFilter,
                                        t.search_mode_filter,
                                    )
                                    .clicked()
                                    || ui
                                        .selectable_value(
                                            &mut self.panes[pane_idx].search_mode,
                                            PaneSearchMode::BestMatchJump,
                                            t.search_mode_best_match,
                                        )
                                        .clicked()
                                    || ui
                                        .selectable_value(
                                            &mut self.panes[pane_idx].search_mode,
                                            PaneSearchMode::SelectMatching,
                                            t.search_mode_select,
                                        )
                                        .clicked()
                                {
                                    self.panes[pane_idx].apply_sort_and_filter(show_hidden);
                                }
                            });
                    });

                    // 3. Error / Disconnected SMB Protection Banner (if any)
                    if let Some(ref err) = self.panes[pane_idx].error_banner.clone() {
                        egui::Frame::none()
                            .fill(Color32::from_rgb(255, 235, 235))
                            .inner_margin(4.0)
                            .show(ui, |ui| {
                                ui.horizontal(|ui| {
                                    ui.label(
                                        RichText::new(format!(
                                            "🛡️ 非阻塞防護已攔截錯誤 (視窗不卡死): {}",
                                            err
                                        ))
                                        .color(Color32::from_rgb(180, 20, 20)),
                                    );
                                    if ui.small_button("返回上一頁").clicked() {
                                        self.panes[pane_idx].go_back();
                                    }
                                });
                            });
                    }

                    // 4. Drop Target Zone for Cross-Window File Comparison & Move/Copy
                    if let Some((src_pane_id, dragged_paths)) = self.drag_payload.clone() {
                        if src_pane_id != pane_id {
                            egui::Frame::none()
                                .fill(Color32::from_rgb(220, 242, 255))
                                .inner_margin(3.0)
                                .show(ui, |ui| {
                                    ui.horizontal(|ui| {
                                        ui.label(
                                            RichText::new(format!(
                                                "📥 拖曳檔案至此視窗 ({} 個項目):",
                                                dragged_paths.len()
                                            ))
                                            .color(Color32::from_rgb(0, 90, 180))
                                            .strong(),
                                        );
                                        if ui.small_button("📋 複製到此處 (Copy Here)").clicked() {
                                            drop_transfer = Some((
                                                dragged_paths.clone(),
                                                self.panes[pane_idx].current_path.clone(),
                                                false,
                                            ));
                                        }
                                        if ui.small_button("✂️ 移動到此處 (Move Here)").clicked() {
                                            drop_transfer = Some((
                                                dragged_paths.clone(),
                                                self.panes[pane_idx].current_path.clone(),
                                                true,
                                            ));
                                        }
                                        if ui.small_button("取消").clicked() {
                                            self.drag_payload = None;
                                        }
                                    });
                                });
                        }
                    }

                    // 5. High-Speed Virtualized File Table (handles 100,000+ files with zero lag)
                    let show_hidden = self.config.show_hidden;
                    let scroll_req = self.panes[pane_idx].scroll_request;
                    self.panes[pane_idx].scroll_request = ScrollRequest::None;

                    let avail_h = (ui.available_height() - 4.0).max(60.0);
                    ui.push_id(format!("pane_table_{}", pane_id), |ui| {
                        let mut table = TableBuilder::new(ui)
                            .striped(true)
                            .resizable(true)
                            .cell_layout(egui::Layout::left_to_right(egui::Align::Center))
                            .column(Column::initial(210.0).at_least(90.0).clip(true))
                            .column(Column::initial(75.0).at_least(55.0))
                            .column(Column::initial(95.0).at_least(65.0).clip(true))
                            .column(Column::remainder().at_least(100.0).clip(true))
                            .min_scrolled_height(avail_h)
                            .max_scroll_height(avail_h);

                        match scroll_req {
                            ScrollRequest::Top => {
                                table = table.scroll_to_row(0, Some(egui::Align::TOP));
                            }
                            ScrollRequest::Bottom => {
                                let last = self.panes[pane_idx]
                                    .filtered_indices
                                    .len()
                                    .saturating_sub(1);
                                table = table.scroll_to_row(last, Some(egui::Align::BOTTOM));
                            }
                            ScrollRequest::Row(r) => {
                                table = table.scroll_to_row(r, Some(egui::Align::Center));
                            }
                            ScrollRequest::None => {}
                        }

                        table
                            .header(20.0, |mut header| {
                                let cur_col = self.panes[pane_idx].sort_col;
                                let cur_asc = self.panes[pane_idx].sort_asc;
                                let arrow = |col: SortColumn| {
                                    if cur_col == col {
                                        if cur_asc { " ▲" } else { " ▼" }
                                    } else {
                                        ""
                                    }
                                };

                                header.col(|ui| {
                                    if ui
                                        .button(
                                            RichText::new(format!(
                                                "{}{}",
                                                t.col_name,
                                                arrow(SortColumn::Name)
                                            ))
                                            .strong(),
                                        )
                                        .clicked()
                                    {
                                        toggle_sort(&mut self.panes[pane_idx], SortColumn::Name, show_hidden);
                                    }
                                });
                                header.col(|ui| {
                                    if ui
                                        .button(
                                            RichText::new(format!(
                                                "{}{}",
                                                t.col_size,
                                                arrow(SortColumn::Size)
                                            ))
                                            .strong(),
                                        )
                                        .clicked()
                                    {
                                        toggle_sort(&mut self.panes[pane_idx], SortColumn::Size, show_hidden);
                                    }
                                });
                                header.col(|ui| {
                                    if ui
                                        .button(
                                            RichText::new(format!(
                                                "{}{}",
                                                t.col_type,
                                                arrow(SortColumn::Type)
                                            ))
                                            .strong(),
                                        )
                                        .clicked()
                                    {
                                        toggle_sort(&mut self.panes[pane_idx], SortColumn::Type, show_hidden);
                                    }
                                });
                                header.col(|ui| {
                                    if ui
                                        .button(
                                            RichText::new(format!(
                                                "{}{}",
                                                t.col_modified,
                                                arrow(SortColumn::Modified)
                                            ))
                                            .strong(),
                                        )
                                        .clicked()
                                    {
                                        toggle_sort(
                                            &mut self.panes[pane_idx],
                                            SortColumn::Modified,
                                            show_hidden,
                                        );
                                    }
                                });
                            })
                            .body(|body| {
                                let total_rows = self.panes[pane_idx].filtered_indices.len();
                                let is_zh = self.config.language == Language::ZhTw;
                                let mut nav_dir = None;
                                let mut open_file = None;

                                body.rows(21.0, total_rows, |mut row| {
                                    let row_idx = row.index();
                                    let entry_idx = self.panes[pane_idx].filtered_indices[row_idx];
                                    let entry = self.panes[pane_idx].entries[entry_idx].clone();
                                    let is_selected =
                                        self.panes[pane_idx].selected_paths.contains(&entry.path);
                                    row.set_selected(is_selected);

                                    row.col(|ui| {
                                        let label_str = if entry.had_special_encoding {
                                            format!("{} {} [🛡️UTF8]", entry.icon(), entry.display_name)
                                        } else {
                                            format!("{} {}", entry.icon(), entry.display_name)
                                        };
                                        let resp = ui.add(
                                            egui::Label::new(label_str)
                                                .truncate()
                                                .sense(Sense::click_and_drag()),
                                        );

                                        if resp.clicked() {
                                            newly_activated_id = Some(pane_id);
                                            let ctrl = ui.input(|i| i.modifiers.command || i.modifiers.ctrl);
                                            if !ctrl {
                                                self.panes[pane_idx].selected_paths.clear();
                                            }
                                            if is_selected && ctrl {
                                                self.panes[pane_idx].selected_paths.remove(&entry.path);
                                            } else {
                                                self.panes[pane_idx]
                                                    .selected_paths
                                                    .insert(entry.path.clone());
                                            }
                                            preview_req = Some(entry.path.clone());
                                        }

                                        if resp.double_clicked() {
                                            newly_activated_id = Some(pane_id);
                                            if entry.is_dir {
                                                nav_dir = Some(entry.path.clone());
                                            } else {
                                                open_file = Some(entry.path.clone());
                                            }
                                        }

                                        if resp.drag_started() {
                                            newly_activated_id = Some(pane_id);
                                            if !self.panes[pane_idx].selected_paths.contains(&entry.path) {
                                                self.panes[pane_idx].selected_paths.clear();
                                                self.panes[pane_idx]
                                                    .selected_paths
                                                    .insert(entry.path.clone());
                                            }
                                            let list: Vec<PathBuf> = self.panes[pane_idx]
                                                .selected_paths
                                                .iter()
                                                .cloned()
                                                .collect();
                                            self.drag_payload = Some((pane_id, list));
                                        }
                                    });

                                    row.col(|ui| {
                                        if !entry.is_dir {
                                            ui.label(format_size(entry.size));
                                        }
                                    });

                                    row.col(|ui| {
                                        ui.label(entry.type_label(is_zh));
                                    });

                                    row.col(|ui| {
                                        ui.label(&entry.modified_str);
                                    });
                                });

                                if let Some(d) = nav_dir {
                                    self.panes[pane_idx].navigate_to(d, true);
                                    self.sync_config_paths();
                                }
                                if let Some(f) = open_file {
                                    preview_req = Some(f.clone());
                                    let _ = open::that(&f);
                                }
                            });
                    });
                });
        }

        if let Some(id) = newly_activated_id {
            self.active_pane_id = id;
        }
        if let Some(p) = preview_req {
            self.trigger_preview(p);
        }
        if let Some((srcs, dst, is_cut)) = drop_transfer {
            self.perform_file_transfer(&srcs, &dst, is_cut);
            self.drag_payload = None;
        }
        if let Some(path) = pane_to_clone {
            self.spawn_new_pane(path);
        }
        if let Some(id) = pane_to_maximize {
            self.active_pane_id = id;
            self.config.layout_mode =
                if self.config.layout_mode == WindowLayoutMode::TabbedMaximized {
                    WindowLayoutMode::TileHorizontally
                } else {
                    WindowLayoutMode::TabbedMaximized
                };
        }
        if let Some(id) = pane_to_close {
            self.close_pane_by_id(id);
        }
    }

    fn render_gesture_overlay(&self, ctx: &egui::Context) {
        if !self.gesture_tracker.is_tracking || self.gesture_tracker.trail.len() < 2 {
            return;
        }
        let painter = ctx.layer_painter(egui::LayerId::new(
            egui::Order::Foreground,
            egui::Id::new("mdie_gesture_overlay"),
        ));

        // Draw glowing cyan-blue gesture trail
        painter.add(egui::Shape::line(
            self.gesture_tracker.trail.clone(),
            Stroke::new(4.0, Color32::from_rgb(0, 190, 255)),
        ));

        // Draw HUD badge at center of screen showing current arrows + matched command
        let screen = ctx.screen_rect();
        let center = screen.center();
        let arrows = GestureTracker::format_arrows(&self.gesture_tracker.current_directions);
        let action_label = self
            .gesture_tracker
            .current_matched_action()
            .map(|a| a.label(self.config.language))
            .unwrap_or(if self.config.language == Language::ZhTw {
                "(繼續拖曳以匹配手勢...)"
            } else {
                "(Keep dragging to match gesture...)"
            });

        let hud_rect = Rect::from_center_size(center, Vec2::new(360.0, 74.0));
        painter.rect_filled(hud_rect, 10.0, Color32::from_black_alpha(210));
        painter.rect_stroke(
            hud_rect,
            10.0,
            Stroke::new(2.0, Color32::from_rgb(0, 190, 255)),
        );
        painter.text(
            Pos2::new(center.x, center.y - 14.0),
            egui::Align2::CENTER_CENTER,
            format!("🖱️ {}", if arrows.is_empty() { "•" } else { &arrows }),
            egui::FontId::proportional(22.0),
            Color32::from_rgb(0, 220, 255),
        );
        painter.text(
            Pos2::new(center.x, center.y + 16.0),
            egui::Align2::CENTER_CENTER,
            action_label,
            egui::FontId::proportional(15.0),
            Color32::WHITE,
        );
    }

    fn render_dialogs(&mut self, ctx: &egui::Context, t: &crate::i18n::Texts) {
        // 1. Next-Gen Ultra-Fast Deep Search Engine Dialog
        if self.show_search_dialog {
            let mut open = self.show_search_dialog;
            egui::Window::new(t.dlg_search_title)
                .open(&mut open)
                .default_size(Vec2::new(760.0, 520.0))
                .resizable(true)
                .show(ctx, |ui| {
                    ui.label(
                        RichText::new(
                            "💡 支援智慧語法：模糊拼字、>10MB (檔案大小)、ext:heic,jpg,rs (副檔名)、type:dir、re:正則表達式、以及內文關鍵字搜尋",
                        )
                        .small()
                        .color(Color32::from_rgb(0, 110, 200)),
                    );
                    ui.horizontal(|ui| {
                        ui.label("🔍 檔名/條件:");
                        let q_resp = ui.add(
                            egui::TextEdit::singleline(&mut self.deep_search_query)
                                .hint_text("例如: report >1MB 或 ext:jpg,png 或 screenshot")
                                .desired_width(260.0),
                        );
                        ui.label("📄 內文包含:");
                        ui.add(
                            egui::TextEdit::singleline(&mut self.deep_search_grep)
                                .hint_text("(選填) 搜尋檔案內部文字")
                                .desired_width(150.0),
                        );
                        ui.checkbox(&mut self.deep_search_scope_all_panes, "搜尋所有並排視窗目錄");

                        let trigger = (q_resp.lost_focus()
                            && ui.input(|i| i.key_pressed(egui::Key::Enter)))
                            || ui.button("🚀 開始極速搜尋").clicked();
                        if trigger {
                            self.deep_search_cancel.store(true, Ordering::Relaxed);
                            self.deep_search_cancel =
                                std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
                            self.deep_search_results.clear();
                            self.deep_search_selected.clear();
                            self.deep_search_scanned = 0;
                            self.deep_search_running = true;

                            let roots: Vec<PathBuf> = if self.deep_search_scope_all_panes {
                                self.panes.iter().map(|p| p.current_path.clone()).collect()
                            } else {
                                let idx = self.active_pane_index();
                                self.panes
                                    .get(idx)
                                    .map(|p| vec![p.current_path.clone()])
                                    .unwrap_or_default()
                            };
                            self.deep_search_rx = Some(spawn_deep_search(
                                roots,
                                self.deep_search_query.clone(),
                                self.deep_search_grep.clone(),
                                2000,
                                self.deep_search_cancel.clone(),
                            ));
                        }
                        if self.deep_search_running && ui.button("⏹ 停止").clicked() {
                            self.deep_search_cancel.store(true, Ordering::Relaxed);
                            self.deep_search_running = false;
                        }
                    });

                    ui.horizontal(|ui| {
                        ui.label(format!(
                            "已掃描: {} 個項目 | 找到: {} 筆結果 | 耗時: {} ms",
                            self.deep_search_scanned,
                            self.deep_search_results.len(),
                            self.deep_search_elapsed_ms
                        ));
                        ui.separator();
                        if ui.small_button("☑️ 全選結果").clicked() {
                            for r in &self.deep_search_results {
                                self.deep_search_selected.insert(r.entry.path.clone());
                            }
                        }
                        if ui
                            .small_button("➕ 將所選檔案所在目錄開啟為新並排視窗")
                            .clicked()
                        {
                            let mut dirs = std::collections::HashSet::new();
                            for p in &self.deep_search_selected {
                                if let Some(parent) = p.parent() {
                                    dirs.insert(parent.to_path_buf());
                                }
                            }
                            for d in dirs.into_iter().take(6) {
                                self.spawn_new_pane(d);
                            }
                        }
                    });
                    ui.separator();

                    let results_snapshot = self.deep_search_results.clone();
                    let mut jump_to_dir = None;
                    let mut spawn_dir = None;

                    TableBuilder::new(ui)
                        .striped(true)
                        .resizable(true)
                        .column(Column::initial(220.0).clip(true))
                        .column(Column::initial(75.0))
                        .column(Column::initial(260.0).clip(true))
                        .column(Column::remainder())
                        .header(20.0, |mut h| {
                            h.col(|ui| {
                                ui.strong("檔案名稱 (Name)");
                            });
                            h.col(|ui| {
                                ui.strong("大小");
                            });
                            h.col(|ui| {
                                ui.strong("所在目錄 (Directory)");
                            });
                            h.col(|ui| {
                                ui.strong("快速動作 / 內文預覽");
                            });
                        })
                        .body(|body| {
                            body.rows(23.0, results_snapshot.len(), |mut row| {
                                let item = &results_snapshot[row.index()];
                                let checked =
                                    self.deep_search_selected.contains(&item.entry.path);
                                row.col(|ui| {
                                    let mut c = checked;
                                    if ui
                                        .checkbox(
                                            &mut c,
                                            format!(
                                                "{} {}",
                                                item.entry.icon(),
                                                item.entry.display_name
                                            ),
                                        )
                                        .changed()
                                    {
                                        if c {
                                            self.deep_search_selected
                                                .insert(item.entry.path.clone());
                                        } else {
                                            self.deep_search_selected.remove(&item.entry.path);
                                        }
                                    }
                                });
                                row.col(|ui| {
                                    ui.label(format_size(item.entry.size));
                                });
                                row.col(|ui| {
                                    ui.label(item.parent_dir.to_string_lossy());
                                });
                                row.col(|ui| {
                                    if ui.small_button("📂 在目前視窗開啟").clicked() {
                                        jump_to_dir =
                                            Some((item.parent_dir.clone(), item.entry.path.clone()));
                                    }
                                    if ui.small_button("➕ 新視窗並排").clicked() {
                                        spawn_dir = Some(item.parent_dir.clone());
                                    }
                                    if let Some(ref snip) = item.matched_content_snippet {
                                        ui.label(
                                            RichText::new(snip)
                                                .small()
                                                .color(Color32::from_rgb(0, 120, 80)),
                                        );
                                    }
                                });
                            });
                        });

                    if let Some((dir, file_p)) = jump_to_dir {
                        let idx = self.active_pane_index();
                        if let Some(p) = self.panes.get_mut(idx) {
                            p.navigate_to(dir, true);
                            p.selected_paths.insert(file_p.clone());
                        }
                        self.trigger_preview(file_p);
                    }
                    if let Some(dir) = spawn_dir {
                        self.spawn_new_pane(dir);
                    }
                });
            self.show_search_dialog = open;
        }

        // 2. Mouse Gesture Settings & Cheat Sheet Dialog
        if self.show_gesture_dialog {
            let mut open = self.show_gesture_dialog;
            egui::Window::new(t.dlg_gesture_title)
                .open(&mut open)
                .default_size(Vec2::new(560.0, 440.0))
                .show(ctx, |ui| {
                    ui.label(
                        "按住滑鼠右鍵並在畫面任意處拖曳即可觸發手勢（支援 L=左, R=右, U=上, D=下 組合）：",
                    );
                    ui.separator();

                    ui.horizontal(|ui| {
                        ui.label("新增/修改手勢序列 (如 L, DR, ULR):");
                        ui.add(
                            egui::TextEdit::singleline(&mut self.new_gesture_seq)
                                .desired_width(70.0),
                        );
                        egui::ComboBox::from_id_salt("gesture_act_combo")
                            .selected_text(self.new_gesture_action.label(self.config.language))
                            .show_ui(ui, |ui| {
                                for &act in GestureAction::all() {
                                    ui.selectable_value(
                                        &mut self.new_gesture_action,
                                        act,
                                        act.label(self.config.language),
                                    );
                                }
                            });
                        if ui.button("➕ 綁定手勢").clicked() {
                            let cleaned: String = self
                                .new_gesture_seq
                                .to_uppercase()
                                .chars()
                                .filter(|c| matches!(c, 'L' | 'R' | 'U' | 'D'))
                                .collect();
                            if !cleaned.is_empty() {
                                self.gesture_tracker
                                    .bindings
                                    .insert(cleaned, self.new_gesture_action);
                                self.sync_config_paths();
                            }
                        }
                    });
                    ui.separator();

                    egui::ScrollArea::vertical().show(ui, |ui| {
                        let mut keys: Vec<String> =
                            self.gesture_tracker.bindings.keys().cloned().collect();
                        keys.sort();
                        let mut to_remove = None;
                        for k in keys {
                            if let Some(&act) = self.gesture_tracker.bindings.get(&k) {
                                ui.horizontal(|ui| {
                                    ui.label(
                                        RichText::new(format!(
                                            "🖱️ {:<6} ({})",
                                            k,
                                            GestureTracker::format_arrows(&k)
                                        ))
                                        .monospace()
                                        .strong(),
                                    );
                                    ui.label("➡");
                                    ui.label(act.label(self.config.language));
                                    if ui.small_button("🗑️").clicked() {
                                        to_remove = Some(k.clone());
                                    }
                                });
                            }
                        }
                        if let Some(k) = to_remove {
                            self.gesture_tracker.bindings.remove(&k);
                            self.sync_config_paths();
                        }
                    });
                });
            self.show_gesture_dialog = open;
        }

        // 3. Non-Blocking SMB Manager Dialog
        if self.show_smb_dialog {
            let mut open = self.show_smb_dialog;
            egui::Window::new(t.dlg_smb_title)
                .open(&mut open)
                .default_size(Vec2::new(540.0, 360.0))
                .show(ctx, |ui| {
                    ui.label(
                        "傳統 MDIE 與 Windows 檔案總管在開啟未連線的 SMB 網域時會卡死 30~60 秒。\nMINE 採用獨立執行緒 + 1.2 秒 TCP 逾時探測，即使網域離線也絕不影響視窗操作！",
                    );
                    ui.separator();
                    ui.horizontal(|ui| {
                        ui.label("名稱:");
                        ui.add(egui::TextEdit::singleline(&mut self.new_smb_name).desired_width(90.0));
                        ui.label("IP/Host:");
                        ui.add(egui::TextEdit::singleline(&mut self.new_smb_host).desired_width(100.0));
                        ui.label("UNC/掛載路徑:");
                        ui.add(egui::TextEdit::singleline(&mut self.new_smb_unc).desired_width(140.0));
                        if ui.button("➕ 新增").clicked() {
                            self.config.smb_bookmarks.push(
                                crate::fs_ops::SmbShareBookmark {
                                    name: self.new_smb_name.clone(),
                                    unc_or_mount_path: self.new_smb_unc.clone(),
                                    host_ip: self.new_smb_host.clone(),
                                    port: self.new_smb_port.parse().unwrap_or(445),
                                    status: SmbStatus::Unknown,
                                },
                            );
                            let _ = self.config.save();
                            self.probe_all_smb();
                        }
                    });
                    ui.separator();
                    if ui.button(t.dlg_smb_test_async).clicked() {
                        self.probe_all_smb();
                    }
                    let mut remove_idx = None;
                    for (i, smb) in self.config.smb_bookmarks.iter().enumerate() {
                        ui.horizontal(|ui| {
                            ui.strong(&smb.name);
                            ui.label(&smb.unc_or_mount_path);
                            ui.label(format!("{:?}", smb.status));
                            if ui.small_button("🗑️").clicked() {
                                remove_idx = Some(i);
                            }
                        });
                    }
                    if let Some(i) = remove_idx {
                        self.config.smb_bookmarks.remove(i);
                        let _ = self.config.save();
                    }
                });
            self.show_smb_dialog = open;
        }

        // 4. Save Workspace Group Modal
        if self.show_save_group_modal {
            egui::Window::new("💾 儲存多視窗並排工作群組 (MDIE Workspace Group)")
                .collapsible(false)
                .show(ctx, |ui| {
                    ui.label(format!(
                        "將目前開啟的 {} 個子視窗路徑與排列模式存為群組，隨時一鍵展開：",
                        self.panes.len()
                    ));
                    ui.text_edit_singleline(&mut self.new_group_name);
                    ui.horizontal(|ui| {
                        if ui.button("💾 儲存").clicked() {
                            let paths = self
                                .panes
                                .iter()
                                .map(|p| p.current_path.to_string_lossy().into_owned())
                                .collect();
                            self.config.workspace_groups.push(WorkspaceGroupBookmark {
                                name: self.new_group_name.clone(),
                                layout: self.config.layout_mode,
                                paths,
                            });
                            let _ = self.config.save();
                            self.show_save_group_modal = false;
                        }
                        if ui.button("取消").clicked() {
                            self.show_save_group_modal = false;
                        }
                    });
                });
        }

        // 5. Create Folder / File Modal
        if let Some((dir_path, is_folder, ref mut name_buf)) = self.create_item_modal.clone() {
            let mut close = false;
            let mut current_name = name_buf.clone();
            egui::Window::new(if is_folder {
                "📁 新增資料夾 (New Folder)"
            } else {
                "📄 新增檔案 (New File)"
            })
            .collapsible(false)
            .show(ctx, |ui| {
                ui.text_edit_singleline(&mut current_name);
                ui.horizontal(|ui| {
                    if ui.button("✅ 建立").clicked() {
                        let target = dir_path.join(&current_name);
                        let _ = if is_folder {
                            std::fs::create_dir_all(&target)
                        } else {
                            std::fs::File::create(&target).map(|_| ())
                        };
                        for p in &mut self.panes {
                            p.trigger_reload();
                        }
                        close = true;
                    }
                    if ui.button("取消").clicked() {
                        close = true;
                    }
                });
            });
            if close {
                self.create_item_modal = None;
            } else if let Some((_, _, ref mut n)) = self.create_item_modal {
                *n = current_name;
            }
        }

        // 6. Rename Item Modal (F2)
        if let Some((orig_path, ref name_buf)) = self.rename_modal.clone() {
            let mut close = false;
            let mut new_name = name_buf.clone();
            egui::Window::new(t.edit_rename)
                .collapsible(false)
                .show(ctx, |ui| {
                    ui.text_edit_singleline(&mut new_name);
                    ui.horizontal(|ui| {
                        if ui.button("✅ 確認重新命名").clicked() {
                            if let Some(parent) = orig_path.parent() {
                                let dst = parent.join(&new_name);
                                let _ = std::fs::rename(&orig_path, &dst);
                                for p in &mut self.panes {
                                    p.trigger_reload();
                                }
                            }
                            close = true;
                        }
                        if ui.button("取消").clicked() {
                            close = true;
                        }
                    });
                });
            if close {
                self.rename_modal = None;
            } else if let Some((_, ref mut n)) = self.rename_modal {
                *n = new_name;
            }
        }

        // 7. About Dialog
        if self.show_about_dialog {
            let mut open = self.show_about_dialog;
            egui::Window::new(t.dlg_about_title)
                .open(&mut open)
                .show(ctx, |ui| {
                    ui.heading("🗂️ MINE v0.1.0 (Multiple Interface Next-gen Explorer)");
                    ui.label("致敬日本開發者 佐野 (Sano) 先生於 2006–2007 開發的經典 MDIE 0.3.0.0 RC6");
                    ui.separator();
                    ui.label("✅ 無限制 MDI 多視窗並排：支援 2、3、4、6、9、12+ 個視窗同時並排或層疊");
                    ui.label("✅ 完整滑鼠手勢引擎：按住右鍵畫軌跡瞬間切換上下頁、開關視窗、並排排列");
                    ui.label("✅ 解決特殊文字編碼當機：全 Rust OsString / Lossy UTF-8 隔離保護");
                    ui.label("✅ 解決 .heic / 損毀圖檔閃退：沙盒化預覽執行緒 (`catch_unwind`) 絕不崩潰");
                    ui.label("✅ 解決 SMB 斷線卡死：非阻塞式 1.2 秒 TCP 探測與非同步資料夾讀取");
                    ui.label("✅ 次世代極速搜尋：多執行緒支援模糊搜尋、大小過濾 (>10MB)、內文搜尋與條件勾選");
                });
            self.show_about_dialog = open;
        }
    }
}

fn toggle_sort(pane: &mut MdiChildPane, col: SortColumn, show_hidden: bool) {
    if pane.sort_col == col {
        pane.sort_asc = !pane.sort_asc;
    } else {
        pane.sort_col = col;
        pane.sort_asc = true;
    }
    pane.apply_sort_and_filter(show_hidden);
}

fn expand_env_vars(input: &str) -> String {
    if input.starts_with('~') {
        if let Some(h) = dirs::home_dir() {
            return input.replacen('~', &h.to_string_lossy(), 1);
        }
    }
    input.to_string()
}

fn open_terminal_at(dir: & std::path::Path) {
    #[cfg(target_os = "windows")]
    {
        let _ = std::process::Command::new("cmd")
            .args(["/C", "start", "cmd"])
            .current_dir(dir)
            .spawn();
    }
    #[cfg(target_os = "macos")]
    {
        let _ = std::process::Command::new("open")
            .args(["-a", "Terminal", &dir.to_string_lossy()])
            .spawn();
    }
    #[cfg(target_os = "linux")]
    {
        let _ = std::process::Command::new("x-terminal-emulator")
            .current_dir(dir)
            .spawn();
    }
}

fn export_windows_shell_reg() -> Result<PathBuf, String> {
    let out_path = std::env::current_dir()
        .unwrap_or_else(|_| PathBuf::from("."))
        .join("mine_windows_shell_context_menu.reg");
    let reg_content = r#"Windows Registry Editor Version 5.00

; MINE (Multiple Interface Next-gen Explorer) - MDIE Successor
; Adds "Open in MINE" to Windows 10 / 11 Folder Context Menu

[HKEY_CURRENT_USER\Software\Classes\Directory\shell\MINE]
@="Open in MINE File Manager (以 MINE 開啟)"
"Icon"="mine.exe"

[HKEY_CURRENT_USER\Software\Classes\Directory\shell\MINE\command]
@="\"mine.exe\" \"%1\""

[HKEY_CURRENT_USER\Software\Classes\Directory\Background\shell\MINE]
@="Open in MINE File Manager (以 MINE 開啟)"
"Icon"="mine.exe"

[HKEY_CURRENT_USER\Software\Classes\Directory\Background\shell\MINE\command]
@="\"mine.exe\" \"%V\""
"#;
    std::fs::write(&out_path, reg_content).map_err(|e| e.to_string())?;
    Ok(out_path)
}

