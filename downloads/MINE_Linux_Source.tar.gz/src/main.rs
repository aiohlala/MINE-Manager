#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod app;
mod dnd;
mod fs_ops;
mod gesture;
mod i18n;
mod icon;
mod media;
mod search;
mod state;
mod ui;

use app::MineApp;

fn main() -> eframe::Result<()> {
    // Install a global crash-recovery hook so if any unexpected error ever happens,
    // it logs cleanly without affecting the OS shell or losing user config.
    std::panic::set_hook(Box::new(|info| {
        eprintln!("🛡 [MINE Crash-Guard] Isolated panic: {}", info);
    }));

    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 3 && args[1] == "--export-icons" {
        let _ = icon::export_icon_assets(std::path::Path::new(&args[2]));
        return Ok(());
    }

    let app_icon = std::sync::Arc::new(icon::build_kawaii_japanese_icon(128));

    let startup_cfg = crate::state::PortableConfig::load_or_default();
    let mut viewport = egui::ViewportBuilder::default()
        .with_title("MINE - Multiple Interface Next-gen Explorer")
        .with_inner_size([1360.0, 820.0])
        .with_min_inner_size([460.0, 360.0])
        .with_visible(true)
        .with_active(true)
        .with_icon(app_icon);

    let has_bounds = if let Some((pos, size)) = startup_cfg.sanitized_window_bounds() {
        viewport = viewport.with_position(pos).with_inner_size(size);
        if startup_cfg.window_maximized {
            viewport = viewport.with_maximized(true);
        }
        true
    } else {
        if startup_cfg.window_maximized {
            viewport = viewport.with_maximized(true);
        }
        false
    };

    let native_options = eframe::NativeOptions {
        viewport,
        persist_window: false,
        centered: !has_bounds,
        ..Default::default()
    };

    eframe::run_native(
        "MINE",
        native_options,
        Box::new(|cc| Ok(Box::new(MineApp::new(cc)))),
    )
}
