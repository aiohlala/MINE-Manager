#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod app;
mod fs_ops;
mod gesture;
mod i18n;
mod search;
mod state;
mod ui;

use app::MineApp;

fn main() -> eframe::Result<()> {
    // Install a global crash-recovery hook so if any unexpected error ever happens,
    // it logs cleanly without affecting the OS shell or losing user config.
    std::panic::set_hook(Box::new(|info| {
        eprintln!("🛡️ [MINE Crash-Guard] Isolated panic: {}", info);
    }));

    let native_options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("MINE - Multiple Interface Next-gen Explorer (MDIE Modern Successor)")
            .with_inner_size([1360.0, 820.0])
            .with_min_inner_size([720.0, 460.0]),
        ..Default::default()
    };

    eframe::run_native(
        "MINE",
        native_options,
        Box::new(|cc| Ok(Box::new(MineApp::new(cc)))),
    )
}
