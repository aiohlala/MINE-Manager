use std::path::{Path, PathBuf};

/// Represents an application that can open a given file type.
#[derive(Debug, Clone)]
pub struct OpenWithApp {
    pub display_name: String,
    pub app_path: PathBuf,
    #[allow(dead_code)]
    pub bundle_id: String,
    pub is_default: bool,
    /// Optional 28x28 (or 32x32) unpremultiplied RGBA8 icon for rendering crisp app icons in menus.
    pub icon_rgba: Option<(usize, usize, Vec<u8>)>,
}

/// Normalizes a file extension to lowercase without a leading dot.
pub fn normalized_ext(path: &Path) -> String {
    path.extension()
        .and_then(|e| e.to_str())
        .map(|s| s.trim_start_matches('.').to_ascii_lowercase())
        .unwrap_or_default()
}

/// Extracts a human-friendly app display name from an executable or `.app` bundle path.
pub fn app_display_name_from_path(app_path: &Path) -> String {
    let raw = app_path
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_else(|| app_path.to_string_lossy().into_owned());
    let stripped = raw
        .strip_suffix(".app")
        .or_else(|| raw.strip_suffix(".APP"))
        .or_else(|| raw.strip_suffix(".exe"))
        .or_else(|| raw.strip_suffix(".EXE"))
        .unwrap_or(&raw);
    if stripped.is_empty() {
        raw
    } else {
        stripped.to_string()
    }
}

/// Parses TSV rows (`is_default\tdisplay_name\tbundle_id\tapp_path`) into sorted, deduplicated `OpenWithApp` entries.
pub fn parse_open_with_tsv(tsv: &str) -> Vec<OpenWithApp> {
    let mut apps: Vec<OpenWithApp> = Vec::new();
    let mut seen: std::collections::HashSet<PathBuf> = std::collections::HashSet::new();

    for line in tsv.lines() {
        let mut parts = line.splitn(4, '\t');
        let is_def = parts.next().unwrap_or("0") == "1";
        let name = parts.next().unwrap_or("").trim();
        let bundle_id = parts.next().unwrap_or("").trim();
        let path_str = parts.next().unwrap_or("").trim();
        if path_str.is_empty() {
            continue;
        }
        let app_path = PathBuf::from(path_str);
        if !seen.insert(app_path.clone()) {
            continue;
        }
        let display_name = if name.is_empty() {
            app_display_name_from_path(&app_path)
        } else {
            name.to_string()
        };
        apps.push(OpenWithApp {
            display_name,
            app_path,
            bundle_id: bundle_id.to_string(),
            is_default: is_def,
            icon_rgba: None,
        });
    }

    apps.sort_by(|a, b| {
        b.is_default
            .cmp(&a.is_default)
            .then_with(|| a.display_name.to_lowercase().cmp(&b.display_name.to_lowercase()))
    });
    apps
}

/// Applies an optional MINE-local custom default override to an enumerated app list.
pub fn apply_custom_default_override(apps: &mut Vec<OpenWithApp>, custom_default: Option<&Path>) {
    let Some(custom_path) = custom_default else {
        return;
    };
    if !custom_path.exists() {
        return;
    }
    let mut matched = false;
    for app in apps.iter_mut() {
        let same = app.app_path == custom_path
            || app
                .app_path
                .to_string_lossy()
                .eq_ignore_ascii_case(&custom_path.to_string_lossy());
        app.is_default = same;
        if same {
            matched = true;
        }
    }
    if !matched {
        apps.push(OpenWithApp {
            display_name: app_display_name_from_path(custom_path),
            app_path: custom_path.to_path_buf(),
            bundle_id: String::new(),
            is_default: true,
            icon_rgba: None,
        });
    }
    apps.sort_by(|a, b| {
        b.is_default
            .cmp(&a.is_default)
            .then_with(|| a.display_name.to_lowercase().cmp(&b.display_name.to_lowercase()))
    });
}

/// Lists OS-registered applications capable of opening `file_path`, with the default app pinned first.
pub fn list_open_with_apps(
    file_path: &Path,
    custom_default: Option<&Path>,
    fetch_icons: bool,
) -> Vec<OpenWithApp> {
    let mut apps = {
        #[cfg(target_os = "macos")]
        {
            macos_open_with::list_apps(file_path)
        }
        #[cfg(target_os = "windows")]
        {
            win_open_with::list_apps(file_path)
        }
        #[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
        {
            linux_open_with::list_apps(file_path)
        }
    };

    apply_custom_default_override(&mut apps, custom_default);

    if fetch_icons {
        #[cfg(target_os = "macos")]
        {
            for app in &mut apps {
                app.icon_rgba = macos_open_with::get_app_icon_rgba(&app.app_path, 28);
            }
        }
    }

    apps
}

/// Opens one or more files with a specific application path.
pub fn open_files_with_app(files: &[PathBuf], app_path: &Path) -> Result<(), String> {
    if files.is_empty() {
        return Err("No files specified".into());
    }
    #[cfg(target_os = "macos")]
    {
        let mut cmd = std::process::Command::new("open");
        cmd.arg("-a").arg(app_path);
        for f in files {
            cmd.arg(f);
        }
        cmd.spawn()
            .map(|_| ())
            .map_err(|e| format!("Failed to launch {}: {}", app_path.display(), e))
    }
    #[cfg(target_os = "windows")]
    {
        let mut cmd = std::process::Command::new(app_path);
        for f in files {
            cmd.arg(f);
        }
        cmd.spawn()
            .map(|_| ())
            .map_err(|e| format!("Failed to launch {}: {}", app_path.display(), e))
    }
    #[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
    {
        let mut cmd = std::process::Command::new(app_path);
        for f in files {
            cmd.arg(f);
        }
        cmd.spawn()
            .map(|_| ())
            .map_err(|e| format!("Failed to launch {}: {}", app_path.display(), e))
    }
}

/// Attempts to set the OS-wide default application for `file_path`'s content type / extension.
/// Returns `Ok(true)` if the OS system-wide default was updated directly,
/// or `Ok(false)` if the OS requires a MINE-local override or interactive system dialog.
pub fn set_os_default_app_for_file(file_path: &Path, app_path: &Path) -> Result<bool, String> {
    #[cfg(target_os = "macos")]
    {
        if macos_open_with::set_default_app(file_path, app_path) {
            return Ok(true);
        }
        return Ok(false);
    }
    #[cfg(target_os = "windows")]
    {
        let _ = (file_path, app_path);
        // Windows 10/11 protects HKCU FileExts UserChoice with an OS hash;
        // callers store the MINE-level override and also offer native SHOpenWithDialog.
        Ok(false)
    }
    #[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
    {
        linux_open_with::set_default_app(file_path, app_path)
    }
}

/// Launches the OS-native "Choose Other App" dialog.
/// - macOS: native `NSOpenPanel` in `/Applications` with an "Always open with" checkbox; returns `Some((app_path, always_default))`.
/// - Windows: native `SHOpenWithDialog` (which handles both launching and Windows' own "Always" association); returns `None`.
/// - Linux: tries `zenity --file-selection` if available.
pub fn choose_other_app_dialog(file_path: &Path, is_zh: bool) -> Option<(PathBuf, bool)> {
    #[cfg(target_os = "macos")]
    {
        let ext = normalized_ext(file_path);
        return macos_open_with::choose_app_dialog(&ext, is_zh);
    }
    #[cfg(target_os = "windows")]
    {
        let _ = is_zh;
        win_open_with::show_native_open_with_dialog(file_path);
        return None;
    }
    #[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
    {
        let _ = file_path;
        let title = if is_zh {
            "選擇開啟檔案的應用程式"
        } else {
            "Choose Application"
        };
        let out = std::process::Command::new("zenity")
            .args(["--file-selection", "--title", title, "--filename=/usr/bin/"])
            .output()
            .ok()?;
        if out.status.success() {
            let p = String::from_utf8_lossy(&out.stdout).trim().to_string();
            if !p.is_empty() {
                return Some((PathBuf::from(p), false));
            }
        }
        None
    }
}

// ============================================================================
// macOS Backend (AppKit NSWorkspace + LaunchServices FFI via src/macos_dnd.m)
// ============================================================================

#[cfg(target_os = "macos")]
mod macos_open_with {
    use super::{parse_open_with_tsv, OpenWithApp};
    use std::ffi::{c_char, c_int, CString};
    use std::path::{Path, PathBuf};
    use std::ptr::null_mut;

    extern "C" {
        fn mine_macos_free_buffer(ptr: *mut u8);
        fn mine_macos_list_open_with_apps(
            path_utf8: *const c_char,
            out_buf: *mut *mut u8,
            out_len: *mut c_int,
        ) -> c_int;
        fn mine_macos_get_app_icon_rgba(
            app_path_utf8: *const c_char,
            size_px: c_int,
            out_rgba: *mut *mut u8,
            out_w: *mut c_int,
            out_h: *mut c_int,
        ) -> c_int;
        fn mine_macos_set_default_app_for_file(
            file_path_utf8: *const c_char,
            app_path_utf8: *const c_char,
        ) -> c_int;
        fn mine_macos_choose_app_dialog(
            ext_utf8: *const c_char,
            is_zh: c_int,
            out_app_path: *mut *mut u8,
            out_len: *mut c_int,
            out_always_default: *mut c_int,
        ) -> c_int;
    }

    pub fn list_apps(file_path: &Path) -> Vec<OpenWithApp> {
        let Ok(c_path) = CString::new(file_path.to_string_lossy().as_bytes()) else {
            return Vec::new();
        };
        let mut buf: *mut u8 = null_mut();
        let mut len: c_int = 0;
        let ok = unsafe { mine_macos_list_open_with_apps(c_path.as_ptr(), &mut buf, &mut len) };
        if ok == 0 || buf.is_null() || len <= 0 {
            if !buf.is_null() {
                unsafe { mine_macos_free_buffer(buf) };
            }
            return Vec::new();
        }
        let bytes = unsafe { std::slice::from_raw_parts(buf, len as usize) };
        let tsv = String::from_utf8_lossy(bytes).into_owned();
        unsafe { mine_macos_free_buffer(buf) };
        parse_open_with_tsv(&tsv)
    }

    pub fn get_app_icon_rgba(app_path: &Path, size_px: u32) -> Option<(usize, usize, Vec<u8>)> {
        let c_path = CString::new(app_path.to_string_lossy().as_bytes()).ok()?;
        let mut buf: *mut u8 = null_mut();
        let mut w: c_int = 0;
        let mut h: c_int = 0;
        let ok = unsafe {
            mine_macos_get_app_icon_rgba(
                c_path.as_ptr(),
                size_px.clamp(16, 128) as c_int,
                &mut buf,
                &mut w,
                &mut h,
            )
        };
        if ok != 0 && !buf.is_null() && w > 0 && h > 0 {
            let len = (w as usize).saturating_mul(h as usize).saturating_mul(4);
            let vec = unsafe { std::slice::from_raw_parts(buf, len).to_vec() };
            unsafe { mine_macos_free_buffer(buf) };
            Some((w as usize, h as usize, vec))
        } else {
            if !buf.is_null() {
                unsafe { mine_macos_free_buffer(buf) };
            }
            None
        }
    }

    pub fn set_default_app(file_path: &Path, app_path: &Path) -> bool {
        let (Ok(cf), Ok(ca)) = (
            CString::new(file_path.to_string_lossy().as_bytes()),
            CString::new(app_path.to_string_lossy().as_bytes()),
        ) else {
            return false;
        };
        unsafe { mine_macos_set_default_app_for_file(cf.as_ptr(), ca.as_ptr()) != 0 }
    }

    pub fn choose_app_dialog(ext: &str, is_zh: bool) -> Option<(PathBuf, bool)> {
        let c_ext = CString::new(ext.as_bytes()).ok()?;
        let mut buf: *mut u8 = null_mut();
        let mut len: c_int = 0;
        let mut always: c_int = 0;
        let ok = unsafe {
            mine_macos_choose_app_dialog(
                c_ext.as_ptr(),
                i32::from(is_zh),
                &mut buf,
                &mut len,
                &mut always,
            )
        };
        if ok == 0 || buf.is_null() || len <= 0 {
            if !buf.is_null() {
                unsafe { mine_macos_free_buffer(buf) };
            }
            return None;
        }
        let bytes = unsafe { std::slice::from_raw_parts(buf, len as usize) };
        let path_str = String::from_utf8_lossy(bytes).into_owned();
        unsafe { mine_macos_free_buffer(buf) };
        Some((PathBuf::from(path_str), always != 0))
    }
}

// ============================================================================
// Windows Backend (Dynamic Win32 Shell / Registry — Zero Extra Crates)
// ============================================================================

#[cfg(target_os = "windows")]
mod win_open_with {
    use super::{app_display_name_from_path, normalized_ext, OpenWithApp};
    use std::ffi::{c_void, OsStr};
    use std::os::windows::ffi::OsStrExt;
    use std::path::{Path, PathBuf};
    use std::ptr::{null, null_mut};

    const HKEY_CLASSES_ROOT: usize = 0x8000_0000;
    const HKEY_CURRENT_USER: usize = 0x8000_0001;
    const KEY_READ: u32 = 0x20019;
    const ASSOCF_NONE: u32 = 0;
    const ASSOCSTR_EXECUTABLE: u32 = 2;
    const ASSOCSTR_FRIENDLYAPPNAME: u32 = 4;
    const OAIF_ALLOW_REGISTRATION: u32 = 0x0001;
    const OAIF_REGISTER_EXT: u32 = 0x0002;
    const OAIF_EXEC: u32 = 0x0004;

    #[repr(C)]
    struct OpenAsInfo {
        pcsz_file: *const u16,
        pcsz_class: *const u16,
        oaif_in_flags: u32,
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn LoadLibraryW(lp_lib_file_name: *const u16) -> *mut c_void;
        fn GetProcAddress(h_module: *mut c_void, lp_proc_name: *const u8) -> *mut c_void;
    }

    #[link(name = "advapi32")]
    extern "system" {
        fn RegOpenKeyExW(
            hkey: usize,
            sub_key: *const u16,
            options: u32,
            sam_desired: u32,
            phk_result: *mut usize,
        ) -> i32;
        fn RegCloseKey(hkey: usize) -> i32;
        fn RegEnumValueW(
            hkey: usize,
            index: u32,
            value_name: *mut u16,
            lpcch_value_name: *mut u32,
            reserved: *mut u32,
            lp_type: *mut u32,
            lp_data: *mut u8,
            lpcb_data: *mut u32,
        ) -> i32;
        fn RegQueryValueExW(
            hkey: usize,
            value_name: *const u16,
            reserved: *mut u32,
            lp_type: *mut u32,
            lp_data: *mut u8,
            lpcb_data: *mut u32,
        ) -> i32;
    }

    fn to_wide_z(s: &str) -> Vec<u16> {
        OsStr::new(s)
            .encode_wide()
            .chain(std::iter::once(0))
            .collect()
    }

    fn assoc_query_str(dot_ext: &str, assoc_str: u32) -> Option<String> {
        unsafe {
            let h = LoadLibraryW(to_wide_z("shlwapi.dll").as_ptr());
            if h.is_null() {
                return None;
            }
            let p = GetProcAddress(h, b"AssocQueryStringW\0".as_ptr());
            if p.is_null() {
                return None;
            }
            let func: unsafe extern "system" fn(
                u32,
                u32,
                *const u16,
                *const u16,
                *mut u16,
                *mut u32,
            ) -> i32 = std::mem::transmute(p);

            let ext_w = to_wide_z(dot_ext);
            let mut len: u32 = 0;
            let hr = func(
                ASSOCF_NONE,
                assoc_str,
                ext_w.as_ptr(),
                null(),
                null_mut(),
                &mut len,
            );
            if hr < 0 || len == 0 || len > 4096 {
                return None;
            }
            let mut buf = vec![0u16; len as usize];
            let hr2 = func(
                ASSOCF_NONE,
                assoc_str,
                ext_w.as_ptr(),
                null(),
                buf.as_mut_ptr(),
                &mut len,
            );
            if hr2 < 0 {
                return None;
            }
            let end = buf.iter().position(|&c| c == 0).unwrap_or(buf.len());
            let s = String::from_utf16_lossy(&buf[..end]).trim().to_string();
            if s.is_empty() {
                None
            } else {
                Some(s)
            }
        }
    }

    fn query_reg_default_string(root: usize, subkey: &str) -> Option<String> {
        unsafe {
            let mut hkey: usize = 0;
            if RegOpenKeyExW(root, to_wide_z(subkey).as_ptr(), 0, KEY_READ, &mut hkey) != 0 {
                return None;
            }
            let mut size: u32 = 0;
            let mut rtype: u32 = 0;
            let rc = RegQueryValueExW(hkey, null(), null_mut(), &mut rtype, null_mut(), &mut size);
            let res = if rc == 0 && size >= 2 && size <= 8192 {
                let mut bytes = vec![0u8; size as usize];
                if RegQueryValueExW(
                    hkey,
                    null(),
                    null_mut(),
                    &mut rtype,
                    bytes.as_mut_ptr(),
                    &mut size,
                ) == 0
                {
                    let u16s: Vec<u16> = bytes
                        .chunks_exact(2)
                        .map(|c| u16::from_le_bytes([c[0], c[1]]))
                        .collect();
                    let end = u16s.iter().position(|&c| c == 0).unwrap_or(u16s.len());
                    let s = String::from_utf16_lossy(&u16s[..end]).trim().to_string();
                    if s.is_empty() {
                        None
                    } else {
                        Some(s)
                    }
                } else {
                    None
                }
            } else {
                None
            };
            RegCloseKey(hkey);
            res
        }
    }

    fn extract_exe_from_command(cmd: &str) -> Option<PathBuf> {
        let trimmed = cmd.trim();
        if trimmed.is_empty() {
            return None;
        }
        let exe_part = if let Some(rest) = trimmed.strip_prefix('"') {
            rest.split('"').next().unwrap_or("")
        } else {
            trimmed.split_whitespace().next().unwrap_or("")
        };
        if exe_part.is_empty() {
            return None;
        }
        let expanded = if exe_part.contains('%') {
            // Expand common %SystemRoot%, %ProgramFiles%, %LOCALAPPDATA%
            let mut s = exe_part.to_string();
            for var in [
                "SystemRoot",
                "WINDIR",
                "ProgramFiles",
                "ProgramFiles(x86)",
                "LOCALAPPDATA",
                "APPDATA",
            ] {
                if let Ok(val) = std::env::var(var) {
                    let pat = format!("%{}%", var);
                    if let Some(idx) = s.to_ascii_lowercase().find(&pat.to_ascii_lowercase()) {
                        s.replace_range(idx..idx + pat.len(), &val);
                    }
                }
            }
            s
        } else {
            exe_part.to_string()
        };
        let p = PathBuf::from(expanded);
        if p.exists() {
            Some(p)
        } else {
            None
        }
    }

    fn enum_open_with_values(root: usize, subkey: &str) -> Vec<(String, String)> {
        let mut out = Vec::new();
        unsafe {
            let mut hkey: usize = 0;
            if RegOpenKeyExW(root, to_wide_z(subkey).as_ptr(), 0, KEY_READ, &mut hkey) != 0 {
                return out;
            }
            for idx in 0..64u32 {
                let mut name_buf = [0u16; 256];
                let mut name_len: u32 = name_buf.len() as u32;
                let mut data_buf = [0u8; 1024];
                let mut data_len: u32 = data_buf.len() as u32;
                let mut rtype: u32 = 0;
                let rc = RegEnumValueW(
                    hkey,
                    idx,
                    name_buf.as_mut_ptr(),
                    &mut name_len,
                    null_mut(),
                    &mut rtype,
                    data_buf.as_mut_ptr(),
                    &mut data_len,
                );
                if rc != 0 {
                    break;
                }
                let name = String::from_utf16_lossy(&name_buf[..name_len as usize]);
                let val = if rtype == 1 || rtype == 2 {
                    let u16s: Vec<u16> = data_buf[..data_len as usize]
                        .chunks_exact(2)
                        .map(|c| u16::from_le_bytes([c[0], c[1]]))
                        .collect();
                    let end = u16s.iter().position(|&c| c == 0).unwrap_or(u16s.len());
                    String::from_utf16_lossy(&u16s[..end])
                } else {
                    String::new()
                };
                out.push((name, val));
            }
            RegCloseKey(hkey);
        }
        out
    }

    pub fn list_apps(file_path: &Path) -> Vec<OpenWithApp> {
        let ext = normalized_ext(file_path);
        if ext.is_empty() {
            return Vec::new();
        }
        let dot_ext = format!(".{}", ext);
        let mut apps: Vec<OpenWithApp> = Vec::new();
        let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();

        // 1. OS default executable via shlwapi!AssocQueryStringW
        if let Some(def_exe) = assoc_query_str(&dot_ext, ASSOCSTR_EXECUTABLE) {
            let p = PathBuf::from(&def_exe);
            if p.exists() {
                let friendly = assoc_query_str(&dot_ext, ASSOCSTR_FRIENDLYAPPNAME)
                    .unwrap_or_else(|| app_display_name_from_path(&p));
                seen.insert(def_exe.to_ascii_lowercase());
                apps.push(OpenWithApp {
                    display_name: friendly,
                    app_path: p,
                    bundle_id: String::new(),
                    is_default: true,
                    icon_rgba: None,
                });
            }
        }

        // 2. Registered OpenWithProgids (HKCU & HKCR)
        let mut progids: Vec<String> = Vec::new();
        let hkcu_progids = format!(
            "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\{}\\OpenWithProgids",
            dot_ext
        );
        for (name, _) in enum_open_with_values(HKEY_CURRENT_USER, &hkcu_progids) {
            if !name.is_empty() {
                progids.push(name);
            }
        }
        let hkcr_progids = format!("{}\\OpenWithProgids", dot_ext);
        for (name, _) in enum_open_with_values(HKEY_CLASSES_ROOT, &hkcr_progids) {
            if !name.is_empty() {
                progids.push(name);
            }
        }
        for progid in progids {
            let cmd_key = format!("{}\\shell\\open\\command", progid);
            if let Some(cmd) = query_reg_default_string(HKEY_CLASSES_ROOT, &cmd_key) {
                if let Some(exe) = extract_exe_from_command(&cmd) {
                    let key = exe.to_string_lossy().to_ascii_lowercase();
                    if seen.insert(key) {
                        apps.push(OpenWithApp {
                            display_name: app_display_name_from_path(&exe),
                            app_path: exe,
                            bundle_id: progid,
                            is_default: false,
                            icon_rgba: None,
                        });
                    }
                }
            }
        }

        // 3. OpenWithList executables (HKCU FileExts)
        let hkcu_list = format!(
            "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\{}\\OpenWithList",
            dot_ext
        );
        for (name, exe_name) in enum_open_with_values(HKEY_CURRENT_USER, &hkcu_list) {
            if name.eq_ignore_ascii_case("MRUList") || exe_name.is_empty() {
                continue;
            }
            let app_cmd_key = format!("Applications\\{}\\shell\\open\\command", exe_name);
            if let Some(cmd) = query_reg_default_string(HKEY_CLASSES_ROOT, &app_cmd_key) {
                if let Some(exe) = extract_exe_from_command(&cmd) {
                    let key = exe.to_string_lossy().to_ascii_lowercase();
                    if seen.insert(key) {
                        apps.push(OpenWithApp {
                            display_name: app_display_name_from_path(&exe),
                            app_path: exe,
                            bundle_id: exe_name,
                            is_default: false,
                            icon_rgba: None,
                        });
                    }
                }
            }
        }

        apps.sort_by(|a, b| {
            b.is_default
                .cmp(&a.is_default)
                .then_with(|| a.display_name.to_lowercase().cmp(&b.display_name.to_lowercase()))
        });
        apps
    }

    pub fn show_native_open_with_dialog(file_path: &Path) {
        let wide_file = to_wide_z(&file_path.to_string_lossy());
        unsafe {
            let h_shell = LoadLibraryW(to_wide_z("shell32.dll").as_ptr());
            if !h_shell.is_null() {
                let p = GetProcAddress(h_shell, b"SHOpenWithDialog\0".as_ptr());
                if !p.is_null() {
                    let sh_open_with: unsafe extern "system" fn(
                        *mut c_void,
                        *const OpenAsInfo,
                    ) -> i32 = std::mem::transmute(p);
                    let info = OpenAsInfo {
                        pcsz_file: wide_file.as_ptr(),
                        pcsz_class: null(),
                        oaif_in_flags: OAIF_ALLOW_REGISTRATION | OAIF_REGISTER_EXT | OAIF_EXEC,
                    };
                    let _ = sh_open_with(null_mut(), &info);
                    return;
                }
            }
        }
        // Fallback: rundll32 shell32.dll,OpenAs_RunDLL <file>
        let _ = std::process::Command::new("rundll32.exe")
            .arg("shell32.dll,OpenAs_RunDLL")
            .arg(file_path)
            .spawn();
    }
}

// ============================================================================
// Linux Backend (xdg-mime + freedesktop .desktop entries)
// ============================================================================

#[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
mod linux_open_with {
    use super::OpenWithApp;
    use std::path::{Path, PathBuf};

    fn query_mime_type(file_path: &Path) -> Option<String> {
        let out = std::process::Command::new("xdg-mime")
            .arg("query")
            .arg("filetype")
            .arg(file_path)
            .output()
            .ok()?;
        if !out.status.success() {
            return None;
        }
        let mime = String::from_utf8_lossy(&out.stdout).trim().to_string();
        if mime.is_empty() {
            None
        } else {
            Some(mime)
        }
    }

    pub fn list_apps(file_path: &Path) -> Vec<OpenWithApp> {
        let Some(mime) = query_mime_type(file_path) else {
            return Vec::new();
        };
        let default_desktop = std::process::Command::new("xdg-mime")
            .args(["query", "default", &mime])
            .output()
            .ok()
            .filter(|o| o.status.success())
            .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
            .unwrap_or_default();

        let mut dirs_to_scan = vec![PathBuf::from("/usr/share/applications")];
        if let Some(home) = dirs::home_dir() {
            dirs_to_scan.push(home.join(".local/share/applications"));
        }

        let mut apps = Vec::new();
        let mut seen = std::collections::HashSet::new();
        for dir in dirs_to_scan {
            let Ok(rd) = std::fs::read_dir(&dir) else {
                continue;
            };
            for ent in rd.flatten() {
                let p = ent.path();
                if p.extension().and_then(|e| e.to_str()) != Some("desktop") {
                    continue;
                }
                let desktop_id = ent.file_name().to_string_lossy().into_owned();
                if !seen.insert(desktop_id.clone()) {
                    continue;
                }
                let Ok(content) = std::fs::read_to_string(&p) else {
                    continue;
                };
                let mut name = String::new();
                let mut exec = String::new();
                let mut supports_mime = false;
                for line in content.lines() {
                    if let Some(v) = line.strip_prefix("Name=") {
                        if name.is_empty() {
                            name = v.trim().to_string();
                        }
                    } else if let Some(v) = line.strip_prefix("Exec=") {
                        if exec.is_empty() {
                            exec = v
                                .split_whitespace()
                                .next()
                                .unwrap_or("")
                                .trim_matches('"')
                                .to_string();
                        }
                    } else if let Some(v) = line.strip_prefix("MimeType=") {
                        if v.split(';').any(|m| m.trim() == mime) {
                            supports_mime = true;
                        }
                    }
                }
                if supports_mime && !name.is_empty() && !exec.is_empty() {
                    let is_default = !default_desktop.is_empty() && desktop_id == default_desktop;
                    apps.push(OpenWithApp {
                        display_name: name,
                        app_path: PathBuf::from(exec),
                        bundle_id: desktop_id,
                        is_default,
                        icon_rgba: None,
                    });
                }
            }
        }
        apps.sort_by(|a, b| {
            b.is_default
                .cmp(&a.is_default)
                .then_with(|| a.display_name.to_lowercase().cmp(&b.display_name.to_lowercase()))
        });
        apps
    }

    pub fn set_default_app(file_path: &Path, app_path: &Path) -> Result<bool, String> {
        let Some(mime) = query_mime_type(file_path) else {
            return Ok(false);
        };
        let app_str = app_path.to_string_lossy();
        if app_str.ends_with(".desktop") {
            let st = std::process::Command::new("xdg-mime")
                .args(["default", &app_str, &mime])
                .status()
                .map_err(|e| e.to_string())?;
            return Ok(st.success());
        }
        Ok(false)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_open_with_tsv_sorts_default_first_and_dedups() {
        let tsv = "\
0\tSafari\tcom.apple.Safari\t/Applications/Safari.app
1\tXnViewMP\tcom.xnview.XnViewMP\t/Applications/XnViewMP.app
0\tBrave Browser\tcom.brave.Browser\t/Applications/Brave Browser.app
0\tDuplicate Safari\tcom.apple.Safari\t/Applications/Safari.app
";
        let apps = parse_open_with_tsv(tsv);
        assert_eq!(apps.len(), 3);
        assert_eq!(apps[0].display_name, "XnViewMP");
        assert!(apps[0].is_default);
        assert_eq!(apps[1].display_name, "Brave Browser");
        assert_eq!(apps[2].display_name, "Safari");
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn test_macos_list_open_with_apps_returns_default_and_icons() {
        let tmp = std::env::temp_dir().join(format!("mine_open_with_test_{}.txt", std::process::id()));
        std::fs::write(&tmp, "hello mine open-with").expect("write temp txt");

        let apps = list_open_with_apps(&tmp, None, true);
        let _ = std::fs::remove_file(&tmp);

        assert!(!apps.is_empty(), "macOS should report at least one app for .txt");
        assert!(apps[0].is_default, "first entry should be the default app");
        assert!(apps[0].app_path.exists(), "default app path should exist");
        let icon = apps[0].icon_rgba.as_ref().expect("macOS app should provide RGBA icon");
        assert_eq!(icon.0, 28);
        assert_eq!(icon.1, 28);
        assert_eq!(icon.2.len(), 28 * 28 * 4);
    }
}
