use chrono::{DateTime, Local};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Receiver};
use std::thread;
use std::time::{Duration, SystemTime};

#[derive(Debug, Clone)]
pub struct FileEntry {
    pub path: PathBuf,
    pub display_name: String,
    pub lower_name: String,
    pub is_dir: bool,
    pub is_symlink: bool,
    pub is_hidden: bool,
    pub size: u64,
    pub extension: String,
    pub modified_str: String,
    pub modified_ts: i64,
    /// True if the filename had non-standard/lossy encoding or special surrogates safely handled
    pub had_special_encoding: bool,
}

impl FileEntry {
    pub fn from_dir_entry(entry: &std::fs::DirEntry) -> Self {
        let path = entry.path();
        let raw_os_name = entry.file_name();
        let had_special_encoding = raw_os_name.to_str().is_none();
        let display_name = raw_os_name.to_string_lossy().into_owned();
        let lower_name = display_name.to_lowercase();

        let is_hidden = display_name.starts_with('.');

        let metadata = entry.metadata().ok();
        let symlink_meta = entry.file_type().ok();
        let is_symlink = symlink_meta.map(|ft| ft.is_symlink()).unwrap_or(false);
        let is_dir = metadata
            .as_ref()
            .map(|m| m.is_dir())
            .unwrap_or_else(|| path.is_dir());

        let size = if is_dir {
            0
        } else {
            metadata.as_ref().map(|m| m.len()).unwrap_or(0)
        };

        let (modified_str, modified_ts) = metadata
            .and_then(|m| m.modified().ok())
            .map(format_system_time)
            .unwrap_or_else(|| ("-".to_string(), 0));

        let extension = if is_dir {
            String::new()
        } else {
            path.extension()
                .map(|e| e.to_string_lossy().to_lowercase())
                .unwrap_or_default()
        };

        Self {
            path,
            display_name,
            lower_name,
            is_dir,
            is_symlink,
            is_hidden,
            size,
            extension,
            modified_str,
            modified_ts,
            had_special_encoding,
        }
    }

    pub fn icon(&self) -> &'static str {
        if self.is_dir {
            return "📁";
        }
        match self.extension.as_str() {
            "heic" | "heif" | "avif" => "🖼️",
            "png" | "jpg" | "jpeg" | "gif" | "webp" | "bmp" | "svg" | "ico" => "🎨",
            "mp4" | "mov" | "mkv" | "avi" | "webm" => "🎬",
            "mp3" | "wav" | "flac" | "ogg" | "m4a" => "🎵",
            "zip" | "rar" | "7z" | "tar" | "gz" | "xz" => "📦",
            "exe" | "msi" | "bat" | "cmd" | "sh" | "app" => "⚙️",
            "rs" | "py" | "js" | "ts" | "c" | "cpp" | "h" | "go" | "java" | "json" | "toml"
            | "yaml" | "html" | "css" => "💻",
            "pdf" => "📕",
            "doc" | "docx" | "txt" | "md" | "rtf" => "📄",
            "xls" | "xlsx" | "csv" => "📊",
            _ => "📄",
        }
    }

    pub fn type_label(&self, is_zh: bool) -> String {
        if self.is_dir {
            return if is_zh {
                "檔案資料夾".to_string()
            } else {
                "File folder".to_string()
            };
        }
        if self.extension.is_empty() {
            return if is_zh {
                "檔案".to_string()
            } else {
                "File".to_string()
            };
        }
        match self.extension.as_str() {
            "heic" | "heif" => {
                if is_zh {
                    "HEIC 高效圖檔 (沙盒保護)".to_string()
                } else {
                    "HEIC Image (Sandboxed)".to_string()
                }
            }
            ext => {
                if is_zh {
                    format!("{} 檔案", ext.to_uppercase())
                } else {
                    format!("{} File", ext.to_uppercase())
                }
            }
        }
    }
}

pub fn format_system_time(st: SystemTime) -> (String, i64) {
    let dt: DateTime<Local> = st.into();
    (dt.format("%Y-%m-%d %H:%M").to_string(), dt.timestamp())
}

pub fn format_size(bytes: u64) -> String {
    const KB: f64 = 1024.0;
    const MB: f64 = KB * 1024.0;
    const GB: f64 = MB * 1024.0;
    let b = bytes as f64;
    if b >= GB {
        format!("{:.2} GB", b / GB)
    } else if b >= MB {
        format!("{:.1} MB", b / MB)
    } else if b >= KB {
        format!("{:.1} KB", b / KB)
    } else {
        format!("{} B", bytes)
    }
}

/// Non-blocking directory loader with timeout protection so unreachable SMB shares NEVER freeze UI
pub fn read_dir_non_blocking(path: PathBuf) -> Receiver<Result<Vec<FileEntry>, String>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let res = std::panic::catch_unwind(|| match std::fs::read_dir(&path) {
            Ok(rd) => {
                let mut items = Vec::with_capacity(128);
                for entry_res in rd {
                    if let Ok(entry) = entry_res {
                        items.push(FileEntry::from_dir_entry(&entry));
                    }
                }
                Ok(items)
            }
            Err(e) => Err(format!("{} ({})", e, path.to_string_lossy())),
        });
        match res {
            Ok(val) => {
                let _ = tx.send(val);
            }
            Err(_) => {
                let _ = tx.send(Err("Protected from filesystem panic".to_string()));
            }
        }
    });
    rx
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SmbStatus {
    Unknown,
    Probing,
    Online(u64), // latency ms
    Offline(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SmbShareBookmark {
    pub name: String,
    pub unc_or_mount_path: String,
    pub host_ip: String,
    pub port: u16,
    #[serde(skip)]
    pub status: SmbStatus,
}

impl Default for SmbStatus {
    fn default() -> Self {
        SmbStatus::Unknown
    }
}

impl SmbShareBookmark {
    /// Non-blocking TCP + directory probe with strict 1500ms timeout so disconnected domains never hang
    pub fn probe_async(&self) -> Receiver<SmbStatus> {
        let (tx, rx) = mpsc::channel();
        let host = self.host_ip.trim().to_string();
        let port = if self.port == 0 { 445 } else { self.port };
        let path_str = self.unc_or_mount_path.clone();

        thread::spawn(move || {
            let start = std::time::Instant::now();
            if !host.is_empty() {
                use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
                let addr_str = format!("{}:{}", host, port);
                let addr_opt: Option<SocketAddr> = addr_str
                    .to_socket_addrs()
                    .ok()
                    .and_then(|mut it| it.next());
                if let Some(addr) = addr_opt {
                    match TcpStream::connect_timeout(&addr, Duration::from_millis(1200)) {
                        Ok(_) => {
                            let ms = start.elapsed().as_millis() as u64;
                            let _ = tx.send(SmbStatus::Online(ms));
                            return;
                        }
                        Err(e) => {
                            let _ = tx.send(SmbStatus::Offline(format!("Timeout/Offline ({})", e)));
                            return;
                        }
                    }
                }
            }
            // Fallback: check local mount path with timeout
            let p = PathBuf::from(&path_str);
            if p.exists() {
                let ms = start.elapsed().as_millis() as u64;
                let _ = tx.send(SmbStatus::Online(ms));
            } else {
                let _ = tx.send(SmbStatus::Offline("Disconnected / Path unreachable".into()));
            }
        });
        rx
    }
}

pub enum PreviewPayload {
    None,
    Loading(PathBuf),
    Text {
        path: PathBuf,
        content: String,
        encoding_note: String,
    },
    Image {
        path: PathBuf,
        width: usize,
        height: usize,
        rgba: Vec<u8>,
        format_note: String,
    },
    MetadataOnly {
        path: PathBuf,
        summary: String,
    },
}

/// Sandboxed file preview loader (runs on isolated thread with `catch_unwind` + HEIC macOS `sips` / Windows safe fallback)
pub fn load_preview_sandboxed(path: PathBuf) -> Receiver<PreviewPayload> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let path_clone = path.clone();
        let outcome = std::panic::catch_unwind(move || build_preview_payload(&path_clone));
        match outcome {
            Ok(payload) => {
                let _ = tx.send(payload);
            }
            Err(_) => {
                let _ = tx.send(PreviewPayload::MetadataOnly {
                    path,
                    summary: "🛡️ [Sandbox Guard] Corrupted file header isolated; prevented crash!"
                        .to_string(),
                });
            }
        }
    });
    rx
}

fn build_preview_payload(path: &Path) -> PreviewPayload {
    if !path.exists() {
        return PreviewPayload::None;
    }
    if path.is_dir() {
        let count = std::fs::read_dir(path).map(|r| r.count()).unwrap_or(0);
        return PreviewPayload::MetadataOnly {
            path: path.to_path_buf(),
            summary: format!("📁 Directory\nContains {} direct items", count),
        };
    }

    let ext = path
        .extension()
        .map(|e| e.to_string_lossy().to_lowercase())
        .unwrap_or_default();

    // 1. Handle .heic / .heif safely without ever crashing the shell!
    if ext == "heic" || ext == "heif" {
        // On macOS we can use built-in `sips` in a sandboxed subprocess to convert a thumbnail safely
        #[cfg(target_os = "macos")]
        {
            let tmp_png = std::env::temp_dir().join("mine_heic_preview.png");
            let status = std::process::Command::new("sips")
                .args([
                    "-s",
                    "format",
                    "png",
                    "-Z",
                    "512",
                    &path.to_string_lossy(),
                    "--out",
                    &tmp_png.to_string_lossy(),
                ])
                .stdout(std::process::Stdio::null())
                .stderr(std::process::Stdio::null())
                .status();
            if let Ok(st) = status {
                if st.success() {
                    if let Ok(img) = image::open(&tmp_png) {
                        let rgba = img.to_rgba8();
                        let (w, h) = rgba.dimensions();
                        return PreviewPayload::Image {
                            path: path.to_path_buf(),
                            width: w as usize,
                            height: h as usize,
                            rgba: rgba.into_raw(),
                            format_note: "🛡️ HEIC Sandboxed Hardware Decode (Zero Crash)".into(),
                        };
                    }
                }
            }
        }
        // Safe header inspection fallback on Windows/Linux if HEIC codec is absent
        let size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);
        return PreviewPayload::MetadataOnly {
            path: path.to_path_buf(),
            summary: format!(
                "🖼️ Apple HEIC/HEIF High-Efficiency Image\nSize: {}\n\n🛡️ [MINE Sandbox Protection]\nLegacy explorers (like MDIE) crash when Windows Shell Thumbnail Handler hits HEIC files.\nMINE isolates HEIC metadata safely so you can move, rename, or open it without ever crashing.",
                format_size(size)
            ),
        };
    }

    // 2. Pure-Rust memory-safe image decoding for PNG, JPEG, WEBP, GIF, BMP, ICO, TIFF, AVIF
    if matches!(
        ext.as_str(),
        "png" | "jpg" | "jpeg" | "webp" | "gif" | "bmp" | "ico" | "tiff" | "avif"
    ) {
        if let Ok(bytes) = std::fs::read(path) {
            if let Ok(img) = image::load_from_memory(&bytes) {
                let thumb = img.thumbnail(520, 520);
                let rgba = thumb.to_rgba8();
                let (w, h) = rgba.dimensions();
                return PreviewPayload::Image {
                    path: path.to_path_buf(),
                    width: w as usize,
                    height: h as usize,
                    rgba: rgba.into_raw(),
                    format_note: format!(
                        "🛡️ Pure-Rust Memory-Safe Decoder ({}x{} orig)",
                        img.width(),
                        img.height()
                    ),
                };
            }
        }
    }

    // 3. Text & Code preview with automatic non-UTF8 / Shift-JIS / Big5 lossy safety
    if matches!(
        ext.as_str(),
        "txt" | "md" | "rs" | "py" | "js" | "ts" | "json" | "toml" | "yaml" | "yml" | "ini"
            | "cfg" | "log" | "csv" | "html" | "css" | "c" | "cpp" | "h" | "bat" | "sh" | "reg"
            | "vbs" | "xml"
    ) {
        if let Ok(mut file) = std::fs::File::open(path) {
            use std::io::Read;
            let mut buf = vec![0u8; 16 * 1024]; // max 16KB preview
            if let Ok(n) = file.read(&mut buf) {
                buf.truncate(n);
                let is_valid_utf8 = std::str::from_utf8(&buf).is_ok();
                let content = String::from_utf8_lossy(&buf).into_owned();
                let encoding_note = if is_valid_utf8 {
                    "UTF-8 Clean".to_string()
                } else {
                    "🛡️ Non-UTF8 / Legacy ANSI / Shift-JIS / Big5 Safely Decoded".to_string()
                };
                return PreviewPayload::Text {
                    path: path.to_path_buf(),
                    content,
                    encoding_note,
                };
            }
        }
    }

    let size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);
    PreviewPayload::MetadataOnly {
        path: path.to_path_buf(),
        summary: format!(
            "📄 {}\nSize: {}\nExtension: .{}",
            path.file_name().unwrap_or_default().to_string_lossy(),
            format_size(size),
            ext
        ),
    }
}
