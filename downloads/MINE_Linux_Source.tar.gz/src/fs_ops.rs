use chrono::{DateTime, Local};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Receiver};
use std::thread;
use std::time::{Duration, SystemTime};

pub const THIS_PC_PATH: &str = "mine://this-pc";

pub fn is_this_pc_path(path: &Path) -> bool {
    path.to_str() == Some(THIS_PC_PATH)
}

#[derive(Debug, Clone)]
pub struct FileEntry {
    pub path: PathBuf,
    pub display_name: String,
    pub lower_name: String,
    pub is_dir: bool,
    pub is_symlink: bool,
    pub is_hidden: bool,
    pub size: u64,
    pub extension: String,
    pub modified_str: String,
    pub modified_ts: i64,
    /// True if the filename had non-standard/lossy encoding or special surrogates safely handled
    pub had_special_encoding: bool,
}

impl FileEntry {
    pub fn from_dir_entry(entry: &std::fs::DirEntry) -> Self {
        let path = entry.path();
        let raw_os_name = entry.file_name();
        let had_special_encoding = raw_os_name.to_str().is_none();
        let display_name = raw_os_name.to_string_lossy().into_owned();
        let lower_name = display_name.to_lowercase();

        let is_hidden = display_name.starts_with('.');

        let symlink_meta = entry.file_type().ok();
        let is_symlink = symlink_meta.as_ref().map(|ft| ft.is_symlink()).unwrap_or(false);
        let metadata = if is_symlink {
            None
        } else {
            entry.metadata().ok()
        };
        let is_dir = symlink_meta
            .as_ref()
            .map(|ft| ft.is_dir())
            .or_else(|| metadata.as_ref().map(|m| m.is_dir()))
            .unwrap_or(false);

        let size = if is_dir {
            0
        } else {
            metadata.as_ref().map(|m| m.len()).unwrap_or(0)
        };

        let (modified_str, modified_ts) = metadata
            .and_then(|m| m.modified().ok())
            .map(format_system_time)
            .unwrap_or_else(|| ("-".to_string(), 0));

        let extension = if is_dir {
            String::new()
        } else {
            path.extension()
                .map(|e| e.to_string_lossy().to_lowercase())
                .unwrap_or_default()
        };

        Self {
            path,
            display_name,
            lower_name,
            is_dir,
            is_symlink,
            is_hidden,
            size,
            extension,
            modified_str,
            modified_ts,
            had_special_encoding,
        }
    }

    pub fn icon(&self) -> &'static str {
        if self.is_dir {
            return "📁";
        }
        match self.extension.as_str() {
            "heic" | "heif" | "avif" => "🖼",
            "png" | "jpg" | "jpeg" | "gif" | "webp" | "bmp" | "svg" | "ico" => "🎨",
            "mp4" | "mov" | "mkv" | "avi" | "webm" => "🎬",
            "mp3" | "wav" | "flac" | "ogg" | "m4a" => "🎵",
            "zip" | "rar" | "7z" | "tar" | "gz" | "xz" => "📦",
            "exe" | "msi" | "bat" | "cmd" | "sh" | "app" => "⚙",
            "rs" | "py" | "js" | "ts" | "c" | "cpp" | "h" | "go" | "java" | "json" | "toml"
            | "yaml" | "html" | "css" => "💻",
            "pdf" => "📕",
            "doc" | "docx" | "txt" | "md" | "rtf" => "📄",
            "xls" | "xlsx" | "csv" => "📊",
            _ => "📄",
        }
    }

    pub fn type_label(&self, is_zh: bool) -> String {
        if self.is_dir {
            return if is_zh {
                "檔案資料夾".to_string()
            } else {
                "File folder".to_string()
            };
        }
        if self.extension.is_empty() {
            return if is_zh {
                "檔案".to_string()
            } else {
                "File".to_string()
            };
        }
        match self.extension.as_str() {
            "heic" | "heif" => {
                if is_zh {
                    "HEIC 高效圖檔 (沙盒保護)".to_string()
                } else {
                    "HEIC Image (Sandboxed)".to_string()
                }
            }
            ext => {
                if is_zh {
                    format!("{} 檔案", ext.to_uppercase())
                } else {
                    format!("{} File", ext.to_uppercase())
                }
            }
        }
    }
}

pub fn format_system_time(st: SystemTime) -> (String, i64) {
    let dt: DateTime<Local> = st.into();
    (dt.format("%Y-%m-%d %H:%M").to_string(), dt.timestamp())
}

pub fn format_size(bytes: u64) -> String {
    const KB: f64 = 1024.0;
    const MB: f64 = KB * 1024.0;
    const GB: f64 = MB * 1024.0;
    let b = bytes as f64;
    if b >= GB {
        format!("{:.2} GB", b / GB)
    } else if b >= MB {
        format!("{:.1} MB", b / MB)
    } else if b >= KB {
        format!("{:.1} KB", b / KB)
    } else {
        format!("{} B", bytes)
    }
}

#[cfg(target_os = "windows")]
pub mod win_fs {
    use super::*;
    use std::ffi::OsString;
    use std::os::windows::ffi::{OsStrExt, OsStringExt};
    use std::path::Path;

    #[repr(C)]
    #[derive(Copy, Clone)]
    #[allow(non_snake_case)]
    pub struct FILETIME {
        pub dwLowDateTime: u32,
        pub dwHighDateTime: u32,
    }

    #[repr(C)]
    #[allow(non_snake_case)]
    pub struct WIN32_FIND_DATAW {
        pub dwFileAttributes: u32,
        pub ftCreationTime: FILETIME,
        pub ftLastAccessTime: FILETIME,
        pub ftLastWriteTime: FILETIME,
        pub nFileSizeHigh: u32,
        pub nFileSizeLow: u32,
        pub dwReserved0: u32,
        pub dwReserved1: u32,
        pub cFileName: [u16; 260],
        pub cAlternateFileName: [u16; 14],
    }

    pub type HANDLE = *mut std::ffi::c_void;

    extern "system" {
        pub fn FindFirstFileExW(
            lpFileName: *const u16,
            fInfoLevelId: i32,
            lpFindFileData: *mut WIN32_FIND_DATAW,
            fSearchOp: i32,
            lpSearchFilter: *mut std::ffi::c_void,
            dwAdditionalFlags: u32,
        ) -> HANDLE;

        pub fn FindNextFileW(hFindFile: HANDLE, lpFindFileData: *mut WIN32_FIND_DATAW) -> i32;

        pub fn FindClose(hFindFile: HANDLE) -> i32;
    }

    const INVALID_HANDLE_VALUE: HANDLE = -1isize as HANDLE;
    const FIND_FIRST_EX_LARGE_FETCH: u32 = 0x00000002;
    const FILE_ATTRIBUTE_DIRECTORY: u32 = 0x00000010;
    const FILE_ATTRIBUTE_HIDDEN: u32 = 0x00000002;
    const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x00000400;

    /// Native Windows Win32 directory enumeration using FindFirstFileExW with FIND_FIRST_EX_LARGE_FETCH.
    /// Obtains file attributes, file size (high/low), and modified FILETIME directly from the stream buffer
    /// in memory — exactly like MDIE and Windows File Explorer, with ZERO extra network round-trips!
    pub fn read_dir_fast_win32(path: &Path) -> Result<Vec<FileEntry>, String> {
        let mut path_str = path.to_string_lossy().into_owned();
        path_str = path_str.replace('/', "\\");
        while path_str.ends_with('\\') && path_str.len() > 3 {
            path_str.pop();
        }
        if !path_str.ends_with('\\') {
            path_str.push('\\');
        }
        let search_pattern = format!("{}*", path_str);

        // Try standard path and extended \\?\ path
        let wide_patterns = vec![
            search_pattern.clone(),
            if search_pattern.starts_with(r"\\?\") {
                search_pattern.clone()
            } else if search_pattern.starts_with(r"\\") {
                format!(r"\\?\UNC\{}", &search_pattern[2..])
            } else if search_pattern.len() >= 2 && search_pattern.as_bytes()[1] == b':' {
                format!(r"\\?\{}", search_pattern)
            } else {
                search_pattern.clone()
            },
        ];

        let mut handle = INVALID_HANDLE_VALUE;
        let mut find_data: WIN32_FIND_DATAW = unsafe { std::mem::zeroed() };

        for pattern in &wide_patterns {
            let wide: Vec<u16> = std::ffi::OsStr::new(pattern)
                .encode_wide()
                .chain(std::iter::once(0))
                .collect();

            handle = unsafe {
                FindFirstFileExW(
                    wide.as_ptr(),
                    1, // FindExInfoBasic (skip 8.3 short name for 3x speed)
                    &mut find_data,
                    0, // FindExSearchNameMatch
                    std::ptr::null_mut(),
                    FIND_FIRST_EX_LARGE_FETCH, // 2 (large buffer batching across network/NTFS)
                )
            };

            if handle != INVALID_HANDLE_VALUE {
                break;
            }
        }

        if handle == INVALID_HANDLE_VALUE {
            let err = std::io::Error::last_os_error();
            return Err(format!("{} ({})", err, path.to_string_lossy()));
        }

        let mut items = Vec::with_capacity(2048);
        let base_path = path.to_path_buf();

        loop {
            let name_len = find_data
                .cFileName
                .iter()
                .position(|&c| c == 0)
                .unwrap_or(find_data.cFileName.len());

            if name_len > 0 {
                let slice = &find_data.cFileName[..name_len];
                // Skip "." and ".."
                if !(slice == [46] || slice == [46, 46]) {
                    let os_name = OsString::from_wide(slice);
                    let display_name = os_name.to_string_lossy().into_owned();
                    let lower_name = display_name.to_lowercase();
                    let is_dir = (find_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
                    let is_hidden = (find_data.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN) != 0
                        || display_name.starts_with('.');
                    let is_symlink = (find_data.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0;

                    let size = if is_dir {
                        0
                    } else {
                        ((find_data.nFileSizeHigh as u64) << 32) | (find_data.nFileSizeLow as u64)
                    };

                    let ft = ((find_data.ftLastWriteTime.dwHighDateTime as u64) << 32)
                        | (find_data.ftLastWriteTime.dwLowDateTime as u64);
                    let (modified_str, modified_ts) = if ft > 116_444_736_000_000_000 {
                        let unix_ns100 = ft - 116_444_736_000_000_000;
                        let secs = (unix_ns100 / 10_000_000) as i64;
                        let ts = secs;
                        let dt = chrono::DateTime::from_timestamp(secs, 0);
                        let s = match dt {
                            Some(d) => d
                                .with_timezone(&chrono::Local)
                                .format("%Y-%m-%d %H:%M")
                                .to_string(),
                            None => "-".to_string(),
                        };
                        (s, ts)
                    } else {
                        ("-".to_string(), 0i64)
                    };

                    let extension = if is_dir {
                        String::new()
                    } else {
                        std::path::Path::new(&display_name)
                            .extension()
                            .map(|e| e.to_string_lossy().to_lowercase())
                            .unwrap_or_default()
                    };

                    let full_path = base_path.join(&os_name);

                    items.push(FileEntry {
                        path: full_path,
                        display_name,
                        lower_name,
                        is_dir,
                        is_symlink,
                        is_hidden,
                        size,
                        extension,
                        modified_str,
                        modified_ts,
                        had_special_encoding: false,
                    });
                }
            }

            if unsafe { FindNextFileW(handle, &mut find_data) } == 0 {
                break;
            }
        }

        unsafe { FindClose(handle) };
        Ok(items)
    }
}

/// Non-blocking directory loader with native fast stream API for instant loading of 10,000+ files
pub fn read_dir_non_blocking(path: PathBuf) -> Receiver<Result<Vec<FileEntry>, String>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        #[cfg(target_os = "windows")]
        {
            let res = std::panic::catch_unwind(|| win_fs::read_dir_fast_win32(&path));
            match res {
                Ok(Ok(items)) => {
                    let _ = tx.send(Ok(items));
                    return;
                }
                Ok(Err(_err)) => {
                    // Fallback to std::fs::read_dir in case win32 had permission error or special virtual path
                }
                Err(_) => {}
            }
        }

        let res = std::panic::catch_unwind(|| match std::fs::read_dir(&path) {
            Ok(rd) => {
                let mut items = Vec::with_capacity(1024);
                for entry_res in rd {
                    if let Ok(entry) = entry_res {
                        items.push(FileEntry::from_dir_entry(&entry));
                    }
                }
                Ok(items)
            }
            Err(e) => Err(format!("{} ({})", e, path.to_string_lossy())),
        });
        match res {
            Ok(val) => {
                let _ = tx.send(val);
            }
            Err(_) => {
                let _ = tx.send(Err("Protected from filesystem panic".to_string()));
            }
        }
    });
    rx
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SmbStatus {
    Unknown,
    Probing,
    Online(u64), // latency ms
    Offline(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SmbShareBookmark {
    pub name: String,
    pub unc_or_mount_path: String,
    pub host_ip: String,
    pub port: u16,
    #[serde(skip)]
    pub status: SmbStatus,
}

impl Default for SmbStatus {
    fn default() -> Self {
        SmbStatus::Unknown
    }
}

impl SmbShareBookmark {
    /// Non-blocking TCP + directory probe with strict 800ms timeout so disconnected domains never hang
    pub fn probe_async(&self) -> Receiver<SmbStatus> {
        let (tx, rx) = mpsc::channel();
        let host = if !self.host_ip.trim().is_empty() {
            self.host_ip.trim().to_string()
        } else {
            extract_host_from_remote_path(&self.unc_or_mount_path)
        };
        let port = if self.port == 0 { 445 } else { self.port };
        let path_str = self.unc_or_mount_path.clone();

        thread::spawn(move || {
            let start = std::time::Instant::now();
            if !host.is_empty() {
                use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
                let addr_str = format!("{}:{}", host, port);
                // Resolve and connect with strict 800ms timeout
                let addr_opt: Option<SocketAddr> = addr_str
                    .to_socket_addrs()
                    .ok()
                    .and_then(|mut it| it.next());
                if let Some(addr) = addr_opt {
                    match TcpStream::connect_timeout(&addr, Duration::from_millis(800)) {
                        Ok(_) => {
                            let ms = start.elapsed().as_millis() as u64;
                            let _ = tx.send(SmbStatus::Online(ms));
                            return;
                        }
                        Err(e) => {
                            let _ = tx.send(SmbStatus::Offline(format!("無法連線 ({})", e)));
                            return;
                        }
                    }
                } else {
                    let _ = tx.send(SmbStatus::Offline(format!("找不到主機 ({})", host)));
                    return;
                }
            }
            // Never call blocking Path::exists() on Windows UNC paths (\\Server\Share)
            if path_str.starts_with("\\\\") || path_str.starts_with("//") {
                let _ = tx.send(SmbStatus::Offline("無法連線 (Disconnected)".into()));
                return;
            }
            let p = PathBuf::from(&path_str);
            if p.exists() {
                let ms = start.elapsed().as_millis() as u64;
                let _ = tx.send(SmbStatus::Online(ms));
            } else {
                let _ = tx.send(SmbStatus::Offline("路徑不存在或已中斷連線".into()));
            }
        });
        rx
    }
}

pub fn extract_host_from_remote_path(remote: &str) -> String {
    let s = remote.trim();
    if let Some(rest) = s.strip_prefix("\\\\").or_else(|| s.strip_prefix("//")) {
        let host_part = rest.split(['\\', '/']).next().unwrap_or("");
        // Strip user@ if present (e.g. //user@192.168.1.10/share)
        let host_clean = host_part.split('@').last().unwrap_or(host_part);
        // Strip :port if present
        return host_clean.split(':').next().unwrap_or(host_clean).to_string();
    }
    String::new()
}

/// Spawns a fast background thread (< 25ms) to discover OS remote folders from local Registry/config
pub fn spawn_remote_folders_discovery() -> Receiver<Vec<SmbShareBookmark>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let remotes = discover_system_remote_folders();
        let _ = tx.send(remotes);
    });
    rx
}

/// Spawns an isolated background thread to query disk capacity so offline network drives never stall UI or SMB discovery
pub fn spawn_disks_discovery() -> Receiver<Vec<(String, PathBuf, u64, u64)>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let mut disk_list = Vec::new();
        let disks = sysinfo::Disks::new_with_refreshed_list();
        for d in disks.list() {
            let mount = d.mount_point().to_path_buf();
            let name = d.name().to_string_lossy().into_owned();
            let label = if name.is_empty() {
                mount.to_string_lossy().into_owned()
            } else {
                format!("{} ({})", name, mount.to_string_lossy())
            };
            disk_list.push((label, mount, d.available_space(), d.total_space()));
        }
        let _ = tx.send(disk_list);
    });
    rx
}

/// Automatically discovers remote / network folders already configured in the OS File Explorer / Finder
/// (just like original MDIE), purely from fast local Registry/config without blocking on offline SMB drives.
pub fn discover_system_remote_folders() -> Vec<SmbShareBookmark> {
    let mut discovered: Vec<SmbShareBookmark> = Vec::new();
    let mut seen_paths = std::collections::HashSet::new();

    let mut add_share = |name: String, path: String, host: String| {
        let key = path.to_lowercase();
        if !path.is_empty() && !seen_paths.contains(&key) {
            seen_paths.insert(key);
            discovered.push(SmbShareBookmark {
                name,
                unc_or_mount_path: path,
                host_ip: host,
                port: 445,
                status: SmbStatus::Probing,
            });
        }
    };

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x08000000;

        // 1. Mapped Network Drives from HKCU\Network (e.g. Z: -> \\Server\Share)
        // IMPORTANT: Never call Path::exists("Z:\\") here, because Windows blocks 30-60s if Z: is offline!
        if let Ok(out) = std::process::Command::new("reg")
            .args(["query", "HKCU\\Network", "/s"])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
        {
            let text = String::from_utf8_lossy(&out.stdout);
            let mut current_drive = String::new();
            for line in text.lines() {
                let trimmed = line.trim();
                if let Some(drive_letter) = trimmed
                    .strip_prefix("HKEY_CURRENT_USER\\Network\\")
                    .or_else(|| trimmed.strip_prefix("HKCU\\Network\\"))
                {
                    current_drive = drive_letter.trim().to_uppercase();
                } else if trimmed.starts_with("RemotePath") {
                    if let Some(idx) = trimmed.find("REG_SZ") {
                        let remote_unc = trimmed[idx + 6..].trim().to_string();
                        if !remote_unc.is_empty() {
                            let host = extract_host_from_remote_path(&remote_unc);
                            let display_name = if !current_drive.is_empty() {
                                format!("🖧 {}: ({})", current_drive, remote_unc)
                            } else {
                                format!("🖧 {}", remote_unc)
                            };
                            add_share(display_name, remote_unc, host);
                        }
                    }
                }
            }
        }

        // 2. Windows Explorer "Network Shortcuts" (%APPDATA%\Microsoft\Windows\Network Shortcuts)
        if let Some(appdata) = dirs::data_dir() {
            let nethood = appdata.join("Microsoft\\Windows\\Network Shortcuts");
            if let Ok(rd) = std::fs::read_dir(&nethood) {
                for entry in rd.flatten() {
                    let p = entry.path();
                    let name = entry.file_name().to_string_lossy().into_owned();
                    if name.eq_ignore_ascii_case("desktop.ini") {
                        continue;
                    }
                    let is_dir_entry = entry.file_type().map(|ft| ft.is_dir()).unwrap_or(false);
                    let clean_name = name.strip_suffix(".lnk").unwrap_or(&name).to_string();
                    let lnk_candidate = if is_dir_entry {
                        p.join("target.lnk")
                    } else {
                        p.clone()
                    };
                    let mut extracted_unc = None;
                    if let Ok(bytes) = std::fs::read(&lnk_candidate) {
                        extracted_unc = extract_unc_from_lnk_bytes(&bytes);
                    }
                    if let Some(unc) = extracted_unc {
                        let host = extract_host_from_remote_path(&unc);
                        add_share(format!("🌐 {} ({})", clean_name, unc), unc, host);
                    } else if is_dir_entry {
                        add_share(
                            format!("🌐 {}", clean_name),
                            p.to_string_lossy().into_owned(),
                            String::new(),
                        );
                    }
                }
            }
        }

        // 3. Windows Explorer MountPoints2 (caches all \\Server\Share folders configured/visited in Explorer as ##Server#Share)
        if let Ok(out) = std::process::Command::new("reg")
            .args([
                "query",
                "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\MountPoints2",
            ])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
        {
            let text = String::from_utf8_lossy(&out.stdout);
            for line in text.lines() {
                let trimmed = line.trim();
                if let Some(pos) = trimmed.find("\\##") {
                    let raw_key = &trimmed[pos + 3..]; // after \##
                    let unc = format!("\\\\{}", raw_key.replace('#', "\\"));
                    let host = extract_host_from_remote_path(&unc);
                    let share_label = raw_key.replace('#', " / ");
                    add_share(format!("🌐 {}", share_label), unc, host);
                }
            }
        }

        // 4. Windows Explorer TypedPaths (any \\Server\Share typed in Explorer address bar)
        if let Ok(out) = std::process::Command::new("reg")
            .args([
                "query",
                "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\TypedPaths",
            ])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
        {
            let text = String::from_utf8_lossy(&out.stdout);
            for line in text.lines() {
                if let Some(idx) = line.find("REG_SZ") {
                    let val = line[idx + 6..].trim();
                    if val.starts_with("\\\\") && val.len() > 3 {
                        let host = extract_host_from_remote_path(val);
                        add_share(format!("🌐 {}", val), val.to_string(), host);
                    }
                }
            }
        }
    }

    #[cfg(target_os = "macos")]
    {
        // 1. Parse `/sbin/mount` for mounted network filesystems (smbfs, nfs, afpfs, webdav, cifs)
        if let Ok(out) = std::process::Command::new("/sbin/mount").output() {
            let text = String::from_utf8_lossy(&out.stdout);
            for line in text.lines() {
                let is_net = line.contains("(smbfs")
                    || line.contains("(nfs")
                    || line.contains("(afpfs")
                    || line.contains("(webdav")
                    || line.contains("(cifs");
                if let Some((remote_spec, rest)) = line.split_once(" on ") {
                    if let Some((mount_point, _flags)) = rest.split_once(" (") {
                        if is_net || mount_point.starts_with("/Volumes/") {
                            let host = extract_host_from_remote_path(remote_spec);
                            let folder_name = Path::new(mount_point)
                                .file_name()
                                .map(|n| n.to_string_lossy().into_owned())
                                .unwrap_or_else(|| mount_point.to_string());
                            let prefix = if is_net { "🌐" } else { "🖴" };
                            let label = if !host.is_empty() {
                                format!("{} {} ({})", prefix, folder_name, host)
                            } else {
                                format!("{} {}", prefix, folder_name)
                            };
                            add_share(label, mount_point.to_string(), host);
                        }
                    }
                }
            }
        }

        // 2. Scan `/Volumes` for any additional Finder mounted volumes (excluding root symlink)
        if let Ok(rd) = std::fs::read_dir("/Volumes") {
            for entry in rd.flatten() {
                let p = entry.path();
                // Skip `/` symlink ("Macintosh HD")
                if let Ok(canon) = std::fs::canonicalize(&p) {
                    if canon == Path::new("/") {
                        continue;
                    }
                }
                let name = entry.file_name().to_string_lossy().into_owned();
                if !name.starts_with('.') {
                    add_share(
                        format!("📂 {}", name),
                        p.to_string_lossy().into_owned(),
                        String::new(),
                    );
                }
            }
        }
    }

    #[cfg(target_os = "linux")]
    {
        if let Ok(mounts) = std::fs::read_to_string("/proc/mounts") {
            for line in mounts.lines() {
                let parts: Vec<&str> = line.split_whitespace().collect();
                if parts.len() >= 3 {
                    let src = parts[0];
                    let mnt = parts[1];
                    let fstype = parts[2];
                    if matches!(fstype, "cifs" | "smb3" | "smbfs" | "nfs" | "nfs4" | "fuse.sshfs") {
                        let host = extract_host_from_remote_path(src);
                        add_share(format!("🌐 {} ({})", mnt, src), mnt.to_string(), host);
                    }
                }
            }
        }
    }

    discovered
}

#[cfg(target_os = "windows")]
fn extract_unc_from_lnk_bytes(bytes: &[u8]) -> Option<String> {
    // 1. Check UTF-16LE `\\` (0x5C, 0x00, 0x5C, 0x00)
    let mut i = 0;
    while i + 8 < bytes.len() {
        if bytes[i] == b'\\'
            && bytes[i + 1] == 0
            && bytes[i + 2] == b'\\'
            && bytes[i + 3] == 0
        {
            let mut chars = Vec::new();
            let mut j = i;
            while j + 1 < bytes.len() {
                let u = u16::from_le_bytes([bytes[j], bytes[j + 1]]);
                if u == 0 || u < 32 {
                    break;
                }
                if let Some(ch) = char::from_u32(u as u32) {
                    chars.push(ch);
                } else {
                    break;
                }
                j += 2;
            }
            let s: String = chars.into_iter().collect();
            if s.len() > 4 && s[2..].contains('\\') && !s.contains("\\\\?\\") {
                return Some(s);
            }
        }
        i += 1;
    }
    // 2. Check ASCII `\\`
    for win in bytes.windows(2).enumerate() {
        let (idx, pair) = win;
        if pair == b"\\\\" {
            let s: String = bytes[idx..]
                .iter()
                .copied()
                .take_while(|&b| b >= 32 && b < 127)
                .map(|b| b as char)
                .collect();
            if s.len() > 4 && s[2..].contains('\\') && !s.contains("\\\\?\\") {
                return Some(s);
            }
        }
    }
    None
}


pub enum PreviewPayload {
    None,
    Loading(PathBuf),
    Text {
        path: PathBuf,
        content: String,
        encoding_note: String,
    },
    Image {
        path: PathBuf,
        width: usize,
        height: usize,
        rgba: Vec<u8>,
        format_note: String,
    },
    MetadataOnly {
        path: PathBuf,
        summary: String,
    },
}

/// Sandboxed file preview loader (runs on isolated thread with `catch_unwind` + HEIC macOS `sips` / Windows safe fallback)
pub fn load_preview_sandboxed(path: PathBuf) -> Receiver<PreviewPayload> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let path_clone = path.clone();
        let outcome = std::panic::catch_unwind(move || build_preview_payload(&path_clone));
        match outcome {
            Ok(payload) => {
                let _ = tx.send(payload);
            }
            Err(_) => {
                let _ = tx.send(PreviewPayload::MetadataOnly {
                    path,
                    summary: "🛡 [Sandbox Guard] Corrupted file header isolated; prevented crash!"
                        .to_string(),
                });
            }
        }
    });
    rx
}

fn build_preview_payload(path: &Path) -> PreviewPayload {
    if !path.exists() {
        return PreviewPayload::None;
    }
    if path.is_dir() {
        let count = std::fs::read_dir(path).map(|r| r.count()).unwrap_or(0);
        return PreviewPayload::MetadataOnly {
            path: path.to_path_buf(),
            summary: format!("📁 Directory\nContains {} direct items", count),
        };
    }

    let ext = path
        .extension()
        .map(|e| e.to_string_lossy().to_lowercase())
        .unwrap_or_default();

    // 1. Handle .heic / .heif safely without ever crashing the shell!
    if ext == "heic" || ext == "heif" {
        // On macOS we can use built-in `sips` in a sandboxed subprocess to convert a thumbnail safely
        #[cfg(target_os = "macos")]
        {
            let tmp_png = std::env::temp_dir().join("mine_heic_preview.png");
            let status = std::process::Command::new("sips")
                .args([
                    "-s",
                    "format",
                    "png",
                    "-Z",
                    "512",
                    &path.to_string_lossy(),
                    "--out",
                    &tmp_png.to_string_lossy(),
                ])
                .stdout(std::process::Stdio::null())
                .stderr(std::process::Stdio::null())
                .status();
            if let Ok(st) = status {
                if st.success() {
                    if let Ok(img) = image::open(&tmp_png) {
                        let rgba = img.to_rgba8();
                        let (w, h) = rgba.dimensions();
                        return PreviewPayload::Image {
                            path: path.to_path_buf(),
                            width: w as usize,
                            height: h as usize,
                            rgba: rgba.into_raw(),
                            format_note: "🛡 HEIC Sandboxed Hardware Decode (Zero Crash)".into(),
                        };
                    }
                }
            }
        }
        // Safe header inspection fallback on Windows/Linux if HEIC codec is absent
        let size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);
        return PreviewPayload::MetadataOnly {
            path: path.to_path_buf(),
            summary: format!(
                "🖼 Apple HEIC/HEIF High-Efficiency Image\nSize: {}\n\n🛡 [MINE Sandbox Protection]\nLegacy explorers (like MDIE) crash when Windows Shell Thumbnail Handler hits HEIC files.\nMINE isolates HEIC metadata safely so you can move, rename, or open it without ever crashing.",
                format_size(size)
            ),
        };
    }

    // 2. Pure-Rust memory-safe image decoding for PNG, JPEG, WEBP, GIF, BMP, ICO, TIFF, AVIF
    if matches!(
        ext.as_str(),
        "png" | "jpg" | "jpeg" | "webp" | "gif" | "bmp" | "ico" | "tiff" | "avif"
    ) {
        if let Ok(bytes) = std::fs::read(path) {
            if let Ok(img) = image::load_from_memory(&bytes) {
                let thumb = img.thumbnail(520, 520);
                let rgba = thumb.to_rgba8();
                let (w, h) = rgba.dimensions();
                return PreviewPayload::Image {
                    path: path.to_path_buf(),
                    width: w as usize,
                    height: h as usize,
                    rgba: rgba.into_raw(),
                    format_note: format!(
                        "🛡 Pure-Rust Memory-Safe Decoder ({}x{} orig)",
                        img.width(),
                        img.height()
                    ),
                };
            }
        }
    }

    // 3. Text & Code preview with automatic non-UTF8 / Shift-JIS / Big5 lossy safety
    if matches!(
        ext.as_str(),
        "txt" | "md" | "rs" | "py" | "js" | "ts" | "json" | "toml" | "yaml" | "yml" | "ini"
            | "cfg" | "log" | "csv" | "html" | "css" | "c" | "cpp" | "h" | "bat" | "sh" | "reg"
            | "vbs" | "xml"
    ) {
        if let Ok(mut file) = std::fs::File::open(path) {
            use std::io::Read;
            let mut buf = vec![0u8; 16 * 1024]; // max 16KB preview
            if let Ok(n) = file.read(&mut buf) {
                buf.truncate(n);
                let is_valid_utf8 = std::str::from_utf8(&buf).is_ok();
                let content = String::from_utf8_lossy(&buf).into_owned();
                let encoding_note = if is_valid_utf8 {
                    "UTF-8 Clean".to_string()
                } else {
                    "🛡 Non-UTF8 / Legacy ANSI / Shift-JIS / Big5 Safely Decoded".to_string()
                };
                return PreviewPayload::Text {
                    path: path.to_path_buf(),
                    content,
                    encoding_note,
                };
            }
        }
    }

    let size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);
    PreviewPayload::MetadataOnly {
        path: path.to_path_buf(),
        summary: format!(
            "📄 {}\nSize: {}\nExtension: .{}",
            path.file_name().unwrap_or_default().to_string_lossy(),
            format_size(size),
            ext
        ),
    }
}

/// Fast listing of subdirectories only (excluding files) for Sidebar Tree View.
/// Automatically filters out system junk ($RECYCLE.BIN, System Volume Information)
/// and sorts folders alphabetically (case-insensitive).
pub fn list_subdirectories_fast(path: &Path) -> Vec<(String, PathBuf)> {
    let mut dirs = Vec::new();
    if let Ok(rd) = std::fs::read_dir(path) {
        for entry_res in rd {
            if let Ok(entry) = entry_res {
                let file_type = entry.file_type();
                let is_dir = match file_type {
                    Ok(ft) => ft.is_dir(),
                    Err(_) => false,
                };
                if is_dir {
                    let os_name = entry.file_name();
                    let name = os_name.to_string_lossy().into_owned();
                    // Skip hidden system volume info or recycle bin on Windows drives
                    if name != "$RECYCLE.BIN"
                        && name != "System Volume Information"
                        && !name.starts_with('$')
                    {
                        dirs.push((name, entry.path()));
                    }
                }
            }
        }
    }
    // Case-insensitive natural alphabetical sort
    dirs.sort_by(|a, b| a.0.to_lowercase().cmp(&b.0.to_lowercase()));
    dirs
}

/// Opens the native OS Properties dialog on Windows (`ShellExecuteExW` with `"properties"`).
/// Returns `true` if the OS dialog was launched, `false` to fall back to the in-app Properties modal.
#[cfg(target_os = "windows")]
pub fn open_os_properties(path: &Path) -> bool {
    use std::ffi::OsStr;
    use std::os::windows::ffi::OsStrExt;
    use std::ptr::{null, null_mut};

    #[repr(C)]
    struct ShellExecuteInfoW {
        cb_size: u32,
        f_mask: u32,
        hwnd: *mut std::ffi::c_void,
        lp_verb: *const u16,
        lp_file: *const u16,
        lp_parameters: *const u16,
        lp_directory: *const u16,
        n_show: i32,
        h_inst_app: *mut std::ffi::c_void,
        lp_id_list: *mut std::ffi::c_void,
        lp_class: *const u16,
        hkey_class: *mut std::ffi::c_void,
        dw_hot_key: u32,
        h_icon_or_monitor: *mut std::ffi::c_void,
        h_process: *mut std::ffi::c_void,
    }

    #[link(name = "shell32")]
    extern "system" {
        fn ShellExecuteExW(pExecInfo: *mut ShellExecuteInfoW) -> i32;
    }

    const SEE_MASK_INVOKEIDLIST: u32 = 0x0000000C;
    const SW_SHOW: i32 = 5;

    let verb: Vec<u16> = OsStr::new("properties").encode_wide().chain(Some(0)).collect();
    let file: Vec<u16> = path.as_os_str().encode_wide().chain(Some(0)).collect();

    let mut sei = ShellExecuteInfoW {
        cb_size: std::mem::size_of::<ShellExecuteInfoW>() as u32,
        f_mask: SEE_MASK_INVOKEIDLIST,
        hwnd: null_mut(),
        lp_verb: verb.as_ptr(),
        lp_file: file.as_ptr(),
        lp_parameters: null(),
        lp_directory: null(),
        n_show: SW_SHOW,
        h_inst_app: null_mut(),
        lp_id_list: null_mut(),
        lp_class: null(),
        hkey_class: null_mut(),
        dw_hot_key: 0,
        h_icon_or_monitor: null_mut(),
        h_process: null_mut(),
    };

    unsafe { ShellExecuteExW(&mut sei) != 0 }
}

#[cfg(not(target_os = "windows"))]
pub fn open_os_properties(_path: &Path) -> bool {
    false
}

/// On macOS, opens Finder's native Get Info window for a file or folder.
#[cfg(target_os = "macos")]
pub fn open_macos_get_info(path: &Path) {
    let p_str = path.to_string_lossy().replace('"', "\\\"");
    let script = format!(
        "tell application \"Finder\" to open information window of (POSIX file \"{}\" as alias)",
        p_str
    );
    let _ = std::process::Command::new("osascript")
        .arg("-e")
        .arg(&script)
        .spawn();
}

#[cfg(not(target_os = "macos"))]
pub fn open_macos_get_info(_path: &Path) {}

#[derive(Debug, Clone)]
pub struct PropertiesStats {
    pub total_bytes: u64,
    pub file_count: u64,
    pub folder_count: u64,
    pub is_complete: bool,
}

/// Spawns a background thread to recursively compute total size, file count, and folder count
/// for the Properties modal without blocking the UI thread.
pub fn spawn_properties_stats(path: PathBuf) -> Receiver<PropertiesStats> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let mut total_bytes: u64 = 0;
        let mut file_count: u64 = 0;
        let mut folder_count: u64 = 0;

        if path.is_file() {
            if let Ok(meta) = std::fs::metadata(&path) {
                total_bytes = meta.len();
                file_count = 1;
            }
            let _ = tx.send(PropertiesStats {
                total_bytes,
                file_count,
                folder_count: 0,
                is_complete: true,
            });
            return;
        }

        let mut stack = vec![path];
        let mut steps = 0usize;
        while let Some(dir) = stack.pop() {
            if let Ok(rd) = std::fs::read_dir(&dir) {
                for entry in rd.flatten() {
                    if let Ok(ft) = entry.file_type() {
                        if ft.is_symlink() {
                            continue;
                        }
                        if ft.is_dir() {
                            folder_count += 1;
                            stack.push(entry.path());
                        } else if ft.is_file() {
                            file_count += 1;
                            if let Ok(m) = entry.metadata() {
                                total_bytes = total_bytes.saturating_add(m.len());
                            }
                        }
                    }
                    steps += 1;
                    if steps % 400 == 0 {
                        if tx
                            .send(PropertiesStats {
                                total_bytes,
                                file_count,
                                folder_count,
                                is_complete: false,
                            })
                            .is_err()
                        {
                            return;
                        }
                    }
                }
            }
        }

        let _ = tx.send(PropertiesStats {
            total_bytes,
            file_count,
            folder_count,
            is_complete: true,
        });
    });
    rx
}

/// Decodes and downscales an image file to RGBA8 bytes for fast grid thumbnail caching.
pub fn load_thumbnail_rgba(path: &Path, max_dim: u32) -> Option<(usize, usize, Vec<u8>)> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .map(|s| s.to_ascii_lowercase())?;
    match ext.as_str() {
        "png" | "jpg" | "jpeg" | "gif" | "bmp" | "webp" | "ico" | "tiff" | "tif" => {}
        _ => return None,
    }
    let meta = std::fs::metadata(path).ok()?;
    if meta.len() > 64 * 1024 * 1024 {
        return None;
    }
    let img = image::open(path).ok()?;
    let thumb = img.thumbnail(max_dim, max_dim);
    let rgba = thumb.to_rgba8();
    let (w, h) = rgba.dimensions();
    Some((w as usize, h as usize, rgba.into_raw()))
}

