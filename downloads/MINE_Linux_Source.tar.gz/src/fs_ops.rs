use chrono::{DateTime, Local};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Receiver};
use std::thread;
use std::time::{Duration, SystemTime};

pub const THIS_PC_PATH: &str = "mine://this-pc";

pub fn is_this_pc_path(path: &Path) -> bool {
    path.to_str() == Some(THIS_PC_PATH)
}

#[derive(Debug, Clone)]
pub struct FileEntry {
    pub path: PathBuf,
    pub display_name: String,
    pub lower_name: String,
    pub is_dir: bool,
    pub is_symlink: bool,
    pub is_hidden: bool,
    pub size: u64,
    pub extension: String,
    pub modified_str: String,
    pub modified_ts: i64,
    /// True if the filename had non-standard/lossy encoding or special surrogates safely handled
    pub had_special_encoding: bool,
}

impl FileEntry {
    pub fn from_dir_entry(entry: &std::fs::DirEntry) -> Self {
        let path = entry.path();
        let raw_os_name = entry.file_name();
        let had_special_encoding = raw_os_name.to_str().is_none();
        let display_name = raw_os_name.to_string_lossy().into_owned();
        let lower_name = display_name.to_lowercase();

        let is_hidden = display_name.starts_with('.');

        let symlink_meta = entry.file_type().ok();
        let is_symlink = symlink_meta.as_ref().map(|ft| ft.is_symlink()).unwrap_or(false);
        let metadata = if is_symlink {
            None
        } else {
            entry.metadata().ok()
        };
        let is_dir = symlink_meta
            .as_ref()
            .map(|ft| ft.is_dir())
            .or_else(|| metadata.as_ref().map(|m| m.is_dir()))
            .unwrap_or(false);

        let size = if is_dir {
            0
        } else {
            metadata.as_ref().map(|m| m.len()).unwrap_or(0)
        };

        let (modified_str, modified_ts) = metadata
            .and_then(|m| m.modified().ok())
            .map(format_system_time)
            .unwrap_or_else(|| ("-".to_string(), 0));

        let extension = if is_dir {
            String::new()
        } else {
            path.extension()
                .map(|e| e.to_string_lossy().to_lowercase())
                .unwrap_or_default()
        };

        Self {
            path,
            display_name,
            lower_name,
            is_dir,
            is_symlink,
            is_hidden,
            size,
            extension,
            modified_str,
            modified_ts,
            had_special_encoding,
        }
    }

    pub fn icon(&self) -> &'static str {
        if self.is_dir {
            return "📁";
        }
        match self.extension.as_str() {
            "heic" | "heif" | "avif" => "🖼",
            "png" | "jpg" | "jpeg" | "gif" | "webp" | "bmp" | "svg" | "ico" => "🎨",
            "mp4" | "mov" | "mkv" | "avi" | "webm" => "🎬",
            "mp3" | "wav" | "flac" | "ogg" | "m4a" => "🎵",
            "zip" | "rar" | "7z" | "tar" | "gz" | "xz" => "📦",
            "exe" | "msi" | "bat" | "cmd" | "sh" | "app" => "⚙",
            "rs" | "py" | "js" | "ts" | "c" | "cpp" | "h" | "go" | "java" | "json" | "toml"
            | "yaml" | "html" | "css" => "💻",
            "pdf" => "📕",
            "doc" | "docx" | "txt" | "md" | "rtf" => "📄",
            "xls" | "xlsx" | "csv" => "📊",
            _ => "📄",
        }
    }

    pub fn type_label(&self, is_zh: bool) -> String {
        if self.is_dir {
            return if is_zh {
                "檔案資料夾".to_string()
            } else {
                "File folder".to_string()
            };
        }
        if self.extension.is_empty() {
            return if is_zh {
                "檔案".to_string()
            } else {
                "File".to_string()
            };
        }
        match self.extension.as_str() {
            "heic" | "heif" => {
                if is_zh {
                    "HEIC 高效圖檔 (沙盒保護)".to_string()
                } else {
                    "HEIC Image (Sandboxed)".to_string()
                }
            }
            ext => {
                if is_zh {
                    format!("{} 檔案", ext.to_uppercase())
                } else {
                    format!("{} File", ext.to_uppercase())
                }
            }
        }
    }
}

pub fn format_system_time(st: SystemTime) -> (String, i64) {
    let dt: DateTime<Local> = st.into();
    (dt.format("%Y-%m-%d %H:%M").to_string(), dt.timestamp())
}

pub fn format_size(bytes: u64) -> String {
    const KB: f64 = 1024.0;
    const MB: f64 = KB * 1024.0;
    const GB: f64 = MB * 1024.0;
    let b = bytes as f64;
    if b >= GB {
        format!("{:.2} GB", b / GB)
    } else if b >= MB {
        format!("{:.1} MB", b / MB)
    } else if b >= KB {
        format!("{:.1} KB", b / KB)
    } else {
        format!("{} B", bytes)
    }
}

#[cfg(target_os = "windows")]
pub mod win_fs {
    use super::*;
    use std::ffi::OsString;
    use std::os::windows::ffi::{OsStrExt, OsStringExt};
    use std::path::Path;

    #[repr(C)]
    #[derive(Copy, Clone)]
    #[allow(non_snake_case)]
    pub struct FILETIME {
        pub dwLowDateTime: u32,
        pub dwHighDateTime: u32,
    }

    #[repr(C)]
    #[allow(non_snake_case)]
    pub struct WIN32_FIND_DATAW {
        pub dwFileAttributes: u32,
        pub ftCreationTime: FILETIME,
        pub ftLastAccessTime: FILETIME,
        pub ftLastWriteTime: FILETIME,
        pub nFileSizeHigh: u32,
        pub nFileSizeLow: u32,
        pub dwReserved0: u32,
        pub dwReserved1: u32,
        pub cFileName: [u16; 260],
        pub cAlternateFileName: [u16; 14],
    }

    pub type HANDLE = *mut std::ffi::c_void;

    extern "system" {
        pub fn FindFirstFileExW(
            lpFileName: *const u16,
            fInfoLevelId: i32,
            lpFindFileData: *mut WIN32_FIND_DATAW,
            fSearchOp: i32,
            lpSearchFilter: *mut std::ffi::c_void,
            dwAdditionalFlags: u32,
        ) -> HANDLE;

        pub fn FindNextFileW(hFindFile: HANDLE, lpFindFileData: *mut WIN32_FIND_DATAW) -> i32;

        pub fn FindClose(hFindFile: HANDLE) -> i32;
    }

    const INVALID_HANDLE_VALUE: HANDLE = -1isize as HANDLE;
    const FIND_FIRST_EX_LARGE_FETCH: u32 = 0x00000002;
    const FILE_ATTRIBUTE_DIRECTORY: u32 = 0x00000010;
    const FILE_ATTRIBUTE_HIDDEN: u32 = 0x00000002;
    const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x00000400;

    /// Native Windows Win32 directory enumeration using FindFirstFileExW with FIND_FIRST_EX_LARGE_FETCH.
    /// Obtains file attributes, file size (high/low), and modified FILETIME directly from the stream buffer
    /// in memory — exactly like MDIE and Windows File Explorer, with ZERO extra network round-trips!
    pub fn read_dir_fast_win32(path: &Path) -> Result<Vec<FileEntry>, String> {
        let mut path_str = path.to_string_lossy().into_owned();
        path_str = path_str.replace('/', "\\");
        while path_str.ends_with('\\') && path_str.len() > 3 {
            path_str.pop();
        }
        if !path_str.ends_with('\\') {
            path_str.push('\\');
        }
        let search_pattern = format!("{}*", path_str);

        // Try standard path and extended \\?\ path
        let wide_patterns = vec![
            search_pattern.clone(),
            if search_pattern.starts_with(r"\\?\") {
                search_pattern.clone()
            } else if search_pattern.starts_with(r"\\") {
                format!(r"\\?\UNC\{}", &search_pattern[2..])
            } else if search_pattern.len() >= 2 && search_pattern.as_bytes()[1] == b':' {
                format!(r"\\?\{}", search_pattern)
            } else {
                search_pattern.clone()
            },
        ];

        let mut handle = INVALID_HANDLE_VALUE;
        let mut find_data: WIN32_FIND_DATAW = unsafe { std::mem::zeroed() };

        for pattern in &wide_patterns {
            let wide: Vec<u16> = std::ffi::OsStr::new(pattern)
                .encode_wide()
                .chain(std::iter::once(0))
                .collect();

            handle = unsafe {
                FindFirstFileExW(
                    wide.as_ptr(),
                    1, // FindExInfoBasic (skip 8.3 short name for 3x speed)
                    &mut find_data,
                    0, // FindExSearchNameMatch
                    std::ptr::null_mut(),
                    FIND_FIRST_EX_LARGE_FETCH, // 2 (large buffer batching across network/NTFS)
                )
            };

            if handle != INVALID_HANDLE_VALUE {
                break;
            }
        }

        if handle == INVALID_HANDLE_VALUE {
            let err = std::io::Error::last_os_error();
            return Err(format!("{} ({})", err, path.to_string_lossy()));
        }

        let mut items = Vec::with_capacity(2048);
        let base_path = path.to_path_buf();

        loop {
            let name_len = find_data
                .cFileName
                .iter()
                .position(|&c| c == 0)
                .unwrap_or(find_data.cFileName.len());

            if name_len > 0 {
                let slice = &find_data.cFileName[..name_len];
                // Skip "." and ".."
                if !(slice == [46] || slice == [46, 46]) {
                    let os_name = OsString::from_wide(slice);
                    let display_name = os_name.to_string_lossy().into_owned();
                    let lower_name = display_name.to_lowercase();
                    let is_dir = (find_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
                    let is_hidden = (find_data.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN) != 0
                        || display_name.starts_with('.');
                    let is_symlink = (find_data.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0;

                    let size = if is_dir {
                        0
                    } else {
                        ((find_data.nFileSizeHigh as u64) << 32) | (find_data.nFileSizeLow as u64)
                    };

                    let ft = ((find_data.ftLastWriteTime.dwHighDateTime as u64) << 32)
                        | (find_data.ftLastWriteTime.dwLowDateTime as u64);
                    let (modified_str, modified_ts) = if ft > 116_444_736_000_000_000 {
                        let unix_ns100 = ft - 116_444_736_000_000_000;
                        let secs = (unix_ns100 / 10_000_000) as i64;
                        let ts = secs;
                        let dt = chrono::DateTime::from_timestamp(secs, 0);
                        let s = match dt {
                            Some(d) => d
                                .with_timezone(&chrono::Local)
                                .format("%Y-%m-%d %H:%M")
                                .to_string(),
                            None => "-".to_string(),
                        };
                        (s, ts)
                    } else {
                        ("-".to_string(), 0i64)
                    };

                    let extension = if is_dir {
                        String::new()
                    } else {
                        std::path::Path::new(&display_name)
                            .extension()
                            .map(|e| e.to_string_lossy().to_lowercase())
                            .unwrap_or_default()
                    };

                    let full_path = base_path.join(&os_name);

                    items.push(FileEntry {
                        path: full_path,
                        display_name,
                        lower_name,
                        is_dir,
                        is_symlink,
                        is_hidden,
                        size,
                        extension,
                        modified_str,
                        modified_ts,
                        had_special_encoding: false,
                    });
                }
            }

            if unsafe { FindNextFileW(handle, &mut find_data) } == 0 {
                break;
            }
        }

        unsafe { FindClose(handle) };
        Ok(items)
    }
}

/// Non-blocking directory loader with native fast stream API for instant loading of 10,000+ files
pub fn read_dir_non_blocking(path: PathBuf) -> Receiver<Result<Vec<FileEntry>, String>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        #[cfg(target_os = "windows")]
        {
            let res = std::panic::catch_unwind(|| win_fs::read_dir_fast_win32(&path));
            match res {
                Ok(Ok(items)) => {
                    let _ = tx.send(Ok(items));
                    return;
                }
                Ok(Err(_err)) => {
                    // Fallback to std::fs::read_dir in case win32 had permission error or special virtual path
                }
                Err(_) => {}
            }
        }

        let res = std::panic::catch_unwind(|| match std::fs::read_dir(&path) {
            Ok(rd) => {
                let mut items = Vec::with_capacity(1024);
                for entry_res in rd {
                    if let Ok(entry) = entry_res {
                        items.push(FileEntry::from_dir_entry(&entry));
                    }
                }
                Ok(items)
            }
            Err(e) => Err(format!("{} ({})", e, path.to_string_lossy())),
        });
        match res {
            Ok(val) => {
                let _ = tx.send(val);
            }
            Err(_) => {
                let _ = tx.send(Err("Protected from filesystem panic".to_string()));
            }
        }
    });
    rx
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SmbStatus {
    Unknown,
    Probing,
    Online(u64), // latency ms
    Offline(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SmbShareBookmark {
    pub name: String,
    pub unc_or_mount_path: String,
    pub host_ip: String,
    pub port: u16,
    #[serde(skip)]
    pub status: SmbStatus,
}

impl Default for SmbStatus {
    fn default() -> Self {
        SmbStatus::Unknown
    }
}

impl SmbShareBookmark {
    /// Non-blocking TCP + directory probe with strict 800ms timeout so disconnected domains never hang
    pub fn probe_async(&self) -> Receiver<SmbStatus> {
        let (tx, rx) = mpsc::channel();
        let host = if !self.host_ip.trim().is_empty() {
            self.host_ip.trim().to_string()
        } else {
            extract_host_from_remote_path(&self.unc_or_mount_path)
        };
        let port = if self.port == 0 { 445 } else { self.port };
        let path_str = self.unc_or_mount_path.clone();

        thread::spawn(move || {
            let start = std::time::Instant::now();
            if !host.is_empty() {
                use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
                let addr_str = format!("{}:{}", host, port);
                // Resolve and connect with strict 800ms timeout
                let addr_opt: Option<SocketAddr> = addr_str
                    .to_socket_addrs()
                    .ok()
                    .and_then(|mut it| it.next());
                if let Some(addr) = addr_opt {
                    match TcpStream::connect_timeout(&addr, Duration::from_millis(800)) {
                        Ok(_) => {
                            let ms = start.elapsed().as_millis() as u64;
                            let _ = tx.send(SmbStatus::Online(ms));
                            return;
                        }
                        Err(e) => {
                            let _ = tx.send(SmbStatus::Offline(format!("無法連線 ({})", e)));
                            return;
                        }
                    }
                } else {
                    let _ = tx.send(SmbStatus::Offline(format!("找不到主機 ({})", host)));
                    return;
                }
            }
            // Never call blocking Path::exists() on Windows UNC paths (\\Server\Share)
            if path_str.starts_with("\\\\") || path_str.starts_with("//") {
                let _ = tx.send(SmbStatus::Offline("無法連線 (Disconnected)".into()));
                return;
            }
            let p = PathBuf::from(&path_str);
            if p.exists() {
                let ms = start.elapsed().as_millis() as u64;
                let _ = tx.send(SmbStatus::Online(ms));
            } else {
                let _ = tx.send(SmbStatus::Offline("路徑不存在或已中斷連線".into()));
            }
        });
        rx
    }
}

pub fn extract_host_from_remote_path(remote: &str) -> String {
    let s = remote.trim();
    if let Some(rest) = s.strip_prefix("\\\\").or_else(|| s.strip_prefix("//")) {
        let host_part = rest.split(['\\', '/']).next().unwrap_or("");
        // Strip user@ if present (e.g. //user@192.168.1.10/share)
        let host_clean = host_part.split('@').last().unwrap_or(host_part);
        // Strip :port if present
        return host_clean.split(':').next().unwrap_or(host_clean).to_string();
    }
    String::new()
}

/// Spawns a fast background thread (< 25ms) to discover OS remote folders from local Registry/config
pub fn spawn_remote_folders_discovery() -> Receiver<Vec<SmbShareBookmark>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let remotes = discover_system_remote_folders();
        let _ = tx.send(remotes);
    });
    rx
}

#[cfg(target_os = "windows")]
mod win_disks {
    use std::ffi::c_void;
    use std::os::windows::process::CommandExt;
    use std::path::{Path, PathBuf};
    use std::ptr::null_mut;

    const SEM_FAILCRITICALERRORS: u32 = 0x0001;
    const DRIVE_REMOVABLE: u32 = 2;
    const DRIVE_FIXED: u32 = 3;
    const DRIVE_CDROM: u32 = 5;
    const DRIVE_RAMDISK: u32 = 6;
    const ERROR_NOT_READY: u32 = 21;
    const ERROR_DEV_NOT_EXIST: u32 = 55;

    const GENERIC_READ: u32 = 0x8000_0000;
    const GENERIC_WRITE: u32 = 0x4000_0000;
    const FILE_SHARE_READ: u32 = 0x0000_0001;
    const FILE_SHARE_WRITE: u32 = 0x0000_0002;
    const OPEN_EXISTING: u32 = 3;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    const BUS_TYPE_USB: u32 = 7;

    const IOCTL_STORAGE_QUERY_PROPERTY: u32 = 0x002D_1400;
    const FSCTL_LOCK_VOLUME: u32 = 0x0009_0018;
    const FSCTL_DISMOUNT_VOLUME: u32 = 0x0009_0020;
    const IOCTL_STORAGE_EJECT_MEDIA: u32 = 0x002D_4808;

    #[repr(C)]
    struct StoragePropertyQuery {
        property_id: u32,
        query_type: u32,
        additional_parameters: [u8; 4],
    }

    #[repr(C)]
    struct StorageDeviceDescriptorHeader {
        version: u32,
        size: u32,
        device_type: u8,
        device_type_modifier: u8,
        removable_media: u8,
        command_queueing: u8,
        vendor_id_offset: u32,
        product_id_offset: u32,
        product_revision_offset: u32,
        serial_number_offset: u32,
        bus_type: u32,
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn GetLogicalDrives() -> u32;
        fn GetDriveTypeW(lp_root_path_name: *const u16) -> u32;
        fn GetVolumeInformationW(
            lp_root_path_name: *const u16,
            lp_volume_name_buffer: *mut u16,
            n_volume_name_size: u32,
            lp_volume_serial_number: *mut u32,
            lp_maximum_component_length: *mut u32,
            lp_file_system_flags: *mut u32,
            lp_file_system_name_buffer: *mut u16,
            n_file_system_name_size: u32,
        ) -> i32;
        fn GetDiskFreeSpaceExW(
            lp_directory_name: *const u16,
            lp_free_bytes_available_to_caller: *mut u64,
            lp_total_number_of_bytes: *mut u64,
            lp_total_number_of_free_bytes: *mut u64,
        ) -> i32;
        fn SetThreadErrorMode(dw_new_mode: u32, lp_old_mode: *mut u32) -> i32;
        fn GetLastError() -> u32;
        fn CreateFileW(
            lp_file_name: *const u16,
            dw_desired_access: u32,
            dw_share_mode: u32,
            lp_security_attributes: *mut c_void,
            dw_creation_disposition: u32,
            dw_flags_and_attributes: u32,
            h_template_file: *mut c_void,
        ) -> *mut c_void;
        fn DeviceIoControl(
            h_device: *mut c_void,
            dw_io_control_code: u32,
            lp_in_buffer: *const c_void,
            n_in_buffer_size: u32,
            lp_out_buffer: *mut c_void,
            n_out_buffer_size: u32,
            lp_bytes_returned: *mut u32,
            lp_overlapped: *mut c_void,
        ) -> i32;
        fn CloseHandle(h_object: *mut c_void) -> i32;
    }

    struct ThreadErrorModeGuard {
        prev_mode: u32,
        active: bool,
    }

    impl ThreadErrorModeGuard {
        fn suppress_critical_errors() -> Self {
            let mut prev = 0u32;
            let ok = unsafe { SetThreadErrorMode(SEM_FAILCRITICALERRORS, &mut prev) != 0 };
            Self {
                prev_mode: prev,
                active: ok,
            }
        }
    }

    impl Drop for ThreadErrorModeGuard {
        fn drop(&mut self) {
            if self.active {
                let mut dummy = 0u32;
                unsafe {
                    let _ = SetThreadErrorMode(self.prev_mode, &mut dummy);
                }
            }
        }
    }

    /// Cheap local-only topology signature combining logical drive bitmask and removable slot readiness.
    /// Never probes network drives (`DRIVE_REMOTE`), so offline SMB mappings cannot stall.
    pub fn topology_signature() -> u64 {
        let _guard = ThreadErrorModeGuard::suppress_critical_errors();
        let mask = unsafe { GetLogicalDrives() };
        let mut sig: u64 = (mask as u64) << 32;

        for idx in 0..26u32 {
            if (mask & (1u32 << idx)) == 0 {
                continue;
            }
            let letter = (b'A' + idx as u8) as char;
            let root_w: [u16; 4] = [letter as u16, b':' as u16, b'\\' as u16, 0];
            let dtype = unsafe { GetDriveTypeW(root_w.as_ptr()) };
            if dtype == DRIVE_REMOVABLE || dtype == DRIVE_CDROM {
                let mut serial = 0u32;
                let ready = unsafe {
                    GetVolumeInformationW(
                        root_w.as_ptr(),
                        null_mut(),
                        0,
                        &mut serial,
                        null_mut(),
                        null_mut(),
                        null_mut(),
                        0,
                    ) != 0
                };
                if ready {
                    sig ^= 1u64 << idx;
                    sig = sig.rotate_left(7) ^ (serial as u64);
                }
            }
        }
        sig
    }

    /// Discovers local fixed, removable (USB/SD/SIM), RAM, and ready optical drives directly via Win32.
    /// Avoids `sysinfo`'s raw-volume `CreateFileW` requirement that silently hides many card readers & USB sticks.
    pub fn list_local_disks() -> Vec<(String, PathBuf, u64, u64)> {
        let _guard = ThreadErrorModeGuard::suppress_critical_errors();
        let mask = unsafe { GetLogicalDrives() };
        let mut out = Vec::new();

        for idx in 0..26u32 {
            if (mask & (1u32 << idx)) == 0 {
                continue;
            }
            let letter = (b'A' + idx as u8) as char;
            let root = format!("{}:\\", letter);
            let root_w: [u16; 4] = [letter as u16, b':' as u16, b'\\' as u16, 0];
            let dtype = unsafe { GetDriveTypeW(root_w.as_ptr()) };
            if dtype != DRIVE_FIXED
                && dtype != DRIVE_REMOVABLE
                && dtype != DRIVE_RAMDISK
                && dtype != DRIVE_CDROM
            {
                continue;
            }

            let mut vol_buf = [0u16; 261];
            let mut serial = 0u32;
            let vol_ok = unsafe {
                GetVolumeInformationW(
                    root_w.as_ptr(),
                    vol_buf.as_mut_ptr(),
                    vol_buf.len() as u32,
                    &mut serial,
                    null_mut(),
                    null_mut(),
                    null_mut(),
                    0,
                ) != 0
            };
            let vol_err = if vol_ok { 0 } else { unsafe { GetLastError() } };

            let mut avail = 0u64;
            let mut total = 0u64;
            let space_ok = unsafe {
                GetDiskFreeSpaceExW(root_w.as_ptr(), &mut avail, &mut total, null_mut()) != 0
            };
            let space_err = if space_ok {
                0
            } else {
                unsafe { GetLastError() }
            };

            // Skip empty CD-ROM drives and empty card-reader bays (`ERROR_NOT_READY`) so they don't clutter This PC
            if dtype == DRIVE_CDROM && !vol_ok && !space_ok {
                continue;
            }
            if dtype == DRIVE_REMOVABLE && !vol_ok && !space_ok {
                let err = if space_err != 0 { space_err } else { vol_err };
                if err == ERROR_NOT_READY || err == ERROR_DEV_NOT_EXIST {
                    continue;
                }
            }

            let vol_name = if vol_ok {
                let len = vol_buf.iter().position(|&c| c == 0).unwrap_or(vol_buf.len());
                String::from_utf16_lossy(&vol_buf[..len]).trim().to_string()
            } else {
                String::new()
            };

            let label = if !vol_name.is_empty() {
                format!("{} ({})", vol_name, root)
            } else if dtype == DRIVE_REMOVABLE {
                format!("卸除式磁碟 ({})", root)
            } else if dtype == DRIVE_CDROM {
                format!("光碟機 ({})", root)
            } else {
                format!("本機磁碟 ({})", root)
            };

            out.push((label, PathBuf::from(root), avail, total));
        }
        out
    }

    fn drive_letter_of(path: &Path) -> Option<char> {
        let s = path.to_string_lossy();
        let bytes = s.as_bytes();
        if bytes.len() >= 2 && bytes[1] == b':' && bytes[0].is_ascii_alphabetic() {
            let is_root = bytes.len() == 2 || (bytes.len() == 3 && (bytes[2] == b'\\' || bytes[2] == b'/'));
            if is_root {
                return Some((bytes[0] as char).to_ascii_uppercase());
            }
        }
        None
    }

    fn is_usb_storage_bus(letter: char) -> bool {
        let dev_path: Vec<u16> = format!("\\\\.\\{}:", letter)
            .encode_utf16()
            .chain(Some(0))
            .collect();
        let invalid = (-1isize) as *mut c_void;
        let handle = unsafe {
            CreateFileW(
                dev_path.as_ptr(),
                0,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                null_mut(),
                OPEN_EXISTING,
                0,
                null_mut(),
            )
        };
        if handle == invalid || handle.is_null() {
            return false;
        }
        let query = StoragePropertyQuery {
            property_id: 0, // StorageDeviceProperty
            query_type: 0,  // PropertyStandardQuery
            additional_parameters: [0; 4],
        };
        let mut out_buf = [0u8; 512];
        let mut returned = 0u32;
        let ok = unsafe {
            DeviceIoControl(
                handle,
                IOCTL_STORAGE_QUERY_PROPERTY,
                &query as *const StoragePropertyQuery as *const c_void,
                std::mem::size_of::<StoragePropertyQuery>() as u32,
                out_buf.as_mut_ptr() as *mut c_void,
                out_buf.len() as u32,
                &mut returned,
                null_mut(),
            ) != 0
        };
        unsafe {
            CloseHandle(handle);
        }
        if ok && (returned as usize) >= std::mem::size_of::<StorageDeviceDescriptorHeader>() {
            let hdr = unsafe { &*(out_buf.as_ptr() as *const StorageDeviceDescriptorHeader) };
            return hdr.removable_media != 0 || hdr.bus_type == BUS_TYPE_USB;
        }
        false
    }

    pub fn is_ejectable_drive(path: &Path) -> bool {
        let Some(letter) = drive_letter_of(path) else {
            return false;
        };
        let root_w: [u16; 4] = [letter as u16, b':' as u16, b'\\' as u16, 0];
        let dtype = unsafe { GetDriveTypeW(root_w.as_ptr()) };
        if dtype == DRIVE_REMOVABLE || dtype == DRIVE_CDROM {
            return true;
        }
        if dtype == DRIVE_FIXED && letter != 'C' {
            return is_usb_storage_bus(letter);
        }
        false
    }

    fn is_volume_ready(letter: char) -> bool {
        let _guard = ThreadErrorModeGuard::suppress_critical_errors();
        let mask = unsafe { GetLogicalDrives() };
        let idx = (letter as u32).saturating_sub('A' as u32);
        if idx >= 26 || (mask & (1u32 << idx)) == 0 {
            return false;
        }
        let root_w: [u16; 4] = [letter as u16, b':' as u16, b'\\' as u16, 0];
        let mut serial = 0u32;
        unsafe {
            GetVolumeInformationW(
                root_w.as_ptr(),
                null_mut(),
                0,
                &mut serial,
                null_mut(),
                null_mut(),
                null_mut(),
                0,
            ) != 0
        }
    }

    pub fn eject_drive(path: &Path) -> Result<String, String> {
        let Some(letter) = drive_letter_of(path) else {
            return Err("不支援的磁碟路徑".to_string());
        };
        let _guard = ThreadErrorModeGuard::suppress_critical_errors();

        // 1. Primary path: Windows Explorer Shell.Application `eject` verb (handles USB Safe Removal toast & SD/USB/Optical)
        let ps_script = format!(
            "$sh = New-Object -ComObject Shell.Application; \
             $ns = $sh.Namespace(17); \
             $it = $ns.ParseName('{}:\\'); \
             if ($null -eq $it) {{ $it = @($ns.Items() | Where-Object {{ $_.Path -eq '{}:\\' -or $_.Path -eq '{}:' }})[0] }}; \
             if ($null -ne $it) {{ $it.InvokeVerb('eject') }}",
            letter, letter, letter
        );
        let _ = std::process::Command::new("powershell")
            .args(["-NoProfile", "-NonInteractive", "-Command", &ps_script])
            .creation_flags(CREATE_NO_WINDOW)
            .output();

        std::thread::sleep(std::time::Duration::from_millis(550));
        if !is_volume_ready(letter) {
            return Ok(format!("⏏ 已安全退出磁碟 ({}:\\)", letter));
        }

        // 2. Fallback: Win32 DeviceIoControl FSCTL_LOCK_VOLUME + FSCTL_DISMOUNT_VOLUME + IOCTL_STORAGE_EJECT_MEDIA
        let dev_path: Vec<u16> = format!("\\\\.\\{}:", letter)
            .encode_utf16()
            .chain(Some(0))
            .collect();
        let invalid = (-1isize) as *mut c_void;
        let mut handle = unsafe {
            CreateFileW(
                dev_path.as_ptr(),
                GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                null_mut(),
                OPEN_EXISTING,
                0,
                null_mut(),
            )
        };
        if handle == invalid || handle.is_null() {
            handle = unsafe {
                CreateFileW(
                    dev_path.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    null_mut(),
                    OPEN_EXISTING,
                    0,
                    null_mut(),
                )
            };
        }
        if handle == invalid || handle.is_null() {
            let err = unsafe { GetLastError() };
            return Err(format!("無法鎖定磁碟 {}:\\ (Win32 error {})", letter, err));
        }

        let mut bytes_ret = 0u32;
        let locked = unsafe {
            DeviceIoControl(
                handle,
                FSCTL_LOCK_VOLUME,
                null_mut(),
                0,
                null_mut(),
                0,
                &mut bytes_ret,
                null_mut(),
            ) != 0
        };
        if !locked {
            unsafe {
                CloseHandle(handle);
            }
            return Err(format!(
                "磁碟 {}:\\ 正在使用中，請關閉開啟該磁碟檔案的程式後再試",
                letter
            ));
        }

        unsafe {
            let _ = DeviceIoControl(
                handle,
                FSCTL_DISMOUNT_VOLUME,
                null_mut(),
                0,
                null_mut(),
                0,
                &mut bytes_ret,
                null_mut(),
            );
            let ejected = DeviceIoControl(
                handle,
                IOCTL_STORAGE_EJECT_MEDIA,
                null_mut(),
                0,
                null_mut(),
                0,
                &mut bytes_ret,
                null_mut(),
            ) != 0;
            CloseHandle(handle);
            if ejected || !is_volume_ready(letter) {
                Ok(format!("⏏ 已安全退出磁碟 ({}:\\)", letter))
            } else {
                Err(format!(
                    "已卸載磁碟 {}:\\ 檔案系統（若為固定式外接硬碟，可從系統匣安全移除硬體）",
                    letter
                ))
            }
        }
    }
}

pub fn is_ejectable_drive(path: &Path) -> bool {
    #[cfg(target_os = "windows")]
    {
        win_disks::is_ejectable_drive(path)
    }
    #[cfg(target_os = "macos")]
    {
        path.starts_with("/Volumes/") && path != Path::new("/Volumes")
    }
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        path.starts_with("/media/") || path.starts_with("/run/media/") || path.starts_with("/mnt/")
    }
}

pub fn spawn_eject_drive(mount: PathBuf) -> Receiver<Result<String, String>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        #[cfg(target_os = "windows")]
        let res = win_disks::eject_drive(&mount);

        #[cfg(target_os = "macos")]
        let res = {
            let out = std::process::Command::new("diskutil")
                .arg("eject")
                .arg(&mount)
                .output();
            match out {
                Ok(o) if o.status.success() => Ok(format!("⏏ 已安全退出 ({})", mount.display())),
                Ok(o) => {
                    let err = String::from_utf8_lossy(&o.stderr).trim().to_string();
                    Err(if err.is_empty() {
                        format!("無法退出 ({})", mount.display())
                    } else {
                        err
                    })
                }
                Err(e) => Err(e.to_string()),
            }
        };

        #[cfg(all(unix, not(target_os = "macos")))]
        let res = {
            let out = std::process::Command::new("umount").arg(&mount).output();
            match out {
                Ok(o) if o.status.success() => Ok(format!("⏏ 已卸載 ({})", mount.display())),
                Ok(o) => Err(String::from_utf8_lossy(&o.stderr).trim().to_string()),
                Err(e) => Err(e.to_string()),
            }
        };

        let _ = tx.send(res);
    });
    rx
}

pub fn open_in_os_file_manager(path: &Path) {
    #[cfg(target_os = "windows")]
    {
        let _ = std::process::Command::new("explorer").arg(path).spawn();
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = open::that(path);
    }
}

pub fn drive_topology_signature() -> u64 {
    #[cfg(target_os = "windows")]
    {
        win_disks::topology_signature()
    }
    #[cfg(not(target_os = "windows"))]
    {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        #[cfg(target_os = "macos")]
        {
            if let Ok(rd) = std::fs::read_dir("/Volumes") {
                let mut names: Vec<String> = rd
                    .flatten()
                    .map(|e| e.file_name().to_string_lossy().into_owned())
                    .collect();
                names.sort();
                names.hash(&mut hasher);
            }
        }
        #[cfg(all(unix, not(target_os = "macos")))]
        {
            if let Ok(mounts) = std::fs::read_to_string("/proc/mounts") {
                mounts.hash(&mut hasher);
            }
        }
        hasher.finish()
    }
}

pub fn discover_local_disks_sync() -> Vec<(String, PathBuf, u64, u64)> {
    #[cfg(target_os = "windows")]
    {
        let direct = win_disks::list_local_disks();
        if !direct.is_empty() {
            return direct;
        }
    }

    let mut disk_list = Vec::new();
    let disks = sysinfo::Disks::new_with_refreshed_list();
    for d in disks.list() {
        let mount = d.mount_point().to_path_buf();
        let name = d.name().to_string_lossy().into_owned();
        let label = if name.is_empty() {
            mount.to_string_lossy().into_owned()
        } else {
            format!("{} ({})", name, mount.to_string_lossy())
        };
        disk_list.push((label, mount, d.available_space(), d.total_space()));
    }
    disk_list
}

/// Spawns an isolated background thread to query disk capacity so offline network drives never stall UI or SMB discovery
pub fn spawn_disks_discovery() -> Receiver<Vec<(String, PathBuf, u64, u64)>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let _ = tx.send(discover_local_disks_sync());
    });
    rx
}

/// Lightweight background watcher that polls drive topology every ~800ms (~1us syscall on Windows)
/// and pushes updated disk lists immediately whenever a USB, SD, SIM, or external volume is mounted/ejected.
pub fn spawn_disks_watcher(ctx: egui::Context) -> Receiver<Vec<(String, PathBuf, u64, u64)>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let mut last_sig = drive_topology_signature();
        let mut last_disks = discover_local_disks_sync();
        if tx.send(last_disks.clone()).is_err() {
            return;
        }
        ctx.request_repaint();

        let mut followup_ticks = 0u8;
        loop {
            thread::sleep(Duration::from_millis(800));
            let cur_sig = drive_topology_signature();
            if cur_sig != last_sig {
                last_sig = cur_sig;
                // Schedule 2 gentle follow-up refreshes because Windows sometimes assigns the drive letter
                // a few hundred milliseconds before volume label / capacity finish mounting.
                followup_ticks = 2;
            } else if followup_ticks == 0 {
                continue;
            } else {
                followup_ticks -= 1;
            }

            let new_disks = discover_local_disks_sync();
            if new_disks != last_disks {
                last_disks = new_disks.clone();
                if tx.send(new_disks).is_err() {
                    break;
                }
                ctx.request_repaint();
            }
        }
    });
    rx
}

/// Automatically discovers remote / network folders already configured in the OS File Explorer / Finder
/// (just like original MDIE), purely from fast local Registry/config without blocking on offline SMB drives.
pub fn discover_system_remote_folders() -> Vec<SmbShareBookmark> {
    let mut discovered: Vec<SmbShareBookmark> = Vec::new();
    let mut seen_paths = std::collections::HashSet::new();

    let mut add_share = |name: String, path: String, host: String| {
        let key = path.to_lowercase();
        if !path.is_empty() && !seen_paths.contains(&key) {
            seen_paths.insert(key);
            discovered.push(SmbShareBookmark {
                name,
                unc_or_mount_path: path,
                host_ip: host,
                port: 445,
                status: SmbStatus::Probing,
            });
        }
    };

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x08000000;

        // 1. Mapped Network Drives from HKCU\Network (e.g. Z: -> \\Server\Share)
        // IMPORTANT: Never call Path::exists("Z:\\") here, because Windows blocks 30-60s if Z: is offline!
        if let Ok(out) = std::process::Command::new("reg")
            .args(["query", "HKCU\\Network", "/s"])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
        {
            let text = String::from_utf8_lossy(&out.stdout);
            let mut current_drive = String::new();
            for line in text.lines() {
                let trimmed = line.trim();
                if let Some(drive_letter) = trimmed
                    .strip_prefix("HKEY_CURRENT_USER\\Network\\")
                    .or_else(|| trimmed.strip_prefix("HKCU\\Network\\"))
                {
                    current_drive = drive_letter.trim().to_uppercase();
                } else if trimmed.starts_with("RemotePath") {
                    if let Some(idx) = trimmed.find("REG_SZ") {
                        let remote_unc = trimmed[idx + 6..].trim().to_string();
                        if !remote_unc.is_empty() {
                            let host = extract_host_from_remote_path(&remote_unc);
                            let display_name = if !current_drive.is_empty() {
                                format!("🖧 {}: ({})", current_drive, remote_unc)
                            } else {
                                format!("🖧 {}", remote_unc)
                            };
                            add_share(display_name, remote_unc, host);
                        }
                    }
                }
            }
        }

        // 2. Windows Explorer "Network Shortcuts" (%APPDATA%\Microsoft\Windows\Network Shortcuts)
        if let Some(appdata) = dirs::data_dir() {
            let nethood = appdata.join("Microsoft\\Windows\\Network Shortcuts");
            if let Ok(rd) = std::fs::read_dir(&nethood) {
                for entry in rd.flatten() {
                    let p = entry.path();
                    let name = entry.file_name().to_string_lossy().into_owned();
                    if name.eq_ignore_ascii_case("desktop.ini") {
                        continue;
                    }
                    let is_dir_entry = entry.file_type().map(|ft| ft.is_dir()).unwrap_or(false);
                    let clean_name = name.strip_suffix(".lnk").unwrap_or(&name).to_string();
                    let lnk_candidate = if is_dir_entry {
                        p.join("target.lnk")
                    } else {
                        p.clone()
                    };
                    let mut extracted_unc = None;
                    if let Ok(bytes) = std::fs::read(&lnk_candidate) {
                        extracted_unc = extract_unc_from_lnk_bytes(&bytes);
                    }
                    if let Some(unc) = extracted_unc {
                        let host = extract_host_from_remote_path(&unc);
                        add_share(format!("🌐 {} ({})", clean_name, unc), unc, host);
                    } else if is_dir_entry {
                        add_share(
                            format!("🌐 {}", clean_name),
                            p.to_string_lossy().into_owned(),
                            String::new(),
                        );
                    }
                }
            }
        }

        // 3. Windows Explorer MountPoints2 (caches all \\Server\Share folders configured/visited in Explorer as ##Server#Share)
        if let Ok(out) = std::process::Command::new("reg")
            .args([
                "query",
                "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\MountPoints2",
            ])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
        {
            let text = String::from_utf8_lossy(&out.stdout);
            for line in text.lines() {
                let trimmed = line.trim();
                if let Some(pos) = trimmed.find("\\##") {
                    let raw_key = &trimmed[pos + 3..]; // after \##
                    let unc = format!("\\\\{}", raw_key.replace('#', "\\"));
                    let host = extract_host_from_remote_path(&unc);
                    let share_label = raw_key.replace('#', " / ");
                    add_share(format!("🌐 {}", share_label), unc, host);
                }
            }
        }

        // 4. Windows Explorer TypedPaths (any \\Server\Share typed in Explorer address bar)
        if let Ok(out) = std::process::Command::new("reg")
            .args([
                "query",
                "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\TypedPaths",
            ])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
        {
            let text = String::from_utf8_lossy(&out.stdout);
            for line in text.lines() {
                if let Some(idx) = line.find("REG_SZ") {
                    let val = line[idx + 6..].trim();
                    if val.starts_with("\\\\") && val.len() > 3 {
                        let host = extract_host_from_remote_path(val);
                        add_share(format!("🌐 {}", val), val.to_string(), host);
                    }
                }
            }
        }
    }

    #[cfg(target_os = "macos")]
    {
        // 1. Parse `/sbin/mount` for mounted network filesystems (smbfs, nfs, afpfs, webdav, cifs)
        if let Ok(out) = std::process::Command::new("/sbin/mount").output() {
            let text = String::from_utf8_lossy(&out.stdout);
            for line in text.lines() {
                let is_net = line.contains("(smbfs")
                    || line.contains("(nfs")
                    || line.contains("(afpfs")
                    || line.contains("(webdav")
                    || line.contains("(cifs");
                if let Some((remote_spec, rest)) = line.split_once(" on ") {
                    if let Some((mount_point, _flags)) = rest.split_once(" (") {
                        if is_net || mount_point.starts_with("/Volumes/") {
                            let host = extract_host_from_remote_path(remote_spec);
                            let folder_name = Path::new(mount_point)
                                .file_name()
                                .map(|n| n.to_string_lossy().into_owned())
                                .unwrap_or_else(|| mount_point.to_string());
                            let prefix = if is_net { "🌐" } else { "🖴" };
                            let label = if !host.is_empty() {
                                format!("{} {} ({})", prefix, folder_name, host)
                            } else {
                                format!("{} {}", prefix, folder_name)
                            };
                            add_share(label, mount_point.to_string(), host);
                        }
                    }
                }
            }
        }

        // 2. Scan `/Volumes` for any additional Finder mounted volumes (excluding root symlink)
        if let Ok(rd) = std::fs::read_dir("/Volumes") {
            for entry in rd.flatten() {
                let p = entry.path();
                // Skip `/` symlink ("Macintosh HD")
                if let Ok(canon) = std::fs::canonicalize(&p) {
                    if canon == Path::new("/") {
                        continue;
                    }
                }
                let name = entry.file_name().to_string_lossy().into_owned();
                if !name.starts_with('.') {
                    add_share(
                        format!("📂 {}", name),
                        p.to_string_lossy().into_owned(),
                        String::new(),
                    );
                }
            }
        }
    }

    #[cfg(target_os = "linux")]
    {
        if let Ok(mounts) = std::fs::read_to_string("/proc/mounts") {
            for line in mounts.lines() {
                let parts: Vec<&str> = line.split_whitespace().collect();
                if parts.len() >= 3 {
                    let src = parts[0];
                    let mnt = parts[1];
                    let fstype = parts[2];
                    if matches!(fstype, "cifs" | "smb3" | "smbfs" | "nfs" | "nfs4" | "fuse.sshfs") {
                        let host = extract_host_from_remote_path(src);
                        add_share(format!("🌐 {} ({})", mnt, src), mnt.to_string(), host);
                    }
                }
            }
        }
    }

    discovered
}

#[cfg(target_os = "windows")]
fn extract_unc_from_lnk_bytes(bytes: &[u8]) -> Option<String> {
    // 1. Check UTF-16LE `\\` (0x5C, 0x00, 0x5C, 0x00)
    let mut i = 0;
    while i + 8 < bytes.len() {
        if bytes[i] == b'\\'
            && bytes[i + 1] == 0
            && bytes[i + 2] == b'\\'
            && bytes[i + 3] == 0
        {
            let mut chars = Vec::new();
            let mut j = i;
            while j + 1 < bytes.len() {
                let u = u16::from_le_bytes([bytes[j], bytes[j + 1]]);
                if u == 0 || u < 32 {
                    break;
                }
                if let Some(ch) = char::from_u32(u as u32) {
                    chars.push(ch);
                } else {
                    break;
                }
                j += 2;
            }
            let s: String = chars.into_iter().collect();
            if s.len() > 4 && s[2..].contains('\\') && !s.contains("\\\\?\\") {
                return Some(s);
            }
        }
        i += 1;
    }
    // 2. Check ASCII `\\`
    for win in bytes.windows(2).enumerate() {
        let (idx, pair) = win;
        if pair == b"\\\\" {
            let s: String = bytes[idx..]
                .iter()
                .copied()
                .take_while(|&b| b >= 32 && b < 127)
                .map(|b| b as char)
                .collect();
            if s.len() > 4 && s[2..].contains('\\') && !s.contains("\\\\?\\") {
                return Some(s);
            }
        }
    }
    None
}


pub enum PreviewPayload {
    None,
    Loading(PathBuf),
    Text {
        path: PathBuf,
        content: String,
        encoding_note: String,
    },
    Image {
        path: PathBuf,
        width: usize,
        height: usize,
        rgba: Vec<u8>,
        format_note: String,
    },
    Media {
        path: PathBuf,
        is_video: bool,
        poster_rgba: Option<(usize, usize, Vec<u8>)>,
        size_bytes: u64,
        ext: String,
    },
    MetadataOnly {
        path: PathBuf,
        summary: String,
    },
}

/// Sandboxed file preview loader (runs on isolated thread with `catch_unwind` + HEIC macOS `sips` / Windows safe fallback)
pub fn load_preview_sandboxed(path: PathBuf) -> Receiver<PreviewPayload> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let path_clone = path.clone();
        let outcome = std::panic::catch_unwind(move || build_preview_payload(&path_clone));
        match outcome {
            Ok(payload) => {
                let _ = tx.send(payload);
            }
            Err(_) => {
                let _ = tx.send(PreviewPayload::MetadataOnly {
                    path,
                    summary: "🛡 [Sandbox Guard] Corrupted file header isolated; prevented crash!"
                        .to_string(),
                });
            }
        }
    });
    rx
}

fn build_preview_payload(path: &Path) -> PreviewPayload {
    if !path.exists() {
        return PreviewPayload::None;
    }
    if path.is_dir() {
        let count = std::fs::read_dir(path).map(|r| r.count()).unwrap_or(0);
        return PreviewPayload::MetadataOnly {
            path: path.to_path_buf(),
            summary: format!("📁 Directory\nContains {} direct items", count),
        };
    }

    let ext = path
        .extension()
        .map(|e| e.to_string_lossy().to_lowercase())
        .unwrap_or_default();

    // 1. Handle .heic / .heif safely without ever crashing the shell!
    if ext == "heic" || ext == "heif" {
        // Fast zero-subprocess / zero-temp-file OS hardware decode (macOS ImageIO / Windows WIC Shell cache)
        if let Some((w, h, rgba)) = crate::media::extract_os_image_thumbnail_rgba(path, 520, false) {
            return PreviewPayload::Image {
                path: path.to_path_buf(),
                width: w,
                height: h,
                rgba,
                format_note: "🛡 HEIC Native Hardware Decode (Zero Temp File)".into(),
            };
        }
        // Fallback on macOS: sandboxed `sips` subprocess if ImageIO failed
        #[cfg(target_os = "macos")]
        {
            let tmp_png = std::env::temp_dir().join("mine_heic_preview.png");
            let status = std::process::Command::new("sips")
                .args([
                    "-s",
                    "format",
                    "png",
                    "-Z",
                    "512",
                    &path.to_string_lossy(),
                    "--out",
                    &tmp_png.to_string_lossy(),
                ])
                .stdout(std::process::Stdio::null())
                .stderr(std::process::Stdio::null())
                .status();
            if let Ok(st) = status {
                if st.success() {
                    if let Ok(img) = image::open(&tmp_png) {
                        let rgba = img.to_rgba8();
                        let (w, h) = rgba.dimensions();
                        return PreviewPayload::Image {
                            path: path.to_path_buf(),
                            width: w as usize,
                            height: h as usize,
                            rgba: rgba.into_raw(),
                            format_note: "🛡 HEIC Sandboxed Hardware Decode (Zero Crash)".into(),
                        };
                    }
                }
            }
        }
        // Safe header inspection fallback on Windows/Linux if HEIC codec is absent
        let size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);
        return PreviewPayload::MetadataOnly {
            path: path.to_path_buf(),
            summary: format!(
                "🖼 Apple HEIC/HEIF High-Efficiency Image\nSize: {}\n\n🛡 [MINE Sandbox Protection]\nLegacy explorers (like MDIE) crash when Windows Shell Thumbnail Handler hits HEIC files.\nMINE isolates HEIC metadata safely so you can move, rename, or open it without ever crashing.",
                format_size(size)
            ),
        };
    }

    // 2. Pure-Rust memory-safe image decoding for PNG, JPEG, WEBP, GIF, BMP, ICO, TIFF, AVIF
    if matches!(
        ext.as_str(),
        "png" | "jpg" | "jpeg" | "webp" | "gif" | "bmp" | "ico" | "tiff" | "avif"
    ) {
        if let Ok(bytes) = std::fs::read(path) {
            if let Ok(img) = image::load_from_memory(&bytes) {
                let thumb = img.thumbnail(520, 520);
                let rgba = thumb.to_rgba8();
                let (w, h) = rgba.dimensions();
                return PreviewPayload::Image {
                    path: path.to_path_buf(),
                    width: w as usize,
                    height: h as usize,
                    rgba: rgba.into_raw(),
                    format_note: format!(
                        "🛡 Pure-Rust Memory-Safe Decoder ({}x{} orig)",
                        img.width(),
                        img.height()
                    ),
                };
            }
        }
    }

    // 2.5. Native OS-accelerated Video & Audio Preview (inline player + poster / album cover art)
    if crate::media::is_media_ext(&ext) {
        let is_video = crate::media::is_video_ext(&ext);
        let size_bytes = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);
        let poster_rgba = crate::media::extract_media_thumbnail_rgba(path, 520);
        return PreviewPayload::Media {
            path: path.to_path_buf(),
            is_video,
            poster_rgba,
            size_bytes,
            ext,
        };
    }

    // 3. Text & Code preview with automatic non-UTF8 / Shift-JIS / Big5 lossy safety
    if matches!(
        ext.as_str(),
        "txt" | "md" | "rs" | "py" | "js" | "ts" | "json" | "toml" | "yaml" | "yml" | "ini"
            | "cfg" | "log" | "csv" | "html" | "css" | "c" | "cpp" | "h" | "bat" | "sh" | "reg"
            | "vbs" | "xml"
    ) {
        if let Ok(mut file) = std::fs::File::open(path) {
            use std::io::Read;
            let mut buf = vec![0u8; 16 * 1024]; // max 16KB preview
            if let Ok(n) = file.read(&mut buf) {
                buf.truncate(n);
                let is_valid_utf8 = std::str::from_utf8(&buf).is_ok();
                let content = String::from_utf8_lossy(&buf).into_owned();
                let encoding_note = if is_valid_utf8 {
                    "UTF-8 Clean".to_string()
                } else {
                    "🛡 Non-UTF8 / Legacy ANSI / Shift-JIS / Big5 Safely Decoded".to_string()
                };
                return PreviewPayload::Text {
                    path: path.to_path_buf(),
                    content,
                    encoding_note,
                };
            }
        }
    }

    let size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);
    PreviewPayload::MetadataOnly {
        path: path.to_path_buf(),
        summary: format!(
            "📄 {}\nSize: {}\nExtension: .{}",
            path.file_name().unwrap_or_default().to_string_lossy(),
            format_size(size),
            ext
        ),
    }
}

/// Fast listing of subdirectories only (excluding files) for Sidebar Tree View.
/// Automatically filters out system junk ($RECYCLE.BIN, System Volume Information)
/// and sorts folders alphabetically (case-insensitive).
pub fn list_subdirectories_fast(path: &Path) -> Vec<(String, PathBuf)> {
    let mut dirs = Vec::new();
    if let Ok(rd) = std::fs::read_dir(path) {
        for entry_res in rd {
            if let Ok(entry) = entry_res {
                let file_type = entry.file_type();
                let is_dir = match file_type {
                    Ok(ft) => ft.is_dir(),
                    Err(_) => false,
                };
                if is_dir {
                    let os_name = entry.file_name();
                    let name = os_name.to_string_lossy().into_owned();
                    // Skip hidden system volume info or recycle bin on Windows drives
                    if name != "$RECYCLE.BIN"
                        && name != "System Volume Information"
                        && !name.starts_with('$')
                    {
                        dirs.push((name, entry.path()));
                    }
                }
            }
        }
    }
    // Case-insensitive natural alphabetical sort
    dirs.sort_by(|a, b| a.0.to_lowercase().cmp(&b.0.to_lowercase()));
    dirs
}

/// Opens the native OS Properties dialog on Windows (`ShellExecuteExW` with `"properties"`).
/// Returns `true` if the OS dialog was launched, `false` to fall back to the in-app Properties modal.
#[cfg(target_os = "windows")]
pub fn open_os_properties(path: &Path) -> bool {
    use std::ffi::OsStr;
    use std::os::windows::ffi::OsStrExt;
    use std::ptr::{null, null_mut};

    #[repr(C)]
    struct ShellExecuteInfoW {
        cb_size: u32,
        f_mask: u32,
        hwnd: *mut std::ffi::c_void,
        lp_verb: *const u16,
        lp_file: *const u16,
        lp_parameters: *const u16,
        lp_directory: *const u16,
        n_show: i32,
        h_inst_app: *mut std::ffi::c_void,
        lp_id_list: *mut std::ffi::c_void,
        lp_class: *const u16,
        hkey_class: *mut std::ffi::c_void,
        dw_hot_key: u32,
        h_icon_or_monitor: *mut std::ffi::c_void,
        h_process: *mut std::ffi::c_void,
    }

    #[link(name = "shell32")]
    extern "system" {
        fn ShellExecuteExW(pExecInfo: *mut ShellExecuteInfoW) -> i32;
    }

    const SEE_MASK_INVOKEIDLIST: u32 = 0x0000000C;
    const SW_SHOW: i32 = 5;

    let verb: Vec<u16> = OsStr::new("properties").encode_wide().chain(Some(0)).collect();
    let file: Vec<u16> = path.as_os_str().encode_wide().chain(Some(0)).collect();

    let mut sei = ShellExecuteInfoW {
        cb_size: std::mem::size_of::<ShellExecuteInfoW>() as u32,
        f_mask: SEE_MASK_INVOKEIDLIST,
        hwnd: null_mut(),
        lp_verb: verb.as_ptr(),
        lp_file: file.as_ptr(),
        lp_parameters: null(),
        lp_directory: null(),
        n_show: SW_SHOW,
        h_inst_app: null_mut(),
        lp_id_list: null_mut(),
        lp_class: null(),
        hkey_class: null_mut(),
        dw_hot_key: 0,
        h_icon_or_monitor: null_mut(),
        h_process: null_mut(),
    };

    unsafe { ShellExecuteExW(&mut sei) != 0 }
}

#[cfg(not(target_os = "windows"))]
pub fn open_os_properties(_path: &Path) -> bool {
    false
}

/// Opens the native OS Properties dialog for one or multiple selected paths on Windows.
/// - Single path: `ShellExecuteExW` (`"properties"`).
/// - Multiple paths in the same folder: `SHCreateDataObject` + `SHMultiFileProperties`
///   (matches Windows Explorer & MDIE multi-selection Properties showing total files, folders & bytes).
/// Returns `true` if the OS dialog was launched, `false` to fall back to MINE's in-app Properties modal.
#[cfg(target_os = "windows")]
pub fn open_os_properties_many(paths: &[PathBuf]) -> bool {
    if paths.is_empty() {
        return false;
    }
    if paths.len() == 1 {
        return open_os_properties(&paths[0]);
    }
    let Some(first_parent) = paths[0].parent() else {
        return false;
    };
    if first_parent.as_os_str().is_empty()
        || !paths.iter().all(|p| p.parent() == Some(first_parent))
    {
        return false;
    }

    use std::ffi::{c_void, OsStr};
    use std::os::windows::ffi::OsStrExt;
    use std::ptr::null_mut;

    #[repr(C)]
    struct Guid {
        data1: u32,
        data2: u16,
        data3: u16,
        data4: [u8; 8],
    }

    const IID_IDATA_OBJECT: Guid = Guid {
        data1: 0x0000_010e,
        data2: 0x0000,
        data3: 0x0000,
        data4: [0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46],
    };
    const COINIT_APARTMENTTHREADED: u32 = 0x2;

    #[link(name = "kernel32")]
    extern "system" {
        fn LoadLibraryW(lp_lib_file_name: *const u16) -> *mut c_void;
        fn GetProcAddress(h_module: *mut c_void, lp_proc_name: *const u8) -> *mut c_void;
    }

    #[link(name = "ole32")]
    extern "system" {
        fn CoInitializeEx(pv_reserved: *mut c_void, dw_coinit: u32) -> i32;
        fn CoUninitialize();
    }

    fn to_wide_z(s: &OsStr) -> Vec<u16> {
        s.encode_wide().chain(std::iter::once(0)).collect()
    }

    unsafe {
        let shell_name: Vec<u16> = OsStr::new("shell32.dll")
            .encode_wide()
            .chain(Some(0))
            .collect();
        let h_shell = LoadLibraryW(shell_name.as_ptr());
        if h_shell.is_null() {
            return false;
        }
        let p_il_create = GetProcAddress(h_shell, b"ILCreateFromPathW\0".as_ptr());
        let p_il_find_last = GetProcAddress(h_shell, b"ILFindLastID\0".as_ptr());
        let p_il_free = GetProcAddress(h_shell, b"ILFree\0".as_ptr());
        let p_create_do = GetProcAddress(h_shell, b"SHCreateDataObject\0".as_ptr());
        let p_multi_props = GetProcAddress(h_shell, b"SHMultiFileProperties\0".as_ptr());
        if p_il_create.is_null()
            || p_il_find_last.is_null()
            || p_il_free.is_null()
            || p_create_do.is_null()
            || p_multi_props.is_null()
        {
            return false;
        }

        let il_create: unsafe extern "system" fn(*const u16) -> *mut c_void =
            std::mem::transmute(p_il_create);
        let il_find_last: unsafe extern "system" fn(*const c_void) -> *const c_void =
            std::mem::transmute(p_il_find_last);
        let il_free: unsafe extern "system" fn(*mut c_void) = std::mem::transmute(p_il_free);
        let sh_create_data_object: unsafe extern "system" fn(
            *const c_void,
            u32,
            *const *const c_void,
            *mut c_void,
            *const Guid,
            *mut *mut c_void,
        ) -> i32 = std::mem::transmute(p_create_do);
        let sh_multi_file_properties: unsafe extern "system" fn(*mut c_void, u32) -> i32 =
            std::mem::transmute(p_multi_props);

        let hr_co = CoInitializeEx(null_mut(), COINIT_APARTMENTTHREADED);
        let did_co_init = hr_co >= 0;

        let parent_w = to_wide_z(first_parent.as_os_str());
        let pidl_parent = il_create(parent_w.as_ptr());
        if pidl_parent.is_null() {
            if did_co_init {
                CoUninitialize();
            }
            return false;
        }

        let mut pidl_items: Vec<*mut c_void> = Vec::with_capacity(paths.len());
        let mut child_ptrs: Vec<*const c_void> = Vec::with_capacity(paths.len());
        for p in paths {
            let pw = to_wide_z(p.as_os_str());
            let pidl = il_create(pw.as_ptr());
            if !pidl.is_null() {
                let last = il_find_last(pidl);
                if !last.is_null() {
                    child_ptrs.push(last);
                }
                pidl_items.push(pidl);
            }
        }

        let mut launched = false;
        if !child_ptrs.is_empty() {
            let mut data_obj: *mut c_void = null_mut();
            let hr = sh_create_data_object(
                pidl_parent,
                child_ptrs.len() as u32,
                child_ptrs.as_ptr(),
                null_mut(),
                &IID_IDATA_OBJECT,
                &mut data_obj,
            );
            if hr >= 0 && !data_obj.is_null() {
                let hr_props = sh_multi_file_properties(data_obj, 0);
                launched = hr_props >= 0;
                let vtbl = *(data_obj as *const *const *mut c_void);
                let release_fn: unsafe extern "system" fn(*mut c_void) -> u32 =
                    std::mem::transmute(*vtbl.add(2));
                let _ = release_fn(data_obj);
            }
        }

        for pidl in pidl_items {
            il_free(pidl);
        }
        il_free(pidl_parent);
        if did_co_init {
            CoUninitialize();
        }
        launched
    }
}

#[cfg(not(target_os = "windows"))]
pub fn open_os_properties_many(_paths: &[PathBuf]) -> bool {
    false
}

/// On macOS, opens Finder's native Get Info window for a file or folder.
#[cfg(target_os = "macos")]
pub fn open_macos_get_info(path: &Path) {
    let _ = std::process::Command::new("osascript")
        .args([
            "-e",
            "on run argv",
            "-e",
            "tell application \"Finder\"",
            "-e",
            "activate",
            "-e",
            "open information window of (POSIX file (item 1 of argv) as alias)",
            "-e",
            "end tell",
            "-e",
            "end run",
            "--",
        ])
        .arg(path)
        .spawn();
}

#[cfg(not(target_os = "macos"))]
pub fn open_macos_get_info(_path: &Path) {}

#[derive(Debug, Clone)]
pub struct PropertiesStats {
    pub total_bytes: u64,
    pub file_count: u64,
    pub folder_count: u64,
    pub is_complete: bool,
}

/// Spawns a background thread to recursively compute total size, file count, and folder count
/// for one or multiple selected paths in the Properties modal without blocking the UI thread.
pub fn spawn_properties_stats_many(paths: Vec<PathBuf>) -> Receiver<PropertiesStats> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let mut total_bytes: u64 = 0;
        let mut file_count: u64 = 0;
        let mut folder_count: u64 = 0;
        let is_multi = paths.len() > 1;
        let mut stack: Vec<PathBuf> = Vec::new();

        for path in paths {
            if let Ok(meta) = std::fs::symlink_metadata(&path) {
                let ft = meta.file_type();
                if ft.is_symlink() {
                    continue;
                }
                if ft.is_dir() {
                    if is_multi {
                        folder_count += 1;
                    }
                    stack.push(path);
                } else if ft.is_file() {
                    file_count += 1;
                    total_bytes = total_bytes.saturating_add(meta.len());
                }
            }
        }

        if stack.is_empty() {
            let _ = tx.send(PropertiesStats {
                total_bytes,
                file_count,
                folder_count,
                is_complete: true,
            });
            return;
        }

        let mut steps = 0usize;
        while let Some(dir) = stack.pop() {
            if let Ok(rd) = std::fs::read_dir(&dir) {
                for entry in rd.flatten() {
                    if let Ok(ft) = entry.file_type() {
                        if ft.is_symlink() {
                            continue;
                        }
                        if ft.is_dir() {
                            folder_count += 1;
                            stack.push(entry.path());
                        } else if ft.is_file() {
                            file_count += 1;
                            if let Ok(m) = entry.metadata() {
                                total_bytes = total_bytes.saturating_add(m.len());
                            }
                        }
                    }
                    steps += 1;
                    if steps % 400 == 0 {
                        if tx
                            .send(PropertiesStats {
                                total_bytes,
                                file_count,
                                folder_count,
                                is_complete: false,
                            })
                            .is_err()
                        {
                            return;
                        }
                    }
                }
            }
        }

        let _ = tx.send(PropertiesStats {
            total_bytes,
            file_count,
            folder_count,
            is_complete: true,
        });
    });
    rx
}

#[allow(dead_code)]
pub fn spawn_properties_stats(path: PathBuf) -> Receiver<PropertiesStats> {
    spawn_properties_stats_many(vec![path])
}

/// Decodes and downscales an image, video frame, or audio album cover to RGBA8 bytes for fast grid thumbnail caching.
pub fn load_thumbnail_rgba(path: &Path, max_dim: u32) -> Option<(usize, usize, Vec<u8>)> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .map(|s| s.to_ascii_lowercase())?;
    if crate::media::is_media_ext(&ext) {
        return crate::media::extract_media_thumbnail_rgba(path, max_dim);
    }
    if !crate::media::is_image_thumb_ext(&ext) {
        return None;
    }
    let meta = std::fs::metadata(path).ok()?;
    if meta.len() > 64 * 1024 * 1024 {
        return None;
    }
    // Native zero-overhead OS thumbnail extraction for HEIC / HEIF / AVIF
    // (macOS ImageIO reads embedded EXIF/HEIF thumbnails in ~1ms; Windows reads Shell thumbcache / WIC)
    if matches!(ext.as_str(), "heic" | "heif") {
        return crate::media::extract_os_image_thumbnail_rgba(path, max_dim, true);
    }
    if ext == "avif" {
        if let Some(rgba) = crate::media::extract_os_image_thumbnail_rgba(path, max_dim, true) {
            return Some(rgba);
        }
    }
    let mut reader = image::ImageReader::open(path)
        .ok()?
        .with_guessed_format()
        .ok()?;
    if reader.format().is_none() {
        if let Some(fmt) = image::ImageFormat::from_extension(&ext) {
            reader.set_format(fmt);
        } else {
            return None;
        }
    }
    let mut limits = image::Limits::default();
    limits.max_image_width = Some(16_384);
    limits.max_image_height = Some(16_384);
    limits.max_alloc = Some(128 * 1024 * 1024);
    reader.limits(limits);
    let img = reader.decode().ok()?;
    let thumb = img.thumbnail(max_dim, max_dim);
    let rgba = thumb.to_rgba8();
    let (w, h) = rgba.dimensions();
    Some((w as usize, h as usize, rgba.into_raw()))
}

fn clear_readonly_flag(path: &std::path::Path) {
    if let Ok(meta) = std::fs::symlink_metadata(path) {
        let mut perms = meta.permissions();
        if perms.readonly() {
            perms.set_readonly(false);
            let _ = std::fs::set_permissions(path, perms);
        }
    }
}

fn clear_readonly_recursive(path: &std::path::Path) {
    clear_readonly_flag(path);
    if let Ok(meta) = std::fs::symlink_metadata(path) {
        if meta.is_dir() && !meta.file_type().is_symlink() {
            if let Ok(entries) = std::fs::read_dir(path) {
                for entry in entries.flatten() {
                    clear_readonly_recursive(&entry.path());
                }
            }
        }
    }
}

/// Permanently deletes a file, symlink, or directory tree, bypassing Trash/Recycle Bin.
/// Retries after clearing read-only flags if initial deletion fails due to permissions.
pub fn remove_path_permanent(path: &std::path::Path) -> std::io::Result<()> {
    let meta = std::fs::symlink_metadata(path)?;
    if meta.file_type().is_symlink() {
        return std::fs::remove_file(path).or_else(|e| {
            clear_readonly_flag(path);
            std::fs::remove_file(path).or_else(|_| std::fs::remove_dir(path).map_err(|_| e))
        });
    }
    if meta.is_dir() {
        match std::fs::remove_dir_all(path) {
            Ok(()) => Ok(()),
            Err(_) => {
                clear_readonly_recursive(path);
                std::fs::remove_dir_all(path)
            }
        }
    } else {
        match std::fs::remove_file(path) {
            Ok(()) => Ok(()),
            Err(_) => {
                clear_readonly_flag(path);
                std::fs::remove_file(path)
            }
        }
    }
}

#[cfg(target_os = "windows")]
mod win_clipboard {
    use std::ffi::{c_void, OsString};
    use std::os::windows::ffi::OsStringExt;
    use std::path::PathBuf;
    use std::ptr::null_mut;

    const CF_HDROP: u32 = 15;
    const GHND: u32 = 0x0042;
    const DROPEFFECT_COPY: u32 = 1;
    const DROPEFFECT_MOVE: u32 = 2;

    const VK_SHIFT: i32 = 0x10;
    const VK_CONTROL: i32 = 0x11;
    const VK_MENU: i32 = 0x12;
    const VK_DELETE: i32 = 0x2E;
    const VK_V: i32 = 0x56;
    const VK_LWIN: i32 = 0x5B;
    const VK_RWIN: i32 = 0x5C;

    #[repr(C)]
    struct DropFiles {
        p_files: u32,
        pt_x: i32,
        pt_y: i32,
        f_nc: i32,
        f_wide: i32,
    }

    #[link(name = "user32")]
    extern "system" {
        fn OpenClipboard(h_wnd_new_owner: *mut c_void) -> i32;
        fn CloseClipboard() -> i32;
        fn EmptyClipboard() -> i32;
        fn GetClipboardData(u_format: u32) -> *mut c_void;
        fn SetClipboardData(u_format: u32, h_mem: *mut c_void) -> *mut c_void;
        fn IsClipboardFormatAvailable(format: u32) -> i32;
        fn RegisterClipboardFormatW(lpsz_format: *const u16) -> u32;
        fn GetAsyncKeyState(v_key: i32) -> i16;
        fn GetActiveWindow() -> *mut c_void;
        fn GetForegroundWindow() -> *mut c_void;
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn GlobalAlloc(u_flags: u32, dw_bytes: usize) -> *mut c_void;
        fn GlobalLock(h_mem: *mut c_void) -> *mut c_void;
        fn GlobalUnlock(h_mem: *mut c_void) -> i32;
        fn GlobalFree(h_mem: *mut c_void) -> *mut c_void;
    }

    #[link(name = "shell32")]
    extern "system" {
        fn DragQueryFileW(
            h_drop: *mut c_void,
            i_file: u32,
            lpsz_file: *mut u16,
            cch: u32,
        ) -> u32;
    }

    struct ClipboardGuard;
    impl ClipboardGuard {
        fn open() -> Option<Self> {
            let owner = unsafe {
                let act = GetActiveWindow();
                if !act.is_null() {
                    act
                } else {
                    GetForegroundWindow()
                }
            };
            for attempt in 0..4 {
                if unsafe { OpenClipboard(owner) } != 0 {
                    return Some(Self);
                }
                if attempt < 3 {
                    std::thread::sleep(std::time::Duration::from_millis(5));
                }
            }
            None
        }
    }
    impl Drop for ClipboardGuard {
        fn drop(&mut self) {
            unsafe {
                CloseClipboard();
            }
        }
    }

    fn preferred_drop_effect_format() -> u32 {
        let name: Vec<u16> = "Preferred DropEffect\0".encode_utf16().collect();
        unsafe { RegisterClipboardFormatW(name.as_ptr()) }
    }

    pub fn has_file_clipboard() -> bool {
        unsafe { IsClipboardFormatAvailable(CF_HDROP) != 0 }
    }

    pub fn set_file_clipboard(paths: &[PathBuf], is_cut: bool) -> bool {
        if paths.is_empty() {
            return false;
        }
        let mut wide_chars: Vec<u16> = Vec::new();
        for p in paths {
            let s = p.as_os_str().to_string_lossy();
            let clean = if let Some(stripped) = s.strip_prefix(r"\\?\UNC\") {
                format!(r"\\{}", stripped)
            } else if let Some(stripped) = s.strip_prefix(r"\\?\") {
                stripped.to_string()
            } else {
                s.into_owned()
            };
            wide_chars.extend(clean.encode_utf16());
            wide_chars.push(0);
        }
        wide_chars.push(0);

        let header_size = std::mem::size_of::<DropFiles>();
        let data_bytes = wide_chars.len() * std::mem::size_of::<u16>();
        let total_bytes = header_size + data_bytes;

        unsafe {
            let h_drop = GlobalAlloc(GHND, total_bytes);
            if h_drop.is_null() {
                return false;
            }
            let ptr = GlobalLock(h_drop) as *mut u8;
            if ptr.is_null() {
                GlobalFree(h_drop);
                return false;
            }
            let header = DropFiles {
                p_files: header_size as u32,
                pt_x: 0,
                pt_y: 0,
                f_nc: 0,
                f_wide: 1,
            };
            std::ptr::copy_nonoverlapping(&header as *const DropFiles as *const u8, ptr, header_size);
            std::ptr::copy_nonoverlapping(
                wide_chars.as_ptr() as *const u8,
                ptr.add(header_size),
                data_bytes,
            );
            GlobalUnlock(h_drop);

            let mut h_effect = GlobalAlloc(GHND, std::mem::size_of::<u32>());
            if !h_effect.is_null() {
                let eff_ptr = GlobalLock(h_effect) as *mut u32;
                if !eff_ptr.is_null() {
                    *eff_ptr = if is_cut { DROPEFFECT_MOVE } else { DROPEFFECT_COPY };
                    GlobalUnlock(h_effect);
                } else {
                    GlobalFree(h_effect);
                    h_effect = null_mut();
                }
            }

            let Some(_guard) = ClipboardGuard::open() else {
                GlobalFree(h_drop);
                if !h_effect.is_null() {
                    GlobalFree(h_effect);
                }
                return false;
            };

            EmptyClipboard();
            let set_res = SetClipboardData(CF_HDROP, h_drop);
            if set_res.is_null() {
                GlobalFree(h_drop);
                if !h_effect.is_null() {
                    GlobalFree(h_effect);
                }
                return false;
            }

            if !h_effect.is_null() {
                let eff_fmt = preferred_drop_effect_format();
                if eff_fmt != 0 {
                    if SetClipboardData(eff_fmt, h_effect).is_null() {
                        GlobalFree(h_effect);
                    }
                } else {
                    GlobalFree(h_effect);
                }
            }
            true
        }
    }

    pub fn get_file_clipboard() -> Option<(Vec<PathBuf>, bool)> {
        if !has_file_clipboard() {
            return None;
        }
        let _guard = ClipboardGuard::open()?;
        unsafe {
            let h_drop = GetClipboardData(CF_HDROP);
            if h_drop.is_null() {
                return None;
            }
            let count = DragQueryFileW(h_drop, 0xFFFF_FFFF, null_mut(), 0);
            if count == 0 {
                return None;
            }
            let mut paths = Vec::with_capacity(count as usize);
            for idx in 0..count {
                let len = DragQueryFileW(h_drop, idx, null_mut(), 0);
                if len == 0 {
                    continue;
                }
                let mut buf = vec![0u16; (len + 1) as usize];
                let copied = DragQueryFileW(h_drop, idx, buf.as_mut_ptr(), len + 1);
                if copied > 0 {
                    let os = OsString::from_wide(&buf[..copied as usize]);
                    paths.push(PathBuf::from(os));
                }
            }
            if paths.is_empty() {
                return None;
            }

            let mut is_cut = false;
            let eff_fmt = preferred_drop_effect_format();
            if eff_fmt != 0 && IsClipboardFormatAvailable(eff_fmt) != 0 {
                let h_eff = GetClipboardData(eff_fmt);
                if !h_eff.is_null() {
                    let eff_ptr = GlobalLock(h_eff) as *const u32;
                    if !eff_ptr.is_null() {
                        let eff = *eff_ptr;
                        is_cut = (eff & DROPEFFECT_MOVE != 0) && (eff & DROPEFFECT_COPY == 0);
                        GlobalUnlock(h_eff);
                    }
                }
            }
            Some((paths, is_cut))
        }
    }

    pub fn clear_file_clipboard() {
        if let Some(_guard) = ClipboardGuard::open() {
            unsafe {
                EmptyClipboard();
            }
        }
    }

    pub fn is_ctrl_v_down() -> bool {
        unsafe {
            let ctrl = GetAsyncKeyState(VK_CONTROL) < 0;
            let v = GetAsyncKeyState(VK_V) < 0;
            if !(ctrl && v) {
                return false;
            }
            let alt = GetAsyncKeyState(VK_MENU) < 0;
            let shift = GetAsyncKeyState(VK_SHIFT) < 0;
            let lwin = GetAsyncKeyState(VK_LWIN) < 0;
            let rwin = GetAsyncKeyState(VK_RWIN) < 0;
            !alt && !shift && !lwin && !rwin
        }
    }

    pub fn is_shift_delete_down() -> bool {
        unsafe {
            let shift = GetAsyncKeyState(VK_SHIFT) < 0;
            let del = GetAsyncKeyState(VK_DELETE) < 0;
            if !(shift && del) {
                return false;
            }
            let ctrl = GetAsyncKeyState(VK_CONTROL) < 0;
            let alt = GetAsyncKeyState(VK_MENU) < 0;
            let lwin = GetAsyncKeyState(VK_LWIN) < 0;
            let rwin = GetAsyncKeyState(VK_RWIN) < 0;
            !ctrl && !alt && !lwin && !rwin
        }
    }
}

#[cfg(target_os = "macos")]
mod macos_clipboard {
    use std::ffi::{c_char, c_int, CString};
    use std::path::PathBuf;

    extern "C" {
        fn mine_macos_has_file_clipboard() -> c_int;
        fn mine_macos_set_file_clipboard(
            paths_utf8: *const *const c_char,
            count: c_int,
            is_cut: c_int,
        ) -> c_int;
        fn mine_macos_get_file_clipboard(
            out_buf: *mut *mut u8,
            out_len: *mut c_int,
            out_is_cut: *mut c_int,
        ) -> c_int;
        fn mine_macos_clear_file_clipboard();
        fn mine_macos_free_buffer(ptr: *mut u8);
        fn mine_macos_is_paste_shortcut_down(out_force_move: *mut c_int) -> c_int;
        #[cfg(test)]
        fn mine_macos_test_pasteboard_roundtrip(
            paths_utf8: *const *const c_char,
            count: c_int,
            is_cut: c_int,
            out_buf: *mut *mut u8,
            out_len: *mut c_int,
            out_is_cut: *mut c_int,
        ) -> c_int;
    }

    pub fn has_file_clipboard() -> bool {
        unsafe { mine_macos_has_file_clipboard() != 0 }
    }

    pub fn set_file_clipboard(paths: &[PathBuf], is_cut: bool) -> bool {
        let cstrings: Vec<CString> = paths
            .iter()
            .filter_map(|p| CString::new(p.to_string_lossy().as_bytes()).ok())
            .collect();
        if cstrings.is_empty() {
            return false;
        }
        let ptrs: Vec<*const c_char> = cstrings.iter().map(|s| s.as_ptr()).collect();
        unsafe {
            mine_macos_set_file_clipboard(
                ptrs.as_ptr(),
                ptrs.len() as c_int,
                if is_cut { 1 } else { 0 },
            ) != 0
        }
    }

    pub unsafe fn decode_and_free_pb_paths(
        buf_ptr: *mut u8,
        len: c_int,
        is_cut_raw: c_int,
    ) -> Option<(Vec<PathBuf>, bool)> {
        if buf_ptr.is_null() || len <= 0 {
            if !buf_ptr.is_null() {
                mine_macos_free_buffer(buf_ptr);
            }
            return None;
        }
        let slice = std::slice::from_raw_parts(buf_ptr, len as usize);
        let paths: Vec<PathBuf> = slice
            .split(|&b| b == 0)
            .filter(|seg| !seg.is_empty())
            .map(|seg| PathBuf::from(String::from_utf8_lossy(seg).into_owned()))
            .collect();
        mine_macos_free_buffer(buf_ptr);
        if paths.is_empty() {
            None
        } else {
            Some((paths, is_cut_raw != 0))
        }
    }

    pub fn get_file_clipboard() -> Option<(Vec<PathBuf>, bool)> {
        let mut buf_ptr: *mut u8 = std::ptr::null_mut();
        let mut len: c_int = 0;
        let mut is_cut_raw: c_int = 0;
        let ok = unsafe { mine_macos_get_file_clipboard(&mut buf_ptr, &mut len, &mut is_cut_raw) };
        if ok == 0 {
            unsafe {
                if !buf_ptr.is_null() {
                    mine_macos_free_buffer(buf_ptr);
                }
            }
            return None;
        }
        unsafe { decode_and_free_pb_paths(buf_ptr, len, is_cut_raw) }
    }

    pub fn clear_file_clipboard() {
        unsafe { mine_macos_clear_file_clipboard() };
    }

    pub fn is_paste_shortcut_down() -> (bool, bool) {
        let mut force_move: c_int = 0;
        let down = unsafe { mine_macos_is_paste_shortcut_down(&mut force_move) != 0 };
        (down, force_move != 0)
    }

    #[cfg(test)]
    pub fn test_pasteboard_roundtrip(
        paths: &[PathBuf],
        is_cut: bool,
    ) -> Option<(Vec<PathBuf>, bool)> {
        let cstrings: Vec<CString> = paths
            .iter()
            .filter_map(|p| CString::new(p.to_string_lossy().as_bytes()).ok())
            .collect();
        let ptrs: Vec<*const c_char> = cstrings.iter().map(|s| s.as_ptr()).collect();
        let mut buf_ptr: *mut u8 = std::ptr::null_mut();
        let mut len: c_int = 0;
        let mut is_cut_raw: c_int = 0;
        let ok = unsafe {
            mine_macos_test_pasteboard_roundtrip(
                ptrs.as_ptr(),
                ptrs.len() as c_int,
                if is_cut { 1 } else { 0 },
                &mut buf_ptr,
                &mut len,
                &mut is_cut_raw,
            )
        };
        if ok == 0 {
            unsafe {
                if !buf_ptr.is_null() {
                    mine_macos_free_buffer(buf_ptr);
                }
            }
            return None;
        }
        unsafe { decode_and_free_pb_paths(buf_ptr, len, is_cut_raw) }
    }
}

pub fn has_os_file_clipboard() -> bool {
    #[cfg(target_os = "windows")]
    {
        win_clipboard::has_file_clipboard()
    }
    #[cfg(target_os = "macos")]
    {
        macos_clipboard::has_file_clipboard()
    }
    #[cfg(not(any(target_os = "windows", target_os = "macos")))]
    {
        false
    }
}

pub fn set_os_file_clipboard(paths: &[std::path::PathBuf], is_cut: bool) -> bool {
    #[cfg(target_os = "windows")]
    {
        win_clipboard::set_file_clipboard(paths, is_cut)
    }
    #[cfg(target_os = "macos")]
    {
        macos_clipboard::set_file_clipboard(paths, is_cut)
    }
    #[cfg(not(any(target_os = "windows", target_os = "macos")))]
    {
        let _ = (paths, is_cut);
        false
    }
}

pub fn get_os_file_clipboard() -> Option<(Vec<std::path::PathBuf>, bool)> {
    #[cfg(target_os = "windows")]
    {
        win_clipboard::get_file_clipboard()
    }
    #[cfg(target_os = "macos")]
    {
        macos_clipboard::get_file_clipboard()
    }
    #[cfg(not(any(target_os = "windows", target_os = "macos")))]
    {
        None
    }
}

pub fn clear_os_file_clipboard() {
    #[cfg(target_os = "windows")]
    {
        win_clipboard::clear_file_clipboard();
    }
    #[cfg(target_os = "macos")]
    {
        macos_clipboard::clear_file_clipboard();
    }
}

/// Returns `(paste_pressed, force_move)` where `force_move` is `true` for macOS `Cmd+Option+V`.
pub fn is_os_paste_shortcut_down() -> (bool, bool) {
    #[cfg(target_os = "windows")]
    {
        (win_clipboard::is_ctrl_v_down(), false)
    }
    #[cfg(target_os = "macos")]
    {
        macos_clipboard::is_paste_shortcut_down()
    }
    #[cfg(not(any(target_os = "windows", target_os = "macos")))]
    {
        (false, false)
    }
}

pub fn is_win_shift_delete_down() -> bool {
    #[cfg(target_os = "windows")]
    {
        win_clipboard::is_shift_delete_down()
    }
    #[cfg(not(target_os = "windows"))]
    {
        false
    }
}

#[cfg(target_os = "windows")]
mod win_window {
    use std::ffi::c_void;
    use std::ptr::null_mut;

    const GWL_STYLE: i32 = -16;
    const GW_OWNER: u32 = 4;
    const WS_CAPTION: u32 = 0x00C0_0000;
    const SW_SHOW: i32 = 5;
    const SW_RESTORE: i32 = 9;
    const MONITOR_DEFAULTTONEAREST: u32 = 2;
    const SWP_NOZORDER: u32 = 0x0004;
    const SWP_SHOWWINDOW: u32 = 0x0040;

    #[repr(C)]
    #[derive(Default, Copy, Clone)]
    struct RectW {
        left: i32,
        top: i32,
        right: i32,
        bottom: i32,
    }

    #[repr(C)]
    #[derive(Copy, Clone)]
    struct MonitorInfoW {
        cb_size: u32,
        rc_monitor: RectW,
        rc_work: RectW,
        dw_flags: u32,
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn GetCurrentThreadId() -> u32;
    }

    #[link(name = "user32")]
    extern "system" {
        fn EnumThreadWindows(
            dw_thread_id: u32,
            lpfn: extern "system" fn(*mut c_void, isize) -> i32,
            l_param: isize,
        ) -> i32;
        fn GetWindow(h_wnd: *mut c_void, u_cmd: u32) -> *mut c_void;
        fn GetWindowLongW(h_wnd: *mut c_void, n_index: i32) -> i32;
        fn GetWindowTextW(h_wnd: *mut c_void, lp_string: *mut u16, n_max_count: i32) -> i32;
        fn IsIconic(h_wnd: *mut c_void) -> i32;
        fn IsWindowVisible(h_wnd: *mut c_void) -> i32;
        fn ShowWindow(h_wnd: *mut c_void, n_cmd_show: i32) -> i32;
        fn GetWindowRect(h_wnd: *mut c_void, lp_rect: *mut RectW) -> i32;
        fn MonitorFromRect(lprc: *const RectW, dw_flags: u32) -> *mut c_void;
        fn GetMonitorInfoW(h_monitor: *mut c_void, lpmi: *mut MonitorInfoW) -> i32;
        fn SetWindowPos(
            h_wnd: *mut c_void,
            h_wnd_insert_after: *mut c_void,
            x: i32,
            y: i32,
            cx: i32,
            cy: i32,
            u_flags: u32,
        ) -> i32;
        fn BringWindowToTop(h_wnd: *mut c_void) -> i32;
        fn SetForegroundWindow(h_wnd: *mut c_void) -> i32;
    }

    extern "system" fn enum_thread_wnd_proc(hwnd: *mut c_void, _lparam: isize) -> i32 {
        unsafe {
            if !GetWindow(hwnd, GW_OWNER).is_null() {
                return 1;
            }
            let style = GetWindowLongW(hwnd, GWL_STYLE) as u32;
            if (style & WS_CAPTION) != WS_CAPTION {
                return 1;
            }
            let mut title_buf = [0u16; 64];
            let len = GetWindowTextW(hwnd, title_buf.as_mut_ptr(), title_buf.len() as i32);
            if len <= 0 {
                return 1;
            }
            let title = String::from_utf16_lossy(&title_buf[..len as usize]);
            if !title.starts_with("MINE") {
                return 1;
            }

            if IsIconic(hwnd) != 0 {
                ShowWindow(hwnd, SW_RESTORE);
            }
            if IsWindowVisible(hwnd) == 0 {
                ShowWindow(hwnd, SW_SHOW);
            }

            let mut rect = RectW::default();
            if GetWindowRect(hwnd, &mut rect) != 0 {
                let rect_w = rect.right - rect.left;
                let rect_h = rect.bottom - rect.top;
                let hmon = MonitorFromRect(&rect as *const RectW, MONITOR_DEFAULTTONEAREST);
                let mut mi = MonitorInfoW {
                    cb_size: std::mem::size_of::<MonitorInfoW>() as u32,
                    rc_monitor: RectW::default(),
                    rc_work: RectW::default(),
                    dw_flags: 0,
                };
                if !hmon.is_null() && GetMonitorInfoW(hmon, &mut mi as *mut MonitorInfoW) != 0 {
                    let work = mi.rc_work;
                    let inter_w = rect.right.min(work.right) - rect.left.max(work.left);
                    let inter_h = rect.bottom.min(work.bottom) - rect.top.max(work.top);
                    if rect.left <= -16000
                        || rect.top <= -16000
                        || rect_w < 320
                        || rect_h < 240
                        || inter_w < 160
                        || inter_h < 120
                    {
                        let work_w = (work.right - work.left).max(640);
                        let work_h = (work.bottom - work.top).max(480);
                        let w = work_w.min(1360).max(640);
                        let h = work_h.min(820).max(480);
                        let x = work.left + (work_w - w) / 2;
                        let y = work.top + (work_h - h) / 2;
                        SetWindowPos(
                            hwnd,
                            null_mut(),
                            x,
                            y,
                            w,
                            h,
                            SWP_NOZORDER | SWP_SHOWWINDOW,
                        );
                    }
                }
            }

            BringWindowToTop(hwnd);
            SetForegroundWindow(hwnd);
        }
        0 // stop after fixing the primary MINE window
    }

    pub fn ensure_main_window_visible() {
        unsafe {
            let tid = GetCurrentThreadId();
            EnumThreadWindows(tid, enum_thread_wnd_proc, 0);
        }
    }
}

/// Ensures the primary window on Windows is not stuck hidden, minimized, or offscreen after launch.
pub fn ensure_main_window_visible_on_windows() {
    #[cfg(target_os = "windows")]
    {
        win_window::ensure_main_window_visible();
    }
}

// ============================================================================
// Archive Utilities & Native / 7-Zip Integration
// ============================================================================

/// Returns `true` if `ext` (case-insensitive, optional leading `.`) is a recognized archive format.
pub fn is_archive_ext(ext: &str) -> bool {
    let e = ext.trim_start_matches('.').to_ascii_lowercase();
    matches!(
        e.as_str(),
        "zip"
            | "7z"
            | "rar"
            | "tar"
            | "gz"
            | "tgz"
            | "bz2"
            | "tbz2"
            | "xz"
            | "txz"
            | "zst"
            | "cab"
            | "iso"
            | "wim"
            | "lzma"
            | "arj"
            | "lzh"
            | "jar"
            | "apk"
            | "xpi"
    )
}

/// Computes the target folder name when extracting an archive into a subfolder,
/// properly stripping compound extensions like `.tar.gz`, `.tar.xz`, `.tar.bz2`, `.tar.zst`.
pub fn archive_folder_stem(path: &Path) -> String {
    let name = path
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_default();
    let lower = name.to_ascii_lowercase();
    for compound in [
        ".tar.gz",
        ".tar.xz",
        ".tar.bz2",
        ".tar.zst",
        ".tar.lzma",
    ] {
        if lower.ends_with(compound) && name.len() > compound.len() {
            return name[..name.len() - compound.len()].to_string();
        }
    }
    path.file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| "extracted".to_string())
}

#[derive(Clone, Debug)]
pub struct SevenZipPaths {
    pub gui: PathBuf,
    pub fm: Option<PathBuf>,
    pub is_gui_app: bool,
}

#[cfg(target_os = "windows")]
fn query_seven_zip_registry_dirs() -> Vec<PathBuf> {
    use std::os::windows::process::CommandExt;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    let mut dirs = Vec::new();
    for key in [r"HKLM\SOFTWARE\7-Zip", r"HKCU\SOFTWARE\7-Zip", r"HKLM\SOFTWARE\WOW6432Node\7-Zip"] {
        if let Ok(out) = std::process::Command::new("reg")
            .args(["query", key])
            .creation_flags(CREATE_NO_WINDOW)
            .output()
        {
            if out.status.success() {
                let txt = String::from_utf8_lossy(&out.stdout);
                for line in txt.lines() {
                    let trimmed = line.trim();
                    if trimmed.starts_with("Path") {
                        if let Some((_, val)) = trimmed.split_once("REG_SZ") {
                            let p = val.trim().trim_matches('"');
                            if !p.is_empty() {
                                dirs.push(PathBuf::from(p));
                            }
                        }
                    }
                }
            }
        }
    }
    dirs
}

/// Detects an installed 7-Zip distribution (preferring `7zG.exe` on Windows, `7zz`/`7z` on POSIX).
pub fn detect_seven_zip() -> Option<SevenZipPaths> {
    #[cfg(target_os = "windows")]
    {
        let mut candidate_dirs: Vec<PathBuf> = vec![
            PathBuf::from(r"C:\Program Files\7-Zip"),
            PathBuf::from(r"C:\Program Files (x86)\7-Zip"),
        ];
        for env_key in ["ProgramFiles", "ProgramW6432", "ProgramFiles(x86)"] {
            if let Ok(val) = std::env::var(env_key) {
                if !val.is_empty() {
                    candidate_dirs.push(PathBuf::from(val).join("7-Zip"));
                }
            }
        }
        if let Ok(val) = std::env::var("LOCALAPPDATA") {
            if !val.is_empty() {
                candidate_dirs.push(PathBuf::from(val).join("Programs").join("7-Zip"));
            }
        }
        candidate_dirs.extend(query_seven_zip_registry_dirs());
        if let Ok(path_env) = std::env::var("PATH") {
            for part in std::env::split_paths(&path_env) {
                candidate_dirs.push(part);
            }
        }

        // First pass: look for GUI 7zG.exe
        for dir in &candidate_dirs {
            let gui = dir.join("7zG.exe");
            if gui.is_file() {
                let fm_cand = dir.join("7zFM.exe");
                return Some(SevenZipPaths {
                    gui,
                    fm: fm_cand.is_file().then_some(fm_cand),
                    is_gui_app: true,
                });
            }
        }
        // Second pass: look for CLI 7z.exe
        for dir in &candidate_dirs {
            let cli = dir.join("7z.exe");
            if cli.is_file() {
                let fm_cand = dir.join("7zFM.exe");
                return Some(SevenZipPaths {
                    gui: cli,
                    fm: fm_cand.is_file().then_some(fm_cand),
                    is_gui_app: false,
                });
            }
        }
        None
    }

    #[cfg(not(target_os = "windows"))]
    {
        let mut candidates = vec![
            PathBuf::from("/opt/homebrew/bin/7zz"),
            PathBuf::from("/usr/local/bin/7zz"),
            PathBuf::from("/opt/homebrew/bin/7z"),
            PathBuf::from("/usr/local/bin/7z"),
            PathBuf::from("/usr/bin/7zz"),
            PathBuf::from("/usr/bin/7z"),
            PathBuf::from("/usr/bin/7za"),
        ];
        if let Ok(path_env) = std::env::var("PATH") {
            for dir in std::env::split_paths(&path_env) {
                candidates.push(dir.join("7zz"));
                candidates.push(dir.join("7z"));
                candidates.push(dir.join("7za"));
            }
        }
        for c in candidates {
            if c.is_file() {
                return Some(SevenZipPaths {
                    gui: c,
                    fm: None,
                    is_gui_app: false,
                });
            }
        }
        None
    }
}

pub fn spawn_detect_seven_zip() -> Receiver<Option<SevenZipPaths>> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let _ = tx.send(detect_seven_zip());
    });
    rx
}

#[derive(Clone, Debug)]
pub enum ArchiveAction {
    OpenArchive(PathBuf),
    ExtractDialog { archive: PathBuf, dest_dir: PathBuf },
    ExtractHere { archive: PathBuf, dest_dir: PathBuf },
    ExtractToSubdir { archive: PathBuf, subdir: PathBuf },
    TestArchive(PathBuf),
    AddDialog { targets: Vec<PathBuf>, out_archive: PathBuf },
    AddArchive { targets: Vec<PathBuf>, out_archive: PathBuf, zip_format: bool },
}

fn spawn_and_wait_cmd(mut cmd: std::process::Command, hide_console: bool) -> Result<Option<i32>, String> {
    #[cfg(target_os = "windows")]
    if hide_console {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x0800_0000);
    }
    #[cfg(not(target_os = "windows"))]
    let _ = hide_console;

    cmd.stdin(std::process::Stdio::null());
    let output = cmd.output().map_err(|e| e.to_string())?;
    let code = output.status.code();
    if output.status.success() {
        Ok(code)
    } else if code == Some(255) {
        // 7-Zip user-cancelled GUI dialog
        Ok(code)
    } else {
        let stderr = String::from_utf8_lossy(&output.stderr).trim().to_string();
        let stdout = String::from_utf8_lossy(&output.stdout).trim().to_string();
        let detail = if !stderr.is_empty() { stderr } else { stdout };
        if detail.is_empty() {
            Err(format!("Exit code {:?}", code))
        } else {
            Err(detail)
        }
    }
}

#[cfg(target_os = "windows")]
fn ps_single_quote_escape(p: &Path) -> String {
    p.to_string_lossy().replace('\'', "''")
}

/// Executes an archive extraction, test, or compression operation asynchronously on a background thread.
/// Returns `(directory_to_reload, Result<status_toast, error_message>)`.
pub fn spawn_archive_action(
    action: ArchiveAction,
    sz: Option<SevenZipPaths>,
    zh_tw: bool,
) -> Receiver<(PathBuf, Result<String, String>)> {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        let res = run_archive_action_blocking(&action, sz.as_ref(), zh_tw);
        let reload_dir = match &action {
            ArchiveAction::OpenArchive(a) | ArchiveAction::TestArchive(a) => {
                a.parent().map(|p| p.to_path_buf()).unwrap_or_default()
            }
            ArchiveAction::ExtractDialog { dest_dir, .. }
            | ArchiveAction::ExtractHere { dest_dir, .. } => dest_dir.clone(),
            ArchiveAction::ExtractToSubdir { subdir, .. } => {
                subdir.parent().map(|p| p.to_path_buf()).unwrap_or_else(|| subdir.clone())
            }
            ArchiveAction::AddDialog { out_archive, .. }
            | ArchiveAction::AddArchive { out_archive, .. } => {
                out_archive.parent().map(|p| p.to_path_buf()).unwrap_or_default()
            }
        };
        let _ = tx.send((reload_dir, res));
    });
    rx
}

fn run_archive_action_blocking(
    action: &ArchiveAction,
    sz: Option<&SevenZipPaths>,
    zh_tw: bool,
) -> Result<String, String> {
    match action {
        ArchiveAction::OpenArchive(archive) => {
            if let Some(sz) = sz {
                if let Some(ref fm) = sz.fm {
                    std::process::Command::new(fm)
                        .arg(archive)
                        .spawn()
                        .map_err(|e| e.to_string())?;
                    return Ok(if zh_tw {
                        format!("📦 已用 7-Zip 開啟: {}", archive.file_name().unwrap_or_default().to_string_lossy())
                    } else {
                        format!("📦 Opened in 7-Zip: {}", archive.file_name().unwrap_or_default().to_string_lossy())
                    });
                }
            }
            open::that(archive).map_err(|e| e.to_string())?;
            Ok(if zh_tw {
                format!("📦 已開啟壓縮檔: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            } else {
                format!("📦 Opened archive: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            })
        }
        ArchiveAction::TestArchive(archive) => {
            let sz = sz.ok_or_else(|| {
                if zh_tw { "未偵測到 7-Zip".to_string() } else { "7-Zip not found".to_string() }
            })?;
            let mut cmd = std::process::Command::new(&sz.gui);
            cmd.arg("t").arg(archive);
            let code = spawn_and_wait_cmd(cmd, !sz.is_gui_app)?;
            if code == Some(255) {
                return Ok(if zh_tw { "⏹ 已取消測試".to_string() } else { "⏹ Test cancelled".to_string() });
            }
            Ok(if zh_tw {
                format!("✔ 壓縮檔測試通過: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            } else {
                format!("✔ Archive test passed: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            })
        }
        ArchiveAction::ExtractDialog { archive, dest_dir } => {
            let sz = sz.ok_or_else(|| {
                if zh_tw { "未偵測到 7-Zip".to_string() } else { "7-Zip not found".to_string() }
            })?;
            let mut cmd = std::process::Command::new(&sz.gui);
            cmd.arg("x")
                .arg(archive)
                .arg(format!("-o{}", dest_dir.display()))
                .arg("-ad");
            let code = spawn_and_wait_cmd(cmd, !sz.is_gui_app)?;
            if code == Some(255) {
                return Ok(if zh_tw { "⏹ 已取消解壓縮".to_string() } else { "⏹ Extraction cancelled".to_string() });
            }
            Ok(if zh_tw {
                format!("📦 解壓縮完成: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            } else {
                format!("📦 Extracted: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            })
        }
        ArchiveAction::ExtractHere { archive, dest_dir } => {
            extract_into_dir(archive, dest_dir, sz, zh_tw)
        }
        ArchiveAction::ExtractToSubdir { archive, subdir } => {
            std::fs::create_dir_all(subdir).map_err(|e| e.to_string())?;
            extract_into_dir(archive, subdir, sz, zh_tw)
        }
        ArchiveAction::AddDialog { targets, out_archive } => {
            let sz = sz.ok_or_else(|| {
                if zh_tw { "未偵測到 7-Zip".to_string() } else { "7-Zip not found".to_string() }
            })?;
            let mut cmd = std::process::Command::new(&sz.gui);
            cmd.arg("a").arg(out_archive);
            for t in targets {
                cmd.arg(t);
            }
            cmd.arg("-ad");
            let code = spawn_and_wait_cmd(cmd, !sz.is_gui_app)?;
            if code == Some(255) {
                return Ok(if zh_tw { "⏹ 已取消壓縮".to_string() } else { "⏹ Compression cancelled".to_string() });
            }
            Ok(if zh_tw {
                format!("🗜 壓縮作業完成: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
            } else {
                format!("🗜 Archive created: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
            })
        }
        ArchiveAction::AddArchive { targets, out_archive, zip_format } => {
            if let Some(sz) = sz {
                let mut cmd = std::process::Command::new(&sz.gui);
                cmd.arg("a");
                if *zip_format {
                    cmd.arg("-tzip");
                }
                cmd.arg(out_archive);
                for t in targets {
                    cmd.arg(t);
                }
                if !sz.is_gui_app {
                    cmd.arg("-y");
                }
                let code = spawn_and_wait_cmd(cmd, !sz.is_gui_app)?;
                if code == Some(255) {
                    return Ok(if zh_tw { "⏹ 已取消壓縮".to_string() } else { "⏹ Compression cancelled".to_string() });
                }
                return Ok(if zh_tw {
                    format!("🗜 已建立壓縮檔: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
                } else {
                    format!("🗜 Created: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
                });
            }

            // Built-in OS fallback (ZIP) when 7-Zip is not installed
            compress_zip_native_fallback(targets, out_archive, zh_tw)
        }
    }
}

fn extract_into_dir(
    archive: &Path,
    dest_dir: &Path,
    sz: Option<&SevenZipPaths>,
    zh_tw: bool,
) -> Result<String, String> {
    if let Some(sz) = sz {
        let mut cmd = std::process::Command::new(&sz.gui);
        cmd.arg("x")
            .arg(archive)
            .arg(format!("-o{}", dest_dir.display()));
        if !sz.is_gui_app {
            cmd.arg("-y");
        }
        let code = spawn_and_wait_cmd(cmd, !sz.is_gui_app)?;
        if code == Some(255) {
            return Ok(if zh_tw { "⏹ 已取消解壓縮".to_string() } else { "⏹ Extraction cancelled".to_string() });
        }
        return Ok(if zh_tw {
            format!("📦 解壓縮完成至: {}", dest_dir.file_name().unwrap_or_default().to_string_lossy())
        } else {
            format!("📦 Extracted to: {}", dest_dir.display())
        });
    }

    let ext = archive
        .extension()
        .map(|e| e.to_string_lossy().to_ascii_lowercase())
        .unwrap_or_default();

    #[cfg(target_os = "windows")]
    {
        let mut tar_cmd = std::process::Command::new("tar.exe");
        tar_cmd
            .arg("-xf")
            .arg(archive)
            .arg("-C")
            .arg(dest_dir);
        if spawn_and_wait_cmd(tar_cmd, true).is_ok() {
            return Ok(if zh_tw {
                format!("📦 解壓縮完成: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            } else {
                format!("📦 Extracted: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            });
        }
        if ext == "zip" {
            let script = format!(
                "Expand-Archive -LiteralPath '{}' -DestinationPath '{}' -Force",
                ps_single_quote_escape(archive),
                ps_single_quote_escape(dest_dir)
            );
            let mut ps = std::process::Command::new("powershell");
            ps.args(["-NoProfile", "-Command", &script]);
            spawn_and_wait_cmd(ps, true)?;
            return Ok(if zh_tw {
                format!("📦 ZIP 解壓縮完成: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            } else {
                format!("📦 Extracted ZIP: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            });
        }
        Err(if zh_tw {
            "此壓縮格式需安裝 7-Zip 方可解壓縮".to_string()
        } else {
            "Please install 7-Zip to extract this archive format".to_string()
        })
    }

    #[cfg(target_os = "macos")]
    {
        if ext == "zip" {
            let mut cmd = std::process::Command::new("ditto");
            cmd.arg("-x").arg("-k").arg(archive).arg(dest_dir);
            spawn_and_wait_cmd(cmd, false)?;
            return Ok(if zh_tw {
                format!("📦 解壓縮完成: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            } else {
                format!("📦 Extracted: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            });
        }
        let mut tar_cmd = std::process::Command::new("tar");
        tar_cmd.arg("-xf").arg(archive).arg("-C").arg(dest_dir);
        if spawn_and_wait_cmd(tar_cmd, false).is_ok() {
            return Ok(if zh_tw {
                format!("📦 解壓縮完成: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            } else {
                format!("📦 Extracted: {}", archive.file_name().unwrap_or_default().to_string_lossy())
            });
        }
        open::that(archive).map_err(|e| e.to_string())?;
        Ok(if zh_tw {
            format!("📦 已交由系統工具解壓縮: {}", archive.file_name().unwrap_or_default().to_string_lossy())
        } else {
            format!("📦 Opened with Archive Utility: {}", archive.file_name().unwrap_or_default().to_string_lossy())
        })
    }

    #[cfg(all(not(target_os = "windows"), not(target_os = "macos")))]
    {
        if ext == "zip" {
            let mut cmd = std::process::Command::new("unzip");
            cmd.arg("-o").arg(archive).arg("-d").arg(dest_dir);
            if spawn_and_wait_cmd(cmd, false).is_ok() {
                return Ok(if zh_tw {
                    format!("📦 解壓縮完成: {}", archive.file_name().unwrap_or_default().to_string_lossy())
                } else {
                    format!("📦 Extracted: {}", archive.file_name().unwrap_or_default().to_string_lossy())
                });
            }
        }
        let mut tar_cmd = std::process::Command::new("tar");
        tar_cmd.arg("-xf").arg(archive).arg("-C").arg(dest_dir);
        spawn_and_wait_cmd(tar_cmd, false)?;
        Ok(if zh_tw {
            format!("📦 解壓縮完成: {}", archive.file_name().unwrap_or_default().to_string_lossy())
        } else {
            format!("📦 Extracted: {}", archive.file_name().unwrap_or_default().to_string_lossy())
        })
    }
}

fn compress_zip_native_fallback(
    targets: &[PathBuf],
    out_archive: &Path,
    zh_tw: bool,
) -> Result<String, String> {
    if targets.is_empty() {
        return Err("No target files selected".to_string());
    }
    let parent_dir = targets[0]
        .parent()
        .map(|p| p.to_path_buf())
        .or_else(|| out_archive.parent().map(|p| p.to_path_buf()))
        .unwrap_or_else(|| PathBuf::from("."));
    let all_same_parent = targets
        .iter()
        .all(|t| t.parent().map(|p| p == parent_dir).unwrap_or(false));

    #[cfg(target_os = "windows")]
    {
        if all_same_parent {
            let mut cmd = std::process::Command::new("tar.exe");
            cmd.arg("-a")
                .arg("-c")
                .arg("-f")
                .arg(out_archive)
                .arg("-C")
                .arg(&parent_dir);
            for t in targets {
                if let Some(name) = t.file_name() {
                    cmd.arg(name);
                }
            }
            if spawn_and_wait_cmd(cmd, true).is_ok() {
                return Ok(if zh_tw {
                    format!("🗜 已壓縮為: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
                } else {
                    format!("🗜 Created: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
                });
            }
        }
        let quoted_paths: Vec<String> = targets
            .iter()
            .map(|p| format!("'{}'", ps_single_quote_escape(p)))
            .collect();
        let script = format!(
            "Compress-Archive -LiteralPath {} -DestinationPath '{}' -Force",
            quoted_paths.join(","),
            ps_single_quote_escape(out_archive)
        );
        let mut ps = std::process::Command::new("powershell");
        ps.args(["-NoProfile", "-Command", &script]);
        spawn_and_wait_cmd(ps, true)?;
        Ok(if zh_tw {
            format!("🗜 已壓縮為: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
        } else {
            format!("🗜 Created: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
        })
    }

    #[cfg(not(target_os = "windows"))]
    {
        let _ = all_same_parent;
        let mut cmd = std::process::Command::new("zip");
        cmd.arg("-r").arg("-q").arg(out_archive);
        if targets
            .iter()
            .all(|t| t.parent().map(|p| p == parent_dir).unwrap_or(false))
        {
            cmd.current_dir(&parent_dir);
            for t in targets {
                if let Some(name) = t.file_name() {
                    cmd.arg(name);
                }
            }
        } else {
            for t in targets {
                cmd.arg(t);
            }
        }
        spawn_and_wait_cmd(cmd, false)?;
        Ok(if zh_tw {
            format!("🗜 已壓縮為: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
        } else {
            format!("🗜 Created: {}", out_archive.file_name().unwrap_or_default().to_string_lossy())
        })
    }
}

#[cfg(all(test, target_os = "macos"))]
mod tests {
    use super::*;

    #[test]
    fn test_macos_pasteboard_file_roundtrip_cjk_and_cut() {
        let p1 = std::path::PathBuf::from("/tmp/測試 檔案.png");
        let p2 = std::path::PathBuf::from("/tmp/sub folder/doc.pdf");
        let inputs = vec![p1.clone(), p2.clone()];

        let copy_res = macos_clipboard::test_pasteboard_roundtrip(&inputs, false);
        assert_eq!(copy_res, Some((inputs.clone(), false)));

        let cut_res = macos_clipboard::test_pasteboard_roundtrip(&inputs, true);
        assert_eq!(cut_res, Some((inputs, true)));
    }

    #[test]
    fn test_macos_heic_thumbnail_and_preview_decode() {
        let tmp_dir = std::env::temp_dir().join(format!("mine_heic_test_{}", std::process::id()));
        let _ = std::fs::create_dir_all(&tmp_dir);
        let png_path = tmp_dir.join("sample.png");
        let heic_path = tmp_dir.join("sample.heic");
        let bad_heic_path = tmp_dir.join("corrupt.heic");

        // Create a tiny valid RGB PNG and convert it to a real HEIC via macOS sips
        let img = image::RgbImage::from_fn(96, 64, |x, y| {
            image::Rgb([(x * 2) as u8, (y * 3) as u8, 180])
        });
        img.save(&png_path).expect("save test png");
        let st = std::process::Command::new("sips")
            .args([
                "-s",
                "format",
                "heic",
                &png_path.to_string_lossy(),
                "--out",
                &heic_path.to_string_lossy(),
            ])
            .stdout(std::process::Stdio::null())
            .stderr(std::process::Stdio::null())
            .status()
            .expect("invoke sips");
        assert!(st.success(), "sips should encode test .heic");

        // 1. Grid thumbnail decode via ImageIO (embedded fast-path / subsampled hardware decode)
        let thumb = load_thumbnail_rgba(&heic_path, 256).expect("HEIC thumbnail should decode");
        assert!(thumb.0 > 0 && thumb.0 <= 256);
        assert!(thumb.1 > 0 && thumb.1 <= 256);
        assert_eq!(thumb.2.len(), thumb.0 * thumb.1 * 4);
        assert!(crate::media::is_image_thumb_ext("HEIC"));
        assert!(crate::media::is_image_thumb_ext("heif"));
        assert!(crate::media::is_image_thumb_ext("avif"));

        // 2. Preview Pane decode should also use native ImageIO directly (zero temp file)
        let preview = load_preview_sandboxed(heic_path.clone())
            .recv()
            .expect("preview channel should return payload");
        match preview {
            PreviewPayload::Image {
                width,
                height,
                rgba,
                format_note,
                ..
            } => {
                assert!(width > 0 && height > 0);
                assert_eq!(rgba.len(), width * height * 4);
                assert!(
                    format_note.contains("Zero Temp File"),
                    "expected native ImageIO decode, got: {}",
                    format_note
                );
            }
            other => panic!(
                "expected PreviewPayload::Image for HEIC, got {:?}",
                std::mem::discriminant(&other)
            ),
        }

        // 3. Corrupt HEIC must safely return None without crashing
        std::fs::write(&bad_heic_path, b"not a real heic file").expect("write corrupt heic");
        assert!(load_thumbnail_rgba(&bad_heic_path, 256).is_none());

        let _ = std::fs::remove_dir_all(&tmp_dir);
    }

    #[test]
    fn test_spawn_properties_stats_many_counts_selected_files_and_folders() {
        let tmp_dir = std::env::temp_dir().join(format!("mine_props_many_{}", std::process::id()));
        let sub_dir = tmp_dir.join("ID 26");
        let _ = std::fs::remove_dir_all(&tmp_dir);
        std::fs::create_dir_all(&sub_dir).expect("create sub_dir");

        let f1 = tmp_dir.join("a.jpg");
        let f2 = tmp_dir.join("b.jpg");
        let inner = sub_dir.join("inside.cr2");
        std::fs::write(&f1, vec![1u8; 120]).expect("write f1");
        std::fs::write(&f2, vec![2u8; 340]).expect("write f2");
        std::fs::write(&inner, vec![3u8; 500]).expect("write inner");

        let rx = spawn_properties_stats_many(vec![sub_dir.clone(), f1.clone(), f2.clone()]);
        let mut final_stats = None;
        while let Ok(s) = rx.recv() {
            let done = s.is_complete;
            final_stats = Some(s);
            if done {
                break;
            }
        }
        let stats = final_stats.expect("should receive complete stats");
        assert!(stats.is_complete);
        assert_eq!(stats.file_count, 3);
        assert_eq!(stats.folder_count, 1);
        assert_eq!(stats.total_bytes, 960);

        let _ = std::fs::remove_dir_all(&tmp_dir);
    }
}



