use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Language {
    ZhTw,
    En,
}

impl Default for Language {
    fn default() -> Self {
        Self::ZhTw
    }
}

pub struct Texts {
    // Menu bar
    pub menu_file: &'static str,
    pub menu_edit: &'static str,
    pub menu_view: &'static str,
    pub menu_favorites: &'static str,
    pub menu_tools: &'static str,
    pub menu_window: &'static str,
    pub menu_help: &'static str,

    // File Menu
    pub file_new_pane: &'static str,
    pub file_clone_pane: &'static str,
    pub file_new_folder: &'static str,
    pub file_new_file: &'static str,
    pub file_open_terminal: &'static str,
    pub file_open_native: &'static str,
    pub file_close_pane: &'static str,
    pub file_restore_closed: &'static str,
    pub file_exit: &'static str,

    // Edit Menu
    pub edit_copy: &'static str,
    pub edit_cut: &'static str,
    pub edit_paste: &'static str,
    pub edit_rename: &'static str,
    pub edit_delete: &'static str,
    pub edit_copy_path: &'static str,
    pub edit_select_all: &'static str,
    pub edit_invert_selection: &'static str,

    // View Menu
    pub view_sidebar: &'static str,
    pub view_preview: &'static str,
    pub view_hidden_files: &'static str,
    pub view_refresh: &'static str,
    pub view_theme_dark: &'static str,
    pub view_theme_light: &'static str,
    pub view_theme_classic_mdie: &'static str,

    // Window Menu (MDIE classic!)
    pub win_mode_title: &'static str,
    pub win_mode_mdi_free: &'static str,
    pub win_mode_tile_grid: &'static str,
    pub win_mode_tile_horiz: &'static str,
    pub win_mode_tile_vert: &'static str,
    pub win_mode_cascade: &'static str,
    pub win_mode_tabbed: &'static str,
    pub win_scroll_top: &'static str,
    pub win_scroll_bottom: &'static str,
    pub win_sync_scroll: &'static str,
    pub win_close_all_except_active: &'static str,

    // Favorites & Workspace Groups
    pub fav_add_current_folder: &'static str,
    pub fav_save_workspace_group: &'static str,
    pub fav_groups_header: &'static str,
    pub fav_folders_header: &'static str,
    pub fav_empty: &'static str,

    // Tools & SMB & Gestures
    pub tools_global_search: &'static str,
    pub tools_smb_manager: &'static str,
    pub tools_gesture_settings: &'static str,
    pub tools_save_portable: &'static str,
    pub tools_export_reg_script: &'static str,

    // Toolbar & Search
    pub btn_back: &'static str,
    pub btn_forward: &'static str,
    pub btn_up: &'static str,
    pub btn_refresh: &'static str,
    pub search_placeholder: &'static str,
    pub search_mode_filter: &'static str,
    pub search_mode_best_match: &'static str,
    pub search_mode_select: &'static str,
    pub search_mode_deep: &'static str,

    // Columns
    pub col_name: &'static str,
    pub col_size: &'static str,
    pub col_type: &'static str,
    pub col_modified: &'static str,
    pub col_encoding_status: &'static str,

    // Sidebar Tabs
    pub side_tree: &'static str,
    pub side_favorites: &'static str,
    pub side_smb: &'static str,
    pub side_closed_history: &'static str,

    // Preview & Status
    pub preview_title: &'static str,
    pub preview_no_selection: &'static str,
    pub preview_heic_sandboxed: &'static str,
    pub status_items: &'static str,
    pub status_selected: &'static str,
    pub status_gesture_hint: &'static str,
    pub status_portable_mode: &'static str,

    // Dialogs
    pub dlg_smb_title: &'static str,
    pub dlg_smb_add: &'static str,
    pub dlg_smb_test_async: &'static str,
    pub dlg_gesture_title: &'static str,
    pub dlg_search_title: &'static str,
    pub dlg_about_title: &'static str,
}

pub const ZH_TW: Texts = Texts {
    menu_file: "檔案(F)",
    menu_edit: "編輯(E)",
    menu_view: "檢視(V)",
    menu_favorites: "我的最愛(A)",
    menu_tools: "工具(T)",
    menu_window: "視窗(W)",
    menu_help: "說明(H)",

    file_new_pane: "➕ 新增子視窗 (New MDI Window)",
    file_clone_pane: "📑 複製目前視窗 (Clone Window)",
    file_new_folder: "📁 新增資料夾 (New Folder)",
    file_new_file: "📄 新增空白檔案 (New File)",
    file_open_terminal: "💻 在此開啟終端機/CMD",
    file_open_native: "📂 以系統預設開啟 (System Open)",
    file_close_pane: "❌ 關閉目前子視窗 (Close)",
    file_restore_closed: "🕒 恢復已關閉視窗 (Restore Closed)",
    file_exit: "🚪 結束程式 (Exit)",

    edit_copy: "📋 複製 (Copy) [Ctrl+C]",
    edit_cut: "✂️ 剪下 (Cut) [Ctrl+X]",
    edit_paste: "📥 貼上 (Paste) [Ctrl+V]",
    edit_rename: "✏️ 重新命名 (Rename) [F2]",
    edit_delete: "🗑️ 移至資源回收桶 (Delete)",
    edit_copy_path: "🔗 複製完整路徑 (Copy Path)",
    edit_select_all: "☑️ 全選 (Select All) [Ctrl+A]",
    edit_invert_selection: "🔄 反向選取 (Invert Selection)",

    view_sidebar: "📚 切換左側導覽列 (Sidebar)",
    view_preview: "🖼️ 切換安全沙盒預覽面板 (Preview)",
    view_hidden_files: "👁️ 顯示隱藏檔案 (Show Hidden)",
    view_refresh: "🔄 重新整理 (Refresh) [F5]",
    view_theme_dark: "🌙 現代深色主題 (Modern Dark)",
    view_theme_light: "☀️ 清爽淺色主題 (Clean Light)",
    view_theme_classic_mdie: "🏛️ 經典 MDIE 懷舊主題 (Classic WinXP/MDIE)",

    win_mode_title: "視窗排列與模式 (MDIE 無限多重視窗)",
    win_mode_mdi_free: "🪟 自由重疊/拖放模式 (MDI Free Floating)",
    win_mode_tile_grid: "田 智慧網格並排 (Auto Grid - 支援無限視窗!)",
    win_mode_tile_horiz: "⬌ 左右並排顯示 (Tile Horizontally - N Columns)",
    win_mode_tile_vert: "⬍ 上下並排顯示 (Tile Vertically - N Rows)",
    win_mode_cascade: "🗗 層疊顯示 (Cascade Windows)",
    win_mode_tabbed: "🗂️ 單一最大化分頁模式 (Tabbed Mode)",
    win_scroll_top: "⏫ 捲動至列表開頭 (Scroll to Top)",
    win_scroll_bottom: "⏬ 捲動至列表結尾 (Scroll to Bottom)",
    win_sync_scroll: "🔗 多視窗同步比對捲動 (Sync Scroll)",
    win_close_all_except_active: "🧹 關閉其他所有視窗 (Close Others)",

    fav_add_current_folder: "⭐ 將目前資料夾加入最愛",
    fav_save_workspace_group: "💾 將目前「所有並排視窗組合」存為工作群組",
    fav_groups_header: "📦 多視窗工作群組 (一鍵展開並排)",
    fav_folders_header: "📁 常用資料夾書籤",
    fav_empty: "(尚無收藏項目)",

    tools_global_search: "🔍 超高速全硬碟/深度強化搜尋引擎 (Ctrl+F)",
    tools_smb_manager: "🌐 SMB / 遠端網路資料夾非阻塞管理員",
    tools_gesture_settings: "🖱️ 滑鼠手勢設定與軌跡一覽 (Mouse Gestures)",
    tools_save_portable: "💾 立即儲存綠色免安裝設定檔 (mine_config.json)",
    tools_export_reg_script: "🛠️ 匯出 Windows 右鍵選單/預設檔案總管登錄檔 (.reg)",

    btn_back: "⬅ 上一頁",
    btn_forward: "➡ 下一頁",
    btn_up: "⬆ 上一層",
    btn_refresh: "🔄 重整",
    search_placeholder: "輸入關鍵字 (支援模糊/正則/大小 >10MB/副檔名)...",
    search_mode_filter: "即時過濾",
    search_mode_best_match: "搜尋最符合",
    search_mode_select: "條件勾選(MDIE)",
    search_mode_deep: "深度遞迴搜尋",

    col_name: "名稱 (Name)",
    col_size: "大小 (Size)",
    col_type: "項目類型 (Type)",
    col_modified: "修改日期 (Modified)",
    col_encoding_status: "編碼/狀態",

    side_tree: "🌲 磁碟與目錄",
    side_favorites: "⭐ 最愛與群組",
    side_smb: "🌐 遠端 SMB",
    side_closed_history: "🕒 已關閉視窗",

    preview_title: "🛡️ 沙盒安全預覽 (防崩潰引擎)",
    preview_no_selection: "請點選任意檔案以預覽資訊、文字或圖片",
    preview_heic_sandboxed: "🛡️ 已啟用沙盒保護：支援 HEIC/WebP/AVIF 及特殊編碼，絕不當機",
    status_items: "個項目",
    status_selected: "已選取",
    status_gesture_hint: "🖱️ 按住滑鼠右鍵拖曳可使用手勢 (←上一頁 →下一頁 ↑上層 ↓新視窗 ↓→關閉)",
    status_portable_mode: "🟢 綠色免安裝模式 (Portable JSON)",

    dlg_smb_title: "🌐 遠端 SMB / 網路磁碟機 (非阻塞防卡死引擎)",
    dlg_smb_add: "新增遠端 SMB / NAS 路徑",
    dlg_smb_test_async: "⚡ 背景非同步檢測連線",
    dlg_gesture_title: "🖱️ MDIE 經典滑鼠手勢引擎設定",
    dlg_search_title: "🚀 MINE 次世代超高速檔案搜尋與批次操作中心",
    dlg_about_title: "關於 MINE (Multiple Interface Next-gen Explorer)",
};

pub const EN: Texts = Texts {
    menu_file: "File(F)",
    menu_edit: "Edit(E)",
    menu_view: "View(V)",
    menu_favorites: "Favorites(A)",
    menu_tools: "Tools(T)",
    menu_window: "Window(W)",
    menu_help: "Help(H)",

    file_new_pane: "➕ New MDI Child Window",
    file_clone_pane: "📑 Clone Active Window",
    file_new_folder: "📁 New Folder",
    file_new_file: "📄 New Empty File",
    file_open_terminal: "💻 Open Terminal / CMD Here",
    file_open_native: "📂 Open in System Default",
    file_close_pane: "❌ Close Active Window",
    file_restore_closed: "🕒 Restore Closed Windows",
    file_exit: "🚪 Exit MINE",

    edit_copy: "📋 Copy [Ctrl+C]",
    edit_cut: "✂️ Cut [Ctrl+X]",
    edit_paste: "📥 Paste [Ctrl+V]",
    edit_rename: "✏️ Rename [F2]",
    edit_delete: "🗑️ Move to Trash (Delete)",
    edit_copy_path: "🔗 Copy Full Path",
    edit_select_all: "☑️ Select All [Ctrl+A]",
    edit_invert_selection: "🔄 Invert Selection",

    view_sidebar: "📚 Toggle Sidebar",
    view_preview: "🖼️ Toggle Safe Sandbox Preview",
    view_hidden_files: "👁️ Show Hidden Files",
    view_refresh: "🔄 Refresh [F5]",
    view_theme_dark: "🌙 Modern Dark Theme",
    view_theme_light: "☀️ Clean Light Theme",
    view_theme_classic_mdie: "🏛️ Classic MDIE Retro Theme",

    win_mode_title: "Window Layout & Mode (Unlimited MDI)",
    win_mode_mdi_free: "🪟 Free Overlapping / Floating Mode (MDI)",
    win_mode_tile_grid: "田 Smart Grid Tiling (Unlimited Windows!)",
    win_mode_tile_horiz: "⬌ Tile Horizontally (Side-by-Side Columns)",
    win_mode_tile_vert: "⬍ Tile Vertically (Stacked Rows)",
    win_mode_cascade: "🗗 Cascade Windows",
    win_mode_tabbed: "🗂️ Maximized Tabbed Mode",
    win_scroll_top: "⏫ Scroll to List Top",
    win_scroll_bottom: "⏬ Scroll to List Bottom",
    win_sync_scroll: "🔗 Sync Scroll Across Windows",
    win_close_all_except_active: "🧹 Close All Other Windows",

    fav_add_current_folder: "⭐ Bookmark Current Folder",
    fav_save_workspace_group: "💾 Save All Open Windows as Workspace Group",
    fav_groups_header: "📦 Multi-Window Workspace Groups",
    fav_folders_header: "📁 Favorite Folders",
    fav_empty: "(No favorites saved yet)",

    tools_global_search: "🔍 Ultra-Fast Deep Search Engine (Ctrl+F)",
    tools_smb_manager: "🌐 Non-Blocking SMB / Network Share Manager",
    tools_gesture_settings: "🖱️ Mouse Gesture Settings & Cheat Sheet",
    tools_save_portable: "💾 Save Portable Config Now (mine_config.json)",
    tools_export_reg_script: "🛠️ Export Windows Shell Context Menu (.reg)",

    btn_back: "⬅ Back",
    btn_forward: "➡ Next",
    btn_up: "⬆ Up",
    btn_refresh: "🔄 Refresh",
    search_placeholder: "Filter or search (fuzzy, regex, >10MB, ext:rs)...",
    search_mode_filter: "Live Filter",
    search_mode_best_match: "Best Match",
    search_mode_select: "Select Match(MDIE)",
    search_mode_deep: "Deep Search",

    col_name: "Name",
    col_size: "Size",
    col_type: "Item Type",
    col_modified: "Date Modified",
    col_encoding_status: "Encoding/Status",

    side_tree: "🌲 Drives & Tree",
    side_favorites: "⭐ Favorites",
    side_smb: "🌐 Network SMB",
    side_closed_history: "🕒 Closed Tabs",

    preview_title: "🛡️ Sandboxed Preview (Crash-Proof)",
    preview_no_selection: "Select any file to preview metadata, text, or image",
    preview_heic_sandboxed: "🛡️ Sandbox Active: Crash-proof HEIC/WebP/AVIF & non-UTF8 handler",
    status_items: "items",
    status_selected: "selected",
    status_gesture_hint: "🖱️ Hold Right-Click & drag for Mouse Gestures (←Back →Next ↑Up ↓New ↓→Close)",
    status_portable_mode: "🟢 Portable Mode (mine_config.json)",

    dlg_smb_title: "🌐 Non-Blocking SMB / Network Share Manager",
    dlg_smb_add: "Add Remote SMB / NAS Share",
    dlg_smb_test_async: "⚡ Async Probe Connection",
    dlg_gesture_title: "🖱️ MDIE Mouse Gesture Engine & Customization",
    dlg_search_title: "🚀 MINE Ultra-Fast Multi-Threaded Search & Batch Action",
    dlg_about_title: "About MINE (Multiple Interface Next-gen Explorer)",
};

impl Language {
    pub fn texts(&self) -> &'static Texts {
        match self {
            Language::ZhTw => &ZH_TW,
            Language::En => &EN,
        }
    }
}
