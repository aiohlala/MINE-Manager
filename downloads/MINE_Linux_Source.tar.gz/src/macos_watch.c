#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/event.h>
#include <sys/time.h>
#include <unistd.h>

#ifndef O_EVTONLY
#define O_EVTONLY O_RDONLY
#endif

typedef struct MineKqueueWatcher {
    int kq;
    int wake_pipe[2];
} MineKqueueWatcher;

MineKqueueWatcher *mine_kqueue_create(void) {
    int kq = kqueue();
    if (kq < 0) {
        return NULL;
    }
    int fds[2] = {-1, -1};
    if (pipe(fds) != 0) {
        close(kq);
        return NULL;
    }
    for (int i = 0; i < 2; i++) {
        int fl = fcntl(fds[i], F_GETFL, 0);
        if (fl >= 0) {
            fcntl(fds[i], F_SETFL, fl | O_NONBLOCK);
        }
        fcntl(fds[i], F_SETFD, FD_CLOEXEC);
    }
    fcntl(kq, F_SETFD, FD_CLOEXEC);

    struct kevent kev;
    EV_SET(&kev, (uintptr_t)fds[0], EVFILT_READ, EV_ADD | EV_CLEAR, 0, 0, NULL);
    if (kevent(kq, &kev, 1, NULL, 0, NULL) < 0) {
        close(fds[0]);
        close(fds[1]);
        close(kq);
        return NULL;
    }

    MineKqueueWatcher *w = (MineKqueueWatcher *)calloc(1, sizeof(MineKqueueWatcher));
    if (!w) {
        close(fds[0]);
        close(fds[1]);
        close(kq);
        return NULL;
    }
    w->kq = kq;
    w->wake_pipe[0] = fds[0];
    w->wake_pipe[1] = fds[1];
    return w;
}

void mine_kqueue_wake(MineKqueueWatcher *w) {
    if (!w || w->wake_pipe[1] < 0) {
        return;
    }
    uint8_t b = 1;
    ssize_t r;
    do {
        r = write(w->wake_pipe[1], &b, 1);
    } while (r < 0 && errno == EINTR);
}

int mine_kqueue_add_dir(MineKqueueWatcher *w, const char *path_utf8, uint64_t watch_id) {
    if (!w || !path_utf8 || w->kq < 0) {
        return -1;
    }
    int fd = open(path_utf8, O_EVTONLY | O_CLOEXEC);
    if (fd < 0) {
        return -1;
    }
    struct kevent kev;
    unsigned int fflags = NOTE_WRITE | NOTE_DELETE | NOTE_RENAME | NOTE_EXTEND | NOTE_ATTRIB | NOTE_REVOKE;
    EV_SET(&kev, (uintptr_t)fd, EVFILT_VNODE, EV_ADD | EV_CLEAR, fflags, 0, (void *)(uintptr_t)watch_id);
    if (kevent(w->kq, &kev, 1, NULL, 0, NULL) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

void mine_kqueue_remove_fd(int fd) {
    if (fd >= 0) {
        close(fd);
    }
}

int mine_kqueue_wait(
    MineKqueueWatcher *w,
    int timeout_ms,
    uint64_t *out_ids,
    uint32_t *out_flags,
    int max_ids,
    int *out_woken
) {
    if (out_woken) {
        *out_woken = 0;
    }
    if (!w || w->kq < 0) {
        return -1;
    }

    struct timespec ts;
    struct timespec *ts_ptr = NULL;
    if (timeout_ms >= 0) {
        ts.tv_sec = timeout_ms / 1000;
        ts.tv_nsec = (long)(timeout_ms % 1000) * 1000000L;
        ts_ptr = &ts;
    }

    struct kevent events[64];
    int n = -1;
    for (;;) {
        n = kevent(w->kq, NULL, 0, events, 64, ts_ptr);
        if (n < 0 && errno == EINTR) {
            if (timeout_ms < 0) {
                continue;
            }
            return 0;
        }
        break;
    }
    if (n < 0) {
        return -1;
    }

    int written = 0;
    for (int i = 0; i < n; i++) {
        if (events[i].filter == EVFILT_READ) {
            uint8_t buf[128];
            while (read(w->wake_pipe[0], buf, sizeof(buf)) > 0) {
            }
            if (out_woken) {
                *out_woken = 1;
            }
        } else if (events[i].filter == EVFILT_VNODE) {
            uint64_t wid = (uint64_t)(uintptr_t)events[i].udata;
            uint32_t needs_reopen = (events[i].fflags & (NOTE_DELETE | NOTE_RENAME | NOTE_REVOKE)) ? 1u : 0u;
            int found = -1;
            for (int k = 0; k < written; k++) {
                if (out_ids[k] == wid) {
                    found = k;
                    break;
                }
            }
            if (found >= 0) {
                if (out_flags) {
                    out_flags[found] |= needs_reopen;
                }
            } else if (written < max_ids) {
                if (out_ids) {
                    out_ids[written] = wid;
                }
                if (out_flags) {
                    out_flags[written] = needs_reopen;
                }
                written++;
            }
        }
    }
    return written;
}

void mine_kqueue_destroy(MineKqueueWatcher *w) {
    if (!w) {
        return;
    }
    if (w->wake_pipe[0] >= 0) {
        close(w->wake_pipe[0]);
    }
    if (w->wake_pipe[1] >= 0) {
        close(w->wake_pipe[1]);
    }
    if (w->kq >= 0) {
        close(w->kq);
    }
    free(w);
}
