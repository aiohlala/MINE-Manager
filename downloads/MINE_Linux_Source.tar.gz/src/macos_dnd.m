#import <Cocoa/Cocoa.h>
#include <stdint.h>

@interface MineDragSource : NSObject <NSDraggingSource>
@end

static MineDragSource *g_active_drag_source = nil;
static int g_drag_ended = 0;
static int g_drag_dropped = 0;
static int g_drag_was_move = 0;

@implementation MineDragSource

- (NSDragOperation)draggingSession:(NSDraggingSession *)session
    sourceOperationMaskForDraggingContext:(NSDraggingContext)context {
    (void)session;
    if (context == NSDraggingContextOutsideApplication) {
        return NSDragOperationCopy | NSDragOperationMove | NSDragOperationLink | NSDragOperationGeneric;
    }
    return NSDragOperationCopy | NSDragOperationMove | NSDragOperationGeneric;
}

- (BOOL)ignoreModifierKeysForDraggingSession:(NSDraggingSession *)session {
    (void)session;
    return NO;
}

- (void)draggingSession:(NSDraggingSession *)session
           endedAtPoint:(NSPoint)screenPoint
              operation:(NSDragOperation)operation {
    (void)session;
    (void)screenPoint;
    g_drag_ended = 1;
    g_drag_dropped = (operation != NSDragOperationNone) ? 1 : 0;
    g_drag_was_move = (operation == NSDragOperationMove) ? 1 : 0;
    g_active_drag_source = nil;
}

@end

static NSWindow *mine_find_main_window(void) {
    NSWindow *win = [NSApp keyWindow];
    if (win != nil && [win contentView] != nil) {
        return win;
    }
    win = [NSApp mainWindow];
    if (win != nil && [win contentView] != nil) {
        return win;
    }
    for (NSWindow *w in [NSApp windows]) {
        if ([w isVisible] && [w contentView] != nil) {
            return w;
        }
    }
    return nil;
}

int mine_macos_is_left_mouse_down(void) {
    return (([NSEvent pressedMouseButtons] & (NSUInteger)1) != 0) ? 1 : 0;
}

int mine_macos_is_cursor_over_other_window(void) {
    @autoreleasepool {
        NSWindow *win = mine_find_main_window();
        if (win == nil) {
            return 0;
        }
        NSPoint pt = [NSEvent mouseLocation];
        if (!NSPointInRect(pt, [win frame])) {
            return 1;
        }
        NSInteger topWin = [NSWindow windowNumberAtPoint:pt belowWindowWithWindowNumber:0];
        if (topWin != 0 && topWin != [win windowNumber]) {
            return 1;
        }
        return 0;
    }
}

int mine_macos_cursor_pos_in_window(float *out_x, float *out_y) {
    @autoreleasepool {
        NSWindow *win = mine_find_main_window();
        if (win == nil || [win contentView] == nil) {
            return 0;
        }
        NSView *view = [win contentView];
        NSPoint screenPt = [NSEvent mouseLocation];
        NSPoint winPt = [win convertRectFromScreen:NSMakeRect(screenPt.x, screenPt.y, 0.0, 0.0)].origin;
        NSPoint viewPt = [view convertPoint:winPt fromView:nil];
        NSRect bounds = [view bounds];
        float x = (float)viewPt.x;
        float y = [view isFlipped] ? (float)viewPt.y : (float)(bounds.size.height - viewPt.y);
        if (x < 0.0f || y < 0.0f || x > (float)bounds.size.width || y > (float)bounds.size.height) {
            return 0;
        }
        if (out_x != NULL) {
            *out_x = x;
        }
        if (out_y != NULL) {
            *out_y = y;
        }
        return 1;
    }
}

int mine_macos_begin_file_drag(const char *const *paths_utf8, int count) {
    if (paths_utf8 == NULL || count <= 0) {
        return 0;
    }

    @autoreleasepool {
        @try {
            NSWindow *win = mine_find_main_window();
            if (win == nil) {
                return 0;
            }
            NSView *view = [win contentView];
            if (view == nil) {
                return 0;
            }

            NSPoint screenPt = [NSEvent mouseLocation];
            NSRect screenRect = NSMakeRect(screenPt.x, screenPt.y, 0.0, 0.0);
            NSPoint winPt = [win convertRectFromScreen:screenRect].origin;
            NSPoint viewPt = [view convertPoint:winPt fromView:nil];

            NSMutableArray<NSDraggingItem *> *items = [NSMutableArray arrayWithCapacity:(NSUInteger)count];
            NSImage *cachedIcon = nil;
            const CGFloat sz = 48.0;

            for (int i = 0; i < count; i++) {
                if (paths_utf8[i] == NULL) {
                    continue;
                }
                NSString *pathStr = [NSString stringWithUTF8String:paths_utf8[i]];
                if (pathStr == nil || [pathStr length] == 0) {
                    continue;
                }
                NSURL *url = [NSURL fileURLWithPath:pathStr];
                if (url == nil) {
                    continue;
                }

                NSDraggingItem *item = [[NSDraggingItem alloc] initWithPasteboardWriter:url];
                if (item == nil) {
                    continue;
                }

                CGFloat off = (CGFloat)(i < 5 ? i : 4) * 5.0;
                NSRect frame = NSMakeRect(viewPt.x - sz * 0.5 + off, viewPt.y - sz * 0.5 - off, sz, sz);

                if (i < 8 || cachedIcon == nil) {
                    NSImage *icon = [[NSWorkspace sharedWorkspace] iconForFile:pathStr];
                    if (icon != nil) {
                        NSImage *copyIcon = [icon copy];
                        [copyIcon setSize:NSMakeSize(sz, sz)];
                        cachedIcon = copyIcon;
                    }
                }
                if (cachedIcon != nil) {
                    [item setDraggingFrame:frame contents:cachedIcon];
                } else {
                    [item setDraggingFrame:frame contents:nil];
                }
                [items addObject:item];
            }

            if ([items count] == 0) {
                return 0;
            }

            NSEvent *dragEvent = [NSApp currentEvent];
            if (dragEvent == nil ||
                (dragEvent.type != NSEventTypeLeftMouseDown && dragEvent.type != NSEventTypeLeftMouseDragged) ||
                dragEvent.windowNumber != [win windowNumber]) {
                dragEvent = [NSEvent mouseEventWithType:NSEventTypeLeftMouseDragged
                                               location:winPt
                                          modifierFlags:[NSEvent modifierFlags]
                                              timestamp:[[NSProcessInfo processInfo] systemUptime]
                                           windowNumber:[win windowNumber]
                                                context:nil
                                            eventNumber:0
                                             clickCount:1
                                               pressure:1.0f];
            }
            if (dragEvent == nil) {
                return 0;
            }

            g_drag_ended = 0;
            g_drag_dropped = 0;
            g_drag_was_move = 0;
            g_active_drag_source = [MineDragSource new];

            NSDraggingSession *session = [view beginDraggingSessionWithItems:items
                                                                       event:dragEvent
                                                                      source:g_active_drag_source];
            if (session == nil) {
                g_active_drag_source = nil;
                return 0;
            }
            session.animatesToStartingPositionsOnCancelOrFail = YES;
            session.draggingFormation = NSDraggingFormationPile;
            return 1;
        } @catch (NSException *ex) {
            (void)ex;
            g_active_drag_source = nil;
            return 0;
        }
    }
}

int mine_macos_is_drag_session_running(void) {
    return g_active_drag_source != nil ? 1 : 0;
}

int mine_macos_poll_drag_ended(int *out_dropped, int *out_was_move) {
    if (g_drag_ended) {
        if (out_dropped != NULL) {
            *out_dropped = g_drag_dropped;
        }
        if (out_was_move != NULL) {
            *out_was_move = g_drag_was_move;
        }
        g_drag_ended = 0;
        return 1;
    }
    return 0;
}
