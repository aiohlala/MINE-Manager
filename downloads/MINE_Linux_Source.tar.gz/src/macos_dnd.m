#import <Cocoa/Cocoa.h>
#import <CoreGraphics/CoreGraphics.h>
#import <CoreServices/CoreServices.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

@interface MineDragSource : NSObject <NSDraggingSource>
@property (nonatomic, assign) BOOL allowMove;
@end

static MineDragSource *g_active_drag_source = nil;
static int g_drag_ended = 0;
static int g_drag_dropped = 0;
static int g_drag_was_move = 0;

static NSString *const kMineCutPasteboardType = @"com.aiohlala.mine.clipboard-cut";
static NSString *const kMineLegacyFilenamesType = @"NSFilenamesPboardType";

static NSWindow *mine_find_main_window(void);

void mine_macos_post_synthetic_mouse_up(void) {
    @autoreleasepool {
        @try {
            NSWindow *win = mine_find_main_window();
            if (win == nil) {
                return;
            }
            NSEvent *upEvent = [NSEvent mouseEventWithType:NSEventTypeLeftMouseUp
                                                  location:NSMakePoint(-1000.0, -1000.0)
                                             modifierFlags:0
                                                 timestamp:[[NSProcessInfo processInfo] systemUptime]
                                              windowNumber:[win windowNumber]
                                                   context:nil
                                               eventNumber:0
                                                clickCount:1
                                                  pressure:0.0f];
            if (upEvent != nil) {
                [NSApp postEvent:upEvent atStart:YES];
            }
        } @catch (NSException *ex) {
            (void)ex;
        }
    }
}

@implementation MineDragSource

- (NSDragOperation)draggingSession:(NSDraggingSession *)session
    sourceOperationMaskForDraggingContext:(NSDraggingContext)context {
    (void)session;
    if (context == NSDraggingContextOutsideApplication) {
        if (self.allowMove) {
            return NSDragOperationMove | NSDragOperationCopy;
        }
        return NSDragOperationCopy;
    }
    return NSDragOperationCopy | NSDragOperationMove | NSDragOperationGeneric;
}

- (BOOL)ignoreModifierKeysForDraggingSession:(NSDraggingSession *)session {
    (void)session;
    return self.allowMove ? NO : YES;
}

- (void)draggingSession:(NSDraggingSession *)session
           endedAtPoint:(NSPoint)screenPoint
              operation:(NSDragOperation)operation {
    (void)session;
    (void)screenPoint;
    g_drag_ended = 1;
    g_drag_dropped = (operation != NSDragOperationNone) ? 1 : 0;
    g_drag_was_move = (operation == NSDragOperationMove) ? 1 : 0;
    g_active_drag_source = nil;
    // AppKit's modal drag tracking consumes the physical LeftMouseUp event; post a synthetic
    // release outside the window so winit/egui immediately reset their primary button state.
    mine_macos_post_synthetic_mouse_up();
}

@end

static NSWindow *mine_find_main_window(void) {
    NSWindow *win = [NSApp keyWindow];
    if (win != nil && [win contentView] != nil) {
        return win;
    }
    win = [NSApp mainWindow];
    if (win != nil && [win contentView] != nil) {
        return win;
    }
    for (NSWindow *w in [NSApp windows]) {
        if ([w isVisible] && [w contentView] != nil) {
            return w;
        }
    }
    return nil;
}

int mine_macos_is_left_mouse_down(void) {
    return (([NSEvent pressedMouseButtons] & (NSUInteger)1) != 0) ? 1 : 0;
}

int mine_macos_is_cursor_over_other_window(void) {
    @autoreleasepool {
        NSWindow *win = mine_find_main_window();
        if (win == nil) {
            return 0;
        }
        NSPoint pt = [NSEvent mouseLocation];
        if (!NSPointInRect(pt, [win frame])) {
            return 1;
        }
        NSInteger topWin = [NSWindow windowNumberAtPoint:pt belowWindowWithWindowNumber:0];
        if (topWin != 0 && topWin != [win windowNumber]) {
            return 1;
        }
        return 0;
    }
}

int mine_macos_cursor_pos_in_window(float *out_x, float *out_y) {
    @autoreleasepool {
        NSWindow *win = mine_find_main_window();
        if (win == nil || [win contentView] == nil) {
            return 0;
        }
        NSView *view = [win contentView];
        NSPoint screenPt = [NSEvent mouseLocation];
        NSPoint winPt = [win convertRectFromScreen:NSMakeRect(screenPt.x, screenPt.y, 0.0, 0.0)].origin;
        NSPoint viewPt = [view convertPoint:winPt fromView:nil];
        NSRect bounds = [view bounds];
        float x = (float)viewPt.x;
        float y = [view isFlipped] ? (float)viewPt.y : (float)(bounds.size.height - viewPt.y);
        if (x < 0.0f || y < 0.0f || x > (float)bounds.size.width || y > (float)bounds.size.height) {
            return 0;
        }
        if (out_x != NULL) {
            *out_x = x;
        }
        if (out_y != NULL) {
            *out_y = y;
        }
        return 1;
    }
}

int mine_macos_begin_file_drag(const char *const *paths_utf8, int count, int allow_move) {
    if (paths_utf8 == NULL || count <= 0) {
        return 0;
    }
    if (g_active_drag_source != nil) {
        return 0;
    }
    if (([NSEvent pressedMouseButtons] & (NSUInteger)1) == 0) {
        return 0;
    }

    @autoreleasepool {
        @try {
            if (![NSApp isActive]) {
                return 0;
            }
            NSWindow *win = mine_find_main_window();
            if (win == nil) {
                return 0;
            }
            NSView *view = [win contentView];
            if (view == nil) {
                return 0;
            }

            NSPoint screenPt = [NSEvent mouseLocation];
            NSRect screenRect = NSMakeRect(screenPt.x, screenPt.y, 0.0, 0.0);
            NSPoint winPt = [win convertRectFromScreen:screenRect].origin;
            NSPoint viewPt = [view convertPoint:winPt fromView:nil];

            NSMutableArray<NSDraggingItem *> *items = [NSMutableArray arrayWithCapacity:(NSUInteger)count];
            NSImage *cachedIcon = nil;
            const CGFloat sz = 48.0;

            for (int i = 0; i < count; i++) {
                if (paths_utf8[i] == NULL) {
                    continue;
                }
                NSString *pathStr = [NSString stringWithUTF8String:paths_utf8[i]];
                if (pathStr == nil || [pathStr length] == 0) {
                    continue;
                }
                NSURL *url = [NSURL fileURLWithPath:pathStr];
                if (url == nil) {
                    continue;
                }

                NSDraggingItem *item = [[NSDraggingItem alloc] initWithPasteboardWriter:url];
                if (item == nil) {
                    continue;
                }

                CGFloat off = (CGFloat)(i < 5 ? i : 4) * 5.0;
                NSRect frame = NSMakeRect(viewPt.x - sz * 0.5 + off, viewPt.y - sz * 0.5 - off, sz, sz);

                if (i < 8 || cachedIcon == nil) {
                    NSImage *icon = [[NSWorkspace sharedWorkspace] iconForFile:pathStr];
                    if (icon != nil) {
                        NSImage *copyIcon = [icon copy];
                        [copyIcon setSize:NSMakeSize(sz, sz)];
                        cachedIcon = copyIcon;
                    }
                }
                if (cachedIcon != nil) {
                    [item setDraggingFrame:frame contents:cachedIcon];
                } else {
                    [item setDraggingFrame:frame contents:nil];
                }
                [items addObject:item];
            }

            if ([items count] == 0) {
                return 0;
            }

            NSEvent *dragEvent = [NSApp currentEvent];
            if (dragEvent == nil ||
                (dragEvent.type != NSEventTypeLeftMouseDown && dragEvent.type != NSEventTypeLeftMouseDragged) ||
                dragEvent.windowNumber != [win windowNumber]) {
                dragEvent = [NSEvent mouseEventWithType:NSEventTypeLeftMouseDragged
                                               location:winPt
                                          modifierFlags:[NSEvent modifierFlags]
                                              timestamp:[[NSProcessInfo processInfo] systemUptime]
                                           windowNumber:[win windowNumber]
                                                context:nil
                                            eventNumber:0
                                             clickCount:1
                                               pressure:1.0f];
            }
            if (dragEvent == nil) {
                return 0;
            }

            g_drag_ended = 0;
            g_drag_dropped = 0;
            g_drag_was_move = 0;
            MineDragSource *src = [MineDragSource new];
            src.allowMove = (allow_move != 0);
            g_active_drag_source = src;

            NSDraggingSession *session = [view beginDraggingSessionWithItems:items
                                                                       event:dragEvent
                                                                      source:g_active_drag_source];
            if (session == nil) {
                g_active_drag_source = nil;
                return 0;
            }
            session.animatesToStartingPositionsOnCancelOrFail = NO;
            session.draggingFormation = NSDraggingFormationPile;
            return 1;
        } @catch (NSException *ex) {
            (void)ex;
            g_active_drag_source = nil;
            return 0;
        }
    }
}

int mine_macos_is_drag_session_running(void) {
    return g_active_drag_source != nil ? 1 : 0;
}

int mine_macos_poll_drag_ended(int *out_dropped, int *out_was_move) {
    if (g_drag_ended) {
        if (out_dropped != NULL) {
            *out_dropped = g_drag_dropped;
        }
        if (out_was_move != NULL) {
            *out_was_move = g_drag_was_move;
        }
        g_drag_ended = 0;
        return 1;
    }
    return 0;
}

// ---- Native macOS NSPasteboard File Clipboard ----

static int mine_write_files_to_pb(NSPasteboard *pb, const char *const *paths_utf8, int count, int is_cut) {
    if (pb == nil || paths_utf8 == NULL || count <= 0) {
        return 0;
    }

    @autoreleasepool {
        NSMutableArray<NSPasteboardItem *> *pbItems = [NSMutableArray arrayWithCapacity:(NSUInteger)count];
        NSMutableArray<NSString *> *pathList = [NSMutableArray arrayWithCapacity:(NSUInteger)count];

        for (int i = 0; i < count; i++) {
            if (paths_utf8[i] == NULL) {
                continue;
            }
            NSString *pathStr = [NSString stringWithUTF8String:paths_utf8[i]];
            if (pathStr == nil || [pathStr length] == 0) {
                continue;
            }
            NSURL *url = [NSURL fileURLWithPath:pathStr];
            if (url == nil) {
                continue;
            }
            NSString *absUrl = [url absoluteString];
            if (absUrl == nil) {
                continue;
            }

            NSPasteboardItem *item = [[NSPasteboardItem alloc] init];
            [item setString:absUrl forType:NSPasteboardTypeFileURL];
            NSString *fname = [pathStr lastPathComponent];
            if (fname != nil && [fname length] > 0) {
                [item setString:fname forType:NSPasteboardTypeString];
            }
            if (is_cut != 0 && [pbItems count] == 0) {
                [item setString:@"1" forType:kMineCutPasteboardType];
            }
            [pbItems addObject:item];
            [pathList addObject:pathStr];
        }

        if ([pbItems count] == 0) {
            return 0;
        }

        [pb clearContents];
        BOOL ok = [pb writeObjects:pbItems];
        [pb addTypes:@[kMineLegacyFilenamesType] owner:nil];
        [pb setPropertyList:pathList forType:kMineLegacyFilenamesType];
        return ok ? 1 : 0;
    }
}

static int mine_has_files_in_pb(NSPasteboard *pb) {
    if (pb == nil) {
        return 0;
    }
    @autoreleasepool {
        NSDictionary *opts = @{NSPasteboardURLReadingFileURLsOnlyKey : @YES};
        if ([pb canReadObjectForClasses:@[[NSURL class]] options:opts]) {
            return 1;
        }
        id plist = [pb propertyListForType:kMineLegacyFilenamesType];
        if ([plist isKindOfClass:[NSArray class]] && [(NSArray *)plist count] > 0) {
            return 1;
        }
        return 0;
    }
}

static int mine_read_files_from_pb(NSPasteboard *pb, uint8_t **out_buf, int *out_len, int *out_is_cut) {
    if (out_buf) *out_buf = NULL;
    if (out_len) *out_len = 0;
    if (out_is_cut) *out_is_cut = 0;
    if (pb == nil || out_buf == NULL || out_len == NULL) {
        return 0;
    }

    @autoreleasepool {
        NSMutableArray<NSString *> *resolvedPaths = [NSMutableArray array];
        NSDictionary *opts = @{NSPasteboardURLReadingFileURLsOnlyKey : @YES};
        NSArray *urls = [pb readObjectsForClasses:@[[NSURL class]] options:opts];
        if (urls != nil) {
            for (id obj in urls) {
                if ([obj isKindOfClass:[NSURL class]]) {
                    NSString *p = [(NSURL *)obj path];
                    if (p != nil && [p length] > 0) {
                        [resolvedPaths addObject:p];
                    }
                }
            }
        }
        if ([resolvedPaths count] == 0) {
            id plist = [pb propertyListForType:kMineLegacyFilenamesType];
            if ([plist isKindOfClass:[NSArray class]]) {
                for (id entry in (NSArray *)plist) {
                    if ([entry isKindOfClass:[NSString class]] && [(NSString *)entry length] > 0) {
                        [resolvedPaths addObject:(NSString *)entry];
                    }
                }
            }
        }
        if ([resolvedPaths count] == 0) {
            return 0;
        }

        NSMutableData *data = [NSMutableData data];
        const uint8_t nul = 0;
        for (NSString *p in resolvedPaths) {
            const char *utf8 = [p UTF8String];
            if (utf8 != NULL && utf8[0] != '\0') {
                [data appendBytes:utf8 length:strlen(utf8)];
                [data appendBytes:&nul length:1];
            }
        }
        NSUInteger totalLen = [data length];
        if (totalLen == 0) {
            return 0;
        }

        uint8_t *raw = (uint8_t *)malloc((size_t)totalLen);
        if (raw == NULL) {
            return 0;
        }
        memcpy(raw, [data bytes], (size_t)totalLen);

        int isCut = 0;
        NSString *cutVal = [pb stringForType:kMineCutPasteboardType];
        if (cutVal != nil && [cutVal isEqualToString:@"1"]) {
            isCut = 1;
        }

        *out_buf = raw;
        *out_len = (int)totalLen;
        if (out_is_cut != NULL) {
            *out_is_cut = isCut;
        }
        return 1;
    }
}

int mine_macos_has_file_clipboard(void) {
    return mine_has_files_in_pb([NSPasteboard generalPasteboard]);
}

int mine_macos_set_file_clipboard(const char *const *paths_utf8, int count, int is_cut) {
    return mine_write_files_to_pb([NSPasteboard generalPasteboard], paths_utf8, count, is_cut);
}

int mine_macos_get_file_clipboard(uint8_t **out_buf, int *out_len, int *out_is_cut) {
    return mine_read_files_from_pb([NSPasteboard generalPasteboard], out_buf, out_len, out_is_cut);
}

void mine_macos_clear_file_clipboard(void) {
    @autoreleasepool {
        [[NSPasteboard generalPasteboard] clearContents];
    }
}

void mine_macos_free_buffer(uint8_t *ptr) {
    if (ptr != NULL) {
        free(ptr);
    }
}

int mine_macos_is_paste_shortcut_down(int *out_force_move) {
    if (out_force_move != NULL) {
        *out_force_move = 0;
    }
    bool v_down = CGEventSourceKeyState(kCGEventSourceStateCombinedSessionState, (CGKeyCode)9);
    if (!v_down) {
        return 0;
    }
    NSEventModifierFlags flags = [NSEvent modifierFlags];
    BOOL has_cmd_or_ctrl = ((flags & NSEventModifierFlagCommand) != 0) ||
                           ((flags & NSEventModifierFlagControl) != 0);
    BOOL has_shift = (flags & NSEventModifierFlagShift) != 0;
    if (has_cmd_or_ctrl && !has_shift) {
        if (out_force_move != NULL) {
            *out_force_move = ((flags & NSEventModifierFlagOption) != 0) ? 1 : 0;
        }
        return 1;
    }
    return 0;
}

int mine_macos_test_pasteboard_roundtrip(
    const char *const *paths_utf8,
    int count,
    int is_cut,
    uint8_t **out_buf,
    int *out_len,
    int *out_is_cut
) {
    @autoreleasepool {
        NSPasteboard *pb = [NSPasteboard pasteboardWithUniqueName];
        if (pb == nil) {
            return 0;
        }
        int wrote = mine_write_files_to_pb(pb, paths_utf8, count, is_cut);
        int has = mine_has_files_in_pb(pb);
        int read = mine_read_files_from_pb(pb, out_buf, out_len, out_is_cut);
        [pb releaseGlobally];
        return (wrote && has && read) ? 1 : 0;
    }
}

// ============================================================================
// macOS Native "Open With" & Default App Association (LaunchServices + AppKit)
// ============================================================================

static NSString *mine_sanitize_tsv_field(NSString *s) {
    if (s == nil) return @"";
    NSString *r = [s stringByReplacingOccurrencesOfString:@"\t" withString:@" "];
    r = [r stringByReplacingOccurrencesOfString:@"\n" withString:@" "];
    r = [r stringByReplacingOccurrencesOfString:@"\r" withString:@" "];
    return r;
}

static NSString *mine_localized_app_name(NSURL *appURL, NSBundle *bundle, int prefer_zh) {
    NSString *appPath = [[appURL path] stringByStandardizingPath];
    NSArray<NSString *> *prefLocs = prefer_zh
        ? @[@"zh_TW", @"zh-Hant-TW", @"zh-Hant", @"zh_HK", @"zh-Hant-HK"]
        : @[@"en", @"en_US", @"Base"];

    if (bundle != nil) {
        // 1. Modern macOS 13+ InfoPlist.loctable (used by Preview.app, ColorSync Utility.app, etc.)
        NSString *loctablePath = [bundle pathForResource:@"InfoPlist" ofType:@"loctable"];
        if (loctablePath != nil) {
            NSDictionary *loctable = [NSDictionary dictionaryWithContentsOfFile:loctablePath];
            if ([loctable isKindOfClass:[NSDictionary class]]) {
                for (NSString *loc in prefLocs) {
                    NSDictionary *tbl = loctable[loc];
                    if ([tbl isKindOfClass:[NSDictionary class]]) {
                        NSString *cand = tbl[@"CFBundleDisplayName"];
                        if (![cand isKindOfClass:[NSString class]] || [cand length] == 0) {
                            cand = tbl[@"CFBundleName"];
                        }
                        if ([cand isKindOfClass:[NSString class]] && [cand length] > 0) {
                            return cand;
                        }
                    }
                }
            }
        }

        // 2. Classic <loc>.lproj/InfoPlist.strings (third-party apps & older macOS)
        for (NSString *loc in prefLocs) {
            NSString *stringsPath = [bundle pathForResource:@"InfoPlist"
                                                     ofType:@"strings"
                                                inDirectory:nil
                                            forLocalization:loc];
            if (stringsPath != nil) {
                NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:stringsPath];
                if ([dict isKindOfClass:[NSDictionary class]]) {
                    NSString *cand = dict[@"CFBundleDisplayName"];
                    if (![cand isKindOfClass:[NSString class]] || [cand length] == 0) {
                        cand = dict[@"CFBundleName"];
                    }
                    if ([cand isKindOfClass:[NSString class]] && [cand length] > 0) {
                        return cand;
                    }
                }
            }
        }
    }

    // 3. Fallback to FileManager displayNameAtPath / filename stem
    NSString *dispName = [[NSFileManager defaultManager] displayNameAtPath:appPath];
    if (dispName == nil || [dispName length] == 0) {
        dispName = [[appPath lastPathComponent] stringByDeletingPathExtension];
    }
    if ([dispName hasSuffix:@".app"]) {
        dispName = [dispName substringToIndex:[dispName length] - 4];
    }
    return dispName;
}

int mine_macos_list_open_with_apps(
    const char *path_utf8,
    int prefer_zh,
    uint8_t **out_buf,
    int *out_len
) {
    if (path_utf8 == NULL || out_buf == NULL || out_len == NULL) {
        return 0;
    }
    *out_buf = NULL;
    *out_len = 0;

    @autoreleasepool {
        @try {
            NSString *nsPath = [NSString stringWithUTF8String:path_utf8];
            if (nsPath == nil || [nsPath length] == 0) {
                return 0;
            }
            NSURL *fileURL = [NSURL fileURLWithPath:nsPath];
            if (fileURL == nil) {
                return 0;
            }

            NSWorkspace *ws = [NSWorkspace sharedWorkspace];
            NSURL *defaultURL = [ws URLForApplicationToOpenURL:fileURL];
            NSString *defaultStdPath = defaultURL ? [[defaultURL path] stringByStandardizingPath] : nil;

            NSArray<NSURL *> *rawURLs = nil;
            if (@available(macOS 12.0, *)) {
                rawURLs = [ws URLsForApplicationsToOpenURL:fileURL];
            }
            if (rawURLs == nil) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
                CFArrayRef cfApps = LSCopyApplicationURLsForURL((__bridge CFURLRef)fileURL, kLSRolesAll);
#pragma clang diagnostic pop
                if (cfApps != NULL) {
                    rawURLs = (__bridge_transfer NSArray<NSURL *> *)cfApps;
                }
            }

            NSMutableArray<NSURL *> *allURLs = [NSMutableArray array];
            if (defaultURL != nil) {
                [allURLs addObject:defaultURL];
            }
            if (rawURLs != nil) {
                [allURLs addObjectsFromArray:rawURLs];
            }

            NSFileManager *fm = [NSFileManager defaultManager];
            NSMutableSet<NSString *> *seenPaths = [NSMutableSet set];
            NSMutableArray<NSDictionary *> *entries = [NSMutableArray array];

            for (NSURL *appURL in allURLs) {
                if (![appURL isFileURL]) continue;
                NSString *appPath = [[appURL path] stringByStandardizingPath];
                if (appPath == nil || [appPath length] == 0) continue;
                if ([seenPaths containsObject:appPath]) continue;
                if (![fm fileExistsAtPath:appPath]) continue;
                [seenPaths addObject:appPath];

                NSBundle *bundle = [NSBundle bundleWithURL:appURL];
                NSString *dispName = mine_localized_app_name(appURL, bundle, prefer_zh);
                NSString *bundleId = [bundle bundleIdentifier] ?: @"";
                BOOL isDef = (defaultStdPath != nil && [appPath isEqualToString:defaultStdPath]);

                [entries addObject:@{
                    @"is_default": @(isDef ? 1 : 0),
                    @"name": mine_sanitize_tsv_field(dispName),
                    @"bundle_id": mine_sanitize_tsv_field(bundleId),
                    @"path": mine_sanitize_tsv_field(appPath),
                }];
            }

            // Sort: default app first, then exact Finder locale collation (CJK before A-Z in zh_TW)
            NSLocale *sortLocale = [NSLocale localeWithLocaleIdentifier:(prefer_zh ? @"zh_TW" : @"en_US")];
            NSStringCompareOptions cmpOpts = NSCaseInsensitiveSearch | NSNumericSearch;
            [entries sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
                int da = [a[@"is_default"] intValue];
                int db = [b[@"is_default"] intValue];
                if (da != db) {
                    return da > db ? NSOrderedAscending : NSOrderedDescending;
                }
                NSString *na = a[@"name"];
                NSString *nb = b[@"name"];
                NSComparisonResult cmp = [na compare:nb options:cmpOpts range:NSMakeRange(0, [na length]) locale:sortLocale];
                if (cmp != NSOrderedSame) return cmp;
                return [a[@"path"] compare:b[@"path"]];
            }];

            NSMutableString *tsv = [NSMutableString string];
            NSUInteger limit = MIN([entries count], (NSUInteger)64);
            for (NSUInteger i = 0; i < limit; i++) {
                NSDictionary *e = entries[i];
                [tsv appendFormat:@"%d\t%@\t%@\t%@\n",
                    [e[@"is_default"] intValue],
                    e[@"name"],
                    e[@"bundle_id"],
                    e[@"path"]];
            }

            NSData *utf8 = [tsv dataUsingEncoding:NSUTF8StringEncoding];
            if (utf8 == nil || [utf8 length] == 0) {
                return 0;
            }
            uint8_t *buf = (uint8_t *)malloc([utf8 length]);
            if (buf == NULL) {
                return 0;
            }
            memcpy(buf, [utf8 bytes], [utf8 length]);
            *out_buf = buf;
            *out_len = (int)[utf8 length];
            return 1;
        } @catch (NSException *ex) {
            (void)ex;
            return 0;
        }
    }
}

int mine_macos_get_app_icon_rgba(
    const char *app_path_utf8,
    int size_px,
    uint8_t **out_rgba,
    int *out_w,
    int *out_h
) {
    if (app_path_utf8 == NULL || out_rgba == NULL || out_w == NULL || out_h == NULL) {
        return 0;
    }
    *out_rgba = NULL;
    *out_w = 0;
    *out_h = 0;
    if (size_px < 16) size_px = 16;
    if (size_px > 128) size_px = 128;

    @autoreleasepool {
        @try {
            NSString *nsPath = [NSString stringWithUTF8String:app_path_utf8];
            if (nsPath == nil || [nsPath length] == 0) return 0;
            NSImage *icon = [[NSWorkspace sharedWorkspace] iconForFile:nsPath];
            if (icon == nil) return 0;

            NSRect proposed = NSMakeRect(0, 0, (CGFloat)size_px, (CGFloat)size_px);
            CGImageRef cgImg = [icon CGImageForProposedRect:&proposed context:nil hints:nil];
            if (cgImg == NULL) return 0;

            size_t w = (size_t)size_px;
            size_t h = (size_t)size_px;
            uint8_t *buf = (uint8_t *)calloc(1, w * h * 4);
            if (buf == NULL) return 0;

            CGColorSpaceRef cs = CGColorSpaceCreateWithName(kCGColorSpaceSRGB);
            if (cs == NULL) {
                cs = CGColorSpaceCreateDeviceRGB();
            }
            CGBitmapInfo bi = kCGBitmapByteOrder32Big | kCGImageAlphaPremultipliedLast;
            CGContextRef ctx = CGBitmapContextCreate(buf, w, h, 8, w * 4, cs, bi);
            CGColorSpaceRelease(cs);
            if (ctx == NULL) {
                free(buf);
                return 0;
            }
            CGContextSetInterpolationQuality(ctx, kCGInterpolationHigh);
            CGContextDrawImage(ctx, CGRectMake(0, 0, (CGFloat)w, (CGFloat)h), cgImg);
            CGContextRelease(ctx);

            // Unpremultiply translucent pixels for egui::ColorImage::from_rgba_unmultiplied
            size_t pxCount = w * h;
            for (size_t i = 0; i < pxCount; i++) {
                uint8_t *px = buf + i * 4;
                uint8_t a = px[3];
                if (a > 0 && a < 255) {
                    px[0] = (uint8_t)((((uint32_t)px[0] * 255u) + (a / 2u)) / a);
                    px[1] = (uint8_t)((((uint32_t)px[1] * 255u) + (a / 2u)) / a);
                    px[2] = (uint8_t)((((uint32_t)px[2] * 255u) + (a / 2u)) / a);
                }
            }

            *out_rgba = buf;
            *out_w = (int)w;
            *out_h = (int)h;
            return 1;
        } @catch (NSException *ex) {
            (void)ex;
            return 0;
        }
    }
}

int mine_macos_set_default_app_for_file(
    const char *file_path_utf8,
    const char *app_path_utf8
) {
    if (file_path_utf8 == NULL || app_path_utf8 == NULL) {
        return 0;
    }
    @autoreleasepool {
        @try {
            NSString *filePath = [NSString stringWithUTF8String:file_path_utf8];
            NSString *appPath = [NSString stringWithUTF8String:app_path_utf8];
            if (filePath == nil || appPath == nil) return 0;

            NSURL *fileURL = [NSURL fileURLWithPath:filePath];
            NSURL *appURL = [NSURL fileURLWithPath:appPath];
            NSBundle *bundle = [NSBundle bundleWithURL:appURL];
            NSString *bundleId = [bundle bundleIdentifier];
            if (bundleId == nil || [bundleId length] == 0) {
                return 0;
            }

            NSString *uti = nil;
            UTType *utType = nil;
            id val = nil;
            if ([fileURL getResourceValue:&val forKey:NSURLContentTypeKey error:nil] && [val isKindOfClass:[UTType class]]) {
                utType = (UTType *)val;
                uti = [utType identifier];
            }
            if (uti == nil || [uti length] == 0) {
                NSString *ext = [[filePath pathExtension] lowercaseString];
                if ([ext length] > 0) {
                    utType = [UTType typeWithFilenameExtension:ext];
                    uti = [utType identifier];
                }
            }
            if (uti == nil || [uti length] == 0) {
                return 0;
            }

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
            OSStatus st = LSSetDefaultRoleHandlerForContentType(
                (__bridge CFStringRef)uti,
                kLSRolesAll,
                (__bridge CFStringRef)bundleId
            );
#pragma clang diagnostic pop

            if (st == noErr) {
                return 1;
            }
            if (@available(macOS 12.0, *)) {
                if (utType != nil) {
                    [[NSWorkspace sharedWorkspace] setDefaultApplicationAtURL:appURL
                                                            toOpenContentType:utType
                                                            completionHandler:^(NSError * _Nullable err) {
                        (void)err;
                    }];
                    return 1;
                }
            }
            return 0;
        } @catch (NSException *ex) {
            (void)ex;
            return 0;
        }
    }
}

int mine_macos_choose_app_dialog(
    const char *ext_utf8,
    int is_zh,
    uint8_t **out_app_path,
    int *out_len,
    int *out_always_default
) {
    if (out_app_path == NULL || out_len == NULL || out_always_default == NULL) {
        return 0;
    }
    *out_app_path = NULL;
    *out_len = 0;
    *out_always_default = 0;

    @autoreleasepool {
        @try {
            NSOpenPanel *panel = [NSOpenPanel openPanel];
            [panel setCanChooseFiles:YES];
            [panel setCanChooseDirectories:NO];
            [panel setAllowsMultipleSelection:NO];
            [panel setTreatsFilePackagesAsDirectories:NO];
            [panel setDirectoryURL:[NSURL fileURLWithPath:@"/Applications"]];
            [panel setAllowedContentTypes:@[UTTypeApplicationBundle]];
            [panel setPrompt:(is_zh ? @"開啟" : @"Open")];
            [panel setMessage:(is_zh ? @"選擇要用來開啟檔案的應用程式" : @"Choose an application to open this file")];

            NSString *extStr = (ext_utf8 != NULL) ? [NSString stringWithUTF8String:ext_utf8] : @"";
            NSButton *alwaysCheckbox = nil;
            if (extStr != nil && [extStr length] > 0) {
                NSString *chkTitle = is_zh
                    ? [NSString stringWithFormat:@"永遠以此應用程式開啟所有「.%@」檔案", extStr]
                    : [NSString stringWithFormat:@"Always open all \".%@\" files with this application", extStr];
                alwaysCheckbox = [NSButton checkboxWithTitle:chkTitle target:nil action:nil];
                [alwaysCheckbox setState:NSControlStateValueOff];
                [alwaysCheckbox sizeToFit];
                NSView *acc = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, MAX(340.0, alwaysCheckbox.frame.size.width + 24.0), 34.0)];
                [alwaysCheckbox setFrameOrigin:NSMakePoint(12.0, 8.0)];
                [acc addSubview:alwaysCheckbox];
                [panel setAccessoryView:acc];
            }

            NSModalResponse resp = [panel runModal];
            mine_macos_post_synthetic_mouse_up();
            if (resp != NSModalResponseOK) {
                return 0;
            }
            NSURL *chosen = [panel URL];
            if (chosen == nil || ![chosen isFileURL]) {
                return 0;
            }
            NSString *chosenPath = [[chosen path] stringByStandardizingPath];
            NSData *utf8 = [chosenPath dataUsingEncoding:NSUTF8StringEncoding];
            if (utf8 == nil || [utf8 length] == 0) {
                return 0;
            }
            uint8_t *buf = (uint8_t *)malloc([utf8 length]);
            if (buf == NULL) {
                return 0;
            }
            memcpy(buf, [utf8 bytes], [utf8 length]);
            *out_app_path = buf;
            *out_len = (int)[utf8 length];
            *out_always_default = (alwaysCheckbox != nil && [alwaysCheckbox state] == NSControlStateValueOn) ? 1 : 0;
            return 1;
        } @catch (NSException *ex) {
            (void)ex;
            return 0;
        }
    }
}
