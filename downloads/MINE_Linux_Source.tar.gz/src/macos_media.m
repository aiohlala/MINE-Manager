#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreGraphics/CoreGraphics.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

@interface MineAvSession : NSObject
@property (nonatomic, strong) AVURLAsset *asset;
@property (nonatomic, strong) AVPlayerItem *item;
@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic, strong) AVPlayerItemVideoOutput *videoOutput;
@property (nonatomic, assign) BOOL hasVideo;
@property (nonatomic, assign) BOOL forceNextFrame;
@property (nonatomic, assign) double cachedDuration;
@property (nonatomic, assign) int rotationDeg;
@end

@implementation MineAvSession
@end

void mine_av_free_buffer(uint8_t *ptr) {
    if (ptr != NULL) {
        free(ptr);
    }
}

int mine_av_extract_thumbnail(
    const char *path_utf8,
    int max_dim,
    uint8_t **out_rgba,
    int *out_w,
    int *out_h
) {
    if (!path_utf8 || !out_rgba || !out_w || !out_h || max_dim <= 0) {
        return 0;
    }
    *out_rgba = NULL;
    *out_w = 0;
    *out_h = 0;

    @autoreleasepool {
        NSString *nsPath = [NSString stringWithUTF8String:path_utf8];
        if (!nsPath) return 0;
        NSURL *url = [NSURL fileURLWithPath:nsPath];
        AVURLAsset *asset = [AVURLAsset URLAssetWithURL:url options:@{
            AVURLAssetPreferPreciseDurationAndTimingKey: @NO
        }];
        if (!asset) return 0;

        AVAssetImageGenerator *gen = [[AVAssetImageGenerator alloc] initWithAsset:asset];
        gen.appliesPreferredTrackTransform = YES;
        gen.maximumSize = CGSizeMake((CGFloat)max_dim, (CGFloat)max_dim);
        gen.requestedTimeToleranceBefore = CMTimeMakeWithSeconds(1.0, 600);
        gen.requestedTimeToleranceAfter = CMTimeMakeWithSeconds(1.0, 600);

        CMTime duration = asset.duration;
        double durSec = CMTIME_IS_NUMERIC(duration) ? CMTimeGetSeconds(duration) : 0.0;
        double targetSec = (durSec > 2.0) ? fmin(1.5, durSec * 0.1) : 0.0;
        CMTime reqTime = CMTimeMakeWithSeconds(targetSec, 600);

        NSError *err = nil;
        CGImageRef cgImg = [gen copyCGImageAtTime:reqTime actualTime:NULL error:&err];
        if (!cgImg && targetSec > 0.0) {
            cgImg = [gen copyCGImageAtTime:kCMTimeZero actualTime:NULL error:&err];
        }
        if (!cgImg) {
            return 0;
        }

        size_t w = CGImageGetWidth(cgImg);
        size_t h = CGImageGetHeight(cgImg);
        if (w == 0 || h == 0 || w > 4096 || h > 4096) {
            CGImageRelease(cgImg);
            return 0;
        }

        size_t byteCount = w * h * 4;
        uint8_t *buf = (uint8_t *)calloc(1, byteCount);
        if (!buf) {
            CGImageRelease(cgImg);
            return 0;
        }

        CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
        CGBitmapInfo bitmapInfo = kCGBitmapByteOrder32Big | kCGImageAlphaPremultipliedLast;
        CGContextRef ctx = CGBitmapContextCreate(buf, w, h, 8, w * 4, cs, bitmapInfo);
        CGColorSpaceRelease(cs);
        if (!ctx) {
            free(buf);
            CGImageRelease(cgImg);
            return 0;
        }

        CGContextDrawImage(ctx, CGRectMake(0, 0, (CGFloat)w, (CGFloat)h), cgImg);
        CGContextRelease(ctx);
        CGImageRelease(cgImg);

        *out_rgba = buf;
        *out_w = (int)w;
        *out_h = (int)h;
        return 1;
    }
}

void *mine_av_create(const char *path_utf8, float volume, int muted) {
    if (!path_utf8) return NULL;
    @autoreleasepool {
        NSString *nsPath = [NSString stringWithUTF8String:path_utf8];
        if (!nsPath) return NULL;
        NSURL *url = [NSURL fileURLWithPath:nsPath];
        AVURLAsset *asset = [AVURLAsset URLAssetWithURL:url options:nil];
        if (!asset) return NULL;

        AVPlayerItem *item = [AVPlayerItem playerItemWithAsset:asset];
        if (!item) return NULL;

        NSDictionary *pixAttrs = @{
            (NSString *)kCVPixelBufferPixelFormatTypeKey: @(kCVPixelFormatType_32BGRA)
        };
        AVPlayerItemVideoOutput *videoOut = [[AVPlayerItemVideoOutput alloc] initWithPixelBufferAttributes:pixAttrs];
        [item addOutput:videoOut];

        AVPlayer *player = [AVPlayer playerWithPlayerItem:item];
        player.actionAtItemEnd = AVPlayerActionAtItemEndPause;
        player.volume = volume;
        player.muted = (muted != 0);

        MineAvSession *sess = [[MineAvSession alloc] init];
        sess.asset = asset;
        sess.item = item;
        sess.player = player;
        sess.videoOutput = videoOut;
        NSArray<AVAssetTrack *> *videoTracks = [asset tracksWithMediaType:AVMediaTypeVideo];
        sess.hasVideo = (videoTracks.count > 0);
        sess.rotationDeg = 0;
        if (videoTracks.count > 0) {
            CGAffineTransform tx = videoTracks[0].preferredTransform;
            if (tx.a == 0 && tx.b == 1.0 && tx.c == -1.0 && tx.d == 0) {
                sess.rotationDeg = 90;
            } else if (tx.a == 0 && tx.b == -1.0 && tx.c == 1.0 && tx.d == 0) {
                sess.rotationDeg = 270;
            } else if (tx.a == -1.0 && tx.b == 0 && tx.c == 0 && tx.d == -1.0) {
                sess.rotationDeg = 180;
            }
        }
        sess.forceNextFrame = YES;

        CMTime dur = asset.duration;
        if (CMTIME_IS_NUMERIC(dur) && !CMTIME_IS_INDEFINITE(dur)) {
            double s = CMTimeGetSeconds(dur);
            sess.cachedDuration = (s > 0.0 && isfinite(s)) ? s : 0.0;
        } else {
            sess.cachedDuration = 0.0;
        }

        return (__bridge_retained void *)sess;
    }
}

void mine_av_destroy(void *handle) {
    if (!handle) return;
    @autoreleasepool {
        MineAvSession *sess = (__bridge_transfer MineAvSession *)handle;
        [sess.player pause];
        if (sess.item && sess.videoOutput) {
            [sess.item removeOutput:sess.videoOutput];
        }
        [sess.player replaceCurrentItemWithPlayerItem:nil];
        sess.videoOutput = nil;
        sess.item = nil;
        sess.player = nil;
        sess.asset = nil;
    }
}

void mine_av_play(void *handle) {
    if (!handle) return;
    @autoreleasepool {
        MineAvSession *sess = (__bridge MineAvSession *)handle;
        double dur = sess.cachedDuration;
        CMTime cur = sess.player.currentTime;
        double pos = CMTIME_IS_NUMERIC(cur) ? CMTimeGetSeconds(cur) : 0.0;
        if (dur > 0.1 && pos >= dur - 0.1) {
            [sess.player seekToTime:kCMTimeZero toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero];
        }
        [sess.player play];
        sess.forceNextFrame = YES;
    }
}

void mine_av_pause(void *handle) {
    if (!handle) return;
    @autoreleasepool {
        MineAvSession *sess = (__bridge MineAvSession *)handle;
        [sess.player pause];
    }
}

void mine_av_seek(void *handle, double sec) {
    if (!handle) return;
    @autoreleasepool {
        MineAvSession *sess = (__bridge MineAvSession *)handle;
        if (sec < 0.0) sec = 0.0;
        CMTime t = CMTimeMakeWithSeconds(sec, 600);
        [sess.player seekToTime:t toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero];
        sess.forceNextFrame = YES;
    }
}

void mine_av_set_volume(void *handle, float vol, int muted) {
    if (!handle) return;
    @autoreleasepool {
        MineAvSession *sess = (__bridge MineAvSession *)handle;
        if (vol < 0.0f) vol = 0.0f;
        if (vol > 1.0f) vol = 1.0f;
        sess.player.volume = vol;
        sess.player.muted = (muted != 0);
    }
}

void mine_av_get_state(
    void *handle,
    double *out_pos,
    double *out_dur,
    int *out_playing,
    int *out_has_video,
    int *out_ready,
    int *out_error
) {
    if (!handle) return;
    @autoreleasepool {
        MineAvSession *sess = (__bridge MineAvSession *)handle;
        CMTime cur = sess.player.currentTime;
        double pos = (CMTIME_IS_NUMERIC(cur) && !CMTIME_IS_INDEFINITE(cur)) ? CMTimeGetSeconds(cur) : 0.0;
        if (!isfinite(pos) || pos < 0.0) pos = 0.0;

        double dur = sess.cachedDuration;
        if (dur <= 0.0 && sess.item) {
            CMTime idur = sess.item.duration;
            if (CMTIME_IS_NUMERIC(idur) && !CMTIME_IS_INDEFINITE(idur)) {
                double s = CMTimeGetSeconds(idur);
                if (isfinite(s) && s > 0.0) {
                    dur = s;
                    sess.cachedDuration = s;
                }
            }
        }

        if (out_pos) *out_pos = pos;
        if (out_dur) *out_dur = dur;
        if (out_playing) *out_playing = (sess.player.rate > 0.01f) ? 1 : 0;
        if (out_has_video) *out_has_video = sess.hasVideo ? 1 : 0;
        if (out_ready) *out_ready = (sess.item.status == AVPlayerItemStatusReadyToPlay) ? 1 : 0;
        if (out_error) *out_error = (sess.item.status == AVPlayerItemStatusFailed) ? 1 : 0;
    }
}

int mine_av_copy_frame_rgba(
    void *handle,
    int max_width,
    uint8_t **out_rgba,
    int *out_w,
    int *out_h
) {
    if (!handle || !out_rgba || !out_w || !out_h) return 0;
    *out_rgba = NULL;
    *out_w = 0;
    *out_h = 0;

    @autoreleasepool {
        MineAvSession *sess = (__bridge MineAvSession *)handle;
        if (!sess.hasVideo || !sess.videoOutput) return 0;
        if (sess.item.status != AVPlayerItemStatusReadyToPlay) return 0;

        CMTime t = [sess.videoOutput itemTimeForHostTime:CACurrentMediaTime()];
        BOOL hasNew = [sess.videoOutput hasNewPixelBufferForItemTime:t];
        if (!hasNew && !sess.forceNextFrame) {
            return 0;
        }

        CVPixelBufferRef pb = [sess.videoOutput copyPixelBufferForItemTime:t itemTimeForDisplay:NULL];
        if (!pb) {
            CMTime cur = sess.player.currentTime;
            pb = [sess.videoOutput copyPixelBufferForItemTime:cur itemTimeForDisplay:NULL];
        }
        if (!pb) {
            return 0;
        }
        sess.forceNextFrame = NO;

        CVPixelBufferLockBaseAddress(pb, kCVPixelBufferLock_ReadOnly);
        size_t srcW = CVPixelBufferGetWidth(pb);
        size_t srcH = CVPixelBufferGetHeight(pb);
        size_t bytesPerRow = CVPixelBufferGetBytesPerRow(pb);
        const uint8_t *base = (const uint8_t *)CVPixelBufferGetBaseAddress(pb);

        if (!base || srcW == 0 || srcH == 0) {
            CVPixelBufferUnlockBaseAddress(pb, kCVPixelBufferLock_ReadOnly);
            CVBufferRelease(pb);
            return 0;
        }

        size_t step = 1;
        size_t maxSrc = (srcW > srcH) ? srcW : srcH;
        if (max_width > 0 && maxSrc > (size_t)max_width) {
            step = (maxSrc + (size_t)max_width - 1) / (size_t)max_width;
            if (step < 1) step = 1;
        }
        size_t subW = (srcW + step - 1) / step;
        size_t subH = (srcH + step - 1) / step;
        int rot = sess.rotationDeg;
        size_t dstW = (rot == 90 || rot == 270) ? subH : subW;
        size_t dstH = (rot == 90 || rot == 270) ? subW : subH;
        uint8_t *rgba = (uint8_t *)malloc(dstW * dstH * 4);
        if (!rgba) {
            CVPixelBufferUnlockBaseAddress(pb, kCVPixelBufferLock_ReadOnly);
            CVBufferRelease(pb);
            return 0;
        }

        for (size_t y = 0; y < subH; y++) {
            size_t sy = y * step;
            if (sy >= srcH) sy = srcH - 1;
            const uint8_t *srcRow = base + sy * bytesPerRow;
            for (size_t x = 0; x < subW; x++) {
                size_t sx = x * step;
                if (sx >= srcW) sx = srcW - 1;
                const uint8_t *px = srcRow + sx * 4;
                size_t dx, dy;
                if (rot == 90) {
                    dx = subH - 1 - y;
                    dy = x;
                } else if (rot == 270) {
                    dx = y;
                    dy = subW - 1 - x;
                } else if (rot == 180) {
                    dx = subW - 1 - x;
                    dy = subH - 1 - y;
                } else {
                    dx = x;
                    dy = y;
                }
                uint8_t *dstPx = rgba + (dy * dstW + dx) * 4;
                // BGRA -> RGBA
                dstPx[0] = px[2];
                dstPx[1] = px[1];
                dstPx[2] = px[0];
                dstPx[3] = 255;
            }
        }

        CVPixelBufferUnlockBaseAddress(pb, kCVPixelBufferLock_ReadOnly);
        CVBufferRelease(pb);

        *out_rgba = rgba;
        *out_w = (int)dstW;
        *out_h = (int)dstH;
        return 1;
    }
}
