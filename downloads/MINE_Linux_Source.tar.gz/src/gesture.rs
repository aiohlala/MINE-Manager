use serde::{Deserialize, Serialize};
use std::collections::HashMap;

use crate::i18n::Language;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum GestureAction {
    NavigateBack,
    NavigateForward,
    NavigateUp,
    NewMdiWindow,
    CloneActiveWindow,
    CloseActiveWindow,
    RestoreClosedWindow,
    RefreshActiveWindow,
    TileGrid,
    TileHorizontally,
    TileVertically,
    CascadeWindows,
    ToggleTabbedMode,
    ScrollToTop,
    ScrollToBottom,
    OpenGlobalSearch,
}

impl GestureAction {
    pub fn all() -> &'static [GestureAction] {
        &[
            GestureAction::NavigateBack,
            GestureAction::NavigateForward,
            GestureAction::NavigateUp,
            GestureAction::NewMdiWindow,
            GestureAction::CloneActiveWindow,
            GestureAction::CloseActiveWindow,
            GestureAction::RestoreClosedWindow,
            GestureAction::RefreshActiveWindow,
            GestureAction::TileGrid,
            GestureAction::TileHorizontally,
            GestureAction::TileVertically,
            GestureAction::CascadeWindows,
            GestureAction::ToggleTabbedMode,
            GestureAction::ScrollToTop,
            GestureAction::ScrollToBottom,
            GestureAction::OpenGlobalSearch,
        ]
    }

    pub fn label(&self, lang: Language) -> &'static str {
        match (self, lang) {
            (Self::NavigateBack, Language::ZhTw) => "⬅ 返回上一頁 (Back)",
            (Self::NavigateBack, Language::En) => "⬅ Navigate Back",
            (Self::NavigateForward, Language::ZhTw) => "➡ 前往下一頁 (Forward)",
            (Self::NavigateForward, Language::En) => "➡ Navigate Forward",
            (Self::NavigateUp, Language::ZhTw) => "⬆ 往上一層目錄 (Up Directory)",
            (Self::NavigateUp, Language::En) => "⬆ Up One Directory",
            (Self::NewMdiWindow, Language::ZhTw) => "➕ 開啟新 MDI 子視窗 (New Window)",
            (Self::NewMdiWindow, Language::En) => "➕ Open New MDI Window",
            (Self::CloneActiveWindow, Language::ZhTw) => "📑 複製目前子視窗 (Clone Window)",
            (Self::CloneActiveWindow, Language::En) => "📑 Clone Active Window",
            (Self::CloseActiveWindow, Language::ZhTw) => "❌ 關閉目前子視窗 (Close Window)",
            (Self::CloseActiveWindow, Language::En) => "❌ Close Active Window",
            (Self::RestoreClosedWindow, Language::ZhTw) => "🕒 恢復剛關閉的視窗 (Restore Closed)",
            (Self::RestoreClosedWindow, Language::En) => "🕒 Restore Last Closed Window",
            (Self::RefreshActiveWindow, Language::ZhTw) => "🔄 重新整理目錄 (Refresh)",
            (Self::RefreshActiveWindow, Language::En) => "🔄 Refresh Directory",
            (Self::TileGrid, Language::ZhTw) => "田 智慧網格並排所有視窗 (Auto Grid Tile)",
            (Self::TileGrid, Language::En) => "田 Smart Grid Tile All Windows",
            (Self::TileHorizontally, Language::ZhTw) => "⬌ 左右並排所有視窗 (Tile Horizontally)",
            (Self::TileHorizontally, Language::En) => "⬌ Tile Horizontally",
            (Self::TileVertically, Language::ZhTw) => "⬍ 上下並排所有視窗 (Tile Vertically)",
            (Self::TileVertically, Language::En) => "⬍ Tile Vertically",
            (Self::CascadeWindows, Language::ZhTw) => "🗗 層疊排列視窗 (Cascade)",
            (Self::CascadeWindows, Language::En) => "🗗 Cascade Windows",
            (Self::ToggleTabbedMode, Language::ZhTw) => "🗂 切換單一分頁/多重視窗模式",
            (Self::ToggleTabbedMode, Language::En) => "🗂 Toggle Tabbed / MDI Mode",
            (Self::ScrollToTop, Language::ZhTw) => "⏫ 快速捲動至列表開頭 (Scroll Top)",
            (Self::ScrollToTop, Language::En) => "⏫ Scroll to List Top",
            (Self::ScrollToBottom, Language::ZhTw) => "⏬ 快速捲動至列表結尾 (Scroll Bottom)",
            (Self::ScrollToBottom, Language::En) => "⏬ Scroll to List Bottom",
            (Self::OpenGlobalSearch, Language::ZhTw) => "🔍 開啟次世代強化搜尋引擎",
            (Self::OpenGlobalSearch, Language::En) => "🔍 Open Ultra-Fast Search",
        }
    }
}

pub struct GestureTracker {
    pub is_tracking: bool,
    pub trail: Vec<egui::Pos2>,
    pub current_directions: String,
    pub bindings: HashMap<String, GestureAction>,
}

impl Default for GestureTracker {
    fn default() -> Self {
        Self {
            is_tracking: false,
            trail: Vec::new(),
            current_directions: String::new(),
            bindings: Self::default_bindings(),
        }
    }
}

impl GestureTracker {
    pub fn default_bindings() -> HashMap<String, GestureAction> {
        let mut map = HashMap::new();
        map.insert("L".to_string(), GestureAction::NavigateBack);
        map.insert("R".to_string(), GestureAction::NavigateForward);
        map.insert("U".to_string(), GestureAction::NavigateUp);
        map.insert("D".to_string(), GestureAction::NewMdiWindow);
        map.insert("DR".to_string(), GestureAction::CloseActiveWindow);
        map.insert("DL".to_string(), GestureAction::RestoreClosedWindow);
        map.insert("UD".to_string(), GestureAction::RefreshActiveWindow);
        map.insert("UR".to_string(), GestureAction::CloneActiveWindow);
        map.insert("UL".to_string(), GestureAction::TileGrid);
        map.insert("LR".to_string(), GestureAction::TileHorizontally);
        map.insert("RL".to_string(), GestureAction::TileVertically);
        map.insert("RU".to_string(), GestureAction::ScrollToTop);
        map.insert("RD".to_string(), GestureAction::ScrollToBottom);
        map.insert("DU".to_string(), GestureAction::OpenGlobalSearch);
        map
    }

    pub fn format_arrows(seq: &str) -> String {
        seq.chars()
            .map(|c| match c {
                'L' => "←",
                'R' => "→",
                'U' => "↑",
                'D' => "↓",
                _ => "?",
            })
            .collect::<Vec<_>>()
            .join(" ")
    }

    pub fn start(&mut self, pos: egui::Pos2) {
        self.is_tracking = true;
        self.trail.clear();
        self.trail.push(pos);
        self.current_directions.clear();
    }

    pub fn update_pos(&mut self, pos: egui::Pos2) {
        if !self.is_tracking {
            return;
        }
        if let Some(&last) = self.trail.last() {
            let delta = pos - last;
            if delta.length() >= 8.0 {
                self.trail.push(pos);
            }
        } else {
            self.trail.push(pos);
        }

        // Recompute direction sequence using anchor points with 26px threshold
        let mut seq = String::new();
        if let Some(&first) = self.trail.first() {
            let mut anchor = first;
            for &pt in &self.trail[1..] {
                let d = pt - anchor;
                if d.length() >= 26.0 {
                    let dir = if d.x.abs() > d.y.abs() {
                        if d.x > 0.0 {
                            'R'
                        } else {
                            'L'
                        }
                    } else if d.y > 0.0 {
                        'D'
                    } else {
                        'U'
                    };
                    if !seq.ends_with(dir) && seq.len() < 4 {
                        seq.push(dir);
                    }
                    anchor = pt;
                }
            }
        }
        self.current_directions = seq;
    }

    pub fn finish(&mut self) -> Option<(String, GestureAction)> {
        self.is_tracking = false;
        let seq = self.current_directions.clone();
        self.trail.clear();
        self.current_directions.clear();
        if seq.is_empty() {
            return None;
        }
        self.bindings.get(&seq).copied().map(|act| (seq, act))
    }

    pub fn current_matched_action(&self) -> Option<GestureAction> {
        if self.current_directions.is_empty() {
            None
        } else {
            self.bindings.get(&self.current_directions).copied()
        }
    }
}
