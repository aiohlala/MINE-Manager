use crate::fs_ops::{read_dir_non_blocking, FileEntry, SmbShareBookmark};
use crate::gesture::GestureAction;
use crate::i18n::Language;
use crate::search::{PaneSearchMode, SmartQuery};
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::path::PathBuf;
use std::sync::mpsc::Receiver;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum WindowLayoutMode {
    /// MDIE "通常 (Normal MDI)" - Free floating overlapping sub-windows inside workspace
    MdiFree,
    /// Smart auto-grid tiling for unlimited windows (2, 3, 4, 6, 9, 12...)
    TileGrid,
    /// Side-by-side N columns ("左右並排")
    TileHorizontally,
    /// Stacked N rows ("上下並排")
    TileVertically,
    /// Classic MDI Cascade ("重疊顯示")
    Cascade,
    /// Maximized single active tab ("分頁模式")
    TabbedMaximized,
}

impl Default for WindowLayoutMode {
    fn default() -> Self {
        Self::TileHorizontally
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SortColumn {
    Name,
    Size,
    Type,
    Modified,
    Directory,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PaneColumn {
    Name,
    Directory,
    Size,
    Type,
    Modified,
}

impl PaneColumn {
    pub fn default_order() -> Vec<PaneColumn> {
        vec![
            PaneColumn::Name,
            PaneColumn::Directory,
            PaneColumn::Size,
            PaneColumn::Type,
            PaneColumn::Modified,
        ]
    }

    pub fn sort_column(&self) -> SortColumn {
        match self {
            PaneColumn::Name => SortColumn::Name,
            PaneColumn::Directory => SortColumn::Directory,
            PaneColumn::Size => SortColumn::Size,
            PaneColumn::Type => SortColumn::Type,
            PaneColumn::Modified => SortColumn::Modified,
        }
    }
}

pub fn default_column_order() -> Vec<PaneColumn> {
    PaneColumn::default_order()
}

pub fn default_font_size() -> f32 {
    13.5
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PaneViewMode {
    Details,
    List,
    SmallIcons,
    LargeIcons,
    Thumbnails,
}

impl Default for PaneViewMode {
    fn default() -> Self {
        Self::Details
    }
}

pub fn default_thumbnail_size() -> f32 {
    96.0
}



#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AppTheme {
    #[serde(alias = "ClassicMdie")]
    MidnightBlue,
    ModernDark,
    CleanLight,
}

impl AppTheme {
    pub fn is_dark(self) -> bool {
        matches!(self, Self::ModernDark | Self::MidnightBlue)
    }
}

impl Default for AppTheme {
    fn default() -> Self {
        Self::MidnightBlue
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkspaceGroupBookmark {
    pub name: String,
    pub layout: WindowLayoutMode,
    pub paths: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuickAccessItem {
    pub id: String,
    pub name: String,
    pub path: String,
    #[serde(default = "default_quick_icon")]
    pub icon: String,
    #[serde(default = "default_true")]
    pub is_visible: bool,
    #[serde(default)]
    pub is_builtin: bool,
}

fn default_quick_icon() -> String {
    "📁".into()
}

fn default_true() -> bool {
    true
}

pub fn default_quick_access_items() -> Vec<QuickAccessItem> {
    let mut items = Vec::new();
    if let Some(h) = dirs::home_dir() {
        items.push(QuickAccessItem {
            id: "builtin_home".into(),
            name: "Home 主目錄".into(),
            path: h.to_string_lossy().into_owned(),
            icon: "🏠".into(),
            is_visible: true,
            is_builtin: true,
        });
    }
    if let Some(d) = dirs::desktop_dir() {
        items.push(QuickAccessItem {
            id: "builtin_desktop".into(),
            name: "Desktop 桌面".into(),
            path: d.to_string_lossy().into_owned(),
            icon: "🖥".into(),
            is_visible: true,
            is_builtin: true,
        });
    }
    if let Some(dl) = dirs::download_dir() {
        items.push(QuickAccessItem {
            id: "builtin_downloads".into(),
            name: "Downloads 下載".into(),
            path: dl.to_string_lossy().into_owned(),
            icon: "📥".into(),
            is_visible: true,
            is_builtin: true,
        });
    }
    if let Some(doc) = dirs::document_dir() {
        items.push(QuickAccessItem {
            id: "builtin_documents".into(),
            name: "Documents 文件".into(),
            path: doc.to_string_lossy().into_owned(),
            icon: "📄".into(),
            is_visible: true,
            is_builtin: true,
        });
    }
    if let Some(pic) = dirs::picture_dir() {
        items.push(QuickAccessItem {
            id: "builtin_pictures".into(),
            name: "Pictures 圖片".into(),
            path: pic.to_string_lossy().into_owned(),
            icon: "🖼".into(),
            is_visible: true,
            is_builtin: true,
        });
    }
    if let Some(mus) = dirs::audio_dir() {
        items.push(QuickAccessItem {
            id: "builtin_music".into(),
            name: "Music 音樂".into(),
            path: mus.to_string_lossy().into_owned(),
            icon: "🎵".into(),
            is_visible: true,
            is_builtin: true,
        });
    }
    if let Some(vid) = dirs::video_dir() {
        items.push(QuickAccessItem {
            id: "builtin_videos".into(),
            name: "Videos 影片".into(),
            path: vid.to_string_lossy().into_owned(),
            icon: "🎬".into(),
            is_visible: true,
            is_builtin: true,
        });
    }
    items
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PortableConfig {
    #[serde(default)]
    pub config_version: u32,
    pub language: Language,
    pub theme: AppTheme,
    pub layout_mode: WindowLayoutMode,
    pub show_sidebar: bool,
    pub show_preview: bool,
    pub show_hidden: bool,
    pub sync_scroll: bool,
    pub open_pane_paths: Vec<String>,
    pub favorite_folders: Vec<(String, String)>,
    pub workspace_groups: Vec<WorkspaceGroupBookmark>,
    pub smb_bookmarks: Vec<SmbShareBookmark>,
    pub closed_history: Vec<String>,
    pub gesture_bindings: HashMap<String, GestureAction>,

    // Left Sidebar section visibility and customization
    #[serde(default = "default_true")]
    pub show_sidebar_quick_access: bool,
    #[serde(default = "default_true")]
    pub show_sidebar_this_pc: bool,
    #[serde(default = "default_true")]
    pub show_sidebar_network: bool,
    #[serde(default)]
    pub hide_offline_network_shares: bool,
    #[serde(default)]
    pub hidden_network_shares: Vec<String>,
    #[serde(default = "default_quick_access_items")]
    pub quick_access_items: Vec<QuickAccessItem>,
    #[serde(default = "default_column_order")]
    pub column_order: Vec<PaneColumn>,
    #[serde(default = "default_font_size")]
    pub file_list_font_size: f32,
    #[serde(default)]
    pub view_mode: PaneViewMode,
    #[serde(default = "default_thumbnail_size")]
    pub thumbnail_size: f32,
    #[serde(default)]
    pub window_bounds: Option<[f32; 4]>,
    #[serde(default)]
    pub window_maximized: bool,
    /// Optional per-extension custom default application override (lowercase ext without dot -> app path).
    #[serde(default)]
    pub custom_open_with_defaults: HashMap<String, String>,
}

impl Default for PortableConfig {
    fn default() -> Self {
        let home = dirs::home_dir().unwrap_or_else(|| PathBuf::from("."));
        let desktop = dirs::desktop_dir().unwrap_or_else(|| home.clone());
        let downloads = dirs::download_dir().unwrap_or_else(|| home.clone());

        Self {
            config_version: 2,
            language: Language::ZhTw,
            theme: AppTheme::MidnightBlue,
            layout_mode: WindowLayoutMode::TileHorizontally,
            show_sidebar: false,
            show_preview: false,
            show_hidden: false,
            sync_scroll: false,
            open_pane_paths: vec![home.to_string_lossy().into_owned()],
            favorite_folders: vec![
                ("⌂ Home / 個人主目錄".into(), home.to_string_lossy().into_owned()),
                ("▣ Desktop / 桌面".into(), desktop.to_string_lossy().into_owned()),
                ("⬇ Downloads / 下載".into(), downloads.to_string_lossy().into_owned()),
            ],
            workspace_groups: Vec::new(),
            smb_bookmarks: Vec::new(),
            closed_history: Vec::new(),
            gesture_bindings: crate::gesture::GestureTracker::default_bindings(),
            show_sidebar_quick_access: true,
            show_sidebar_this_pc: true,
            show_sidebar_network: true,
            hide_offline_network_shares: false,
            hidden_network_shares: Vec::new(),
            quick_access_items: default_quick_access_items(),
            column_order: default_column_order(),
            file_list_font_size: 13.5,
            view_mode: PaneViewMode::Details,
            thumbnail_size: 96.0,
            window_bounds: None,
            window_maximized: false,
            custom_open_with_defaults: HashMap::new(),
        }
    }
}

impl PortableConfig {
    pub fn config_file_path() -> PathBuf {
        if let Ok(exe) = std::env::current_exe() {
            if let Some(dir) = exe.parent() {
                let candidate = dir.join("mine_config.json");
                if candidate.exists() || is_dir_writable(dir) {
                    return candidate;
                }
            }
        }
        std::env::current_dir()
            .unwrap_or_else(|_| PathBuf::from("."))
            .join("mine_config.json")
    }

    pub fn load_or_default() -> Self {
        let path = Self::config_file_path();
        if let Ok(text) = std::fs::read_to_string(&path) {
            if let Ok(mut cfg) = serde_json::from_str::<PortableConfig>(&text) {
                let mut changed = false;
                // Clean up any legacy sample SMB entries if present from initial prototype
                let prev_len = cfg.smb_bookmarks.len();
                cfg.smb_bookmarks.retain(|b| {
                    !b.name.contains("AI_MINI") && b.name != "Localhost Loopback Test"
                });
                if cfg.smb_bookmarks.len() != prev_len {
                    changed = true;
                }
                if cfg.config_version < 2 {
                    cfg.config_version = 2;
                    cfg.show_sidebar = false;
                    cfg.show_preview = false;
                    if cfg.open_pane_paths.len() > 1 {
                        cfg.open_pane_paths.truncate(1);
                    }
                    changed = true;
                }
                if cfg.quick_access_items.is_empty() {
                    cfg.quick_access_items = default_quick_access_items();
                    changed = true;
                }
                if cfg.column_order.is_empty() {
                    cfg.column_order = default_column_order();
                    changed = true;
                } else {
                    for c in [
                        PaneColumn::Name,
                        PaneColumn::Directory,
                        PaneColumn::Size,
                        PaneColumn::Type,
                        PaneColumn::Modified,
                    ] {
                        if !cfg.column_order.contains(&c) {
                            cfg.column_order.push(c);
                            changed = true;
                        }
                    }
                }
                if cfg.file_list_font_size < 8.0 || cfg.file_list_font_size > 30.0 {
                    cfg.file_list_font_size = 13.5;
                    changed = true;
                }
                if changed {
                    let _ = cfg.save();
                }
                return cfg;
            }
        }
        Self::default()
    }

    pub fn save(&self) -> Result<PathBuf, String> {
        let path = Self::config_file_path();
        let json = serde_json::to_string_pretty(self).map_err(|e| e.to_string())?;
        std::fs::write(&path, json).map_err(|e| e.to_string())?;
        Ok(path)
    }

    pub fn sanitized_window_bounds(&self) -> Option<([f32; 2], [f32; 2])> {
        let [x, y, w, h] = self.window_bounds?;
        if !x.is_finite() || !y.is_finite() || !w.is_finite() || !h.is_finite() {
            return None;
        }
        if w < 640.0 || w > 7680.0 || h < 420.0 || h > 4320.0 {
            return None;
        }
        // Reject Win32 minimized (-32000, -32000) and absurd offscreen coordinates
        if x < -3840.0 || x > 7680.0 || y < -2160.0 || y > 4320.0 {
            return None;
        }
        Some(([x, y], [w, h]))
    }
}

fn is_dir_writable(dir: &std::path::Path) -> bool {
    let probe = dir.join(".mine_write_probe");
    if std::fs::write(&probe, b"ok").is_ok() {
        let _ = std::fs::remove_file(&probe);
        true
    } else {
        false
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScrollRequest {
    None,
    Top,
    Bottom,
    Row(usize),
}

#[derive(Debug, Default)]
pub struct PollLoadOutcome {
    pub completed: bool,
    pub was_silent: bool,
    pub changed: bool,
    pub invalidated_paths: Vec<PathBuf>,
    pub subdirs_changed: bool,
}

pub struct MdiChildPane {
    pub id: usize,
    pub title: String,
    pub current_path: PathBuf,
    pub address_input: String,
    pub back_stack: Vec<PathBuf>,
    pub forward_stack: Vec<PathBuf>,
    pub entries: Vec<FileEntry>,
    pub filtered_indices: Vec<usize>,
    pub selected_paths: HashSet<PathBuf>,
    pub last_clicked_idx: Option<usize>,
    pub sort_col: SortColumn,
    pub sort_asc: bool,
    pub search_query: String,
    pub search_mode: PaneSearchMode,
    pub best_match_highlight: Option<PathBuf>,
    pub is_loading: bool,
    pub is_silent_reload: bool,
    pub error_banner: Option<String>,
    pub pending_rx: Option<Receiver<Result<Vec<FileEntry>, String>>>,
    pub pending_target: Option<(PathBuf, bool)>,
    /// Free-floating MDI rectangle (normalized or pixel offset within workspace)
    pub float_rect: Option<egui::Rect>,
    pub is_minimized: bool,
    pub scroll_request: ScrollRequest,
    pub is_search_results: bool,
    pub view_mode: PaneViewMode,
    pub thumbnail_size: f32,
    pub is_locked: bool,
}

impl MdiChildPane {
    pub fn new(id: usize, path: PathBuf) -> Self {
        let title = Self::compute_title(&path);
        let address_input = crate::mtp::display_address_for_path(&path);
        let mut pane = Self {
            id,
            title,
            current_path: path,
            address_input,
            back_stack: Vec::new(),
            forward_stack: Vec::new(),
            entries: Vec::new(),
            filtered_indices: Vec::new(),
            selected_paths: HashSet::new(),
            last_clicked_idx: None,
            sort_col: SortColumn::Name,
            sort_asc: true,
            search_query: String::new(),
            search_mode: PaneSearchMode::InstantFilter,
            best_match_highlight: None,
            is_loading: false,
            is_silent_reload: false,
            error_banner: None,
            pending_rx: None,
            pending_target: None,
            float_rect: None,
            is_minimized: false,
            scroll_request: ScrollRequest::None,
            is_search_results: false,
            view_mode: PaneViewMode::Details,
            thumbnail_size: 96.0,
            is_locked: false,
        };
        pane.trigger_reload();
        pane
    }

    pub fn new_search_results(id: usize, search_root: PathBuf, query: &str) -> Self {
        let title = if query.is_empty() {
            "🔍 檢索結果".to_string()
        } else {
            format!("🔍 檢索結果: {}", query)
        };
        let address_input = format!("mine://search?q={}", query);
        Self {
            id,
            title,
            current_path: search_root,
            address_input,
            back_stack: Vec::new(),
            forward_stack: Vec::new(),
            entries: Vec::new(),
            filtered_indices: Vec::new(),
            selected_paths: HashSet::new(),
            last_clicked_idx: None,
            sort_col: SortColumn::Name,
            sort_asc: true,
            search_query: String::new(),
            search_mode: PaneSearchMode::InstantFilter,
            best_match_highlight: None,
            is_loading: false,
            is_silent_reload: false,
            error_banner: None,
            pending_rx: None,
            pending_target: None,
            float_rect: None,
            is_minimized: false,
            scroll_request: ScrollRequest::None,
            is_search_results: true,
            view_mode: PaneViewMode::Details,
            thumbnail_size: 96.0,
            is_locked: false,
        }
    }

    pub fn compute_title(path: &std::path::Path) -> String {
        if crate::fs_ops::is_this_pc_path(path) {
            return "💻 本機電腦 (This PC)".to_string();
        }
        if crate::mtp::is_mtp_path(path) {
            return crate::mtp::display_name_for_mtp_path(path);
        }
        path.file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| path.to_string_lossy().into_owned())
    }

    pub fn navigate_to(&mut self, target: PathBuf, push_history: bool) {
        if crate::fs_ops::is_this_pc_path(&target) {
            if push_history && self.current_path != target {
                self.back_stack.push(self.current_path.clone());
                self.forward_stack.clear();
            }
            self.current_path = target;
            self.address_input = crate::fs_ops::THIS_PC_PATH.to_string();
            self.title = Self::compute_title(&self.current_path);
            self.entries.clear();
            self.filtered_indices.clear();
            self.selected_paths.clear();
            self.last_clicked_idx = None;
            self.is_loading = false;
            self.is_silent_reload = false;
            self.error_banner = None;
            self.pending_target = None;
            self.pending_rx = None;
            self.is_search_results = false;
            return;
        }
        self.is_loading = true;
        self.is_silent_reload = false;
        self.error_banner = None;
        self.pending_target = Some((target.clone(), push_history));
        self.pending_rx = Some(read_dir_non_blocking(target));
    }

    pub fn go_back(&mut self) -> bool {
        if let Some(prev) = self.back_stack.pop() {
            let cur = self.current_path.clone();
            self.forward_stack.push(cur);
            self.navigate_to(prev, false);
            true
        } else {
            false
        }
    }

    pub fn go_forward(&mut self) -> bool {
        if let Some(next) = self.forward_stack.pop() {
            let cur = self.current_path.clone();
            self.back_stack.push(cur);
            self.navigate_to(next, false);
            true
        } else {
            false
        }
    }

    pub fn go_up(&mut self) -> bool {
        if crate::fs_ops::is_this_pc_path(&self.current_path) {
            return false;
        }
        if crate::mtp::is_mtp_path(&self.current_path) {
            let parent = crate::mtp::mtp_parent_path(&self.current_path);
            self.navigate_to(parent, true);
            return true;
        }
        if let Some(parent) = self.current_path.parent().map(|p| p.to_path_buf()) {
            if parent != self.current_path {
                self.navigate_to(parent, true);
                return true;
            }
        }
        self.navigate_to(PathBuf::from(crate::fs_ops::THIS_PC_PATH), true);
        true
    }

    pub fn trigger_reload(&mut self) {
        if self.is_search_results {
            self.apply_sort_and_filter(true);
            return;
        }
        if crate::fs_ops::is_this_pc_path(&self.current_path) {
            self.is_loading = false;
            self.is_silent_reload = false;
            self.error_banner = None;
            return;
        }
        self.is_loading = true;
        self.is_silent_reload = false;
        self.error_banner = None;
        self.pending_target = None;
        self.pending_rx = Some(read_dir_non_blocking(self.current_path.clone()));
    }

    /// Background silent diff reload triggered by OS filesystem watcher / focus regain:
    /// never flashes the loading banner or disrupts user scrolling/selection.
    pub fn trigger_silent_reload(&mut self) {
        if self.is_search_results
            || crate::fs_ops::is_this_pc_path(&self.current_path)
            || self.pending_rx.is_some()
            || self.pending_target.is_some()
        {
            return;
        }
        self.is_silent_reload = true;
        self.pending_target = None;
        self.pending_rx = Some(read_dir_non_blocking(self.current_path.clone()));
    }

    pub fn poll_async_load(&mut self, show_hidden: bool) -> PollLoadOutcome {
        if let Some(ref rx) = self.pending_rx {
            if let Ok(result) = rx.try_recv() {
                self.is_loading = false;
                self.pending_rx = None;
                let was_silent = std::mem::take(&mut self.is_silent_reload);
                let nav_target = self.pending_target.take();
                match result {
                    Ok(items) => {
                        if let Some((target, push_history)) = nav_target {
                            if push_history && target != self.current_path {
                                self.back_stack.push(self.current_path.clone());
                                self.forward_stack.clear();
                            }
                            self.current_path = target;
                            self.title = Self::compute_title(&self.current_path);
                            self.address_input =
                                crate::mtp::display_address_for_path(&self.current_path);
                            self.selected_paths.clear();
                            self.last_clicked_idx = None;
                            self.entries = items;
                            self.error_banner = None;
                            self.apply_sort_and_filter(show_hidden);
                            return PollLoadOutcome {
                                completed: true,
                                was_silent: false,
                                changed: true,
                                invalidated_paths: Vec::new(),
                                subdirs_changed: false,
                            };
                        }

                        // Diff incoming snapshot against current entries to eliminate needless redraws
                        let old_map: std::collections::HashMap<PathBuf, (u64, i64, bool, bool)> =
                            self.entries
                                .iter()
                                .map(|e| {
                                    (
                                        e.path.clone(),
                                        (e.size, e.modified_ts, e.is_dir, e.is_hidden),
                                    )
                                })
                                .collect();
                        let new_map: std::collections::HashMap<PathBuf, (u64, i64, bool, bool)> =
                            items
                                .iter()
                                .map(|e| {
                                    (
                                        e.path.clone(),
                                        (e.size, e.modified_ts, e.is_dir, e.is_hidden),
                                    )
                                })
                                .collect();

                        let mut invalidated_paths = Vec::new();
                        for (old_path, old_meta) in &old_map {
                            match new_map.get(old_path) {
                                None => invalidated_paths.push(old_path.clone()),
                                Some(new_meta) if new_meta != old_meta => {
                                    invalidated_paths.push(old_path.clone());
                                }
                                _ => {}
                            }
                        }
                        let any_added = items.iter().any(|e| !old_map.contains_key(&e.path));
                        let old_dirs: HashSet<&PathBuf> = self
                            .entries
                            .iter()
                            .filter(|e| e.is_dir)
                            .map(|e| &e.path)
                            .collect();
                        let new_dirs: HashSet<&PathBuf> = items
                            .iter()
                            .filter(|e| e.is_dir)
                            .map(|e| &e.path)
                            .collect();
                        let subdirs_changed = old_dirs != new_dirs;

                        if was_silent && invalidated_paths.is_empty() && !any_added {
                            return PollLoadOutcome {
                                completed: true,
                                was_silent: true,
                                changed: false,
                                invalidated_paths: Vec::new(),
                                subdirs_changed: false,
                            };
                        }

                        let retain_set: HashSet<PathBuf> =
                            items.iter().map(|e| e.path.clone()).collect();
                        self.selected_paths.retain(|p| retain_set.contains(p));
                        self.entries = items;
                        self.error_banner = None;
                        self.apply_sort_and_filter(show_hidden);
                        return PollLoadOutcome {
                            completed: true,
                            was_silent,
                            changed: true,
                            invalidated_paths,
                            subdirs_changed,
                        };
                    }
                    Err(err_msg) => {
                        if let Some((failed_target, _)) = nav_target {
                            // Keep existing current_path, title, and entries unchanged!
                            self.address_input = self.current_path.to_string_lossy().into_owned();
                            self.error_banner = Some(format!(
                                "✖ 無法連線至「{}」：{} (已維持目前資料夾「{}」)",
                                failed_target.to_string_lossy(),
                                err_msg,
                                self.title
                            ));
                        } else if !was_silent || !self.current_path.exists() {
                            self.entries.clear();
                            self.filtered_indices.clear();
                            self.error_banner = Some(format!("✖ {}", err_msg));
                        }
                        return PollLoadOutcome {
                            completed: true,
                            was_silent,
                            changed: !was_silent,
                            invalidated_paths: Vec::new(),
                            subdirs_changed: false,
                        };
                    }
                }
            }
        }
        PollLoadOutcome::default()
    }

    pub fn apply_sort_and_filter(&mut self, show_hidden: bool) {
        let col = self.sort_col;
        let asc = self.sort_asc;
        self.entries.sort_by(|a, b| {
            // Directories always first (like MDIE & Windows Explorer)
            match (a.is_dir, b.is_dir) {
                (true, false) => return std::cmp::Ordering::Less,
                (false, true) => return std::cmp::Ordering::Greater,
                _ => {}
            }
            let ord = match col {
                SortColumn::Name => a.lower_name.cmp(&b.lower_name),
                SortColumn::Size => a
                    .size
                    .cmp(&b.size)
                    .then_with(|| a.lower_name.cmp(&b.lower_name)),
                SortColumn::Type => a
                    .extension
                    .cmp(&b.extension)
                    .then_with(|| a.lower_name.cmp(&b.lower_name)),
                SortColumn::Modified => a
                    .modified_ts
                    .cmp(&b.modified_ts)
                    .then_with(|| a.lower_name.cmp(&b.lower_name)),
                SortColumn::Directory => {
                    let pa = a.path.parent().map(|p| p.to_string_lossy()).unwrap_or_default();
                    let pb = b.path.parent().map(|p| p.to_string_lossy()).unwrap_or_default();
                    pa.cmp(&pb).then_with(|| a.lower_name.cmp(&b.lower_name))
                }
            };
            if asc {
                ord
            } else {
                ord.reverse()
            }
        });

        let smart_q = SmartQuery::parse(&self.search_query);
        self.filtered_indices.clear();
        self.best_match_highlight = None;

        let mut best_score = i64::MIN;
        let mut best_row_idx = None;

        for (idx, entry) in self.entries.iter().enumerate() {
            if !show_hidden && entry.is_hidden {
                continue;
            }
            match self.search_mode {
                PaneSearchMode::InstantFilter => {
                    if smart_q.score_entry(entry).is_some() {
                        self.filtered_indices.push(idx);
                    }
                }
                PaneSearchMode::BestMatchJump | PaneSearchMode::SelectMatching => {
                    let row_pos = self.filtered_indices.len();
                    self.filtered_indices.push(idx);
                    if !smart_q.is_empty() {
                        if let Some(sc) = smart_q.score_entry(entry) {
                            if sc > best_score {
                                best_score = sc;
                                best_row_idx = Some((row_pos, entry.path.clone()));
                            }
                        }
                    }
                }
            }
        }

        if self.search_mode == PaneSearchMode::BestMatchJump {
            if let Some((row_pos, best_path)) = best_row_idx {
                self.best_match_highlight = Some(best_path.clone());
                self.selected_paths.clear();
                self.selected_paths.insert(best_path);
                self.scroll_request = ScrollRequest::Row(row_pos);
            }
        }
    }

    /// MDIE Classic: "選擇檔案 (Select Matching Files)" when pressing Enter in search box
    pub fn execute_mdie_select_matching(&mut self) -> usize {
        let smart_q = SmartQuery::parse(&self.search_query);
        if smart_q.is_empty() {
            return 0;
        }
        self.selected_paths.clear();
        for &idx in &self.filtered_indices {
            if let Some(entry) = self.entries.get(idx) {
                if smart_q.score_entry(entry).is_some() {
                    self.selected_paths.insert(entry.path.clone());
                }
            }
        }
        self.selected_paths.len()
    }
}
