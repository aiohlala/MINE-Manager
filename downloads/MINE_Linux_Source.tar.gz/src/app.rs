use crate::fs_ops::{load_preview_sandboxed, PreviewPayload, SmbStatus};
use crate::gesture::{GestureAction, GestureTracker};
use crate::i18n::Language;
use crate::search::{DeepSearchResult, SearchProgressMsg};
use crate::state::{AppTheme, MdiChildPane, PortableConfig, ScrollRequest, WindowLayoutMode};
use egui::{Color32, Pos2, Rect, Stroke, TextureHandle, Vec2};
use std::path::{Path, PathBuf};
use std::sync::atomic::AtomicBool;
use std::sync::mpsc::Receiver;
use std::sync::Arc;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SidebarTab {
    DrivesAndTree,
    Favorites,
    SmbNetwork,
    ClosedHistory,
}

#[derive(Debug, Clone)]
pub enum ClipboardOp {
    None,
    Copy(Vec<PathBuf>),
    Cut(Vec<PathBuf>),
}

#[derive(Debug, Clone)]
pub struct ContextMenuState {
    pub pos: Pos2,
    pub pane_id: usize,
    pub target_entry: Option<crate::fs_ops::FileEntry>,
}

pub struct MineApp {
    pub config: PortableConfig,
    pub panes: Vec<MdiChildPane>,
    pub active_pane_id: usize,
    pub next_pane_id: usize,
    pub sidebar_tab: SidebarTab,
    pub gesture_tracker: GestureTracker,
    pub status_toast: String,
    pub clipboard: ClipboardOp,
    pub drag_payload: Option<(usize, Vec<PathBuf>)>,
    pub context_menu: Option<ContextMenuState>,
    pub rmb_press_target: Option<(usize, Option<crate::fs_ops::FileEntry>)>,

    // Preview Sandbox State
    pub preview_target: Option<PathBuf>,
    pub preview_rx: Option<Receiver<PreviewPayload>>,
    pub preview_state: PreviewPayload,
    pub preview_texture: Option<TextureHandle>,

    // SMB Non-blocking probes (both auto-discovered OS Explorer remote folders & user custom bookmarks)
    pub system_smb_shares: Vec<crate::fs_ops::SmbShareBookmark>,
    pub system_smb_probes: Vec<(usize, Receiver<SmbStatus>)>,
    pub smb_probes: Vec<(usize, Receiver<SmbStatus>)>,
    pub remote_discovery_rx: Option<Receiver<Vec<crate::fs_ops::SmbShareBookmark>>>,
    pub disks_discovery_rx: Option<Receiver<Vec<(String, PathBuf, u64, u64)>>>,
    pub is_discovering_remotes: bool,
    pub new_smb_name: String,
    pub new_smb_unc: String,
    pub new_smb_host: String,
    pub new_smb_port: String,

    // Dialog toggles
    pub show_smb_dialog: bool,
    pub show_gesture_dialog: bool,
    pub show_search_dialog: bool,
    pub show_about_dialog: bool,
    pub show_save_group_modal: bool,
    pub new_group_name: String,

    // Rename / New Item inline modal
    pub rename_modal: Option<(PathBuf, String)>,
    pub create_item_modal: Option<(PathBuf, bool, String)>, // (dir_path, is_folder, name)

    // Gesture binding editor state
    pub new_gesture_seq: String,
    pub new_gesture_action: GestureAction,

    // Deep Search Engine State
    pub deep_search_query: String,
    pub deep_search_grep: String,
    pub deep_search_scope_all_panes: bool,
    pub deep_search_results: Vec<DeepSearchResult>,
    pub deep_search_scanned: usize,
    pub deep_search_elapsed_ms: u128,
    pub deep_search_running: bool,
    pub deep_search_rx: Option<Receiver<SearchProgressMsg>>,
    pub deep_search_cancel: Arc<AtomicBool>,
    pub deep_search_selected: std::collections::HashSet<PathBuf>,

    // System Resource Telemetry (shows low RAM usage)
    pub sys_disks: Vec<(String, PathBuf, u64, u64)>,
    pub process_ram_mb: f64,
    pub last_telemetry_tick: std::time::Instant,
    pub last_smb_probe_tick: std::time::Instant,
    pub needs_cascade_recalc: bool,
    pub last_workspace_rect: Option<Rect>,
    pub app_icon_tex: Option<TextureHandle>,
}

impl MineApp {
    pub fn new(cc: &eframe::CreationContext<'_>) -> Self {
        Self::configure_cjk_fonts(&cc.egui_ctx);

        let icon_rgba = crate::icon::render_kawaii_icon_rgba(64);
        let icon_img = egui::ColorImage::from_rgba_unmultiplied([64, 64], &icon_rgba);
        let app_icon_tex = Some(cc.egui_ctx.load_texture(
            "mine_kawaii_icon",
            icon_img,
            egui::TextureOptions::LINEAR,
        ));

        let config = PortableConfig::load_or_default();
        let mut gesture_tracker = GestureTracker::default();
        if !config.gesture_bindings.is_empty() {
            gesture_tracker.bindings = config.gesture_bindings.clone();
        }

        let mut panes = Vec::new();
        let mut next_id = 1usize;

        // If user launched MINE on a specific directory (e.g. "Open in MINE"), open ONLY that directory
        // without blocking on main-thread .exists() calls!
        if let Some(cli_arg) = std::env::args().nth(1) {
            if !cli_arg.starts_with('-') {
                panes.push(MdiChildPane::new(1, PathBuf::from(&cli_arg)));
                next_id = 2;
            }
        }

        if panes.is_empty() {
            let home = dirs::home_dir().unwrap_or_else(|| PathBuf::from("."));
            for p_str in &config.open_pane_paths {
                let trimmed = p_str.trim();
                // Never block startup on remote network UNC paths; MdiChildPane loads local paths asynchronously
                let target_pb = if trimmed.is_empty()
                    || trimmed.starts_with("\\\\")
                    || trimmed.starts_with("//")
                {
                    home.clone()
                } else {
                    PathBuf::from(trimmed)
                };
                panes.push(MdiChildPane::new(next_id, target_pb));
                next_id += 1;
            }
        }
        if panes.is_empty() {
            let home = dirs::home_dir().unwrap_or_else(|| PathBuf::from("."));
            panes.push(MdiChildPane::new(1, home));
            next_id = 2;
        }

        // Pre-populate instant local system drive placeholder so UI opens in < 30ms,
        // while full disk & remote folder discovery runs 100% asynchronously in the background!
        #[cfg(target_os = "windows")]
        let initial_disks = vec![("C:\\ (本機磁碟)".to_string(), PathBuf::from("C:\\"), 0, 0)];
        #[cfg(not(target_os = "windows"))]
        let initial_disks = vec![("/ (System Root)".to_string(), PathBuf::from("/"), 0, 0)];

        let remote_discovery_rx = Some(crate::fs_ops::spawn_remote_folders_discovery());
        let disks_discovery_rx = Some(crate::fs_ops::spawn_disks_discovery());

        let mut app = Self {
            config,
            panes,
            active_pane_id: 1,
            next_pane_id: next_id,
            sidebar_tab: SidebarTab::DrivesAndTree,
            gesture_tracker,
            status_toast: "⚡ MINE 已瞬間啟動 — 本機資料夾可立即操作 (背景同步偵測遠端資料夾中...)".into(),
            clipboard: ClipboardOp::None,
            drag_payload: None,
            context_menu: None,
            rmb_press_target: None,
            preview_target: None,
            preview_rx: None,
            preview_state: PreviewPayload::None,
            preview_texture: None,
            system_smb_shares: Vec::new(),
            system_smb_probes: Vec::new(),
            smb_probes: Vec::new(),
            remote_discovery_rx,
            disks_discovery_rx,
            is_discovering_remotes: true,
            new_smb_name: String::new(),
            new_smb_unc: String::new(),
            new_smb_host: String::new(),
            new_smb_port: "445".into(),
            show_smb_dialog: false,
            show_gesture_dialog: false,
            show_search_dialog: false,
            show_about_dialog: false,
            show_save_group_modal: false,
            new_group_name: "Workspace_Group_1".into(),
            rename_modal: None,
            create_item_modal: None,
            new_gesture_seq: "UDR".into(),
            new_gesture_action: GestureAction::TileGrid,
            deep_search_query: String::new(),
            deep_search_grep: String::new(),
            deep_search_scope_all_panes: true,
            deep_search_results: Vec::new(),
            deep_search_scanned: 0,
            deep_search_elapsed_ms: 0,
            deep_search_running: false,
            deep_search_rx: None,
            deep_search_cancel: Arc::new(AtomicBool::new(false)),
            deep_search_selected: std::collections::HashSet::new(),
            sys_disks: initial_disks,
            process_ram_mb: 24.5,
            last_telemetry_tick: std::time::Instant::now() - std::time::Duration::from_secs(10),
            last_smb_probe_tick: std::time::Instant::now(),
            needs_cascade_recalc: true,
            last_workspace_rect: None,
            app_icon_tex,
        };
        cc.egui_ctx.style_mut(|s| {
            s.interaction.selectable_labels = false;
        });
        app.probe_all_smb();
        app
    }

    fn configure_cjk_fonts(ctx: &egui::Context) {
        let mut fonts = egui::FontDefinitions::default();
        // Load native system CJK fonts as fallback AFTER egui's built-in Latin & icon fonts
        // so icons/symbols never turn into missing boxes and CJK renders crisply.
        let candidate_paths = [
            // macOS
            "/System/Library/Fonts/PingFang.ttc",
            "/System/Library/Fonts/STHeiti Light.ttc",
            "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
            // Windows 10 / 11
            "C:\\Windows\\Fonts\\msjh.ttc",
            "C:\\Windows\\Fonts\\msyh.ttc",
            "C:\\Windows\\Fonts\\mingliu.ttc",
            "C:\\Windows\\Fonts\\msgothic.ttc",
            // Linux
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        ];

        for font_path in candidate_paths {
            if let Ok(bytes) = std::fs::read(font_path) {
                fonts.font_data.insert(
                    "cjk_system".to_owned(),
                    egui::FontData::from_owned(bytes).into(),
                );
                if let Some(vec) = fonts.families.get_mut(&egui::FontFamily::Proportional) {
                    vec.push("cjk_system".to_owned());
                }
                if let Some(vec) = fonts.families.get_mut(&egui::FontFamily::Monospace) {
                    vec.push("cjk_system".to_owned());
                }
                break;
            }
        }

        // On Windows, also load Segoe UI Symbol if available for rich Unicode symbols
        if let Ok(sym_bytes) = std::fs::read("C:\\Windows\\Fonts\\seguisym.ttf") {
            fonts.font_data.insert(
                "win_symbols".to_owned(),
                egui::FontData::from_owned(sym_bytes).into(),
            );
            if let Some(vec) = fonts.families.get_mut(&egui::FontFamily::Proportional) {
                vec.push("win_symbols".to_owned());
            }
        }

        ctx.set_fonts(fonts);
    }

    pub fn refresh_system_remote_folders(&mut self) {
        self.is_discovering_remotes = true;
        self.remote_discovery_rx = Some(crate::fs_ops::spawn_remote_folders_discovery());
        self.disks_discovery_rx = Some(crate::fs_ops::spawn_disks_discovery());
    }

    pub fn probe_all_smb(&mut self) {
        self.last_smb_probe_tick = std::time::Instant::now();
        self.system_smb_probes.clear();
        for (idx, smb) in self.system_smb_shares.iter_mut().enumerate() {
            if matches!(smb.status, SmbStatus::Unknown) {
                smb.status = SmbStatus::Probing;
            }
            let rx = smb.probe_async();
            self.system_smb_probes.push((idx, rx));
        }

        self.smb_probes.clear();
        for (idx, smb) in self.config.smb_bookmarks.iter_mut().enumerate() {
            if matches!(smb.status, SmbStatus::Unknown) {
                smb.status = SmbStatus::Probing;
            }
            let rx = smb.probe_async();
            self.smb_probes.push((idx, rx));
        }
    }

    pub fn active_pane_index(&self) -> usize {
        self.panes
            .iter()
            .position(|p| p.id == self.active_pane_id)
            .unwrap_or(0)
    }

    pub fn spawn_new_pane(&mut self, path: PathBuf) {
        for p in &mut self.panes {
            p.selected_paths.clear();
            p.last_clicked_idx = None;
        }
        let id = self.next_pane_id;
        self.next_pane_id += 1;
        let mut pane = MdiChildPane::new(id, path);
        if let Some(ws) = self.last_workspace_rect {
            let offset = ((self.panes.len() % 8) as f32) * 28.0;
            let w = (ws.width() * 0.68).clamp(280.0, (ws.width() - 16.0).max(280.0));
            let h = (ws.height() * 0.72).clamp(200.0, (ws.height() - 16.0).max(200.0));
            let x = (ws.min.x + 14.0 + offset)
                .clamp(ws.min.x + 4.0, (ws.max.x - w - 4.0).max(ws.min.x + 4.0));
            let y = (ws.min.y + 14.0 + offset)
                .clamp(ws.min.y + 4.0, (ws.max.y - h - 4.0).max(ws.min.y + 4.0));
            pane.float_rect = Some(Rect::from_min_size(Pos2::new(x, y), Vec2::new(w, h)));
        } else {
            pane.float_rect = None;
        }
        self.panes.push(pane);
        self.active_pane_id = id;
        if self.config.layout_mode == WindowLayoutMode::Cascade {
            self.needs_cascade_recalc = true;
        }
        self.sync_config_paths();
    }

    pub fn close_pane_by_id(&mut self, id: usize) {
        if self.panes.len() <= 1 {
            self.status_toast = if self.config.language == Language::ZhTw {
                "⚠ 至少需保留一個子視窗".into()
            } else {
                "⚠ At least one MDI child window must remain open".into()
            };
            return;
        }
        if let Some(pos) = self.panes.iter().position(|p| p.id == id) {
            let removed = self.panes.remove(pos);
            let path_str = removed.current_path.to_string_lossy().into_owned();
            self.config.closed_history.retain(|p| p != &path_str);
            self.config.closed_history.insert(0, path_str);
            if self.config.closed_history.len() > 25 {
                self.config.closed_history.truncate(25);
            }
            if self.active_pane_id == id {
                if let Some(first) = self.panes.first() {
                    self.active_pane_id = first.id;
                }
            }
            self.sync_config_paths();
        }
    }

    pub fn restore_last_closed_pane(&mut self) {
        if let Some(last_path) = self.config.closed_history.first().cloned() {
            self.config.closed_history.remove(0);
            self.spawn_new_pane(PathBuf::from(last_path));
        }
    }

    pub fn sync_config_paths(&mut self) {
        self.config.open_pane_paths = self
            .panes
            .iter()
            .map(|p| p.current_path.to_string_lossy().into_owned())
            .collect();
        self.config.gesture_bindings = self.gesture_tracker.bindings.clone();
        let _ = self.config.save();
    }

    pub fn execute_gesture_action(&mut self, action: GestureAction) {
        let idx = self.active_pane_index();
        match action {
            GestureAction::NavigateBack => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.go_back();
                }
            }
            GestureAction::NavigateForward => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.go_forward();
                }
            }
            GestureAction::NavigateUp => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.go_up();
                }
            }
            GestureAction::NewMdiWindow => {
                let path = self
                    .panes
                    .get(idx)
                    .map(|p| p.current_path.clone())
                    .unwrap_or_else(|| dirs::home_dir().unwrap_or_else(|| PathBuf::from(".")));
                self.spawn_new_pane(path);
            }
            GestureAction::CloneActiveWindow => {
                if let Some(p) = self.panes.get(idx) {
                    let path = p.current_path.clone();
                    self.spawn_new_pane(path);
                }
            }
            GestureAction::CloseActiveWindow => {
                let id = self.active_pane_id;
                self.close_pane_by_id(id);
            }
            GestureAction::RestoreClosedWindow => {
                self.restore_last_closed_pane();
            }
            GestureAction::RefreshActiveWindow => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.trigger_reload();
                }
            }
            GestureAction::TileGrid => {
                self.config.layout_mode = WindowLayoutMode::TileGrid;
            }
            GestureAction::TileHorizontally => {
                self.config.layout_mode = WindowLayoutMode::TileHorizontally;
            }
            GestureAction::TileVertically => {
                self.config.layout_mode = WindowLayoutMode::TileVertically;
            }
            GestureAction::CascadeWindows => {
                self.config.layout_mode = WindowLayoutMode::Cascade;
                self.needs_cascade_recalc = true;
            }
            GestureAction::ToggleTabbedMode => {
                self.config.layout_mode =
                    if self.config.layout_mode == WindowLayoutMode::TabbedMaximized {
                        WindowLayoutMode::TileHorizontally
                    } else {
                        WindowLayoutMode::TabbedMaximized
                    };
            }
            GestureAction::ScrollToTop => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.scroll_request = ScrollRequest::Top;
                }
            }
            GestureAction::ScrollToBottom => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.scroll_request = ScrollRequest::Bottom;
                }
            }
            GestureAction::OpenGlobalSearch => {
                self.show_search_dialog = true;
            }
        }
        self.status_toast = format!(
            "🖱 {} -> {}",
            if self.config.language == Language::ZhTw {
                "手勢觸發"
            } else {
                "Gesture Executed"
            },
            action.label(self.config.language)
        );
    }

    pub fn recalculate_cascade_rects(&mut self, workspace_rect: Rect) {
        let n = self.panes.len().max(1);
        let pad = 10.0;
        let step = if n > 1 {
            ((workspace_rect.width() * 0.22) / ((n - 1) as f32)).clamp(24.0, 36.0)
        } else {
            0.0
        };
        let total_offset = step * ((n.saturating_sub(1)) as f32);
        let max_w = (workspace_rect.width() - pad * 2.0).max(220.0);
        let max_h = (workspace_rect.height() - pad * 2.0).max(160.0);
        let w = (workspace_rect.width() - pad * 2.0 - total_offset.max(60.0))
            .clamp(300.0_f32.min(max_w), max_w);
        let h = (workspace_rect.height() - pad * 2.0 - total_offset.max(50.0))
            .clamp(220.0_f32.min(max_h), max_h);

        for (i, pane) in self.panes.iter_mut().enumerate() {
            let offset = (i as f32) * step;
            let min_x = (workspace_rect.min.x + pad + offset).clamp(
                workspace_rect.min.x + 4.0,
                (workspace_rect.max.x - w - 4.0).max(workspace_rect.min.x + 4.0),
            );
            let min_y = (workspace_rect.min.y + pad + offset).clamp(
                workspace_rect.min.y + 4.0,
                (workspace_rect.max.y - h - 4.0).max(workspace_rect.min.y + 4.0),
            );
            pane.float_rect = Some(Rect::from_min_size(
                Pos2::new(min_x, min_y),
                Vec2::new(w, h),
            ));
            pane.is_minimized = false;
        }
        self.needs_cascade_recalc = false;
    }

    pub fn trigger_preview(&mut self, path: PathBuf) {
        if self.preview_target.as_ref() == Some(&path) {
            return;
        }
        self.preview_target = Some(path.clone());
        self.preview_state = PreviewPayload::Loading(path.clone());
        self.preview_texture = None;
        self.preview_rx = Some(load_preview_sandboxed(path));
    }

    pub fn perform_file_transfer(
        &mut self,
        sources: &[PathBuf],
        dest_dir: &Path,
        is_cut: bool,
    ) {
        if !dest_dir.is_dir() {
            return;
        }
        let mut ok_count = 0usize;
        for src in sources {
            if let Some(name) = src.file_name() {
                let dst = dest_dir.join(name);
                if dst == *src {
                    continue;
                }
                let res = if is_cut {
                    std::fs::rename(src, &dst).or_else(|_| {
                        copy_path_recursive(src, &dst).and_then(|_| {
                            if src.is_dir() {
                                std::fs::remove_dir_all(src)
                            } else {
                                std::fs::remove_file(src)
                            }
                        })
                    })
                } else {
                    copy_path_recursive(src, &dst)
                };
                if res.is_ok() {
                    ok_count += 1;
                }
            }
        }
        for p in &mut self.panes {
            p.trigger_reload();
        }
        self.status_toast = format!(
            "✅ {} {} -> {}",
            if is_cut { "Moved" } else { "Copied" },
            ok_count,
            dest_dir.to_string_lossy()
        );
    }

    pub fn apply_theme(&self, ctx: &egui::Context) {
        match self.config.theme {
            AppTheme::ModernDark => {
                let mut vis = egui::Visuals::dark();
                vis.window_rounding = egui::Rounding::same(6.0);
                vis.panel_fill = Color32::from_rgb(22, 24, 30);
                vis.extreme_bg_color = Color32::from_rgb(18, 20, 26);
                ctx.set_visuals(vis);
            }
            AppTheme::CleanLight => {
                let mut vis = egui::Visuals::light();
                vis.window_rounding = egui::Rounding::same(6.0);
                vis.extreme_bg_color = Color32::from_rgb(235, 238, 244);
                ctx.set_visuals(vis);
            }
            AppTheme::ClassicMdie => {
                // Classic Windows XP / MDIE crisp light bluish-silver MDI styling
                let mut vis = egui::Visuals::light();
                vis.window_rounding = egui::Rounding::same(3.0);
                vis.panel_fill = Color32::from_rgb(240, 242, 246);
                vis.extreme_bg_color = Color32::from_rgb(232, 236, 242);
                vis.selection.bg_fill = Color32::from_rgb(51, 153, 255);
                vis.selection.stroke = Stroke::new(1.0, Color32::WHITE);
                ctx.set_visuals(vis);
            }
        }
        ctx.style_mut(|s| {
            s.interaction.selectable_labels = false;
            // Always show a solid, draggable right-side scrollbar on every folder window
            s.spacing.scroll = egui::style::ScrollStyle::solid();
            s.spacing.scroll.bar_width = 12.0;
            s.spacing.scroll.handle_min_length = 28.0;
            s.spacing.scroll.bar_inner_margin = 2.0;
            s.spacing.scroll.bar_outer_margin = 2.0;
            s.spacing.scroll.foreground_color = false;
        });
    }
}

fn copy_path_recursive(src: &Path, dst: &Path) -> std::io::Result<()> {
    if src.is_dir() {
        std::fs::create_dir_all(dst)?;
        for entry in std::fs::read_dir(src)? {
            let entry = entry?;
            let ty = entry.file_type()?;
            if ty.is_dir() {
                copy_path_recursive(&entry.path(), &dst.join(entry.file_name()))?;
            } else {
                std::fs::copy(entry.path(), dst.join(entry.file_name()))?;
            }
        }
        Ok(())
    } else {
        std::fs::copy(src, dst).map(|_| ())
    }
}
