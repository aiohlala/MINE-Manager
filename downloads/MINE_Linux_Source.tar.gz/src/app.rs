use crate::fs_ops::{load_preview_sandboxed, PreviewPayload, SmbStatus};
use crate::gesture::{GestureAction, GestureTracker};
use crate::i18n::Language;
use crate::search::{DeepSearchResult, SearchProgressMsg};
use crate::state::{
    AppTheme, MdiChildPane, PaneColumn, PortableConfig, ScrollRequest, WindowLayoutMode,
};
use egui::{Color32, Pos2, Rect, Stroke, TextureHandle, Vec2};
use std::path::{Path, PathBuf};
use std::sync::atomic::AtomicBool;
use std::sync::mpsc::Receiver;
use std::sync::Arc;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SidebarTab {
    DrivesAndTree,
    Favorites,
    Search,
    SmbNetwork,
    ClosedHistory,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SearchScopeMode {
    ActivePane,
    AllPanes,
    Custom,
}

#[derive(Debug, Clone)]
pub enum ClipboardOp {
    None,
    Copy(Vec<PathBuf>),
    Cut(Vec<PathBuf>),
}

#[derive(Debug, Clone)]
pub struct ContextMenuState {
    pub pos: Pos2,
    pub pane_id: usize,
    pub target_entry: Option<crate::fs_ops::FileEntry>,
    pub view_submenu_open: bool,
}

pub struct MineApp {
    pub config: PortableConfig,
    pub panes: Vec<MdiChildPane>,
    pub active_pane_id: usize,
    pub next_pane_id: usize,
    pub sidebar_tab: SidebarTab,
    pub gesture_tracker: GestureTracker,
    pub status_toast: String,
    pub clipboard: ClipboardOp,
    pub drag_payload: Option<(usize, Vec<PathBuf>)>,
    pub context_menu: Option<ContextMenuState>,
    pub rmb_press_target: Option<(usize, Option<crate::fs_ops::FileEntry>)>,

    // Preview Sandbox State
    pub preview_target: Option<PathBuf>,
    pub preview_rx: Option<Receiver<PreviewPayload>>,
    pub preview_state: PreviewPayload,
    pub preview_texture: Option<TextureHandle>,
    pub preview_image_zoom: f32,

    // Column Reordering State
    pub drag_col_source: Option<PaneColumn>,

    // SMB Non-blocking probes (both auto-discovered OS Explorer remote folders & user custom bookmarks)
    pub system_smb_shares: Vec<crate::fs_ops::SmbShareBookmark>,
    pub system_smb_probes: Vec<(usize, Receiver<SmbStatus>)>,
    pub smb_probes: Vec<(usize, Receiver<SmbStatus>)>,
    pub remote_discovery_rx: Option<Receiver<Vec<crate::fs_ops::SmbShareBookmark>>>,
    pub disks_discovery_rx: Option<Receiver<Vec<(String, PathBuf, u64, u64)>>>,
    pub is_discovering_remotes: bool,
    pub new_smb_name: String,
    pub new_smb_unc: String,
    pub new_smb_host: String,
    pub new_smb_port: String,

    // Dialog toggles
    pub show_smb_dialog: bool,
    pub show_gesture_dialog: bool,
    pub show_about_dialog: bool,
    pub show_save_group_modal: bool,
    pub new_group_name: String,
    pub show_quick_access_manager: bool,
    pub show_network_shares_manager: bool,
    pub show_add_quick_access_modal: bool,
    pub new_qa_name: String,
    pub new_qa_path: String,

    // Rename / New Item inline modal
    pub rename_modal: Option<(PathBuf, String)>,
    pub create_item_modal: Option<(PathBuf, bool, String)>, // (dir_path, is_folder, name)

    // Gesture binding editor state
    pub new_gesture_seq: String,
    pub new_gesture_action: GestureAction,

    // Deep Search Engine State
    pub deep_search_query: String,
    pub deep_search_grep: String,
    pub deep_search_results: Vec<DeepSearchResult>,
    pub deep_search_scanned: usize,
    pub deep_search_elapsed_ms: u128,
    pub deep_search_running: bool,
    pub deep_search_rx: Option<Receiver<SearchProgressMsg>>,
    pub deep_search_cancel: Arc<AtomicBool>,
    pub deep_search_selected: std::collections::HashSet<PathBuf>,
    pub search_subdirs: bool,
    pub search_wildcard: bool,
    pub search_case_sensitive: bool,
    pub search_include_hidden: bool,
    pub search_include_system: bool,
    pub search_scope_mode: SearchScopeMode,
    pub search_custom_path: String,
    pub focus_search_input: bool,

    // System Resource Telemetry (shows low RAM usage)
    pub sys_disks: Vec<(String, PathBuf, u64, u64)>,
    pub process_ram_mb: f64,
    pub last_telemetry_tick: std::time::Instant,
    pub last_smb_probe_tick: std::time::Instant,
    pub needs_cascade_recalc: bool,
    pub last_workspace_rect: Option<Rect>,
    pub app_icon_tex: Option<TextureHandle>,

    // Sidebar Hierarchical Tree View State
    pub tree_expanded: std::collections::HashSet<PathBuf>,
    pub tree_cache: std::collections::HashMap<PathBuf, Vec<(String, PathBuf)>>,
    pub tree_pending: std::collections::HashSet<PathBuf>,
    pub tree_load_tx: std::sync::mpsc::Sender<(PathBuf, Vec<(String, PathBuf)>)>,
    pub tree_load_rx: std::sync::mpsc::Receiver<(PathBuf, Vec<(String, PathBuf)>)>,

    // Thumbnail Grid Cache & Worker
    pub thumb_textures: std::collections::HashMap<PathBuf, TextureHandle>,
    pub thumb_pending: std::collections::HashSet<PathBuf>,
    pub thumb_failed: std::collections::HashSet<PathBuf>,
    pub thumb_req_tx: std::sync::mpsc::Sender<PathBuf>,
    pub thumb_res_rx: std::sync::mpsc::Receiver<(PathBuf, Option<(usize, usize, Vec<u8>)>)>,

    // In-app Properties Modal (macOS/Linux or Windows fallback)
    pub properties_modal: Option<PropertiesModalState>,
}

pub struct PropertiesModalState {
    pub path: PathBuf,
    pub display_name: String,
    pub item_type: String,
    pub location: String,
    pub created_str: String,
    pub modified_str: String,
    pub is_readonly: bool,
    pub is_hidden: bool,
    pub stats: crate::fs_ops::PropertiesStats,
    pub stats_rx: Option<Receiver<crate::fs_ops::PropertiesStats>>,
    pub disk_total_avail: Option<(u64, u64)>,
}

impl MineApp {
    pub fn new(cc: &eframe::CreationContext<'_>) -> Self {
        Self::configure_cjk_fonts(&cc.egui_ctx);

        let icon_rgba = crate::icon::render_kawaii_icon_rgba(64);
        let icon_img = egui::ColorImage::from_rgba_unmultiplied([64, 64], &icon_rgba);
        let app_icon_tex = Some(cc.egui_ctx.load_texture(
            "mine_kawaii_icon",
            icon_img,
            egui::TextureOptions::LINEAR,
        ));

        let config = PortableConfig::load_or_default();
        let mut gesture_tracker = GestureTracker::default();
        if !config.gesture_bindings.is_empty() {
            gesture_tracker.bindings = config.gesture_bindings.clone();
        }

        let mut panes = Vec::new();
        let mut next_id = 1usize;

        // If user launched MINE on a specific directory (e.g. "Open in MINE"), open ONLY that directory
        // without blocking on main-thread .exists() calls!
        if let Some(cli_arg) = std::env::args().nth(1) {
            if !cli_arg.starts_with('-') {
                panes.push(MdiChildPane::new(1, PathBuf::from(&cli_arg)));
                next_id = 2;
            }
        }

        if panes.is_empty() {
            let home = dirs::home_dir().unwrap_or_else(|| PathBuf::from("."));
            for p_str in &config.open_pane_paths {
                let trimmed = p_str.trim();
                // Never block startup on remote network UNC paths; MdiChildPane loads local paths asynchronously
                let target_pb = if trimmed.is_empty()
                    || trimmed.starts_with("\\\\")
                    || trimmed.starts_with("//")
                {
                    home.clone()
                } else {
                    PathBuf::from(trimmed)
                };
                panes.push(MdiChildPane::new(next_id, target_pb));
                next_id += 1;
            }
        }
        if panes.is_empty() {
            let home = dirs::home_dir().unwrap_or_else(|| PathBuf::from("."));
            panes.push(MdiChildPane::new(1, home));
            next_id = 2;
        }

        // Pre-populate instant local system drive placeholder so UI opens in < 30ms,
        // while full disk & remote folder discovery runs 100% asynchronously in the background!
        #[cfg(target_os = "windows")]
        let initial_disks = vec![("C:\\ (本機磁碟)".to_string(), PathBuf::from("C:\\"), 0, 0)];
        #[cfg(not(target_os = "windows"))]
        let initial_disks = vec![("/ (System Root)".to_string(), PathBuf::from("/"), 0, 0)];

        let remote_discovery_rx = Some(crate::fs_ops::spawn_remote_folders_discovery());
        let disks_discovery_rx = Some(crate::fs_ops::spawn_disks_discovery());
        let (tree_load_tx, tree_load_rx) = std::sync::mpsc::channel();
        let (thumb_req_tx, thumb_req_rx) = std::sync::mpsc::channel::<PathBuf>();
        let (thumb_res_tx, thumb_res_rx) = std::sync::mpsc::channel();
        std::thread::spawn(move || {
            while let Ok(path) = thumb_req_rx.recv() {
                let res = crate::fs_ops::load_thumbnail_rgba(&path, 256);
                if thumb_res_tx.send((path, res)).is_err() {
                    break;
                }
            }
        });

        let mut app = Self {
            config,
            panes,
            active_pane_id: 1,
            next_pane_id: next_id,
            sidebar_tab: SidebarTab::DrivesAndTree,
            gesture_tracker,
            status_toast: "⚡ MINE 已瞬間啟動 — 本機資料夾可立即操作 (背景同步偵測遠端資料夾中...)".into(),
            clipboard: ClipboardOp::None,
            drag_payload: None,
            context_menu: None,
            rmb_press_target: None,
            preview_target: None,
            preview_rx: None,
            preview_state: PreviewPayload::None,
            preview_texture: None,
            preview_image_zoom: 1.0,
            drag_col_source: None,
            system_smb_shares: Vec::new(),
            system_smb_probes: Vec::new(),
            smb_probes: Vec::new(),
            remote_discovery_rx,
            disks_discovery_rx,
            is_discovering_remotes: true,
            new_smb_name: String::new(),
            new_smb_unc: String::new(),
            new_smb_host: String::new(),
            new_smb_port: "445".into(),
            show_smb_dialog: false,
            show_gesture_dialog: false,
            show_about_dialog: false,
            show_save_group_modal: false,
            new_group_name: "Workspace_Group_1".into(),
            show_quick_access_manager: false,
            show_network_shares_manager: false,
            show_add_quick_access_modal: false,
            new_qa_name: String::new(),
            new_qa_path: String::new(),
            rename_modal: None,
            create_item_modal: None,
            new_gesture_seq: "UDR".into(),
            new_gesture_action: GestureAction::TileGrid,
            deep_search_query: String::new(),
            deep_search_grep: String::new(),
            deep_search_results: Vec::new(),
            deep_search_scanned: 0,
            deep_search_elapsed_ms: 0,
            deep_search_running: false,
            deep_search_rx: None,
            deep_search_cancel: Arc::new(AtomicBool::new(false)),
            deep_search_selected: std::collections::HashSet::new(),
            search_subdirs: true,
            search_wildcard: false,
            search_case_sensitive: false,
            search_include_hidden: false,
            search_include_system: false,
            search_scope_mode: SearchScopeMode::ActivePane,
            search_custom_path: String::new(),
            focus_search_input: false,
            sys_disks: initial_disks,
            process_ram_mb: 24.5,
            last_telemetry_tick: std::time::Instant::now() - std::time::Duration::from_secs(10),
            last_smb_probe_tick: std::time::Instant::now(),
            needs_cascade_recalc: true,
            last_workspace_rect: None,
            app_icon_tex,
            tree_expanded: std::collections::HashSet::new(),
            tree_cache: std::collections::HashMap::new(),
            tree_pending: std::collections::HashSet::new(),
            tree_load_tx,
            tree_load_rx,
            thumb_textures: std::collections::HashMap::new(),
            thumb_pending: std::collections::HashSet::new(),
            thumb_failed: std::collections::HashSet::new(),
            thumb_req_tx,
            thumb_res_rx,
            properties_modal: None,
        };
        cc.egui_ctx.style_mut(|s| {
            s.interaction.selectable_labels = false;
        });
        app.probe_all_smb();
        app
    }

    pub fn open_properties_for(&mut self, path: &Path) {
        if crate::fs_ops::is_this_pc_path(path) {
            return;
        }
        if crate::fs_ops::open_os_properties(path) {
            self.status_toast = "📋 已開啟系統內容 (Properties)".into();
            return;
        }

        let display_name = path
            .file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| path.to_string_lossy().into_owned());
        let location = path
            .parent()
            .map(|p| p.to_string_lossy().into_owned())
            .unwrap_or_else(|| path.to_string_lossy().into_owned());
        let meta = std::fs::metadata(path).ok();
        let disk_total_avail = self
            .sys_disks
            .iter()
            .find(|(_, mp, _, _)| mp == path)
            .map(|(_, _, avail, total)| (*total, *avail));

        let is_dir = meta.as_ref().map(|m| m.is_dir()).unwrap_or_else(|| path.is_dir());
        let item_type = if disk_total_avail.is_some() {
            "本機磁碟 (Local Disk)".to_string()
        } else if is_dir {
            "檔案資料夾 (File Folder)".to_string()
        } else {
            let ext = path
                .extension()
                .and_then(|e| e.to_str())
                .unwrap_or("")
                .to_ascii_uppercase();
            if ext.is_empty() {
                "檔案 (File)".to_string()
            } else {
                format!("{} 檔案 (.{})", ext, ext.to_lowercase())
            }
        };

        let fmt_time = |st: std::io::Result<std::time::SystemTime>| -> String {
            match st {
                Ok(t) => {
                    let dt: chrono::DateTime<chrono::Local> = t.into();
                    dt.format("%Y-%m-%d %H:%M:%S").to_string()
                }
                Err(_) => "-".to_string(),
            }
        };

        let created_str = meta
            .as_ref()
            .map(|m| fmt_time(m.created()))
            .unwrap_or_else(|| "-".into());
        let modified_str = meta
            .as_ref()
            .map(|m| fmt_time(m.modified()))
            .unwrap_or_else(|| "-".into());
        let is_readonly = meta
            .as_ref()
            .map(|m| m.permissions().readonly())
            .unwrap_or(false);
        let is_hidden = display_name.starts_with('.');

        let stats_rx = if disk_total_avail.is_some() {
            None
        } else {
            Some(crate::fs_ops::spawn_properties_stats(path.to_path_buf()))
        };

        self.properties_modal = Some(PropertiesModalState {
            path: path.to_path_buf(),
            display_name,
            item_type,
            location,
            created_str,
            modified_str,
            is_readonly,
            is_hidden,
            stats: crate::fs_ops::PropertiesStats {
                total_bytes: meta.as_ref().map(|m| m.len()).unwrap_or(0),
                file_count: if is_dir { 0 } else { 1 },
                folder_count: 0,
                is_complete: !is_dir || disk_total_avail.is_some(),
            },
            stats_rx,
            disk_total_avail,
        });
    }

    pub fn request_thumbnail(&mut self, path: &Path) {
        if !self.thumb_textures.contains_key(path)
            && !self.thumb_pending.contains(path)
            && !self.thumb_failed.contains(path)
        {
            self.thumb_pending.insert(path.to_path_buf());
            let _ = self.thumb_req_tx.send(path.to_path_buf());
        }
    }

    pub fn poll_thumbnails_and_properties(&mut self, ctx: &egui::Context) {
        let mut decoded_any = false;
        for _ in 0..16 {
            match self.thumb_res_rx.try_recv() {
                Ok((path, Some((w, h, rgba)))) => {
                    self.thumb_pending.remove(&path);
                    if self.thumb_textures.len() > 600 {
                        self.thumb_textures.clear();
                    }
                    let color_img = egui::ColorImage::from_rgba_unmultiplied([w, h], &rgba);
                    let tex = ctx.load_texture(
                        format!("thumb:{}", path.display()),
                        color_img,
                        egui::TextureOptions::LINEAR,
                    );
                    self.thumb_textures.insert(path, tex);
                    decoded_any = true;
                }
                Ok((path, None)) => {
                    self.thumb_pending.remove(&path);
                    self.thumb_failed.insert(path);
                }
                Err(_) => break,
            }
        }
        if decoded_any {
            ctx.request_repaint();
        }

        if let Some(ref mut modal) = self.properties_modal {
            if let Some(ref rx) = modal.stats_rx {
                let mut latest = None;
                while let Ok(s) = rx.try_recv() {
                    latest = Some(s);
                }
                if let Some(s) = latest {
                    let done = s.is_complete;
                    modal.stats = s;
                    if done {
                        modal.stats_rx = None;
                    }
                    ctx.request_repaint();
                }
            }
        }
    }

    pub fn request_expand_tree_path(&mut self, path: &std::path::Path) {
        if self.tree_expanded.contains(path) {
            self.tree_expanded.remove(path);
        } else {
            self.tree_expanded.insert(path.to_path_buf());
            if !self.tree_cache.contains_key(path) && !self.tree_pending.contains(path) {
                self.tree_pending.insert(path.to_path_buf());
                let tx = self.tree_load_tx.clone();
                let p_clone = path.to_path_buf();
                std::thread::spawn(move || {
                    let children = crate::fs_ops::list_subdirectories_fast(&p_clone);
                    let _ = tx.send((p_clone, children));
                });
            }
        }
    }

    pub fn sync_tree_to_active_folder(&mut self) {
        let idx = self.active_pane_index();
        if let Some(p) = self.panes.get(idx) {
            let cur = p.current_path.clone();
            let mut curr = cur.as_path();
            while let Some(parent) = curr.parent() {
                if !self.tree_expanded.contains(parent) {
                    self.tree_expanded.insert(parent.to_path_buf());
                    if !self.tree_cache.contains_key(parent) && !self.tree_pending.contains(parent) {
                        self.tree_pending.insert(parent.to_path_buf());
                        let tx = self.tree_load_tx.clone();
                        let p_clone = parent.to_path_buf();
                        std::thread::spawn(move || {
                            let children = crate::fs_ops::list_subdirectories_fast(&p_clone);
                            let _ = tx.send((p_clone, children));
                        });
                    }
                }
                curr = parent;
            }
        }
    }

    fn configure_cjk_fonts(ctx: &egui::Context) {
        let mut fonts = egui::FontDefinitions::default();
        // Load native system CJK fonts as fallback AFTER egui's built-in Latin & icon fonts
        // so icons/symbols never turn into missing boxes and CJK renders crisply.
        let candidate_paths = [
            // macOS
            "/System/Library/Fonts/PingFang.ttc",
            "/System/Library/Fonts/STHeiti Light.ttc",
            "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
            // Windows 10 / 11
            "C:\\Windows\\Fonts\\msjh.ttc",
            "C:\\Windows\\Fonts\\msyh.ttc",
            "C:\\Windows\\Fonts\\mingliu.ttc",
            "C:\\Windows\\Fonts\\msgothic.ttc",
            // Linux
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        ];

        for font_path in candidate_paths {
            if let Ok(bytes) = std::fs::read(font_path) {
                fonts.font_data.insert(
                    "cjk_system".to_owned(),
                    egui::FontData::from_owned(bytes).into(),
                );
                if let Some(vec) = fonts.families.get_mut(&egui::FontFamily::Proportional) {
                    vec.push("cjk_system".to_owned());
                }
                if let Some(vec) = fonts.families.get_mut(&egui::FontFamily::Monospace) {
                    vec.push("cjk_system".to_owned());
                }
                break;
            }
        }

        // On Windows, also load Segoe UI Symbol if available for rich Unicode symbols
        if let Ok(sym_bytes) = std::fs::read("C:\\Windows\\Fonts\\seguisym.ttf") {
            fonts.font_data.insert(
                "win_symbols".to_owned(),
                egui::FontData::from_owned(sym_bytes).into(),
            );
            if let Some(vec) = fonts.families.get_mut(&egui::FontFamily::Proportional) {
                vec.push("win_symbols".to_owned());
            }
        }

        ctx.set_fonts(fonts);
    }

    pub fn refresh_system_remote_folders(&mut self) {
        self.is_discovering_remotes = true;
        self.remote_discovery_rx = Some(crate::fs_ops::spawn_remote_folders_discovery());
        self.disks_discovery_rx = Some(crate::fs_ops::spawn_disks_discovery());
    }

    pub fn probe_all_smb(&mut self) {
        self.last_smb_probe_tick = std::time::Instant::now();
        self.system_smb_probes.clear();
        for (idx, smb) in self.system_smb_shares.iter_mut().enumerate() {
            if matches!(smb.status, SmbStatus::Unknown) {
                smb.status = SmbStatus::Probing;
            }
            let rx = smb.probe_async();
            self.system_smb_probes.push((idx, rx));
        }

        self.smb_probes.clear();
        for (idx, smb) in self.config.smb_bookmarks.iter_mut().enumerate() {
            if matches!(smb.status, SmbStatus::Unknown) {
                smb.status = SmbStatus::Probing;
            }
            let rx = smb.probe_async();
            self.smb_probes.push((idx, rx));
        }
    }

    pub fn active_pane_index(&self) -> usize {
        self.panes
            .iter()
            .position(|p| p.id == self.active_pane_id)
            .unwrap_or(0)
    }

    pub fn spawn_new_pane(&mut self, path: PathBuf) {
        for p in &mut self.panes {
            p.selected_paths.clear();
            p.last_clicked_idx = None;
        }
        let id = self.next_pane_id;
        self.next_pane_id += 1;
        let mut pane = MdiChildPane::new(id, path);
        if let Some(ws) = self.last_workspace_rect {
            let offset = ((self.panes.len() % 8) as f32) * 28.0;
            let w = (ws.width() * 0.68).clamp(280.0, (ws.width() - 16.0).max(280.0));
            let h = (ws.height() * 0.72).clamp(200.0, (ws.height() - 16.0).max(200.0));
            let x = (ws.min.x + 14.0 + offset)
                .clamp(ws.min.x + 4.0, (ws.max.x - w - 4.0).max(ws.min.x + 4.0));
            let y = (ws.min.y + 14.0 + offset)
                .clamp(ws.min.y + 4.0, (ws.max.y - h - 4.0).max(ws.min.y + 4.0));
            pane.float_rect = Some(Rect::from_min_size(Pos2::new(x, y), Vec2::new(w, h)));
        } else {
            pane.float_rect = None;
        }
        self.panes.push(pane);
        self.active_pane_id = id;
        if self.config.layout_mode == WindowLayoutMode::Cascade {
            self.needs_cascade_recalc = true;
        }
        self.sync_config_paths();
    }

    pub fn close_pane_by_id(&mut self, id: usize) {
        if self.panes.len() <= 1 {
            self.status_toast = if self.config.language == Language::ZhTw {
                "⚠ 至少需保留一個子視窗".into()
            } else {
                "⚠ At least one MDI child window must remain open".into()
            };
            return;
        }
        if let Some(pos) = self.panes.iter().position(|p| p.id == id) {
            let removed = self.panes.remove(pos);
            let path_str = removed.current_path.to_string_lossy().into_owned();
            self.config.closed_history.retain(|p| p != &path_str);
            self.config.closed_history.insert(0, path_str);
            if self.config.closed_history.len() > 25 {
                self.config.closed_history.truncate(25);
            }
            if self.active_pane_id == id {
                if let Some(first) = self.panes.first() {
                    self.active_pane_id = first.id;
                }
            }
            self.sync_config_paths();
        }
    }

    pub fn restore_last_closed_pane(&mut self) {
        if let Some(last_path) = self.config.closed_history.first().cloned() {
            self.config.closed_history.remove(0);
            self.spawn_new_pane(PathBuf::from(last_path));
        }
    }

    pub fn sync_config_paths(&mut self) {
        self.config.open_pane_paths = self
            .panes
            .iter()
            .map(|p| p.current_path.to_string_lossy().into_owned())
            .collect();
        self.config.gesture_bindings = self.gesture_tracker.bindings.clone();
        let _ = self.config.save();
    }

    pub fn execute_gesture_action(&mut self, action: GestureAction) {
        let idx = self.active_pane_index();
        match action {
            GestureAction::NavigateBack => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.go_back();
                }
            }
            GestureAction::NavigateForward => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.go_forward();
                }
            }
            GestureAction::NavigateUp => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.go_up();
                }
            }
            GestureAction::NewMdiWindow => {
                let path = self
                    .panes
                    .get(idx)
                    .map(|p| p.current_path.clone())
                    .unwrap_or_else(|| dirs::home_dir().unwrap_or_else(|| PathBuf::from(".")));
                self.spawn_new_pane(path);
            }
            GestureAction::CloneActiveWindow => {
                if let Some(p) = self.panes.get(idx) {
                    let path = p.current_path.clone();
                    self.spawn_new_pane(path);
                }
            }
            GestureAction::CloseActiveWindow => {
                let id = self.active_pane_id;
                self.close_pane_by_id(id);
            }
            GestureAction::RestoreClosedWindow => {
                self.restore_last_closed_pane();
            }
            GestureAction::RefreshActiveWindow => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.trigger_reload();
                }
            }
            GestureAction::TileGrid => {
                self.config.layout_mode = WindowLayoutMode::TileGrid;
            }
            GestureAction::TileHorizontally => {
                self.config.layout_mode = WindowLayoutMode::TileHorizontally;
            }
            GestureAction::TileVertically => {
                self.config.layout_mode = WindowLayoutMode::TileVertically;
            }
            GestureAction::CascadeWindows => {
                self.config.layout_mode = WindowLayoutMode::Cascade;
                self.needs_cascade_recalc = true;
            }
            GestureAction::ToggleTabbedMode => {
                self.config.layout_mode =
                    if self.config.layout_mode == WindowLayoutMode::TabbedMaximized {
                        WindowLayoutMode::TileHorizontally
                    } else {
                        WindowLayoutMode::TabbedMaximized
                    };
            }
            GestureAction::ScrollToTop => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.scroll_request = ScrollRequest::Top;
                }
            }
            GestureAction::ScrollToBottom => {
                if let Some(p) = self.panes.get_mut(idx) {
                    p.scroll_request = ScrollRequest::Bottom;
                }
            }
            GestureAction::OpenGlobalSearch => {
                self.config.show_sidebar = true;
                self.sidebar_tab = SidebarTab::Search;
                self.focus_search_input = true;
            }
        }
        self.status_toast = format!(
            "🖱 {} -> {}",
            if self.config.language == Language::ZhTw {
                "手勢觸發"
            } else {
                "Gesture Executed"
            },
            action.label(self.config.language)
        );
    }

    pub fn execute_start_search(&mut self) {
        if self.deep_search_query.trim().is_empty() && self.deep_search_grep.trim().is_empty() {
            self.status_toast = if self.config.language == Language::ZhTw {
                "⚠ 請輸入搜尋檔名關鍵字或內文".to_string()
            } else {
                "⚠ Please enter file name or content keyword".to_string()
            };
            return;
        }

        // Cancel previous search
        self.deep_search_cancel.store(true, std::sync::atomic::Ordering::Relaxed);
        self.deep_search_cancel = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        self.deep_search_results.clear();
        self.deep_search_selected.clear();
        self.deep_search_scanned = 0;
        self.deep_search_running = true;

        let roots: Vec<PathBuf> = match self.search_scope_mode {
            SearchScopeMode::ActivePane => {
                let idx = self.active_pane_index();
                self.panes
                    .get(idx)
                    .map(|p| vec![p.current_path.clone()])
                    .unwrap_or_else(|| vec![std::env::current_dir().unwrap_or_default()])
            }
            SearchScopeMode::AllPanes => {
                let mut list: Vec<PathBuf> = self
                    .panes
                    .iter()
                    .filter(|p| !p.is_search_results)
                    .map(|p| p.current_path.clone())
                    .collect();
                if list.is_empty() {
                    list.push(std::env::current_dir().unwrap_or_default());
                }
                list
            }
            SearchScopeMode::Custom => {
                let p = PathBuf::from(self.search_custom_path.trim());
                if p.exists() {
                    vec![p]
                } else {
                    let idx = self.active_pane_index();
                    self.panes
                        .get(idx)
                        .map(|p| vec![p.current_path.clone()])
                        .unwrap_or_default()
                }
            }
        };

        let search_root_display = roots.first().cloned().unwrap_or_else(|| PathBuf::from("."));

        let t_cfg = self.config.language.texts();
        let search_title = format!("🔍 {}: {}", t_cfg.search_results_title, self.deep_search_query);

        let mut existing_id = None;
        for p in &mut self.panes {
            if p.is_search_results {
                p.title = search_title.clone();
                p.address_input = format!("mine://search?q={}", self.deep_search_query);
                p.entries.clear();
                p.filtered_indices.clear();
                p.selected_paths.clear();
                p.current_path = search_root_display.clone();
                p.sort_col = crate::state::SortColumn::Name;
                p.sort_asc = true;
                existing_id = Some(p.id);
                break;
            }
        }

        if let Some(id) = existing_id {
            self.active_pane_id = id;
        } else {
            let new_id = self.next_pane_id;
            self.next_pane_id += 1;
            let mut new_pane = MdiChildPane::new_search_results(
                new_id,
                search_root_display,
                &self.deep_search_query,
            );
            new_pane.title = search_title;
            self.panes.push(new_pane);
            self.active_pane_id = new_id;
        }

        let opts = crate::search::DeepSearchOptions {
            search_subdirs: self.search_subdirs,
            wildcard_mode: self.search_wildcard,
            case_sensitive: self.search_case_sensitive,
            include_hidden: self.search_include_hidden,
            include_system: self.search_include_system,
        };

        self.deep_search_rx = Some(crate::search::spawn_deep_search(
            roots,
            self.deep_search_query.clone(),
            self.deep_search_grep.clone(),
            3000,
            opts,
            self.deep_search_cancel.clone(),
        ));

        self.status_toast = if self.config.language == Language::ZhTw {
            "🔍 已啟動搜尋，檢索結果將即時呈現在右側「檢索結果」視窗中".to_string()
        } else {
            "🔍 Search started. Real-time results streaming in the Search Results tab.".to_string()
        };
    }

    pub fn recalculate_cascade_rects(&mut self, workspace_rect: Rect) {
        let n = self.panes.len().max(1);
        let pad = 10.0;
        let step = if n > 1 {
            ((workspace_rect.width() * 0.22) / ((n - 1) as f32)).clamp(24.0, 36.0)
        } else {
            0.0
        };
        let total_offset = step * ((n.saturating_sub(1)) as f32);
        let max_w = (workspace_rect.width() - pad * 2.0).max(220.0);
        let max_h = (workspace_rect.height() - pad * 2.0).max(160.0);
        let w = (workspace_rect.width() - pad * 2.0 - total_offset.max(60.0))
            .clamp(300.0_f32.min(max_w), max_w);
        let h = (workspace_rect.height() - pad * 2.0 - total_offset.max(50.0))
            .clamp(220.0_f32.min(max_h), max_h);

        for (i, pane) in self.panes.iter_mut().enumerate() {
            let offset = (i as f32) * step;
            let min_x = (workspace_rect.min.x + pad + offset).clamp(
                workspace_rect.min.x + 4.0,
                (workspace_rect.max.x - w - 4.0).max(workspace_rect.min.x + 4.0),
            );
            let min_y = (workspace_rect.min.y + pad + offset).clamp(
                workspace_rect.min.y + 4.0,
                (workspace_rect.max.y - h - 4.0).max(workspace_rect.min.y + 4.0),
            );
            pane.float_rect = Some(Rect::from_min_size(
                Pos2::new(min_x, min_y),
                Vec2::new(w, h),
            ));
            pane.is_minimized = false;
        }
        self.needs_cascade_recalc = false;
    }

    pub fn trigger_preview(&mut self, path: PathBuf) {
        if self.preview_target.as_ref() == Some(&path) {
            return;
        }
        self.preview_target = Some(path.clone());
        self.preview_state = PreviewPayload::Loading(path.clone());
        self.preview_texture = None;
        self.preview_rx = Some(load_preview_sandboxed(path));
    }

    pub fn perform_file_transfer(
        &mut self,
        sources: &[PathBuf],
        dest_dir: &Path,
        is_cut: bool,
    ) {
        if !dest_dir.is_dir() {
            return;
        }
        let mut ok_count = 0usize;
        for src in sources {
            if let Some(name) = src.file_name() {
                let dst = dest_dir.join(name);
                if dst == *src {
                    continue;
                }
                let res = if is_cut {
                    std::fs::rename(src, &dst).or_else(|_| {
                        copy_path_recursive(src, &dst).and_then(|_| {
                            if src.is_dir() {
                                std::fs::remove_dir_all(src)
                            } else {
                                std::fs::remove_file(src)
                            }
                        })
                    })
                } else {
                    copy_path_recursive(src, &dst)
                };
                if res.is_ok() {
                    ok_count += 1;
                }
            }
        }
        for p in &mut self.panes {
            p.trigger_reload();
        }
        self.status_toast = format!(
            "✅ {} {} -> {}",
            if is_cut { "Moved" } else { "Copied" },
            ok_count,
            dest_dir.to_string_lossy()
        );
    }

    pub fn apply_theme(&self, ctx: &egui::Context) {
        match self.config.theme {
            AppTheme::ModernDark => {
                let mut vis = egui::Visuals::dark();
                vis.window_rounding = egui::Rounding::same(6.0);
                vis.panel_fill = Color32::from_rgb(22, 24, 30);
                vis.extreme_bg_color = Color32::from_rgb(18, 20, 26);
                ctx.set_visuals(vis);
            }
            AppTheme::CleanLight => {
                let mut vis = egui::Visuals::light();
                vis.window_rounding = egui::Rounding::same(6.0);
                vis.extreme_bg_color = Color32::from_rgb(235, 238, 244);
                ctx.set_visuals(vis);
            }
            AppTheme::ClassicMdie => {
                // Classic Windows XP / MDIE crisp light bluish-silver MDI styling
                let mut vis = egui::Visuals::light();
                vis.window_rounding = egui::Rounding::same(3.0);
                vis.panel_fill = Color32::from_rgb(240, 242, 246);
                vis.extreme_bg_color = Color32::from_rgb(232, 236, 242);
                vis.selection.bg_fill = Color32::from_rgb(51, 153, 255);
                vis.selection.stroke = Stroke::new(1.0, Color32::WHITE);
                ctx.set_visuals(vis);
            }
        }
        ctx.style_mut(|s| {
            s.interaction.selectable_labels = false;
            // Always show a solid, draggable right-side scrollbar on every folder window
            s.spacing.scroll = egui::style::ScrollStyle::solid();
            s.spacing.scroll.bar_width = 12.0;
            s.spacing.scroll.handle_min_length = 28.0;
            s.spacing.scroll.bar_inner_margin = 2.0;
            s.spacing.scroll.bar_outer_margin = 2.0;
            s.spacing.scroll.foreground_color = false;
        });
    }

    pub fn add_quick_access_item(&mut self, name: String, path: String) {
        let clean_path = path.trim().to_string();
        if clean_path.is_empty() {
            return;
        }
        if let Some(existing) = self
            .config
            .quick_access_items
            .iter_mut()
            .find(|it| it.path == clean_path)
        {
            existing.is_visible = true;
            if !name.trim().is_empty() {
                existing.name = name.trim().to_string();
            }
        } else {
            let id = format!("qa_{}", chrono::Local::now().timestamp_millis());
            let final_name = if name.trim().is_empty() {
                PathBuf::from(&clean_path)
                    .file_name()
                    .map(|n| n.to_string_lossy().into_owned())
                    .unwrap_or_else(|| clean_path.clone())
            } else {
                name.trim().to_string()
            };
            self.config.quick_access_items.push(crate::state::QuickAccessItem {
                id,
                name: final_name,
                path: clean_path,
                icon: "📁".into(),
                is_visible: true,
                is_builtin: false,
            });
        }
        let _ = self.config.save();
        self.status_toast = if self.config.language == crate::i18n::Language::ZhTw {
            "⭐ 已成功加入常用資料夾！".into()
        } else {
            "⭐ Added to Quick Access successfully!".into()
        };
    }

    pub fn remove_quick_access_item(&mut self, id: &str) {
        if let Some(pos) = self
            .config
            .quick_access_items
            .iter()
            .position(|it| it.id == id)
        {
            if self.config.quick_access_items[pos].is_builtin {
                self.config.quick_access_items[pos].is_visible = false;
            } else {
                self.config.quick_access_items.remove(pos);
            }
            let _ = self.config.save();
            self.status_toast = if self.config.language == crate::i18n::Language::ZhTw {
                "🗑 已從常用資料夾移除".into()
            } else {
                "🗑 Removed from Quick Access".into()
            };
        }
    }

    pub fn reset_quick_access_items(&mut self) {
        self.config.quick_access_items = crate::state::default_quick_access_items();
        let _ = self.config.save();
        self.status_toast = if self.config.language == crate::i18n::Language::ZhTw {
            "🔄 常用資料夾已恢復為系統預設清單".into()
        } else {
            "🔄 Quick Access items reset to defaults".into()
        };
    }
}

fn copy_path_recursive(src: &Path, dst: &Path) -> std::io::Result<()> {
    if src.is_dir() {
        std::fs::create_dir_all(dst)?;
        for entry in std::fs::read_dir(src)? {
            let entry = entry?;
            let ty = entry.file_type()?;
            if ty.is_dir() {
                copy_path_recursive(&entry.path(), &dst.join(entry.file_name()))?;
            } else {
                std::fs::copy(entry.path(), dst.join(entry.file_name()))?;
            }
        }
        Ok(())
    } else {
        std::fs::copy(src, dst).map(|_| ())
    }
}
