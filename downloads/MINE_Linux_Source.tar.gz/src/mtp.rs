use crate::fs_ops::FileEntry;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{OnceLock, RwLock};

/// Virtual path prefix for Windows Portable Devices (MTP / PTP phones, tablets, cameras)
/// backed by Windows Shell Namespace (`IShellItem` / `IEnumShellItems` / `IFileOperation`).
pub const MTP_PREFIX: &str = "mine-mtp://";

fn mtp_name_cache() -> &'static RwLock<HashMap<String, String>> {
    static CACHE: OnceLock<RwLock<HashMap<String, String>>> = OnceLock::new();
    CACHE.get_or_init(|| RwLock::new(HashMap::new()))
}

fn mtp_breadcrumb_cache() -> &'static RwLock<HashMap<String, String>> {
    static CACHE: OnceLock<RwLock<HashMap<String, String>>> = OnceLock::new();
    CACHE.get_or_init(|| RwLock::new(HashMap::new()))
}

pub fn register_mtp_display_name(mtp_path: &Path, display_name: &str, parent_path: Option<&Path>) {
    let key = mtp_path.to_string_lossy().into_owned();
    if let Ok(mut map) = mtp_name_cache().write() {
        map.insert(key.clone(), display_name.to_string());
    }
    let breadcrumb = if let Some(parent) = parent_path {
        let p_key = parent.to_string_lossy().into_owned();
        let parent_bc = mtp_breadcrumb_cache()
            .read()
            .ok()
            .and_then(|m| m.get(&p_key).cloned());
        match parent_bc {
            Some(bc) => format!("{} > {}", bc, display_name),
            None => format!("📱 {}", display_name),
        }
    } else {
        format!("📱 {}", display_name)
    };
    if let Ok(mut map) = mtp_breadcrumb_cache().write() {
        map.insert(key, breadcrumb);
    }
}

/// Returns `true` if `path` is a MINE virtual MTP / Portable Device Shell path.
pub fn is_mtp_path(path: &Path) -> bool {
    path.to_string_lossy().starts_with(MTP_PREFIX)
}

/// Extracts the underlying Windows Shell parsing name (`SIGDN_DESKTOPABSOLUTEPARSING`)
/// from a `mine-mtp://...` path.
pub fn strip_mtp_prefix(path: &Path) -> Option<String> {
    let s = path.to_string_lossy();
    s.strip_prefix(MTP_PREFIX).map(|rest| rest.to_string())
}

/// Builds a `mine-mtp://...` virtual `PathBuf` from a Windows Shell parsing name.
pub fn make_mtp_path(shell_parsing_name: &str) -> PathBuf {
    PathBuf::from(format!("{}{}", MTP_PREFIX, shell_parsing_name))
}

/// Returns `true` if a Windows `This PC` child's `SIGDN_DESKTOPABSOLUTEPARSING` string
/// represents a Portable Device (MTP / PTP / WPD phone, tablet, or camera).
pub fn is_portable_device_parsing_name(parsing_name: &str) -> bool {
    let lower = parsing_name.to_ascii_lowercase();
    lower.contains("\\\\?\\")
        || lower.contains("wpdbusenum#")
        || lower.contains("{6ac27878-a6fa-4155-ba85-f98f491d4f33}")
}

/// Human-friendly title for a `mine-mtp://...` path (used in window titles & tabs).
pub fn display_name_for_mtp_path(path: &Path) -> String {
    let key = path.to_string_lossy();
    if let Ok(map) = mtp_name_cache().read() {
        if let Some(name) = map.get(key.as_ref()) {
            return format!("📱 {}", name);
        }
    }
    "📱 MTP Device".to_string()
}

/// Human-friendly breadcrumb for the address bar (e.g. `📱 MTP USB Device > 內部共用儲存空間 > DCIM`).
pub fn display_address_for_path(path: &Path) -> String {
    if !is_mtp_path(path) {
        return path.to_string_lossy().into_owned();
    }
    let key = path.to_string_lossy();
    if let Ok(map) = mtp_breadcrumb_cache().read() {
        if let Some(bc) = map.get(key.as_ref()) {
            return bc.clone();
        }
    }
    display_name_for_mtp_path(path)
}

/// Enumerates currently connected Portable Devices (MTP/PTP phones, cameras) under `This PC`.
/// Returns `(label, mine-mtp://..., free_bytes, total_bytes)`.
pub fn list_portable_devices() -> Vec<(String, PathBuf, u64, u64)> {
    #[cfg(target_os = "windows")]
    {
        win_mtp::list_portable_devices()
    }
    #[cfg(not(target_os = "windows"))]
    {
        Vec::new()
    }
}

/// Lists children (storages, folders, and files) of an MTP / Portable Device folder.
pub fn list_mtp_dir(path: &Path) -> Result<Vec<FileEntry>, String> {
    #[cfg(target_os = "windows")]
    {
        win_mtp::list_mtp_dir(path)
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = path;
        Err("MTP browsing is only supported via Windows Shell Namespace on Windows".into())
    }
}

/// Lists only child folders of an MTP folder (for Left Sidebar tree expansion).
pub fn list_mtp_subdirectories(path: &Path) -> Vec<(String, PathBuf)> {
    match list_mtp_dir(path) {
        Ok(entries) => entries
            .into_iter()
            .filter(|e| e.is_dir)
            .map(|e| (e.display_name, e.path))
            .collect(),
        Err(_) => Vec::new(),
    }
}

/// Returns the parent virtual path of an MTP path (`mine://this-pc` when at a device root).
pub fn mtp_parent_path(path: &Path) -> PathBuf {
    #[cfg(target_os = "windows")]
    {
        win_mtp::mtp_parent_path(path)
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = path;
        PathBuf::from(crate::fs_ops::THIS_PC_PATH)
    }
}

/// Copies or moves items involving at least one MTP path using Windows `IFileOperation`.
pub fn shell_transfer_items(
    sources: &[PathBuf],
    dest_dir: &Path,
    is_move: bool,
) -> Result<usize, String> {
    #[cfg(target_os = "windows")]
    {
        win_mtp::shell_transfer_items(sources, dest_dir, is_move)
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = (sources, dest_dir, is_move);
        Err("MTP transfer is only supported on Windows".into())
    }
}

/// Deletes one or more MTP items using Windows `IFileOperation`.
pub fn shell_delete_items(targets: &[PathBuf]) -> Result<usize, String> {
    #[cfg(target_os = "windows")]
    {
        win_mtp::shell_delete_items(targets)
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = targets;
        Err("MTP delete is only supported on Windows".into())
    }
}

/// Creates a new folder inside an MTP directory using Windows `IFileOperation`.
pub fn shell_new_folder(parent_dir: &Path, folder_name: &str) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        win_mtp::shell_new_folder(parent_dir, folder_name)
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = (parent_dir, folder_name);
        Err("MTP new folder is only supported on Windows".into())
    }
}

/// Renames an MTP file or folder using Windows `IFileOperation`.
pub fn shell_rename_item(item_path: &Path, new_name: &str) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        win_mtp::shell_rename_item(item_path, new_name)
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = (item_path, new_name);
        Err("MTP rename is only supported on Windows".into())
    }
}

/// Copies a single MTP file to a temporary directory and opens it with the OS default application.
pub fn open_mtp_file(path: &Path) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        win_mtp::open_mtp_file(path)
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = path;
        Err("MTP open is only supported on Windows".into())
    }
}

// ============================================================================
// Windows Shell Namespace COM Backend (Zero Extra Crates)
// ============================================================================

#[cfg(target_os = "windows")]
mod win_mtp {
    use super::*;
    use std::ffi::{c_void, OsStr};
    use std::os::windows::ffi::OsStrExt;
    use std::ptr::{null, null_mut};

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct Guid {
        data1: u32,
        data2: u16,
        data3: u16,
        data4: [u8; 8],
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct PropertyKey {
        fmtid: Guid,
        pid: u32,
    }

    const COINIT_APARTMENTTHREADED: u32 = 0x2;
    const CLSCTX_INPROC_SERVER: u32 = 0x1;

    const SIGDN_NORMALDISPLAY: u32 = 0x0000_0000;
    const SIGDN_DESKTOPABSOLUTEPARSING: u32 = 0x8002_8000;

    const SFGAO_FOLDER: u32 = 0x2000_0000;
    const SFGAO_FILESYSTEM: u32 = 0x4000_0000;

    const FILE_ATTRIBUTE_DIRECTORY: u32 = 0x0000_0010;
    const FOF_NOCONFIRMATION: u32 = 0x0010;
    const FOF_NOCONFIRMMKDIR: u32 = 0x0200;
    const FOF_NOERRORUI: u32 = 0x0400;

    const FOLDERID_COMPUTER_FOLDER: Guid = Guid {
        data1: 0x0ac0_837c,
        data2: 0xbbf8,
        data3: 0x452a,
        data4: [0x85, 0x0d, 0x79, 0xd0, 0x8e, 0x66, 0x7c, 0xa7],
    };
    const IID_ISHELL_ITEM: Guid = Guid {
        data1: 0x4382_6d1e,
        data2: 0xe718,
        data3: 0x42ee,
        data4: [0xbc, 0x55, 0xa1, 0xe2, 0x61, 0xc3, 0x7b, 0xfe],
    };
    const IID_ISHELL_ITEM2: Guid = Guid {
        data1: 0x7e9f_b0d3,
        data2: 0x919f,
        data3: 0x4307,
        data4: [0xab, 0x2e, 0x9b, 0x18, 0x60, 0x31, 0x0c, 0x93],
    };
    const BHID_ENUM_ITEMS: Guid = Guid {
        data1: 0x94f6_0519,
        data2: 0x2850,
        data3: 0x4924,
        data4: [0xaa, 0x5a, 0xd1, 0x5e, 0x84, 0x86, 0x80, 0x39],
    };
    const IID_IENUM_SHELL_ITEMS: Guid = Guid {
        data1: 0x7062_9033,
        data2: 0xe363,
        data3: 0x4a28,
        data4: [0xa5, 0x67, 0x0d, 0xb7, 0x80, 0x06, 0xe6, 0xd7],
    };
    const CLSID_FILE_OPERATION: Guid = Guid {
        data1: 0x3ad0_5575,
        data2: 0x8857,
        data3: 0x4850,
        data4: [0x92, 0x77, 0x11, 0xb8, 0x5b, 0xdb, 0x8e, 0x09],
    };
    const IID_IFILE_OPERATION: Guid = Guid {
        data1: 0x947a_ab5f,
        data2: 0x0a5c,
        data3: 0x4c13,
        data4: [0xb4, 0xd6, 0x4b, 0xf7, 0x83, 0x6f, 0xc9, 0xf8],
    };

    const PKEY_SIZE: PropertyKey = PropertyKey {
        fmtid: Guid {
            data1: 0xb725_f130,
            data2: 0x47ef,
            data3: 0x101a,
            data4: [0xa5, 0xf1, 0x02, 0x60, 0x8c, 0x9e, 0xeb, 0xac],
        },
        pid: 12,
    };
    const PKEY_DATE_MODIFIED: PropertyKey = PropertyKey {
        fmtid: Guid {
            data1: 0xb725_f130,
            data2: 0x47ef,
            data3: 0x101a,
            data4: [0xa5, 0xf1, 0x02, 0x60, 0x8c, 0x9e, 0xeb, 0xac],
        },
        pid: 14,
    };
    const PKEY_FREE_SPACE: PropertyKey = PropertyKey {
        fmtid: Guid {
            data1: 0x9b17_4b35,
            data2: 0x40ff,
            data3: 0x11d2,
            data4: [0xa2, 0x7e, 0x00, 0xc0, 0x4f, 0xc3, 0x08, 0x71],
        },
        pid: 2,
    };
    const PKEY_CAPACITY: PropertyKey = PropertyKey {
        fmtid: Guid {
            data1: 0x9b17_4b35,
            data2: 0x40ff,
            data3: 0x11d2,
            data4: [0xa2, 0x7e, 0x00, 0xc0, 0x4f, 0xc3, 0x08, 0x71],
        },
        pid: 3,
    };

    #[link(name = "kernel32")]
    extern "system" {
        fn LoadLibraryW(lp_lib_file_name: *const u16) -> *mut c_void;
        fn GetProcAddress(h_module: *mut c_void, lp_proc_name: *const u8) -> *mut c_void;
    }

    #[link(name = "ole32")]
    extern "system" {
        fn CoInitializeEx(pv_reserved: *mut c_void, dw_coinit: u32) -> i32;
        fn CoUninitialize();
        fn CoTaskMemFree(pv: *mut c_void);
        fn CoCreateInstance(
            rclsid: *const Guid,
            p_unk_outer: *mut c_void,
            dw_cls_context: u32,
            riid: *const Guid,
            ppv: *mut *mut c_void,
        ) -> i32;
    }

    struct ComGuard(bool);
    impl ComGuard {
        fn init_sta() -> Self {
            let hr = unsafe { CoInitializeEx(null_mut(), COINIT_APARTMENTTHREADED) };
            Self(hr >= 0)
        }
    }
    impl Drop for ComGuard {
        fn drop(&mut self) {
            if self.0 {
                unsafe { CoUninitialize() };
            }
        }
    }

    fn to_wide_z(s: &str) -> Vec<u16> {
        OsStr::new(s)
            .encode_wide()
            .chain(std::iter::once(0))
            .collect()
    }

    unsafe fn vtable_fn(obj: *mut c_void, slot: usize) -> *mut c_void {
        let vtbl = *(obj as *const *const *mut c_void);
        *vtbl.add(slot)
    }

    unsafe fn com_release(obj: *mut c_void) {
        if !obj.is_null() {
            let f: unsafe extern "system" fn(*mut c_void) -> u32 =
                std::mem::transmute(vtable_fn(obj, 2));
            let _ = f(obj);
        }
    }

    unsafe fn com_query_interface(obj: *mut c_void, riid: &Guid) -> *mut c_void {
        let mut out: *mut c_void = null_mut();
        let qi: unsafe extern "system" fn(*mut c_void, *const Guid, *mut *mut c_void) -> i32 =
            std::mem::transmute(vtable_fn(obj, 0));
        if qi(obj, riid, &mut out) >= 0 {
            out
        } else {
            null_mut()
        }
    }

    unsafe fn shell_item_display_name(item: *mut c_void, sigdn: u32) -> Option<String> {
        let get_name: unsafe extern "system" fn(*mut c_void, u32, *mut *mut u16) -> i32 =
            std::mem::transmute(vtable_fn(item, 5));
        let mut ptr: *mut u16 = null_mut();
        if get_name(item, sigdn, &mut ptr) < 0 || ptr.is_null() {
            return None;
        }
        let mut len = 0usize;
        while *ptr.add(len) != 0 && len < 16_384 {
            len += 1;
        }
        let s = String::from_utf16_lossy(std::slice::from_raw_parts(ptr, len));
        CoTaskMemFree(ptr as *mut c_void);
        if s.is_empty() {
            None
        } else {
            Some(s)
        }
    }

    unsafe fn shell_item_attributes(item: *mut c_void, mask: u32) -> u32 {
        let get_attr: unsafe extern "system" fn(*mut c_void, u32, *mut u32) -> i32 =
            std::mem::transmute(vtable_fn(item, 6));
        let mut out = 0u32;
        let _ = get_attr(item, mask, &mut out);
        out
    }

    unsafe fn shell_item_u64_prop(item: *mut c_void, key: &PropertyKey) -> Option<u64> {
        let item2 = com_query_interface(item, &IID_ISHELL_ITEM2);
        if item2.is_null() {
            return None;
        }
        let get_u64: unsafe extern "system" fn(*mut c_void, *const PropertyKey, *mut u64) -> i32 =
            std::mem::transmute(vtable_fn(item2, 19));
        let mut val = 0u64;
        let hr = get_u64(item2, key, &mut val);
        com_release(item2);
        if hr >= 0 {
            Some(val)
        } else {
            None
        }
    }

    unsafe fn shell_item_filetime_prop(item: *mut c_void, key: &PropertyKey) -> Option<u64> {
        let item2 = com_query_interface(item, &IID_ISHELL_ITEM2);
        if item2.is_null() {
            return None;
        }
        let get_ft: unsafe extern "system" fn(*mut c_void, *const PropertyKey, *mut u64) -> i32 =
            std::mem::transmute(vtable_fn(item2, 15));
        let mut ft = 0u64;
        let hr = get_ft(item2, key, &mut ft);
        com_release(item2);
        if hr >= 0 && ft > 0 {
            Some(ft)
        } else {
            None
        }
    }

    fn filetime_to_local_str_and_ts(ft: u64) -> (String, i64) {
        const WINDOWS_TICK: u64 = 10_000_000;
        const SEC_TO_UNIX_EPOCH: u64 = 11_644_473_600;
        let secs = ft / WINDOWS_TICK;
        if secs < SEC_TO_UNIX_EPOCH {
            return ("-".into(), 0);
        }
        let unix = (secs - SEC_TO_UNIX_EPOCH) as i64;
        if let Some(dt) = chrono::DateTime::from_timestamp(unix, 0) {
            let local: chrono::DateTime<chrono::Local> = dt.into();
            (local.format("%Y-%m-%d %H:%M").to_string(), unix)
        } else {
            ("-".into(), unix)
        }
    }

    unsafe fn create_shell_item_from_path(path: &Path) -> *mut c_void {
        let shell_str = if let Some(raw) = strip_mtp_prefix(path) {
            raw
        } else {
            path.to_string_lossy().into_owned()
        };
        let h_shell = LoadLibraryW(to_wide_z("shell32.dll").as_ptr());
        if h_shell.is_null() {
            return null_mut();
        }
        let p = GetProcAddress(h_shell, b"SHCreateItemFromParsingName\0".as_ptr());
        if p.is_null() {
            return null_mut();
        }
        let sh_create: unsafe extern "system" fn(
            *const u16,
            *mut c_void,
            *const Guid,
            *mut *mut c_void,
        ) -> i32 = std::mem::transmute(p);
        let wide = to_wide_z(&shell_str);
        let mut item: *mut c_void = null_mut();
        if sh_create(wide.as_ptr(), null_mut(), &IID_ISHELL_ITEM, &mut item) >= 0 {
            item
        } else {
            null_mut()
        }
    }

    unsafe fn enum_shell_children(folder_item: *mut c_void) -> Vec<*mut c_void> {
        let mut out = Vec::new();
        let bind: unsafe extern "system" fn(
            *mut c_void,
            *mut c_void,
            *const Guid,
            *const Guid,
            *mut *mut c_void,
        ) -> i32 = std::mem::transmute(vtable_fn(folder_item, 3));
        let mut enum_items: *mut c_void = null_mut();
        if bind(
            folder_item,
            null_mut(),
            &BHID_ENUM_ITEMS,
            &IID_IENUM_SHELL_ITEMS,
            &mut enum_items,
        ) < 0
            || enum_items.is_null()
        {
            return out;
        }
        let next: unsafe extern "system" fn(
            *mut c_void,
            u32,
            *mut *mut c_void,
            *mut u32,
        ) -> i32 = std::mem::transmute(vtable_fn(enum_items, 3));
        loop {
            let mut child: *mut c_void = null_mut();
            let mut fetched = 0u32;
            let hr = next(enum_items, 1, &mut child, &mut fetched);
            if hr != 0 || fetched == 0 || child.is_null() {
                break;
            }
            out.push(child);
        }
        com_release(enum_items);
        out
    }

    pub fn list_portable_devices() -> Vec<(String, PathBuf, u64, u64)> {
        let _com = ComGuard::init_sta();
        let mut out = Vec::new();
        unsafe {
            let h_shell = LoadLibraryW(to_wide_z("shell32.dll").as_ptr());
            if h_shell.is_null() {
                return out;
            }
            let p_kf = GetProcAddress(h_shell, b"SHGetKnownFolderItem\0".as_ptr());
            if p_kf.is_null() {
                return out;
            }
            let sh_get_kf: unsafe extern "system" fn(
                *const Guid,
                u32,
                *mut c_void,
                *const Guid,
                *mut *mut c_void,
            ) -> i32 = std::mem::transmute(p_kf);

            let mut this_pc: *mut c_void = null_mut();
            if sh_get_kf(
                &FOLDERID_COMPUTER_FOLDER,
                0,
                null_mut(),
                &IID_ISHELL_ITEM,
                &mut this_pc,
            ) < 0
                || this_pc.is_null()
            {
                return out;
            }

            let children = enum_shell_children(this_pc);
            for child in children {
                let attrs = shell_item_attributes(child, SFGAO_FOLDER | SFGAO_FILESYSTEM);
                if (attrs & SFGAO_FOLDER) != 0 && (attrs & SFGAO_FILESYSTEM) == 0 {
                    if let Some(parsing) =
                        shell_item_display_name(child, SIGDN_DESKTOPABSOLUTEPARSING)
                    {
                        if is_portable_device_parsing_name(&parsing) {
                            let disp = shell_item_display_name(child, SIGDN_NORMALDISPLAY)
                                .unwrap_or_else(|| "MTP Device".into());
                            let mtp_path = make_mtp_path(&parsing);
                            register_mtp_display_name(&mtp_path, &disp, None);

                            let mut avail =
                                shell_item_u64_prop(child, &PKEY_FREE_SPACE).unwrap_or(0);
                            let mut total =
                                shell_item_u64_prop(child, &PKEY_CAPACITY).unwrap_or(0);

                            // Many Android MTP devices report 0 at the top device node and expose
                            // real capacity on their child storage(s) (e.g. "內部共用儲存空間").
                            if total == 0 {
                                let storages = enum_shell_children(child);
                                for st in storages {
                                    let st_avail =
                                        shell_item_u64_prop(st, &PKEY_FREE_SPACE).unwrap_or(0);
                                    let st_total =
                                        shell_item_u64_prop(st, &PKEY_CAPACITY).unwrap_or(0);
                                    avail = avail.saturating_add(st_avail);
                                    total = total.saturating_add(st_total);
                                    com_release(st);
                                }
                            }

                            out.push((disp, mtp_path, avail, total));
                        }
                    }
                }
                com_release(child);
            }
            com_release(this_pc);
        }
        out
    }

    pub fn list_mtp_dir(path: &Path) -> Result<Vec<FileEntry>, String> {
        let _com = ComGuard::init_sta();
        unsafe {
            let folder = create_shell_item_from_path(path);
            if folder.is_null() {
                return Err("無法連線至行動裝置 (MTP 裝置可能已斷開或鎖定)".into());
            }
            if let Some(folder_disp) = shell_item_display_name(folder, SIGDN_NORMALDISPLAY) {
                let parent_opt = {
                    let p = mtp_parent_path_inner(folder);
                    if crate::fs_ops::is_this_pc_path(&p) {
                        None
                    } else {
                        Some(p)
                    }
                };
                register_mtp_display_name(path, &folder_disp, parent_opt.as_deref());
            }

            let children = enum_shell_children(folder);
            let mut entries = Vec::with_capacity(children.len());
            for child in children {
                let disp = shell_item_display_name(child, SIGDN_NORMALDISPLAY)
                    .unwrap_or_else(|| "Item".into());
                let parsing = shell_item_display_name(child, SIGDN_DESKTOPABSOLUTEPARSING);
                let Some(parsing_str) = parsing else {
                    com_release(child);
                    continue;
                };
                let child_path = make_mtp_path(&parsing_str);
                let attrs = shell_item_attributes(child, SFGAO_FOLDER);
                let is_dir = (attrs & SFGAO_FOLDER) != 0;
                if is_dir {
                    register_mtp_display_name(&child_path, &disp, Some(path));
                }

                let size = if is_dir {
                    0
                } else {
                    shell_item_u64_prop(child, &PKEY_SIZE).unwrap_or(0)
                };
                let (modified_str, modified_ts) =
                    shell_item_filetime_prop(child, &PKEY_DATE_MODIFIED)
                        .map(filetime_to_local_str_and_ts)
                        .unwrap_or_else(|| ("-".into(), 0));
                let extension = if is_dir {
                    String::new()
                } else {
                    Path::new(&disp)
                        .extension()
                        .map(|e| e.to_string_lossy().to_lowercase())
                        .unwrap_or_default()
                };
                let lower_name = disp.to_lowercase();
                let is_hidden = disp.starts_with('.');

                entries.push(FileEntry {
                    path: child_path,
                    display_name: disp,
                    lower_name,
                    is_dir,
                    is_symlink: false,
                    is_hidden,
                    size,
                    extension,
                    modified_str,
                    modified_ts,
                    had_special_encoding: false,
                });
                com_release(child);
            }
            com_release(folder);
            Ok(entries)
        }
    }

    unsafe fn mtp_parent_path_inner(item: *mut c_void) -> PathBuf {
        let get_parent: unsafe extern "system" fn(*mut c_void, *mut *mut c_void) -> i32 =
            std::mem::transmute(vtable_fn(item, 4));
        let mut parent: *mut c_void = null_mut();
        if get_parent(item, &mut parent) < 0 || parent.is_null() {
            return PathBuf::from(crate::fs_ops::THIS_PC_PATH);
        }
        let res = if let Some(parsing) =
            shell_item_display_name(parent, SIGDN_DESKTOPABSOLUTEPARSING)
        {
            let lower = parsing.to_ascii_lowercase();
            // If parent is "This PC" itself (`::{20D04FE0-3AEA-1069-A2D8-08002B30309D}`)
            if lower == "::{20d04fe0-3aea-1069-a2d8-08002b30309d}"
                || !is_portable_device_parsing_name(&parsing)
            {
                PathBuf::from(crate::fs_ops::THIS_PC_PATH)
            } else {
                let mp = make_mtp_path(&parsing);
                if let Some(disp) = shell_item_display_name(parent, SIGDN_NORMALDISPLAY) {
                    register_mtp_display_name(&mp, &disp, None);
                }
                mp
            }
        } else {
            PathBuf::from(crate::fs_ops::THIS_PC_PATH)
        };
        com_release(parent);
        res
    }

    pub fn mtp_parent_path(path: &Path) -> PathBuf {
        let _com = ComGuard::init_sta();
        unsafe {
            let item = create_shell_item_from_path(path);
            if item.is_null() {
                return PathBuf::from(crate::fs_ops::THIS_PC_PATH);
            }
            let parent = mtp_parent_path_inner(item);
            com_release(item);
            parent
        }
    }

    unsafe fn create_file_operation(flags: u32) -> Option<*mut c_void> {
        let mut fop: *mut c_void = null_mut();
        let hr = CoCreateInstance(
            &CLSID_FILE_OPERATION,
            null_mut(),
            CLSCTX_INPROC_SERVER,
            &IID_IFILE_OPERATION,
            &mut fop,
        );
        if hr < 0 || fop.is_null() {
            return None;
        }
        let set_flags: unsafe extern "system" fn(*mut c_void, u32) -> i32 =
            std::mem::transmute(vtable_fn(fop, 5));
        let _ = set_flags(fop, flags);
        Some(fop)
    }

    pub fn shell_transfer_items(
        sources: &[PathBuf],
        dest_dir: &Path,
        is_move: bool,
    ) -> Result<usize, String> {
        let _com = ComGuard::init_sta();
        unsafe {
            let dst_item = create_shell_item_from_path(dest_dir);
            if dst_item.is_null() {
                return Err("無法開啟目標資料夾".into());
            }
            let Some(fop) = create_file_operation(FOF_NOCONFIRMMKDIR) else {
                com_release(dst_item);
                return Err("無法初始化 Windows 檔案傳送介面 (IFileOperation)".into());
            };
            let op_fn: unsafe extern "system" fn(
                *mut c_void,
                *mut c_void,
                *mut c_void,
                *const u16,
                *mut c_void,
            ) -> i32 = std::mem::transmute(vtable_fn(fop, if is_move { 14 } else { 16 }));

            let mut queued = 0usize;
            for src in sources {
                let src_item = create_shell_item_from_path(src);
                if !src_item.is_null() {
                    if op_fn(fop, src_item, dst_item, null(), null_mut()) >= 0 {
                        queued += 1;
                    }
                    com_release(src_item);
                }
            }
            let perform: unsafe extern "system" fn(*mut c_void) -> i32 =
                std::mem::transmute(vtable_fn(fop, 21));
            let hr = if queued > 0 { perform(fop) } else { -1 };
            com_release(fop);
            com_release(dst_item);
            if hr >= 0 {
                Ok(queued)
            } else {
                Err(format!("MTP 檔案傳送失敗 (HRESULT 0x{:08X})", hr as u32))
            }
        }
    }

    pub fn shell_delete_items(targets: &[PathBuf]) -> Result<usize, String> {
        let _com = ComGuard::init_sta();
        unsafe {
            let Some(fop) = create_file_operation(FOF_NOCONFIRMATION | FOF_NOERRORUI) else {
                return Err("無法初始化 Windows 檔案刪除介面".into());
            };
            let del_item: unsafe extern "system" fn(*mut c_void, *mut c_void, *mut c_void) -> i32 =
                std::mem::transmute(vtable_fn(fop, 18));
            let mut queued = 0usize;
            for t in targets {
                let item = create_shell_item_from_path(t);
                if !item.is_null() {
                    if del_item(fop, item, null_mut()) >= 0 {
                        queued += 1;
                    }
                    com_release(item);
                }
            }
            let perform: unsafe extern "system" fn(*mut c_void) -> i32 =
                std::mem::transmute(vtable_fn(fop, 21));
            let hr = if queued > 0 { perform(fop) } else { -1 };
            com_release(fop);
            if hr >= 0 {
                Ok(queued)
            } else {
                Err(format!("MTP 刪除失敗 (HRESULT 0x{:08X})", hr as u32))
            }
        }
    }

    pub fn shell_new_folder(parent_dir: &Path, folder_name: &str) -> Result<(), String> {
        let _com = ComGuard::init_sta();
        unsafe {
            let parent = create_shell_item_from_path(parent_dir);
            if parent.is_null() {
                return Err("無法開啟目標 MTP 資料夾".into());
            }
            let Some(fop) = create_file_operation(FOF_NOCONFIRMATION | FOF_NOERRORUI) else {
                com_release(parent);
                return Err("無法初始化 IFileOperation".into());
            };
            let new_item: unsafe extern "system" fn(
                *mut c_void,
                *mut c_void,
                u32,
                *const u16,
                *const u16,
                *mut c_void,
            ) -> i32 = std::mem::transmute(vtable_fn(fop, 20));
            let name_w = to_wide_z(folder_name);
            let hr1 = new_item(
                fop,
                parent,
                FILE_ATTRIBUTE_DIRECTORY,
                name_w.as_ptr(),
                null(),
                null_mut(),
            );
            let perform: unsafe extern "system" fn(*mut c_void) -> i32 =
                std::mem::transmute(vtable_fn(fop, 21));
            let hr2 = if hr1 >= 0 { perform(fop) } else { hr1 };
            com_release(fop);
            com_release(parent);
            if hr2 >= 0 {
                Ok(())
            } else {
                Err(format!("建立 MTP 資料夾失敗 (HRESULT 0x{:08X})", hr2 as u32))
            }
        }
    }

    pub fn shell_rename_item(item_path: &Path, new_name: &str) -> Result<(), String> {
        let _com = ComGuard::init_sta();
        unsafe {
            let item = create_shell_item_from_path(item_path);
            if item.is_null() {
                return Err("無法開啟目標 MTP 項目".into());
            }
            let Some(fop) = create_file_operation(FOF_NOCONFIRMATION | FOF_NOERRORUI) else {
                com_release(item);
                return Err("無法初始化 IFileOperation".into());
            };
            let rename_item: unsafe extern "system" fn(
                *mut c_void,
                *mut c_void,
                *const u16,
                *mut c_void,
            ) -> i32 = std::mem::transmute(vtable_fn(fop, 12));
            let name_w = to_wide_z(new_name);
            let hr1 = rename_item(fop, item, name_w.as_ptr(), null_mut());
            let perform: unsafe extern "system" fn(*mut c_void) -> i32 =
                std::mem::transmute(vtable_fn(fop, 21));
            let hr2 = if hr1 >= 0 { perform(fop) } else { hr1 };
            com_release(fop);
            com_release(item);
            if hr2 >= 0 {
                Ok(())
            } else {
                Err(format!("MTP 重新命名失敗 (HRESULT 0x{:08X})", hr2 as u32))
            }
        }
    }

    pub fn open_mtp_file(path: &Path) -> Result<(), String> {
        let _com = ComGuard::init_sta();
        let tmp_dir = std::env::temp_dir().join("mine_mtp_open");
        let _ = std::fs::create_dir_all(&tmp_dir);
        let disp_name = unsafe {
            let item = create_shell_item_from_path(path);
            if item.is_null() {
                return Err("無法開啟 MTP 檔案".into());
            }
            let name = shell_item_display_name(item, SIGDN_NORMALDISPLAY);
            com_release(item);
            name.unwrap_or_else(|| "mtp_file".into())
        };
        let target_file = tmp_dir.join(&disp_name);
        let _ = std::fs::remove_file(&target_file);
        shell_transfer_items(&[path.to_path_buf()], &tmp_dir, false)?;
        if target_file.exists() {
            open::that(&target_file).map_err(|e| e.to_string())
        } else {
            Err("無法從行動裝置暫存並開啟檔案".into())
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mtp_path_helpers_and_portable_device_detection() {
        let raw = "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\\\\\?\\usb#vid_18d1&pid_4ee1#abc#{6ac27878-a6fa-4155-ba85-f98f491d4f33}";
        assert!(is_portable_device_parsing_name(raw));
        assert!(!is_portable_device_parsing_name(
            "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}"
        ));

        let mp = make_mtp_path(raw);
        assert!(is_mtp_path(&mp));
        assert_eq!(strip_mtp_prefix(&mp).as_deref(), Some(raw));

        register_mtp_display_name(&mp, "MTP USB Device", None);
        assert_eq!(display_name_for_mtp_path(&mp), "📱 MTP USB Device");
        assert_eq!(display_address_for_path(&mp), "📱 MTP USB Device");

        let sub = make_mtp_path(&format!("{}\\SID-10001", raw));
        register_mtp_display_name(&sub, "內部共用儲存空間", Some(&mp));
        assert_eq!(
            display_address_for_path(&sub),
            "📱 MTP USB Device > 內部共用儲存空間"
        );
    }
}
