use std::path::{Path, PathBuf};

/// Returns `true` if the extension (with or without leading dot, any case) is a video format.
pub fn is_video_ext(ext: &str) -> bool {
    let e = ext.trim_start_matches('.').to_ascii_lowercase();
    matches!(
        e.as_str(),
        "mp4"
            | "m4v"
            | "mov"
            | "mkv"
            | "webm"
            | "avi"
            | "wmv"
            | "flv"
            | "mpg"
            | "mpeg"
            | "3gp"
            | "ts"
            | "mts"
    )
}

/// Returns `true` if the extension (with or without leading dot, any case) is an audio format.
pub fn is_audio_ext(ext: &str) -> bool {
    let e = ext.trim_start_matches('.').to_ascii_lowercase();
    matches!(
        e.as_str(),
        "mp3" | "m4a" | "wav" | "flac" | "aac" | "ogg" | "wma" | "aiff" | "aif" | "opus" | "alac"
    )
}

/// Returns `true` if the extension is either a video or audio format.
pub fn is_media_ext(ext: &str) -> bool {
    is_video_ext(ext) || is_audio_ext(ext)
}

/// Formats seconds into `MM:SS` or `H:MM:SS` for the inline media player HUD.
pub fn format_duration_sec(sec: f64) -> String {
    if !sec.is_finite() || sec <= 0.0 {
        return "00:00".to_string();
    }
    let total = sec.floor() as u64;
    let h = total / 3600;
    let m = (total % 3600) / 60;
    let s = total % 60;
    if h > 0 {
        format!("{}:{:02}:{:02}", h, m, s)
    } else {
        format!("{:02}:{:02}", m, s)
    }
}

// ============================================================================
// Pure-Rust Cross-Platform Embedded Audio Cover Art Extractor
// Supports: ID3v2.2/2.3/2.4 (MP3 / AIFF), MP4/M4A `covr` atom, FLAC `PICTURE`
// Zero external dependencies, reads only metadata headers.
// ============================================================================

fn decode_image_bytes_to_rgba(raw: &[u8], max_dim: u32) -> Option<(usize, usize, Vec<u8>)> {
    if raw.len() < 16 || raw.len() > 24 * 1024 * 1024 {
        return None;
    }
    let mut reader = image::ImageReader::new(std::io::Cursor::new(raw))
        .with_guessed_format()
        .ok()?;
    let mut limits = image::Limits::default();
    limits.max_image_width = Some(8192);
    limits.max_image_height = Some(8192);
    limits.max_alloc = Some(64 * 1024 * 1024);
    reader.limits(limits);
    let img = reader.decode().ok()?;
    let limit = max_dim.max(16);
    let thumb = if img.width() > limit || img.height() > limit {
        img.thumbnail(limit, limit)
    } else {
        img
    };
    let rgba = thumb.to_rgba8();
    let (w, h) = rgba.dimensions();
    if w == 0 || h == 0 {
        return None;
    }
    Some((w as usize, h as usize, rgba.into_raw()))
}

fn find_image_magic_slice(data: &[u8]) -> Option<&[u8]> {
    // JPEG SOI (FF D8 FF), PNG (89 50 4E 47 0D 0A 1A 0A), WEBP (RIFF....WEBP)
    for i in 0..data.len().saturating_sub(8) {
        if data[i] == 0xFF && data[i + 1] == 0xD8 && data[i + 2] == 0xFF {
            return Some(&data[i..]);
        }
        if data[i..].starts_with(&[0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]) {
            return Some(&data[i..]);
        }
        if i + 12 <= data.len() && &data[i..i + 4] == b"RIFF" && &data[i + 8..i + 12] == b"WEBP" {
            return Some(&data[i..]);
        }
    }
    None
}

fn syncsafe_u32(b: &[u8]) -> u32 {
    (((b[0] & 0x7F) as u32) << 21)
        | (((b[1] & 0x7F) as u32) << 14)
        | (((b[2] & 0x7F) as u32) << 7)
        | ((b[3] & 0x7F) as u32)
}

fn parse_id3v2_apic(buf: &[u8]) -> Option<Vec<u8>> {
    if buf.len() < 10 || &buf[0..3] != b"ID3" {
        return None;
    }
    let ver_major = buf[3];
    let flags = buf[5];
    let tag_size = syncsafe_u32(&buf[6..10]) as usize;
    let tag_end = (10 + tag_size).min(buf.len());
    let mut pos = 10usize;

    // Skip extended header if present
    if (flags & 0x40) != 0 && pos + 4 <= tag_end {
        let ext_sz = if ver_major >= 4 {
            syncsafe_u32(&buf[pos..pos + 4]) as usize
        } else {
            u32::from_be_bytes([buf[pos], buf[pos + 1], buf[pos + 2], buf[pos + 3]]) as usize + 4
        };
        pos = pos.saturating_add(ext_sz);
    }

    if ver_major == 2 {
        // ID3v2.2: 3-byte ID + 3-byte big-endian size
        while pos + 6 <= tag_end {
            let fid = &buf[pos..pos + 3];
            if fid[0] == 0 {
                break;
            }
            let fsz = ((buf[pos + 3] as usize) << 16)
                | ((buf[pos + 4] as usize) << 8)
                | (buf[pos + 5] as usize);
            pos += 6;
            if fsz == 0 || pos + fsz > tag_end {
                break;
            }
            if fid == b"PIC" && fsz > 6 {
                let frame = &buf[pos..pos + fsz];
                if let Some(img_slice) = parse_apic_payload(frame, true) {
                    return Some(img_slice.to_vec());
                }
            }
            pos += fsz;
        }
    } else if ver_major == 3 || ver_major == 4 {
        // ID3v2.3 / 2.4: 4-byte ID + 4-byte size + 2-byte flags
        while pos + 10 <= tag_end {
            let fid = &buf[pos..pos + 4];
            if fid[0] == 0 {
                break;
            }
            let raw_sz =
                u32::from_be_bytes([buf[pos + 4], buf[pos + 5], buf[pos + 6], buf[pos + 7]])
                    as usize;
            let fsz = if ver_major == 4 {
                let ss = syncsafe_u32(&buf[pos + 4..pos + 8]) as usize;
                // Some encoders erroneously write non-syncsafe sizes in v2.4
                if pos + 10 + ss <= tag_end {
                    ss
                } else {
                    raw_sz
                }
            } else {
                raw_sz
            };
            let frame_flags = u16::from_be_bytes([buf[pos + 8], buf[pos + 9]]);
            pos += 10;
            if fsz == 0 || pos + fsz > tag_end {
                break;
            }
            if fid == b"APIC" && fsz > 16 {
                let mut frame = &buf[pos..pos + fsz];
                // Skip ID3v2.4 Data Length Indicator (4 bytes) if flag bit 0x0001 is set
                if ver_major == 4 && (frame_flags & 0x0001) != 0 && frame.len() > 4 {
                    frame = &frame[4..];
                }
                let unsync = (flags & 0x80) != 0 || (ver_major == 4 && (frame_flags & 0x0002) != 0);
                let owned;
                let payload = if unsync {
                    owned = deunsync_id3(frame);
                    owned.as_slice()
                } else {
                    frame
                };
                if let Some(img_slice) = parse_apic_payload(payload, false) {
                    return Some(img_slice.to_vec());
                }
            }
            pos += fsz;
        }
    }
    None
}

fn deunsync_id3(src: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(src.len());
    let mut i = 0;
    while i < src.len() {
        out.push(src[i]);
        if src[i] == 0xFF && i + 1 < src.len() && src[i + 1] == 0x00 {
            i += 2;
        } else {
            i += 1;
        }
    }
    out
}

fn parse_apic_payload(frame: &[u8], is_v22_pic: bool) -> Option<&[u8]> {
    if frame.len() < 8 {
        return None;
    }
    let encoding = frame[0];
    let mut i = 1usize;
    if is_v22_pic {
        // 3-byte image format (e.g. "JPG", "PNG")
        i += 3;
    } else {
        // Null-terminated MIME string
        while i < frame.len() && frame[i] != 0 {
            i += 1;
        }
        i += 1; // skip NUL
    }
    if i >= frame.len() {
        return find_image_magic_slice(frame);
    }
    // Skip 1-byte picture type
    i += 1;
    if i >= frame.len() {
        return find_image_magic_slice(frame);
    }
    // Skip null-terminated description
    if encoding == 1 || encoding == 2 {
        while i + 1 < frame.len() {
            if frame[i] == 0 && frame[i + 1] == 0 {
                i += 2;
                break;
            }
            i += 2;
        }
    } else {
        while i < frame.len() && frame[i] != 0 {
            i += 1;
        }
        if i < frame.len() {
            i += 1;
        }
    }
    if i < frame.len() {
        let rest = &frame[i..];
        if rest.len() >= 16 {
            return Some(rest);
        }
    }
    find_image_magic_slice(frame)
}

fn parse_flac_picture(file: &mut std::fs::File) -> Option<Vec<u8>> {
    use std::io::{Read, Seek, SeekFrom};
    file.seek(SeekFrom::Start(0)).ok()?;
    let mut magic = [0u8; 4];
    file.read_exact(&mut magic).ok()?;
    if &magic != b"fLaC" {
        return None;
    }
    for _ in 0..64 {
        let mut hdr = [0u8; 4];
        if file.read_exact(&mut hdr).is_err() {
            break;
        }
        let is_last = (hdr[0] & 0x80) != 0;
        let block_type = hdr[0] & 0x7F;
        let len = ((hdr[1] as usize) << 16) | ((hdr[2] as usize) << 8) | (hdr[3] as usize);
        if block_type == 6 && len > 32 && len <= 16 * 1024 * 1024 {
            let mut block = vec![0u8; len];
            file.read_exact(&mut block).ok()?;
            let mut p = 4usize; // picture type
            if p + 4 > block.len() {
                return None;
            }
            let mime_len = u32::from_be_bytes([block[p], block[p + 1], block[p + 2], block[p + 3]])
                as usize;
            p = p.checked_add(4)?.checked_add(mime_len)?;
            if p + 4 > block.len() {
                return None;
            }
            let desc_len = u32::from_be_bytes([block[p], block[p + 1], block[p + 2], block[p + 3]])
                as usize;
            p = p.checked_add(4)?.checked_add(desc_len)?.checked_add(16)?;
            if p + 4 > block.len() {
                return None;
            }
            let data_len = u32::from_be_bytes([block[p], block[p + 1], block[p + 2], block[p + 3]])
                as usize;
            p += 4;
            if data_len >= 16 && p + data_len <= block.len() {
                return Some(block[p..p + data_len].to_vec());
            }
        } else {
            file.seek(SeekFrom::Current(len as i64)).ok()?;
        }
        if is_last {
            break;
        }
    }
    None
}

fn find_mp4_covr_in_range(
    file: &mut std::fs::File,
    mut pos: u64,
    end: u64,
    depth: u8,
) -> Option<Vec<u8>> {
    use std::io::{Read, Seek, SeekFrom};
    if depth > 8 {
        return None;
    }
    let mut steps = 0usize;
    while pos + 8 <= end && steps < 512 {
        steps += 1;
        file.seek(SeekFrom::Start(pos)).ok()?;
        let mut hdr = [0u8; 8];
        if file.read_exact(&mut hdr).is_err() {
            break;
        }
        let sz32 = u32::from_be_bytes([hdr[0], hdr[1], hdr[2], hdr[3]]) as u64;
        let kind = [hdr[4], hdr[5], hdr[6], hdr[7]];
        let (box_size, header_len) = if sz32 == 1 {
            let mut ext = [0u8; 8];
            if file.read_exact(&mut ext).is_err() {
                break;
            }
            (u64::from_be_bytes(ext), 16u64)
        } else if sz32 == 0 {
            (end.saturating_sub(pos), 8u64)
        } else {
            (sz32, 8u64)
        };
        if box_size < header_len || pos.saturating_add(box_size) > end {
            break;
        }
        let child_start = pos + header_len;
        let child_end = pos + box_size;

        match &kind {
            b"moov" | b"udta" | b"ilst" | b"covr" => {
                if let Some(found) = find_mp4_covr_in_range(file, child_start, child_end, depth + 1)
                {
                    return Some(found);
                }
            }
            b"meta" => {
                // `meta` is a FullBox (4-byte version+flags) before child atoms
                if child_start + 4 <= child_end {
                    if let Some(found) =
                        find_mp4_covr_in_range(file, child_start + 4, child_end, depth + 1)
                    {
                        return Some(found);
                    }
                }
            }
            b"data" if depth >= 4 => {
                // iTunes `data` atom: 4-byte type + 4-byte locale + raw image payload
                if child_start + 8 < child_end {
                    let payload_len = (child_end - (child_start + 8)) as usize;
                    if payload_len >= 16 && payload_len <= 16 * 1024 * 1024 {
                        file.seek(SeekFrom::Start(child_start + 8)).ok()?;
                        let mut data = vec![0u8; payload_len];
                        if file.read_exact(&mut data).is_ok() {
                            return Some(data);
                        }
                    }
                }
            }
            _ => {}
        }
        pos = child_end;
    }
    None
}

/// Extracts embedded album cover art from MP3 (ID3v2), M4A/MP4 (`covr`), or FLAC (`PICTURE`).
pub fn extract_audio_cover_rgba(path: &Path, max_dim: u32) -> Option<(usize, usize, Vec<u8>)> {
    use std::io::Read;
    let mut file = std::fs::File::open(path).ok()?;
    let file_len = file.metadata().ok()?.len();
    if file_len < 16 {
        return None;
    }

    let mut head = [0u8; 12];
    let n = file.read(&mut head).ok()?;
    if n < 10 {
        return None;
    }

    // 1. ID3v2 header (MP3, some WAV/AIFF/FLAC)
    if &head[0..3] == b"ID3" {
        let tag_sz = syncsafe_u32(&head[6..10]) as usize;
        let read_len = (10 + tag_sz).min(12 * 1024 * 1024).min(file_len as usize);
        let mut buf = vec![0u8; read_len];
        buf[..n].copy_from_slice(&head[..n]);
        if read_len > n {
            let _ = file.read_exact(&mut buf[n..]);
        }
        if let Some(raw_img) = parse_id3v2_apic(&buf) {
            if let Some(rgba) = decode_image_bytes_to_rgba(&raw_img, max_dim) {
                return Some(rgba);
            }
        }
    }

    // 2. FLAC native metadata blocks
    if &head[0..4] == b"fLaC" {
        if let Some(raw_img) = parse_flac_picture(&mut file) {
            if let Some(rgba) = decode_image_bytes_to_rgba(&raw_img, max_dim) {
                return Some(rgba);
            }
        }
    }

    // 3. ISO Base Media / MP4 / M4A (`ftyp` at offset 4)
    if n >= 8 && &head[4..8] == b"ftyp" {
        if let Some(raw_img) = find_mp4_covr_in_range(&mut file, 0, file_len, 0) {
            if let Some(rgba) = decode_image_bytes_to_rgba(&raw_img, max_dim) {
                return Some(rgba);
            }
        }
    }

    None
}

// ============================================================================
// Cross-Platform Media Thumbnail Extraction (Video frames + Audio cover art)
// ============================================================================

/// Extracts a thumbnail RGBA image for a video or audio file.
/// - Audio: pure-Rust embedded cover art (ID3v2 / M4A / FLAC), with Windows Shell fallback.
/// - Video: OS-native hardware decoder (macOS `AVAssetImageGenerator`, Windows Shell/Media Foundation).
pub fn extract_media_thumbnail_rgba(path: &Path, max_dim: u32) -> Option<(usize, usize, Vec<u8>)> {
    let ext = path
        .extension()
        .map(|e| e.to_string_lossy().to_ascii_lowercase())
        .unwrap_or_default();

    if is_audio_ext(&ext) {
        if let Some(cover) = extract_audio_cover_rgba(path, max_dim) {
            return Some(cover);
        }
        #[cfg(target_os = "windows")]
        {
            if let Some(shell_thumb) = win_media::extract_shell_thumbnail_rgba(path, max_dim) {
                return Some(shell_thumb);
            }
        }
        return None;
    }

    if is_video_ext(&ext) {
        #[cfg(target_os = "macos")]
        {
            if let Some(t) = macos_media::extract_video_thumbnail_rgba(path, max_dim) {
                return Some(t);
            }
        }
        #[cfg(target_os = "windows")]
        {
            if let Some(t) = win_media::extract_video_thumbnail_rgba(path, max_dim) {
                return Some(t);
            }
        }
        #[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
        {
            if let Some(t) = linux_extract_video_thumbnail_rgba(path, max_dim) {
                return Some(t);
            }
        }
    }

    None
}

#[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
fn linux_extract_video_thumbnail_rgba(path: &Path, max_dim: u32) -> Option<(usize, usize, Vec<u8>)> {
    let out = std::process::Command::new("ffmpeg")
        .args([
            "-v",
            "error",
            "-ss",
            "1",
            "-i",
            &path.to_string_lossy(),
            "-frames:v",
            "1",
            "-vf",
            &format!("scale='min({},iw)':-1", max_dim.max(64)),
            "-f",
            "image2pipe",
            "-vcodec",
            "png",
            "-",
        ])
        .output()
        .ok()?;
    if out.status.success() && !out.stdout.is_empty() {
        decode_image_bytes_to_rgba(&out.stdout, max_dim)
    } else {
        None
    }
}

// ============================================================================
// Cross-Platform Inline Media Player (Preview Pane)
// ============================================================================

#[derive(Clone, Debug, Default)]
pub struct MediaState {
    pub pos_sec: f64,
    pub dur_sec: f64,
    pub is_playing: bool,
    pub has_video: bool,
    pub is_ready: bool,
    pub error: Option<String>,
}

pub struct MediaPlayer {
    path: PathBuf,
    #[cfg(target_os = "macos")]
    inner: macos_media::MacPlayer,
    #[cfg(target_os = "windows")]
    inner: win_media::WinPlayer,
    #[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
    inner: StubPlayer,
}

impl MediaPlayer {
    pub fn open(path: PathBuf, volume: f32, muted: bool, ctx: egui::Context) -> Self {
        #[cfg(target_os = "macos")]
        let inner = {
            let _ = ctx;
            macos_media::MacPlayer::open(&path, volume, muted)
        };
        #[cfg(target_os = "windows")]
        let inner = win_media::WinPlayer::open(path.clone(), volume, muted, ctx);
        #[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
        let inner = {
            let _ = (volume, muted, ctx);
            StubPlayer
        };
        Self { path, inner }
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn play(&mut self) {
        self.inner.play();
    }

    pub fn pause(&mut self) {
        self.inner.pause();
    }

    pub fn toggle_play(&mut self, currently_playing: bool) {
        if currently_playing {
            self.pause();
        } else {
            self.play();
        }
    }

    pub fn seek(&mut self, sec: f64) {
        self.inner.seek(sec.max(0.0));
    }

    pub fn set_volume(&mut self, vol: f32, muted: bool) {
        self.inner.set_volume(vol.clamp(0.0, 1.0), muted);
    }

    pub fn poll_state_and_frame(&mut self) -> (MediaState, Option<(usize, usize, Vec<u8>)>) {
        self.inner.poll_state_and_frame()
    }
}

#[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
struct StubPlayer;

#[cfg(all(not(target_os = "macos"), not(target_os = "windows")))]
impl StubPlayer {
    fn play(&mut self) {}
    fn pause(&mut self) {}
    fn seek(&mut self, _sec: f64) {}
    fn set_volume(&mut self, _vol: f32, _muted: bool) {}
    fn poll_state_and_frame(&mut self) -> (MediaState, Option<(usize, usize, Vec<u8>)>) {
        (
            MediaState {
                error: Some("Inline playback is supported on macOS & Windows. Use External Player.".into()),
                ..Default::default()
            },
            None,
        )
    }
}

// ============================================================================
// macOS Backend (AVFoundation hardware-accelerated FFI via src/macos_media.m)
// ============================================================================

#[cfg(target_os = "macos")]
mod macos_media {
    use super::MediaState;
    use std::ffi::{c_char, c_double, c_float, c_int, c_void, CString};
    use std::path::Path;
    use std::ptr::null_mut;

    extern "C" {
        fn mine_av_free_buffer(ptr: *mut u8);
        fn mine_av_extract_thumbnail(
            path_utf8: *const c_char,
            max_dim: c_int,
            out_rgba: *mut *mut u8,
            out_w: *mut c_int,
            out_h: *mut c_int,
        ) -> c_int;
        fn mine_av_create(path_utf8: *const c_char, volume: c_float, muted: c_int) -> *mut c_void;
        fn mine_av_destroy(handle: *mut c_void);
        fn mine_av_play(handle: *mut c_void);
        fn mine_av_pause(handle: *mut c_void);
        fn mine_av_seek(handle: *mut c_void, sec: c_double);
        fn mine_av_set_volume(handle: *mut c_void, vol: c_float, muted: c_int);
        fn mine_av_get_state(
            handle: *mut c_void,
            out_pos: *mut c_double,
            out_dur: *mut c_double,
            out_playing: *mut c_int,
            out_has_video: *mut c_int,
            out_ready: *mut c_int,
            out_error: *mut c_int,
        );
        fn mine_av_copy_frame_rgba(
            handle: *mut c_void,
            max_width: c_int,
            out_rgba: *mut *mut u8,
            out_w: *mut c_int,
            out_h: *mut c_int,
        ) -> c_int;
    }

    pub fn extract_video_thumbnail_rgba(
        path: &Path,
        max_dim: u32,
    ) -> Option<(usize, usize, Vec<u8>)> {
        let c_path = CString::new(path.to_string_lossy().as_bytes()).ok()?;
        let mut ptr: *mut u8 = null_mut();
        let mut w: c_int = 0;
        let mut h: c_int = 0;
        let ok = unsafe {
            mine_av_extract_thumbnail(
                c_path.as_ptr(),
                max_dim.clamp(32, 1024) as c_int,
                &mut ptr,
                &mut w,
                &mut h,
            )
        };
        if ok != 0 && !ptr.is_null() && w > 0 && h > 0 {
            let len = (w as usize).saturating_mul(h as usize).saturating_mul(4);
            let vec = unsafe { std::slice::from_raw_parts(ptr, len).to_vec() };
            unsafe { mine_av_free_buffer(ptr) };
            Some((w as usize, h as usize, vec))
        } else {
            if !ptr.is_null() {
                unsafe { mine_av_free_buffer(ptr) };
            }
            None
        }
    }

    pub struct MacPlayer {
        handle: *mut c_void,
    }

    impl MacPlayer {
        pub fn open(path: &Path, volume: f32, muted: bool) -> Self {
            let handle = CString::new(path.to_string_lossy().as_bytes())
                .ok()
                .map(|c_path| unsafe {
                    mine_av_create(c_path.as_ptr(), volume.clamp(0.0, 1.0), i32::from(muted))
                })
                .unwrap_or(null_mut());
            Self { handle }
        }

        pub fn play(&mut self) {
            if !self.handle.is_null() {
                unsafe { mine_av_play(self.handle) };
            }
        }

        pub fn pause(&mut self) {
            if !self.handle.is_null() {
                unsafe { mine_av_pause(self.handle) };
            }
        }

        pub fn seek(&mut self, sec: f64) {
            if !self.handle.is_null() {
                unsafe { mine_av_seek(self.handle, sec) };
            }
        }

        pub fn set_volume(&mut self, vol: f32, muted: bool) {
            if !self.handle.is_null() {
                unsafe { mine_av_set_volume(self.handle, vol, i32::from(muted)) };
            }
        }

        pub fn poll_state_and_frame(&mut self) -> (MediaState, Option<(usize, usize, Vec<u8>)>) {
            if self.handle.is_null() {
                return (
                    MediaState {
                        error: Some("AVFoundation failed to open file".into()),
                        ..Default::default()
                    },
                    None,
                );
            }
            let mut pos: c_double = 0.0;
            let mut dur: c_double = 0.0;
            let mut playing: c_int = 0;
            let mut has_video: c_int = 0;
            let mut ready: c_int = 0;
            let mut err: c_int = 0;
            unsafe {
                mine_av_get_state(
                    self.handle,
                    &mut pos,
                    &mut dur,
                    &mut playing,
                    &mut has_video,
                    &mut ready,
                    &mut err,
                );
            }
            let state = MediaState {
                pos_sec: pos.max(0.0),
                dur_sec: dur.max(0.0),
                is_playing: playing != 0,
                has_video: has_video != 0,
                is_ready: ready != 0,
                error: if err != 0 {
                    Some("Unsupported codec or unreadable media (use System Player)".into())
                } else {
                    None
                },
            };

            let mut frame = None;
            if has_video != 0 && err == 0 {
                let mut ptr: *mut u8 = null_mut();
                let mut w: c_int = 0;
                let mut h: c_int = 0;
                let got = unsafe {
                    mine_av_copy_frame_rgba(self.handle, 960, &mut ptr, &mut w, &mut h)
                };
                if got != 0 && !ptr.is_null() && w > 0 && h > 0 {
                    let len = (w as usize).saturating_mul(h as usize).saturating_mul(4);
                    let vec = unsafe { std::slice::from_raw_parts(ptr, len).to_vec() };
                    unsafe { mine_av_free_buffer(ptr) };
                    frame = Some((w as usize, h as usize, vec));
                } else if !ptr.is_null() {
                    unsafe { mine_av_free_buffer(ptr) };
                }
            }
            (state, frame)
        }
    }

    impl Drop for MacPlayer {
        fn drop(&mut self) {
            if !self.handle.is_null() {
                unsafe { mine_av_destroy(self.handle) };
                self.handle = null_mut();
            }
        }
    }
}

// ============================================================================
// Windows Backend (100% Dynamic DLL Loading: Shell Thumbnails + Media Foundation + waveOut)
// Zero extra crates, zero static link issues, zero bloat!
// ============================================================================

#[cfg(target_os = "windows")]
mod win_media {
    use super::MediaState;
    use std::collections::VecDeque;
    use std::ffi::{c_void, OsStr};
    use std::os::windows::ffi::OsStrExt;
    use std::path::{Path, PathBuf};
    use std::ptr::{null, null_mut};
    use std::sync::atomic::{AtomicBool, Ordering};
    use std::sync::{mpsc, Arc, Mutex};
    use std::time::{Duration, Instant};

    #[repr(C)]
    #[derive(Clone, Copy, PartialEq, Eq)]
    struct Guid {
        data1: u32,
        data2: u16,
        data3: u16,
        data4: [u8; 8],
    }

    const GUID_NULL: Guid = Guid {
        data1: 0,
        data2: 0,
        data3: 0,
        data4: [0; 8],
    };

    const IID_ISHELL_ITEM_IMAGE_FACTORY: Guid = Guid {
        data1: 0xbcc18b79,
        data2: 0xba16,
        data3: 0x442f,
        data4: [0x80, 0xc4, 0x8a, 0x59, 0xc3, 0x0c, 0x46, 0x3b],
    };

    const MF_SOURCE_READER_ENABLE_VIDEO_PROCESSING: Guid = Guid {
        data1: 0xfb394f3d,
        data2: 0xccf1,
        data3: 0x42ee,
        data4: [0xbb, 0xb3, 0xf9, 0xb8, 0x45, 0xd5, 0x68, 0x1d],
    };
    const MF_MT_MAJOR_TYPE: Guid = Guid {
        data1: 0x48eba18e,
        data2: 0xf8c9,
        data3: 0x4687,
        data4: [0xbf, 0x11, 0x0a, 0x74, 0xc9, 0xf9, 0x6a, 0x8f],
    };
    const MF_MT_SUBTYPE: Guid = Guid {
        data1: 0xf7e34c9a,
        data2: 0x42e8,
        data3: 0x4714,
        data4: [0xb7, 0x4b, 0xcb, 0x29, 0xd7, 0x2c, 0x35, 0xe5],
    };
    const MF_MT_FRAME_SIZE: Guid = Guid {
        data1: 0x1652c33d,
        data2: 0xd6b2,
        data3: 0x4012,
        data4: [0xb8, 0x34, 0x72, 0x03, 0x08, 0x49, 0xa3, 0x7d],
    };
    const MF_MT_DEFAULT_STRIDE: Guid = Guid {
        data1: 0x644b4e48,
        data2: 0x1e02,
        data3: 0x4516,
        data4: [0xb0, 0xeb, 0xc0, 0x1c, 0xa9, 0xd4, 0x9a, 0xc6],
    };
    const MF_MT_AUDIO_NUM_CHANNELS: Guid = Guid {
        data1: 0x37e48bf5,
        data2: 0x645e,
        data3: 0x4c5b,
        data4: [0x89, 0xde, 0xad, 0xa9, 0xe2, 0x9b, 0x69, 0x6a],
    };
    const MF_MT_AUDIO_SAMPLES_PER_SECOND: Guid = Guid {
        data1: 0x5faeeae7,
        data2: 0x0290,
        data3: 0x4c31,
        data4: [0x9e, 0x8a, 0xc5, 0x34, 0xf6, 0x8d, 0x9d, 0xba],
    };
    const MF_MT_AUDIO_BITS_PER_SAMPLE: Guid = Guid {
        data1: 0xf2deb57f,
        data2: 0x40fa,
        data3: 0x4764,
        data4: [0xaa, 0x33, 0xed, 0x4f, 0x2d, 0x1f, 0xf6, 0x69],
    };
    const MF_PD_DURATION: Guid = Guid {
        data1: 0x6c990d33,
        data2: 0xbb8e,
        data3: 0x477a,
        data4: [0x85, 0x98, 0x0d, 0x5d, 0x96, 0xfc, 0xd8, 0x8a],
    };
    const MF_MEDIA_TYPE_VIDEO: Guid = Guid {
        data1: 0x73646976,
        data2: 0x0000,
        data3: 0x0010,
        data4: [0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71],
    };
    const MF_MEDIA_TYPE_AUDIO: Guid = Guid {
        data1: 0x73647561,
        data2: 0x0000,
        data3: 0x0010,
        data4: [0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71],
    };
    const MF_VIDEO_FORMAT_RGB32: Guid = Guid {
        data1: 0x00000016,
        data2: 0x0000,
        data3: 0x0010,
        data4: [0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71],
    };
    const MF_AUDIO_FORMAT_PCM: Guid = Guid {
        data1: 0x00000001,
        data2: 0x0000,
        data3: 0x0010,
        data4: [0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71],
    };

    const MF_VERSION: u32 = 0x0002_0070;
    const MFSTARTUP_LITE: u32 = 1;
    const COINIT_MULTITHREADED: u32 = 0x0;
    const COINIT_APARTMENTTHREADED: u32 = 0x2;

    const MF_SOURCE_READER_ALL_STREAMS: u32 = 0xFFFFFFFE;
    const MF_SOURCE_READER_ANY_STREAM: u32 = 0xFFFFFFFE;
    const MF_SOURCE_READER_FIRST_AUDIO_STREAM: u32 = 0xFFFFFFFD;
    const MF_SOURCE_READER_FIRST_VIDEO_STREAM: u32 = 0xFFFFFFFC;
    const MF_SOURCE_READER_MEDIASOURCE: u32 = 0xFFFFFFFF;
    const MF_SOURCE_READERF_ENDOFSTREAM: u32 = 0x0000_0002;
    const MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED: u32 = 0x0000_0020;

    const VT_I8: u16 = 20;
    const VT_UI8: u16 = 21;

    const WAVE_MAPPER: u32 = 0xFFFF_FFFF;
    const WAVE_FORMAT_PCM: u16 = 1;
    const WHDR_DONE: u32 = 0x0000_0001;
    const SIIGBF_BIGGERSIZEOK: u32 = 0x01;
    const SIIGBF_THUMBNAILONLY: u32 = 0x08;

    #[repr(C)]
    #[derive(Clone, Copy, Default)]
    struct PropVariant {
        vt: u16,
        r1: u16,
        r2: u16,
        r3: u16,
        val: i64,
        pad: u64,
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct SizeWin {
        cx: i32,
        cy: i32,
    }

    #[repr(C)]
    #[derive(Clone, Copy, Default)]
    struct BitmapInfoHeader {
        bi_size: u32,
        bi_width: i32,
        bi_height: i32,
        bi_planes: u16,
        bi_bit_count: u16,
        bi_compression: u32,
        bi_size_image: u32,
        bi_x_pels_per_meter: i32,
        bi_y_pels_per_meter: i32,
        bi_clr_used: u32,
        bi_clr_important: u32,
    }

    #[repr(C)]
    #[derive(Clone, Copy, Default)]
    struct BitmapWin {
        bm_type: i32,
        bm_width: i32,
        bm_height: i32,
        bm_width_bytes: i32,
        bm_planes: u16,
        bm_bits_pixel: u16,
        bm_bits: *mut c_void,
    }

    #[repr(C, packed(1))]
    #[derive(Clone, Copy, Default)]
    struct WaveFormatEx {
        w_format_tag: u16,
        n_channels: u16,
        n_samples_per_sec: u32,
        n_avg_bytes_per_sec: u32,
        n_block_align: u16,
        w_bits_per_sample: u16,
        cb_size: u16,
    }

    #[repr(C, packed(1))]
    #[derive(Clone, Copy)]
    struct WaveHdr {
        lp_data: *mut u8,
        dw_buffer_length: u32,
        dw_bytes_recorded: u32,
        dw_user: usize,
        dw_flags: u32,
        dw_loops: u32,
        lp_next: *mut WaveHdr,
        reserved: usize,
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn LoadLibraryW(lp_lib_file_name: *const u16) -> *mut c_void;
        fn GetProcAddress(h_module: *mut c_void, lp_proc_name: *const u8) -> *mut c_void;
    }

    #[link(name = "ole32")]
    extern "system" {
        fn CoInitializeEx(pv_reserved: *mut c_void, dw_coinit: u32) -> i32;
        fn CoUninitialize();
    }

    #[link(name = "gdi32")]
    extern "system" {
        fn GetObjectW(h: *mut c_void, c: i32, pv: *mut c_void) -> i32;
        fn CreateCompatibleDC(hdc: *mut c_void) -> *mut c_void;
        fn DeleteDC(hdc: *mut c_void) -> i32;
        fn DeleteObject(ho: *mut c_void) -> i32;
        fn GetDIBits(
            hdc: *mut c_void,
            hbm: *mut c_void,
            start: u32,
            c_lines: u32,
            lpv_bits: *mut c_void,
            lpbmi: *mut BitmapInfoHeader,
            usage: u32,
        ) -> i32;
    }

    fn to_wide_z(s: &str) -> Vec<u16> {
        OsStr::new(s)
            .encode_wide()
            .chain(std::iter::once(0))
            .collect()
    }

    fn path_to_wide_z(p: &Path) -> Vec<u16> {
        p.as_os_str()
            .encode_wide()
            .chain(std::iter::once(0))
            .collect()
    }

    unsafe fn com_vtable_fn(obj: *mut c_void, slot: usize) -> *mut c_void {
        let vtbl = *(obj as *const *const *mut c_void);
        *vtbl.add(slot)
    }

    unsafe fn com_release(obj: *mut c_void) {
        if !obj.is_null() {
            let f: unsafe extern "system" fn(*mut c_void) -> u32 =
                std::mem::transmute(com_vtable_fn(obj, 2));
            let _ = f(obj);
        }
    }

    // ---- Shell Thumbnail via SHCreateItemFromParsingName + IShellItemImageFactory ----

    pub fn extract_shell_thumbnail_rgba(
        path: &Path,
        max_dim: u32,
    ) -> Option<(usize, usize, Vec<u8>)> {
        unsafe {
            let h_shell = LoadLibraryW(to_wide_z("shell32.dll").as_ptr());
            if h_shell.is_null() {
                return None;
            }
            let proc = GetProcAddress(h_shell, b"SHCreateItemFromParsingName\0".as_ptr());
            if proc.is_null() {
                return None;
            }
            let sh_create: unsafe extern "system" fn(
                *const u16,
                *mut c_void,
                *const Guid,
                *mut *mut c_void,
            ) -> i32 = std::mem::transmute(proc);

            let hr_co = CoInitializeEx(null_mut(), COINIT_APARTMENTTHREADED);
            let did_co_init = hr_co >= 0;

            let wide = path_to_wide_z(path);
            let mut factory: *mut c_void = null_mut();
            let hr = sh_create(
                wide.as_ptr(),
                null_mut(),
                &IID_ISHELL_ITEM_IMAGE_FACTORY,
                &mut factory,
            );
            let mut result = None;
            if hr >= 0 && !factory.is_null() {
                let get_image: unsafe extern "system" fn(
                    *mut c_void,
                    SizeWin,
                    u32,
                    *mut *mut c_void,
                ) -> i32 = std::mem::transmute(com_vtable_fn(factory, 3));
                let dim = max_dim.clamp(48, 512) as i32;
                let mut hbm: *mut c_void = null_mut();
                let hr_img = get_image(
                    factory,
                    SizeWin { cx: dim, cy: dim },
                    SIIGBF_THUMBNAILONLY | SIIGBF_BIGGERSIZEOK,
                    &mut hbm,
                );
                if hr_img >= 0 && !hbm.is_null() {
                    result = hbitmap_to_rgba(hbm, max_dim);
                    DeleteObject(hbm);
                }
                com_release(factory);
            }
            if did_co_init {
                CoUninitialize();
            }
            result
        }
    }

    unsafe fn hbitmap_to_rgba(hbm: *mut c_void, max_dim: u32) -> Option<(usize, usize, Vec<u8>)> {
        let mut bm = BitmapWin::default();
        if GetObjectW(
            hbm,
            std::mem::size_of::<BitmapWin>() as i32,
            &mut bm as *mut BitmapWin as *mut c_void,
        ) == 0
        {
            return None;
        }
        let w = bm.bm_width.unsigned_abs() as usize;
        let h = bm.bm_height.unsigned_abs() as usize;
        if w == 0 || h == 0 || w > 4096 || h > 4096 {
            return None;
        }

        let hdc = CreateCompatibleDC(null_mut());
        if hdc.is_null() {
            return None;
        }
        let mut bih = BitmapInfoHeader {
            bi_size: std::mem::size_of::<BitmapInfoHeader>() as u32,
            bi_width: w as i32,
            bi_height: -(h as i32), // top-down DIB
            bi_planes: 1,
            bi_bit_count: 32,
            bi_compression: 0, // BI_RGB
            ..Default::default()
        };
        let mut bgra = vec![0u8; w * h * 4];
        let lines = GetDIBits(
            hdc,
            hbm,
            0,
            h as u32,
            bgra.as_mut_ptr() as *mut c_void,
            &mut bih,
            0,
        );
        DeleteDC(hdc);
        if lines == 0 {
            return None;
        }
        // Convert BGRA -> RGBA (force opaque alpha because video shell HBITMAPs often have alpha=0)
        for px in bgra.chunks_exact_mut(4) {
            px.swap(0, 2);
            px[3] = 255;
        }
        Some(downscale_rgba_if_needed(w, h, bgra, max_dim as usize))
    }

    // ---- Dynamic Media Foundation + winmm Loaders ----

    #[derive(Clone, Copy)]
    struct MfApi {
        mf_startup: unsafe extern "system" fn(u32, u32) -> i32,
        mf_shutdown: unsafe extern "system" fn() -> i32,
        mf_create_attributes: unsafe extern "system" fn(*mut *mut c_void, u32) -> i32,
        mf_create_media_type: unsafe extern "system" fn(*mut *mut c_void) -> i32,
        mf_create_source_reader:
            unsafe extern "system" fn(*const u16, *mut c_void, *mut *mut c_void) -> i32,
    }

    impl MfApi {
        unsafe fn load() -> Option<Self> {
            let h_plat = LoadLibraryW(to_wide_z("mfplat.dll").as_ptr());
            let h_rw = LoadLibraryW(to_wide_z("mfreadwrite.dll").as_ptr());
            if h_plat.is_null() || h_rw.is_null() {
                return None;
            }
            let p_start = GetProcAddress(h_plat, b"MFStartup\0".as_ptr());
            let p_shut = GetProcAddress(h_plat, b"MFShutdown\0".as_ptr());
            let p_attr = GetProcAddress(h_plat, b"MFCreateAttributes\0".as_ptr());
            let p_mt = GetProcAddress(h_plat, b"MFCreateMediaType\0".as_ptr());
            let p_sr = GetProcAddress(h_rw, b"MFCreateSourceReaderFromURL\0".as_ptr());
            if p_start.is_null()
                || p_shut.is_null()
                || p_attr.is_null()
                || p_mt.is_null()
                || p_sr.is_null()
            {
                return None;
            }
            Some(Self {
                mf_startup: std::mem::transmute(p_start),
                mf_shutdown: std::mem::transmute(p_shut),
                mf_create_attributes: std::mem::transmute(p_attr),
                mf_create_media_type: std::mem::transmute(p_mt),
                mf_create_source_reader: std::mem::transmute(p_sr),
            })
        }
    }

    #[derive(Clone, Copy)]
    struct WaveOutApi {
        open: unsafe extern "system" fn(
            *mut *mut c_void,
            u32,
            *const WaveFormatEx,
            usize,
            usize,
            u32,
        ) -> u32,
        prepare: unsafe extern "system" fn(*mut c_void, *mut WaveHdr, u32) -> u32,
        unprepare: unsafe extern "system" fn(*mut c_void, *mut WaveHdr, u32) -> u32,
        write: unsafe extern "system" fn(*mut c_void, *mut WaveHdr, u32) -> u32,
        pause: unsafe extern "system" fn(*mut c_void) -> u32,
        restart: unsafe extern "system" fn(*mut c_void) -> u32,
        reset: unsafe extern "system" fn(*mut c_void) -> u32,
        close: unsafe extern "system" fn(*mut c_void) -> u32,
        set_volume: unsafe extern "system" fn(*mut c_void, u32) -> u32,
    }

    impl WaveOutApi {
        unsafe fn load() -> Option<Self> {
            let h = LoadLibraryW(to_wide_z("winmm.dll").as_ptr());
            if h.is_null() {
                return None;
            }
            let p_open = GetProcAddress(h, b"waveOutOpen\0".as_ptr());
            let p_prep = GetProcAddress(h, b"waveOutPrepareHeader\0".as_ptr());
            let p_unprep = GetProcAddress(h, b"waveOutUnprepareHeader\0".as_ptr());
            let p_write = GetProcAddress(h, b"waveOutWrite\0".as_ptr());
            let p_pause = GetProcAddress(h, b"waveOutPause\0".as_ptr());
            let p_restart = GetProcAddress(h, b"waveOutRestart\0".as_ptr());
            let p_reset = GetProcAddress(h, b"waveOutReset\0".as_ptr());
            let p_close = GetProcAddress(h, b"waveOutClose\0".as_ptr());
            let p_vol = GetProcAddress(h, b"waveOutSetVolume\0".as_ptr());
            if p_open.is_null()
                || p_prep.is_null()
                || p_unprep.is_null()
                || p_write.is_null()
                || p_pause.is_null()
                || p_restart.is_null()
                || p_reset.is_null()
                || p_close.is_null()
                || p_vol.is_null()
            {
                return None;
            }
            Some(Self {
                open: std::mem::transmute(p_open),
                prepare: std::mem::transmute(p_prep),
                unprepare: std::mem::transmute(p_unprep),
                write: std::mem::transmute(p_write),
                pause: std::mem::transmute(p_pause),
                restart: std::mem::transmute(p_restart),
                reset: std::mem::transmute(p_reset),
                close: std::mem::transmute(p_close),
                set_volume: std::mem::transmute(p_vol),
            })
        }
    }

    // Verified IMFAttributes / IMFSourceReader / IMFSample / IMFMediaBuffer COM helpers
    unsafe fn attr_get_u32(obj: *mut c_void, key: &Guid) -> Option<u32> {
        let f: unsafe extern "system" fn(*mut c_void, *const Guid, *mut u32) -> i32 =
            std::mem::transmute(com_vtable_fn(obj, 7));
        let mut val = 0u32;
        if f(obj, key, &mut val) >= 0 {
            Some(val)
        } else {
            None
        }
    }

    unsafe fn attr_get_u64(obj: *mut c_void, key: &Guid) -> Option<u64> {
        let f: unsafe extern "system" fn(*mut c_void, *const Guid, *mut u64) -> i32 =
            std::mem::transmute(com_vtable_fn(obj, 8));
        let mut val = 0u64;
        if f(obj, key, &mut val) >= 0 {
            Some(val)
        } else {
            None
        }
    }

    unsafe fn attr_get_guid(obj: *mut c_void, key: &Guid) -> Option<Guid> {
        let f: unsafe extern "system" fn(*mut c_void, *const Guid, *mut Guid) -> i32 =
            std::mem::transmute(com_vtable_fn(obj, 10));
        let mut val = GUID_NULL;
        if f(obj, key, &mut val) >= 0 {
            Some(val)
        } else {
            None
        }
    }

    unsafe fn attr_set_u32(obj: *mut c_void, key: &Guid, val: u32) -> i32 {
        let f: unsafe extern "system" fn(*mut c_void, *const Guid, u32) -> i32 =
            std::mem::transmute(com_vtable_fn(obj, 21));
        f(obj, key, val)
    }

    unsafe fn attr_set_guid(obj: *mut c_void, key: &Guid, val: &Guid) -> i32 {
        let f: unsafe extern "system" fn(*mut c_void, *const Guid, *const Guid) -> i32 =
            std::mem::transmute(com_vtable_fn(obj, 24));
        f(obj, key, val)
    }

    unsafe fn sr_set_stream_selection(sr: *mut c_void, stream: u32, selected: i32) -> i32 {
        let f: unsafe extern "system" fn(*mut c_void, u32, i32) -> i32 =
            std::mem::transmute(com_vtable_fn(sr, 4));
        f(sr, stream, selected)
    }

    unsafe fn sr_get_native_media_type(
        sr: *mut c_void,
        stream: u32,
        idx: u32,
    ) -> Option<*mut c_void> {
        let f: unsafe extern "system" fn(*mut c_void, u32, u32, *mut *mut c_void) -> i32 =
            std::mem::transmute(com_vtable_fn(sr, 5));
        let mut mt: *mut c_void = null_mut();
        if f(sr, stream, idx, &mut mt) >= 0 && !mt.is_null() {
            Some(mt)
        } else {
            None
        }
    }

    unsafe fn sr_get_current_media_type(sr: *mut c_void, stream: u32) -> Option<*mut c_void> {
        let f: unsafe extern "system" fn(*mut c_void, u32, *mut *mut c_void) -> i32 =
            std::mem::transmute(com_vtable_fn(sr, 6));
        let mut mt: *mut c_void = null_mut();
        if f(sr, stream, &mut mt) >= 0 && !mt.is_null() {
            Some(mt)
        } else {
            None
        }
    }

    unsafe fn sr_set_current_media_type(sr: *mut c_void, stream: u32, mt: *mut c_void) -> i32 {
        let f: unsafe extern "system" fn(*mut c_void, u32, *const u32, *mut c_void) -> i32 =
            std::mem::transmute(com_vtable_fn(sr, 7));
        f(sr, stream, null(), mt)
    }

    unsafe fn sr_set_current_position(sr: *mut c_void, hns: i64) -> i32 {
        let f: unsafe extern "system" fn(*mut c_void, *const Guid, *const PropVariant) -> i32 =
            std::mem::transmute(com_vtable_fn(sr, 8));
        let pv = PropVariant {
            vt: VT_I8,
            val: hns.max(0),
            ..Default::default()
        };
        f(sr, &GUID_NULL, &pv)
    }

    unsafe fn sr_read_sample(
        sr: *mut c_void,
        stream: u32,
    ) -> Result<(u32, u32, i64, *mut c_void), i32> {
        let f: unsafe extern "system" fn(
            *mut c_void,
            u32,
            u32,
            *mut u32,
            *mut u32,
            *mut i64,
            *mut *mut c_void,
        ) -> i32 = std::mem::transmute(com_vtable_fn(sr, 9));
        let mut actual_stream = 0u32;
        let mut flags = 0u32;
        let mut timestamp = 0i64;
        let mut sample: *mut c_void = null_mut();
        let hr = f(
            sr,
            stream,
            0,
            &mut actual_stream,
            &mut flags,
            &mut timestamp,
            &mut sample,
        );
        if hr >= 0 {
            Ok((actual_stream, flags, timestamp, sample))
        } else {
            Err(hr)
        }
    }

    unsafe fn sr_flush(sr: *mut c_void, stream: u32) -> i32 {
        let f: unsafe extern "system" fn(*mut c_void, u32) -> i32 =
            std::mem::transmute(com_vtable_fn(sr, 10));
        f(sr, stream)
    }

    unsafe fn sr_get_duration_sec(sr: *mut c_void) -> f64 {
        let f: unsafe extern "system" fn(
            *mut c_void,
            u32,
            *const Guid,
            *mut PropVariant,
        ) -> i32 = std::mem::transmute(com_vtable_fn(sr, 12));
        let mut pv = PropVariant::default();
        if f(sr, MF_SOURCE_READER_MEDIASOURCE, &MF_PD_DURATION, &mut pv) >= 0 {
            if pv.vt == VT_I8 || pv.vt == VT_UI8 {
                let hns = pv.val as u64;
                return (hns as f64) / 10_000_000.0;
            }
        }
        0.0
    }

    unsafe fn sample_copy_bytes(sample: *mut c_void) -> Option<Vec<u8>> {
        if sample.is_null() {
            return None;
        }
        let conv: unsafe extern "system" fn(*mut c_void, *mut *mut c_void) -> i32 =
            std::mem::transmute(com_vtable_fn(sample, 41));
        let mut buf: *mut c_void = null_mut();
        if conv(sample, &mut buf) < 0 || buf.is_null() {
            return None;
        }
        let lock: unsafe extern "system" fn(
            *mut c_void,
            *mut *mut u8,
            *mut u32,
            *mut u32,
        ) -> i32 = std::mem::transmute(com_vtable_fn(buf, 3));
        let unlock: unsafe extern "system" fn(*mut c_void) -> i32 =
            std::mem::transmute(com_vtable_fn(buf, 4));

        let mut ptr: *mut u8 = null_mut();
        let mut max_len = 0u32;
        let mut cur_len = 0u32;
        let out = if lock(buf, &mut ptr, &mut max_len, &mut cur_len) >= 0
            && !ptr.is_null()
            && cur_len > 0
        {
            let slice = std::slice::from_raw_parts(ptr, cur_len as usize).to_vec();
            let _ = unlock(buf);
            Some(slice)
        } else {
            None
        };
        com_release(buf);
        out
    }

    unsafe fn query_video_format(sr: *mut c_void, stream: u32) -> Option<(usize, usize, i32)> {
        let mt = sr_get_current_media_type(sr, stream)?;
        let packed = attr_get_u64(mt, &MF_MT_FRAME_SIZE);
        let stride_u32 = attr_get_u32(mt, &MF_MT_DEFAULT_STRIDE);
        com_release(mt);
        let packed = packed?;
        let w = (packed >> 32) as usize;
        let h = (packed & 0xFFFF_FFFF) as usize;
        if w == 0 || h == 0 || w > 8192 || h > 8192 {
            return None;
        }
        let stride = stride_u32.map(|v| v as i32).unwrap_or((w * 4) as i32);
        Some((w, h, stride))
    }

    fn downscale_rgba_if_needed(
        w: usize,
        h: usize,
        rgba: Vec<u8>,
        max_dim: usize,
    ) -> (usize, usize, Vec<u8>) {
        if w <= max_dim && h <= max_dim {
            return (w, h, rgba);
        }
        let scale = (max_dim as f64 / w as f64).min(max_dim as f64 / h as f64);
        let nw = ((w as f64 * scale).round() as usize).max(1);
        let nh = ((h as f64 * scale).round() as usize).max(1);
        let mut out = vec![0u8; nw * nh * 4];
        for y in 0..nh {
            let sy = (y * h) / nh;
            for x in 0..nw {
                let sx = (x * w) / nw;
                let si = (sy * w + sx) * 4;
                let di = (y * nw + x) * 4;
                out[di..di + 4].copy_from_slice(&rgba[si..si + 4]);
            }
        }
        (nw, nh, out)
    }

    fn rgb32_buffer_to_rgba(
        buf: &[u8],
        w: usize,
        h: usize,
        stride: i32,
        max_dim: usize,
    ) -> Option<(usize, usize, Vec<u8>)> {
        let row_bytes = stride.unsigned_abs() as usize;
        if row_bytes < w * 4 || buf.len() < row_bytes * h {
            return None;
        }
        let bottom_up = stride < 0;
        let scale = if w > max_dim || h > max_dim {
            (max_dim as f64 / w as f64).min(max_dim as f64 / h as f64)
        } else {
            1.0
        };
        let nw = ((w as f64 * scale).round() as usize).max(1);
        let nh = ((h as f64 * scale).round() as usize).max(1);
        let mut out = vec![0u8; nw * nh * 4];
        for y in 0..nh {
            let sy_logical = (y * h) / nh;
            let sy = if bottom_up {
                h - 1 - sy_logical
            } else {
                sy_logical
            };
            let row_off = sy * row_bytes;
            for x in 0..nw {
                let sx = (x * w) / nw;
                let si = row_off + sx * 4;
                let di = (y * nw + x) * 4;
                // BGRX -> RGBA
                out[di] = buf[si + 2];
                out[di + 1] = buf[si + 1];
                out[di + 2] = buf[si];
                out[di + 3] = 255;
            }
        }
        Some((nw, nh, out))
    }

    /// Video thumbnail on Windows: tries fast OS Shell cache first, falls back to Media Foundation 1-frame decode.
    pub fn extract_video_thumbnail_rgba(
        path: &Path,
        max_dim: u32,
    ) -> Option<(usize, usize, Vec<u8>)> {
        if let Some(shell_thumb) = extract_shell_thumbnail_rgba(path, max_dim) {
            return Some(shell_thumb);
        }
        extract_mf_single_frame_rgba(path, max_dim as usize)
    }

    fn extract_mf_single_frame_rgba(
        path: &Path,
        max_dim: usize,
    ) -> Option<(usize, usize, Vec<u8>)> {
        unsafe {
            let api = MfApi::load()?;
            let hr_co = CoInitializeEx(null_mut(), COINIT_MULTITHREADED);
            let did_co = hr_co >= 0;
            if (api.mf_startup)(MF_VERSION, MFSTARTUP_LITE) < 0 {
                if did_co {
                    CoUninitialize();
                }
                return None;
            }

            let mut result = None;
            let mut attrs: *mut c_void = null_mut();
            if (api.mf_create_attributes)(&mut attrs, 1) >= 0 && !attrs.is_null() {
                attr_set_u32(attrs, &MF_SOURCE_READER_ENABLE_VIDEO_PROCESSING, 1);
            }

            let wide = path_to_wide_z(path);
            let mut sr: *mut c_void = null_mut();
            if (api.mf_create_source_reader)(wide.as_ptr(), attrs, &mut sr) >= 0 && !sr.is_null() {
                let mut mt: *mut c_void = null_mut();
                if (api.mf_create_media_type)(&mut mt) >= 0 && !mt.is_null() {
                    attr_set_guid(mt, &MF_MT_MAJOR_TYPE, &MF_MEDIA_TYPE_VIDEO);
                    attr_set_guid(mt, &MF_MT_SUBTYPE, &MF_VIDEO_FORMAT_RGB32);
                    if sr_set_current_media_type(sr, MF_SOURCE_READER_FIRST_VIDEO_STREAM, mt) >= 0 {
                        let dur = sr_get_duration_sec(sr);
                        if dur > 2.0 {
                            let seek_sec = (dur * 0.1).min(1.5);
                            let _ = sr_set_current_position(sr, (seek_sec * 10_000_000.0) as i64);
                        }
                        if let Some((mut w, mut h, mut stride)) =
                            query_video_format(sr, MF_SOURCE_READER_FIRST_VIDEO_STREAM)
                        {
                            for _ in 0..8 {
                                let Ok((_, flags, _, sample)) =
                                    sr_read_sample(sr, MF_SOURCE_READER_FIRST_VIDEO_STREAM)
                                else {
                                    break;
                                };
                                if (flags & MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED) != 0 {
                                    if let Some(fmt) =
                                        query_video_format(sr, MF_SOURCE_READER_FIRST_VIDEO_STREAM)
                                    {
                                        w = fmt.0;
                                        h = fmt.1;
                                        stride = fmt.2;
                                    }
                                }
                                if !sample.is_null() {
                                    if let Some(raw) = sample_copy_bytes(sample) {
                                        result = rgb32_buffer_to_rgba(&raw, w, h, stride, max_dim);
                                    }
                                    com_release(sample);
                                    if result.is_some() {
                                        break;
                                    }
                                }
                                if (flags & MF_SOURCE_READERF_ENDOFSTREAM) != 0 {
                                    break;
                                }
                            }
                        }
                    }
                    com_release(mt);
                }
                com_release(sr);
            }
            if !attrs.is_null() {
                com_release(attrs);
            }
            let _ = (api.mf_shutdown)();
            if did_co {
                CoUninitialize();
            }
            result
        }
    }

    // ---- Background Media Foundation + waveOut Player ----

    enum WinCmd {
        Play,
        Pause,
        Seek(f64),
        SetVolume(f32, bool),
        Stop,
    }

    struct WinShared {
        state: Mutex<MediaState>,
        latest_frame: Mutex<Option<(usize, usize, Vec<u8>)>>,
        stop_flag: AtomicBool,
    }

    pub struct WinPlayer {
        shared: Arc<WinShared>,
        cmd_tx: mpsc::Sender<WinCmd>,
    }

    impl WinPlayer {
        pub fn open(path: PathBuf, volume: f32, muted: bool, ctx: egui::Context) -> Self {
            let shared = Arc::new(WinShared {
                state: Mutex::new(MediaState::default()),
                latest_frame: Mutex::new(None),
                stop_flag: AtomicBool::new(false),
            });
            let (cmd_tx, cmd_rx) = mpsc::channel();
            let sh_bg = Arc::clone(&shared);
            std::thread::spawn(move || {
                let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    run_win_player_thread(path, volume, muted, ctx, sh_bg, cmd_rx);
                }));
            });
            Self { shared, cmd_tx }
        }

        pub fn play(&mut self) {
            let _ = self.cmd_tx.send(WinCmd::Play);
        }

        pub fn pause(&mut self) {
            let _ = self.cmd_tx.send(WinCmd::Pause);
        }

        pub fn seek(&mut self, sec: f64) {
            let _ = self.cmd_tx.send(WinCmd::Seek(sec));
        }

        pub fn set_volume(&mut self, vol: f32, muted: bool) {
            let _ = self.cmd_tx.send(WinCmd::SetVolume(vol, muted));
        }

        pub fn poll_state_and_frame(&mut self) -> (MediaState, Option<(usize, usize, Vec<u8>)>) {
            let st = self
                .shared
                .state
                .lock()
                .map(|g| g.clone())
                .unwrap_or_default();
            let frame = self
                .shared
                .latest_frame
                .lock()
                .ok()
                .and_then(|mut g| g.take());
            (st, frame)
        }
    }

    impl Drop for WinPlayer {
        fn drop(&mut self) {
            self.shared.stop_flag.store(true, Ordering::Relaxed);
            let _ = self.cmd_tx.send(WinCmd::Stop);
        }
    }

    struct InFlightWave {
        hdr: Box<WaveHdr>,
        _pcm: Vec<u8>,
    }

    struct DecodedVideoFrame {
        pts_sec: f64,
        w: usize,
        h: usize,
        rgba: Vec<u8>,
    }

    fn apply_wave_volume(wapi: &WaveOutApi, hwo: *mut c_void, vol: f32, muted: bool) {
        if hwo.is_null() {
            return;
        }
        let level = if muted {
            0u32
        } else {
            (vol.clamp(0.0, 1.0) * 65535.0).round() as u32
        };
        let packed = (level & 0xFFFF) | ((level & 0xFFFF) << 16);
        unsafe {
            let _ = (wapi.set_volume)(hwo, packed);
        }
    }

    fn reclaim_done_waves(wapi: &WaveOutApi, hwo: *mut c_void, q: &mut VecDeque<InFlightWave>) {
        while let Some(front) = q.front() {
            let flags = front.hdr.dw_flags;
            if (flags & WHDR_DONE) != 0 {
                if let Some(mut item) = q.pop_front() {
                    unsafe {
                        let _ = (wapi.unprepare)(
                            hwo,
                            item.hdr.as_mut() as *mut WaveHdr,
                            std::mem::size_of::<WaveHdr>() as u32,
                        );
                    }
                }
            } else {
                break;
            }
        }
    }

    fn flush_all_waves(wapi: &WaveOutApi, hwo: *mut c_void, q: &mut VecDeque<InFlightWave>) {
        if !hwo.is_null() {
            unsafe {
                let _ = (wapi.reset)(hwo);
            }
            while let Some(mut item) = q.pop_front() {
                unsafe {
                    let _ = (wapi.unprepare)(
                        hwo,
                        item.hdr.as_mut() as *mut WaveHdr,
                        std::mem::size_of::<WaveHdr>() as u32,
                    );
                }
            }
        }
    }

    fn run_win_player_thread(
        path: PathBuf,
        init_vol: f32,
        init_muted: bool,
        ctx: egui::Context,
        shared: Arc<WinShared>,
        cmd_rx: mpsc::Receiver<WinCmd>,
    ) {
        unsafe {
            let Some(api) = MfApi::load() else {
                if let Ok(mut st) = shared.state.lock() {
                    st.error = Some("Windows Media Foundation unavailable".into());
                }
                ctx.request_repaint();
                return;
            };
            let hr_co = CoInitializeEx(null_mut(), COINIT_MULTITHREADED);
            let did_co = hr_co >= 0;
            if (api.mf_startup)(MF_VERSION, MFSTARTUP_LITE) < 0 {
                if did_co {
                    CoUninitialize();
                }
                if let Ok(mut st) = shared.state.lock() {
                    st.error = Some("Failed to start Windows Media Foundation".into());
                }
                ctx.request_repaint();
                return;
            }

            let mut attrs: *mut c_void = null_mut();
            if (api.mf_create_attributes)(&mut attrs, 1) >= 0 && !attrs.is_null() {
                attr_set_u32(attrs, &MF_SOURCE_READER_ENABLE_VIDEO_PROCESSING, 1);
            }

            let wide = path_to_wide_z(&path);
            let mut sr: *mut c_void = null_mut();
            if (api.mf_create_source_reader)(wide.as_ptr(), attrs, &mut sr) < 0 || sr.is_null() {
                if !attrs.is_null() {
                    com_release(attrs);
                }
                let _ = (api.mf_shutdown)();
                if did_co {
                    CoUninitialize();
                }
                if let Ok(mut st) = shared.state.lock() {
                    st.error = Some("Codec unsupported by Windows Media Foundation (use System Player)".into());
                }
                ctx.request_repaint();
                return;
            }
            if !attrs.is_null() {
                com_release(attrs);
            }

            let dur_sec = sr_get_duration_sec(sr);

            // Identify exact numeric stream indices for first video and first audio streams
            let mut video_stream_idx: Option<u32> = None;
            let mut audio_stream_idx: Option<u32> = None;
            for idx in 0..16u32 {
                let Some(mt) = sr_get_native_media_type(sr, idx, 0) else {
                    break;
                };
                if let Some(major) = attr_get_guid(mt, &MF_MT_MAJOR_TYPE) {
                    if major == MF_MEDIA_TYPE_VIDEO && video_stream_idx.is_none() {
                        video_stream_idx = Some(idx);
                    } else if major == MF_MEDIA_TYPE_AUDIO && audio_stream_idx.is_none() {
                        audio_stream_idx = Some(idx);
                    }
                }
                com_release(mt);
            }

            let _ = sr_set_stream_selection(sr, MF_SOURCE_READER_ALL_STREAMS, 0);

            // Configure video output -> RGB32
            let mut video_fmt: Option<(usize, usize, i32)> = None;
            if let Some(v_idx) = video_stream_idx {
                let _ = sr_set_stream_selection(sr, v_idx, 1);
                let mut mt: *mut c_void = null_mut();
                if (api.mf_create_media_type)(&mut mt) >= 0 && !mt.is_null() {
                    attr_set_guid(mt, &MF_MT_MAJOR_TYPE, &MF_MEDIA_TYPE_VIDEO);
                    attr_set_guid(mt, &MF_MT_SUBTYPE, &MF_VIDEO_FORMAT_RGB32);
                    if sr_set_current_media_type(sr, v_idx, mt) >= 0 {
                        video_fmt = query_video_format(sr, v_idx);
                    }
                    com_release(mt);
                }
                if video_fmt.is_none() {
                    let _ = sr_set_stream_selection(sr, v_idx, 0);
                    video_stream_idx = None;
                }
            }

            // Configure audio output -> PCM + waveOut
            let wave_api = WaveOutApi::load();
            let mut hwo: *mut c_void = null_mut();
            if let (Some(a_idx), Some(wapi)) = (audio_stream_idx, wave_api) {
                let _ = sr_set_stream_selection(sr, a_idx, 1);
                let mut mt: *mut c_void = null_mut();
                if (api.mf_create_media_type)(&mut mt) >= 0 && !mt.is_null() {
                    attr_set_guid(mt, &MF_MT_MAJOR_TYPE, &MF_MEDIA_TYPE_AUDIO);
                    attr_set_guid(mt, &MF_MT_SUBTYPE, &MF_AUDIO_FORMAT_PCM);
                    if sr_set_current_media_type(sr, a_idx, mt) >= 0 {
                        if let Some(cur) = sr_get_current_media_type(sr, a_idx) {
                            let ch = attr_get_u32(cur, &MF_MT_AUDIO_NUM_CHANNELS).unwrap_or(2) as u16;
                            let rate = attr_get_u32(cur, &MF_MT_AUDIO_SAMPLES_PER_SECOND).unwrap_or(44100);
                            let bits = attr_get_u32(cur, &MF_MT_AUDIO_BITS_PER_SAMPLE).unwrap_or(16) as u16;
                            com_release(cur);
                            let block_align = ch.saturating_mul(bits / 8).max(1);
                            let wfx = WaveFormatEx {
                                w_format_tag: WAVE_FORMAT_PCM,
                                n_channels: ch,
                                n_samples_per_sec: rate,
                                n_avg_bytes_per_sec: rate.saturating_mul(block_align as u32),
                                n_block_align: block_align,
                                w_bits_per_sample: bits,
                                cb_size: 0,
                            };
                            if (wapi.open)(&mut hwo, WAVE_MAPPER, &wfx, 0, 0, 0) == 0 && !hwo.is_null() {
                                apply_wave_volume(&wapi, hwo, init_vol, init_muted);
                            } else {
                                hwo = null_mut();
                            }
                        }
                    }
                    com_release(mt);
                }
                if hwo.is_null() {
                    let _ = sr_set_stream_selection(sr, a_idx, 0);
                    audio_stream_idx = None;
                }
            } else {
                audio_stream_idx = None;
            }

            if video_stream_idx.is_none() && audio_stream_idx.is_none() {
                com_release(sr);
                let _ = (api.mf_shutdown)();
                if did_co {
                    CoUninitialize();
                }
                if let Ok(mut st) = shared.state.lock() {
                    st.error = Some("No playable video/audio stream found (use System Player)".into());
                }
                ctx.request_repaint();
                return;
            }

            let has_video = video_stream_idx.is_some();
            if let Ok(mut st) = shared.state.lock() {
                st.dur_sec = dur_sec;
                st.has_video = has_video;
                st.is_ready = true;
            }
            ctx.request_repaint();

            let mut is_playing = false;
            let mut ended = false;
            let mut eof_all = false;
            let mut cur_pos_sec = 0.0f64;
            let mut anchor_instant = Instant::now();
            let mut anchor_pts_sec = 0.0f64;
            let mut cur_vol = init_vol;
            let mut cur_muted = init_muted;

            let mut wave_q: VecDeque<InFlightWave> = VecDeque::new();
            let mut video_q: VecDeque<DecodedVideoFrame> = VecDeque::new();

            // Helper to decode 1 video frame immediately after seeking while paused
            let decode_preview_frame = |sr: *mut c_void,
                                        v_idx: u32,
                                        vfmt: &mut Option<(usize, usize, i32)>,
                                        shared: &Arc<WinShared>,
                                        ctx: &egui::Context| {
                for _ in 0..8 {
                    let Ok((_, flags, _, sample)) = sr_read_sample(sr, v_idx) else {
                        break;
                    };
                    if (flags & MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED) != 0 {
                        if let Some(fmt) = query_video_format(sr, v_idx) {
                            *vfmt = Some(fmt);
                        }
                    }
                    if !sample.is_null() {
                        let mut published = false;
                        if let (Some((w, h, stride)), Some(raw)) = (*vfmt, sample_copy_bytes(sample)) {
                            if let Some(rgba) = rgb32_buffer_to_rgba(&raw, w, h, stride, 960) {
                                if let Ok(mut lf) = shared.latest_frame.lock() {
                                    *lf = Some(rgba);
                                }
                                ctx.request_repaint();
                                published = true;
                            }
                        }
                        com_release(sample);
                        if published {
                            break;
                        }
                    }
                    if (flags & MF_SOURCE_READERF_ENDOFSTREAM) != 0 {
                        break;
                    }
                }
            };

            // Show initial poster frame if video
            if let Some(v_idx) = video_stream_idx {
                decode_preview_frame(sr, v_idx, &mut video_fmt, &shared, &ctx);
                let _ = sr_flush(sr, MF_SOURCE_READER_ALL_STREAMS);
                let _ = sr_set_current_position(sr, 0);
            }

            let mut stop_now = false;
            while !stop_now && !shared.stop_flag.load(Ordering::Relaxed) {
                // 1. Drain commands (blocking when paused for ~0% idle CPU)
                let first_cmd = if is_playing {
                    cmd_rx.try_recv().ok()
                } else {
                    cmd_rx.recv_timeout(Duration::from_millis(45)).ok()
                };

                let mut pending_cmds = Vec::new();
                if let Some(c) = first_cmd {
                    pending_cmds.push(c);
                    while let Ok(more) = cmd_rx.try_recv() {
                        pending_cmds.push(more);
                    }
                }

                for cmd in pending_cmds {
                    match cmd {
                        WinCmd::Stop => {
                            stop_now = true;
                            break;
                        }
                        WinCmd::SetVolume(v, m) => {
                            cur_vol = v;
                            cur_muted = m;
                            if let Some(wapi) = wave_api {
                                apply_wave_volume(&wapi, hwo, cur_vol, cur_muted);
                            }
                        }
                        WinCmd::Pause => {
                            if is_playing {
                                cur_pos_sec = anchor_pts_sec + anchor_instant.elapsed().as_secs_f64();
                                is_playing = false;
                                if let Some(wapi) = wave_api {
                                    if !hwo.is_null() {
                                        let _ = (wapi.pause)(hwo);
                                    }
                                }
                            }
                        }
                        WinCmd::Play => {
                            if ended {
                                ended = false;
                                eof_all = false;
                                cur_pos_sec = 0.0;
                                video_q.clear();
                                if let Some(wapi) = wave_api {
                                    flush_all_waves(&wapi, hwo, &mut wave_q);
                                }
                                let _ = sr_flush(sr, MF_SOURCE_READER_ALL_STREAMS);
                                let _ = sr_set_current_position(sr, 0);
                            }
                            is_playing = true;
                            anchor_pts_sec = cur_pos_sec;
                            anchor_instant = Instant::now();
                            if let Some(wapi) = wave_api {
                                if !hwo.is_null() {
                                    let _ = (wapi.restart)(hwo);
                                    apply_wave_volume(&wapi, hwo, cur_vol, cur_muted);
                                }
                            }
                        }
                        WinCmd::Seek(sec) => {
                            let target = if dur_sec > 0.0 {
                                sec.clamp(0.0, dur_sec)
                            } else {
                                sec.max(0.0)
                            };
                            ended = false;
                            eof_all = false;
                            cur_pos_sec = target;
                            anchor_pts_sec = target;
                            anchor_instant = Instant::now();
                            video_q.clear();
                            if let Some(wapi) = wave_api {
                                flush_all_waves(&wapi, hwo, &mut wave_q);
                                if !is_playing && !hwo.is_null() {
                                    let _ = (wapi.pause)(hwo);
                                }
                            }
                            let _ = sr_flush(sr, MF_SOURCE_READER_ALL_STREAMS);
                            let _ = sr_set_current_position(sr, (target * 10_000_000.0) as i64);
                            if !is_playing {
                                if let Some(v_idx) = video_stream_idx {
                                    decode_preview_frame(sr, v_idx, &mut video_fmt, &shared, &ctx);
                                    let _ = sr_flush(sr, MF_SOURCE_READER_ALL_STREAMS);
                                    let _ = sr_set_current_position(
                                        sr,
                                        (target * 10_000_000.0) as i64,
                                    );
                                }
                            }
                        }
                    }
                }
                if stop_now {
                    break;
                }

                // 2. Active playback tick
                if is_playing {
                    if let Some(wapi) = wave_api {
                        if !hwo.is_null() {
                            reclaim_done_waves(&wapi, hwo, &mut wave_q);
                        }
                    }

                    // Pump interleaved samples while queues have headroom
                    let mut reads_this_tick = 0u32;
                    while !eof_all && reads_this_tick < 6 {
                        let need_audio = audio_stream_idx.is_some() && wave_q.len() < 10;
                        let need_video = video_stream_idx.is_some() && video_q.len() < 4;
                        if !need_audio && !need_video {
                            break;
                        }
                        let req_stream = if need_audio && need_video {
                            MF_SOURCE_READER_ANY_STREAM
                        } else if need_audio {
                            audio_stream_idx.unwrap_or(MF_SOURCE_READER_FIRST_AUDIO_STREAM)
                        } else {
                            video_stream_idx.unwrap_or(MF_SOURCE_READER_FIRST_VIDEO_STREAM)
                        };
                        reads_this_tick += 1;

                        let Ok((actual_stream, flags, ts_hns, sample)) =
                            sr_read_sample(sr, req_stream)
                        else {
                            eof_all = true;
                            break;
                        };
                        if (flags & MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED) != 0 {
                            if Some(actual_stream) == video_stream_idx {
                                if let Some(fmt) = query_video_format(sr, actual_stream) {
                                    video_fmt = Some(fmt);
                                }
                            }
                        }
                        if (flags & MF_SOURCE_READERF_ENDOFSTREAM) != 0 {
                            if !sample.is_null() {
                                com_release(sample);
                            }
                            // Mark EOF when all active streams hit end
                            if req_stream == MF_SOURCE_READER_ANY_STREAM
                                || (video_stream_idx.is_none() || Some(actual_stream) == video_stream_idx)
                                    && (audio_stream_idx.is_none() || Some(actual_stream) == audio_stream_idx)
                            {
                                eof_all = true;
                            } else {
                                // Only one stream ended; let other finish
                                eof_all = true;
                            }
                            break;
                        }
                        if sample.is_null() {
                            continue;
                        }

                        let pts_sec = (ts_hns as f64 / 10_000_000.0).max(0.0);
                        if Some(actual_stream) == video_stream_idx {
                            if let (Some((w, h, stride)), Some(raw)) =
                                (video_fmt, sample_copy_bytes(sample))
                            {
                                if let Some((fw, fh, rgba)) =
                                    rgb32_buffer_to_rgba(&raw, w, h, stride, 960)
                                {
                                    video_q.push_back(DecodedVideoFrame {
                                        pts_sec,
                                        w: fw,
                                        h: fh,
                                        rgba,
                                    });
                                }
                            }
                        } else if Some(actual_stream) == audio_stream_idx {
                            if let (Some(wapi), Some(mut pcm)) =
                                (wave_api, sample_copy_bytes(sample))
                            {
                                if !hwo.is_null() && !pcm.is_empty() {
                                    let mut hdr = Box::new(WaveHdr {
                                        lp_data: pcm.as_mut_ptr(),
                                        dw_buffer_length: pcm.len() as u32,
                                        dw_bytes_recorded: 0,
                                        dw_user: 0,
                                        dw_flags: 0,
                                        dw_loops: 0,
                                        lp_next: null_mut(),
                                        reserved: 0,
                                    });
                                    let hdr_sz = std::mem::size_of::<WaveHdr>() as u32;
                                    if (wapi.prepare)(hwo, hdr.as_mut() as *mut WaveHdr, hdr_sz) == 0
                                    {
                                        if (wapi.write)(hwo, hdr.as_mut() as *mut WaveHdr, hdr_sz)
                                            == 0
                                        {
                                            wave_q.push_back(InFlightWave { hdr, _pcm: pcm });
                                        } else {
                                            let _ = (wapi.unprepare)(
                                                hwo,
                                                hdr.as_mut() as *mut WaveHdr,
                                                hdr_sz,
                                            );
                                        }
                                    }
                                }
                            }
                        }
                        com_release(sample);
                    }

                    // Advance presentation clock & present due video frame
                    let clock_sec = anchor_pts_sec + anchor_instant.elapsed().as_secs_f64();
                    cur_pos_sec = if dur_sec > 0.0 {
                        clock_sec.min(dur_sec)
                    } else {
                        clock_sec
                    };

                    let mut latest_due: Option<DecodedVideoFrame> = None;
                    while let Some(front) = video_q.front() {
                        if front.pts_sec <= clock_sec + 0.015 {
                            latest_due = video_q.pop_front();
                        } else {
                            break;
                        }
                    }
                    if let Some(frame) = latest_due {
                        if let Ok(mut lf) = shared.latest_frame.lock() {
                            *lf = Some((frame.w, frame.h, frame.rgba));
                        }
                        ctx.request_repaint();
                    }

                    if eof_all && video_q.is_empty() && wave_q.is_empty() {
                        is_playing = false;
                        ended = true;
                        if dur_sec > 0.0 {
                            cur_pos_sec = dur_sec;
                        }
                        ctx.request_repaint();
                    }
                }

                if let Ok(mut st) = shared.state.lock() {
                    st.pos_sec = cur_pos_sec;
                    st.dur_sec = dur_sec;
                    st.is_playing = is_playing;
                    st.has_video = has_video;
                    st.is_ready = true;
                }

                if is_playing {
                    std::thread::sleep(Duration::from_millis(8));
                }
            }

            if let Some(wapi) = wave_api {
                if !hwo.is_null() {
                    flush_all_waves(&wapi, hwo, &mut wave_q);
                    let _ = (wapi.close)(hwo);
                }
            }
            com_release(sr);
            let _ = (api.mf_shutdown)();
            if did_co {
                CoUninitialize();
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_media_extension_classification() {
        assert!(is_video_ext("mp4"));
        assert!(is_video_ext(".MOV"));
        assert!(is_video_ext("mkv"));
        assert!(!is_video_ext("mp3"));
        assert!(!is_video_ext("png"));

        assert!(is_audio_ext("mp3"));
        assert!(is_audio_ext(".FLAC"));
        assert!(is_audio_ext("m4a"));
        assert!(!is_audio_ext("mp4"));
        assert!(!is_audio_ext("txt"));

        assert!(is_media_ext("mp4"));
        assert!(is_media_ext("mp3"));
        assert!(!is_media_ext("jpg"));
    }

    #[test]
    fn test_format_duration_sec() {
        assert_eq!(format_duration_sec(0.0), "00:00");
        assert_eq!(format_duration_sec(15.4), "00:15");
        assert_eq!(format_duration_sec(65.0), "01:05");
        assert_eq!(format_duration_sec(3661.9), "1:01:01");
    }

    #[test]
    fn test_extract_id3v2_mp3_album_cover() {
        // Build a minimal real 16x16 PNG in memory
        let mut img = image::RgbaImage::new(16, 16);
        for px in img.pixels_mut() {
            *px = image::Rgba([220, 80, 120, 255]);
        }
        let mut png_bytes = Vec::new();
        {
            let mut cursor = std::io::Cursor::new(&mut png_bytes);
            img.write_to(&mut cursor, image::ImageFormat::Png).unwrap();
        }

        // Build an ID3v2.3 APIC frame:
        // encoding(0) + "image/png\0" + pic_type(3) + "cover\0" + png_bytes
        let mut apic_payload = Vec::new();
        apic_payload.push(0x00); // Latin-1
        apic_payload.extend_from_slice(b"image/png\0");
        apic_payload.push(0x03); // Front cover
        apic_payload.extend_from_slice(b"cover\0");
        apic_payload.extend_from_slice(&png_bytes);

        let mut frame = Vec::new();
        frame.extend_from_slice(b"APIC");
        frame.extend_from_slice(&(apic_payload.len() as u32).to_be_bytes());
        frame.extend_from_slice(&[0x00, 0x00]); // flags
        frame.extend_from_slice(&apic_payload);

        // Syncsafe 28-bit tag size
        let sz = frame.len() as u32;
        let ss = [
            ((sz >> 21) & 0x7F) as u8,
            ((sz >> 14) & 0x7F) as u8,
            ((sz >> 7) & 0x7F) as u8,
            (sz & 0x7F) as u8,
        ];

        let mut mp3 = Vec::new();
        mp3.extend_from_slice(b"ID3");
        mp3.extend_from_slice(&[3, 0, 0]); // v2.3.0, flags=0
        mp3.extend_from_slice(&ss);
        mp3.extend_from_slice(&frame);
        mp3.extend_from_slice(&[0xFF, 0xFB, 0x90, 0x00]); // fake MP3 frame sync

        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos();
        let tmp = std::env::temp_dir().join(format!("mine_id3_test_{}.mp3", nanos));
        std::fs::write(&tmp, &mp3).unwrap();

        let extracted = extract_audio_cover_rgba(&tmp, 128);
        let _ = std::fs::remove_file(&tmp);

        let (w, h, rgba) = extracted.expect("should extract embedded ID3v2 APIC PNG cover");
        assert_eq!((w, h), (16, 16));
        assert_eq!(rgba.len(), 16 * 16 * 4);
        assert_eq!(&rgba[0..4], &[220, 80, 120, 255]);
    }

    #[test]
    fn test_extract_flac_picture_cover() {
        let mut img = image::RgbaImage::new(12, 12);
        for px in img.pixels_mut() {
            *px = image::Rgba([40, 160, 240, 255]);
        }
        let mut png_bytes = Vec::new();
        {
            let mut cursor = std::io::Cursor::new(&mut png_bytes);
            img.write_to(&mut cursor, image::ImageFormat::Png).unwrap();
        }

        let mime = b"image/png";
        let mut pic = Vec::new();
        pic.extend_from_slice(&3u32.to_be_bytes()); // front cover
        pic.extend_from_slice(&(mime.len() as u32).to_be_bytes());
        pic.extend_from_slice(mime);
        pic.extend_from_slice(&0u32.to_be_bytes()); // desc len
        pic.extend_from_slice(&12u32.to_be_bytes()); // w
        pic.extend_from_slice(&12u32.to_be_bytes()); // h
        pic.extend_from_slice(&32u32.to_be_bytes()); // depth
        pic.extend_from_slice(&0u32.to_be_bytes()); // colors
        pic.extend_from_slice(&(png_bytes.len() as u32).to_be_bytes());
        pic.extend_from_slice(&png_bytes);

        let blen = pic.len();
        let mut flac = Vec::new();
        flac.extend_from_slice(b"fLaC");
        flac.push(0x80 | 6); // last block + PICTURE (6)
        flac.push(((blen >> 16) & 0xFF) as u8);
        flac.push(((blen >> 8) & 0xFF) as u8);
        flac.push((blen & 0xFF) as u8);
        flac.extend_from_slice(&pic);

        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos();
        let tmp = std::env::temp_dir().join(format!("mine_flac_test_{}.flac", nanos));
        std::fs::write(&tmp, &flac).unwrap();

        let extracted = extract_audio_cover_rgba(&tmp, 128);
        let _ = std::fs::remove_file(&tmp);

        let (w, h, rgba) = extracted.expect("should extract FLAC PICTURE cover");
        assert_eq!((w, h), (12, 12));
        assert_eq!(&rgba[0..4], &[40, 160, 240, 255]);
    }
}
