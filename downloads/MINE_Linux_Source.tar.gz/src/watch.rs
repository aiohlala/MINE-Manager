use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::mpsc::{self, Receiver};
use std::sync::{Arc, Condvar, Mutex};
use std::time::{Duration, Instant};

const DEBOUNCE_DELAY: Duration = Duration::from_millis(220);
const MAX_BURST_DELAY: Duration = Duration::from_millis(500);
const COOLDOWN_INTERVAL: Duration = Duration::from_millis(650);

/// Pure-Rust trailing debounce + burst cap + per-directory cooldown queue.
/// Coalesces multi-file bursts (extract, bulk copy, npm install) into a single folder reload.
pub struct DirDebounceQueue {
    pending: HashMap<PathBuf, (Instant, Instant)>,
    last_emitted: HashMap<PathBuf, Instant>,
}

impl DirDebounceQueue {
    pub fn new() -> Self {
        Self {
            pending: HashMap::new(),
            last_emitted: HashMap::new(),
        }
    }

    pub fn record_event(&mut self, path: PathBuf, now: Instant) {
        let earliest_allowed = self
            .last_emitted
            .get(&path)
            .map(|t| *t + COOLDOWN_INTERVAL)
            .unwrap_or(now);

        if let Some((first_seen, due_at)) = self.pending.get_mut(&path) {
            let max_due = *first_seen + MAX_BURST_DELAY;
            *due_at = (now + DEBOUNCE_DELAY)
                .min(max_due)
                .max(earliest_allowed);
        } else {
            let due_at = (now + DEBOUNCE_DELAY).max(earliest_allowed);
            self.pending.insert(path, (now, due_at));
        }
    }

    pub fn next_timeout(&self, now: Instant) -> Option<Duration> {
        let earliest = self.pending.values().map(|(_, due)| *due).min()?;
        Some(earliest.saturating_duration_since(now))
    }

    pub fn drain_ready(&mut self, now: Instant) -> Vec<PathBuf> {
        let mut ready = Vec::new();
        self.pending.retain(|p, (_, due)| {
            if *due <= now {
                ready.push(p.clone());
                false
            } else {
                true
            }
        });
        for p in &ready {
            self.last_emitted.insert(p.clone(), now);
        }
        if self.last_emitted.len() > 128 {
            self.last_emitted
                .retain(|_, ts| now.saturating_duration_since(*ts) < Duration::from_secs(15));
        }
        ready
    }

    pub fn retain_paths(&mut self, active: &HashSet<PathBuf>) {
        self.pending.retain(|p, _| active.contains(p));
        self.last_emitted.retain(|p, _| active.contains(p));
    }
}

struct WatcherShared {
    desired_dirs: Vec<PathBuf>,
    desired_gen: u64,
    applied_gen: u64,
    shutdown: bool,
}

/// Event-driven OS filesystem watcher sharing one kernel wait handle across all open panes
/// (0.0% idle CPU via Darwin kqueue+O_EVTONLY, Win32 FindFirstChangeNotificationW, or Linux inotify).
pub struct DirWatcher {
    shared: Arc<(Mutex<WatcherShared>, Condvar)>,
    changed_rx: Receiver<Vec<PathBuf>>,
    wake_fn: Arc<dyn Fn() + Send + Sync>,
    join_handle: Option<std::thread::JoinHandle<()>>,
}

impl DirWatcher {
    pub fn new(on_change_wakeup: Arc<dyn Fn() + Send + Sync>) -> Self {
        let (tx, rx) = mpsc::channel();
        let shared = Arc::new((
            Mutex::new(WatcherShared {
                desired_dirs: Vec::new(),
                desired_gen: 0,
                applied_gen: 0,
                shutdown: false,
            }),
            Condvar::new(),
        ));

        let shared_bg = Arc::clone(&shared);
        let wakeup_cb = Arc::clone(&on_change_wakeup);
        let wake_fn = backend::create_wake_fn();
        let wake_bg = Arc::clone(&wake_fn);

        let join_handle = std::thread::Builder::new()
            .name("mine_dir_watcher".into())
            .spawn(move || {
                backend::run_watcher_loop(shared_bg, wake_bg, tx, wakeup_cb);
            })
            .ok();

        Self {
            shared,
            changed_rx: rx,
            wake_fn,
            join_handle,
        }
    }

    /// Updates the watched directory set (only wakes kernel loop when set changes).
    pub fn set_watched_dirs(&self, mut dirs: Vec<PathBuf>) {
        dirs.sort();
        dirs.dedup();
        let mut st = self.shared.0.lock().unwrap_or_else(|e| e.into_inner());
        if st.desired_dirs != dirs {
            st.desired_dirs = dirs;
            st.desired_gen = st.desired_gen.wrapping_add(1);
            drop(st);
            (self.wake_fn)();
        }
    }

    /// Synchronously closes any OS watch handles under `prefix` before drive ejection.
    pub fn release_prefix_and_wait(&self, prefix: &Path, max_wait: Duration) {
        let target_gen = {
            let mut st = self.shared.0.lock().unwrap_or_else(|e| e.into_inner());
            let before = st.desired_dirs.len();
            st.desired_dirs.retain(|d| !d.starts_with(prefix));
            if st.desired_dirs.len() != before {
                st.desired_gen = st.desired_gen.wrapping_add(1);
            }
            st.desired_gen
        };
        (self.wake_fn)();

        let deadline = Instant::now() + max_wait;
        let mut st = self.shared.0.lock().unwrap_or_else(|e| e.into_inner());
        while st.applied_gen < target_gen && !st.shutdown {
            let rem = deadline.saturating_duration_since(Instant::now());
            if rem.is_zero() {
                break;
            }
            let (guard, _) = self
                .shared
                .1
                .wait_timeout(st, rem)
                .unwrap_or_else(|e| e.into_inner());
            st = guard;
        }
    }

    /// Non-blocking drain of directories whose contents changed since last poll.
    pub fn poll_changed_dirs(&self) -> Vec<PathBuf> {
        let mut out = Vec::new();
        while let Ok(batch) = self.changed_rx.try_recv() {
            for p in batch {
                if !out.contains(&p) {
                    out.push(p);
                }
            }
        }
        out
    }
}

impl Drop for DirWatcher {
    fn drop(&mut self) {
        {
            let mut st = self.shared.0.lock().unwrap_or_else(|e| e.into_inner());
            st.shutdown = true;
            st.desired_gen = st.desired_gen.wrapping_add(1);
            self.shared.1.notify_all();
        }
        (self.wake_fn)();
        if let Some(jh) = self.join_handle.take() {
            let _ = jh.join();
        }
    }
}

#[cfg(target_os = "macos")]
mod backend {
    use super::{DirDebounceQueue, WatcherShared};
    use std::collections::{HashMap, HashSet};
    use std::ffi::{c_char, c_int, c_void, CString};
    use std::path::PathBuf;
    use std::sync::mpsc::Sender;
    use std::sync::{Arc, Condvar, Mutex};
    use std::time::Instant;

    #[repr(C)]
    struct MineKqueueWatcher {
        _private: [u8; 0],
    }

    extern "C" {
        fn mine_kqueue_create() -> *mut MineKqueueWatcher;
        fn mine_kqueue_wake(w: *mut MineKqueueWatcher);
        fn mine_kqueue_add_dir(
            w: *mut MineKqueueWatcher,
            path_utf8: *const c_char,
            watch_id: u64,
        ) -> c_int;
        fn mine_kqueue_remove_fd(fd: c_int);
        fn mine_kqueue_wait(
            w: *mut MineKqueueWatcher,
            timeout_ms: c_int,
            out_ids: *mut u64,
            out_flags: *mut u32,
            max_ids: c_int,
            out_woken: *mut c_int,
        ) -> c_int;
        fn mine_kqueue_destroy(w: *mut MineKqueueWatcher);
    }

    struct KqSlot(std::sync::atomic::AtomicUsize);
    static GLOBAL_WAKE_PTR: KqSlot = KqSlot(std::sync::atomic::AtomicUsize::new(0));

    pub fn create_wake_fn() -> Arc<dyn Fn() + Send + Sync> {
        Arc::new(|| {
            let ptr = GLOBAL_WAKE_PTR.0.load(std::sync::atomic::Ordering::Acquire);
            if ptr != 0 {
                unsafe { mine_kqueue_wake(ptr as *mut MineKqueueWatcher) };
            }
        })
    }

    pub fn run_watcher_loop(
        shared: Arc<(Mutex<WatcherShared>, Condvar)>,
        _wake_fn: Arc<dyn Fn() + Send + Sync>,
        tx: Sender<Vec<PathBuf>>,
        on_change_wakeup: Arc<dyn Fn() + Send + Sync>,
    ) {
        let kq = unsafe { mine_kqueue_create() };
        if kq.is_null() {
            return;
        }
        GLOBAL_WAKE_PTR
            .0
            .store(kq as usize, std::sync::atomic::Ordering::Release);

        let mut watches: HashMap<PathBuf, (c_int, u64)> = HashMap::new();
        let mut id_to_path: HashMap<u64, PathBuf> = HashMap::new();
        let mut next_id: u64 = 1;
        let mut last_gen: u64 = 0;
        let mut debounce = DirDebounceQueue::new();

        let mut ids_buf = [0u64; 64];
        let mut flags_buf = [0u32; 64];

        loop {
            let (shutdown, desired_gen, desired_dirs) = {
                let st = shared.0.lock().unwrap_or_else(|e| e.into_inner());
                (st.shutdown, st.desired_gen, st.desired_dirs.clone())
            };
            if shutdown {
                break;
            }

            if desired_gen != last_gen {
                let desired_set: HashSet<PathBuf> = desired_dirs.iter().cloned().collect();
                watches.retain(|p, (fd, id)| {
                    if !desired_set.contains(p) {
                        unsafe { mine_kqueue_remove_fd(*fd) };
                        id_to_path.remove(id);
                        false
                    } else {
                        true
                    }
                });
                for p in &desired_dirs {
                    if !watches.contains_key(p) {
                        if let Ok(cs) = CString::new(p.to_string_lossy().as_bytes()) {
                            let wid = next_id;
                            next_id = next_id.wrapping_add(1).max(1);
                            let fd = unsafe { mine_kqueue_add_dir(kq, cs.as_ptr(), wid) };
                            if fd >= 0 {
                                watches.insert(p.clone(), (fd, wid));
                                id_to_path.insert(wid, p.clone());
                            }
                        }
                    }
                }
                debounce.retain_paths(&desired_set);
                last_gen = desired_gen;
                let mut st = shared.0.lock().unwrap_or_else(|e| e.into_inner());
                st.applied_gen = desired_gen;
                shared.1.notify_all();
            }

            let now = Instant::now();
            let timeout_ms: c_int = match debounce.next_timeout(now) {
                None => -1,
                Some(d) => d.as_millis().clamp(1, i32::MAX as u128) as c_int,
            };

            let mut woken: c_int = 0;
            let count = unsafe {
                mine_kqueue_wait(
                    kq,
                    timeout_ms,
                    ids_buf.as_mut_ptr(),
                    flags_buf.as_mut_ptr(),
                    ids_buf.len() as c_int,
                    &mut woken,
                )
            };
            if count < 0 {
                break;
            }

            let ev_now = Instant::now();
            for i in 0..(count as usize) {
                let wid = ids_buf[i];
                let needs_reopen = flags_buf[i] != 0;
                if let Some(path) = id_to_path.get(&wid).cloned() {
                    debounce.record_event(path.clone(), ev_now);
                    if needs_reopen {
                        if let Some((old_fd, old_id)) = watches.remove(&path) {
                            unsafe { mine_kqueue_remove_fd(old_fd) };
                            id_to_path.remove(&old_id);
                        }
                        if let Ok(cs) = CString::new(path.to_string_lossy().as_bytes()) {
                            let new_wid = next_id;
                            next_id = next_id.wrapping_add(1).max(1);
                            let new_fd = unsafe { mine_kqueue_add_dir(kq, cs.as_ptr(), new_wid) };
                            if new_fd >= 0 {
                                watches.insert(path.clone(), (new_fd, new_wid));
                                id_to_path.insert(new_wid, path);
                            }
                        }
                    }
                }
            }

            let flush_now = Instant::now();
            let ready = debounce.drain_ready(flush_now);
            if !ready.is_empty() {
                if tx.send(ready).is_err() {
                    break;
                }
                on_change_wakeup();
            }
        }

        for (_, (fd, _)) in watches.drain() {
            unsafe { mine_kqueue_remove_fd(fd) };
        }
        let cur_ptr = GLOBAL_WAKE_PTR.0.load(std::sync::atomic::Ordering::Acquire);
        if cur_ptr == kq as usize {
            GLOBAL_WAKE_PTR
                .0
                .store(0, std::sync::atomic::Ordering::Release);
        }
        unsafe {
            let _ = kq as *mut c_void;
            mine_kqueue_destroy(kq);
        }
    }
}

#[cfg(target_os = "windows")]
mod backend {
    use super::{DirDebounceQueue, WatcherShared};
    use std::collections::HashSet;
    use std::ffi::c_void;
    use std::path::{Path, PathBuf};
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::mpsc::Sender;
    use std::sync::{Arc, Condvar, Mutex};
    use std::time::{Duration, Instant};

    const FILE_NOTIFY_CHANGE_FILE_NAME: u32 = 1;
    const FILE_NOTIFY_CHANGE_DIR_NAME: u32 = 2;
    const FILE_NOTIFY_CHANGE_ATTRIBUTES: u32 = 4;
    const FILE_NOTIFY_CHANGE_SIZE: u32 = 8;
    const FILE_NOTIFY_CHANGE_LAST_WRITE: u32 = 16;
    const WATCH_FLAGS: u32 = FILE_NOTIFY_CHANGE_FILE_NAME
        | FILE_NOTIFY_CHANGE_DIR_NAME
        | FILE_NOTIFY_CHANGE_ATTRIBUTES
        | FILE_NOTIFY_CHANGE_SIZE
        | FILE_NOTIFY_CHANGE_LAST_WRITE;

    const DRIVE_REMOTE: u32 = 4;
    const INFINITE: u32 = 0xFFFF_FFFF;
    const WAIT_OBJECT_0: u32 = 0;
    const WAIT_TIMEOUT: u32 = 258;
    const WAIT_FAILED: u32 = 0xFFFF_FFFF;
    const INVALID_HANDLE_VALUE: *mut c_void = (-1isize) as *mut c_void;
    const MAX_DIR_HANDLES: usize = 63; // MAXIMUM_WAIT_OBJECTS (64) - 1 wake event

    #[link(name = "kernel32")]
    extern "system" {
        fn CreateEventW(
            lp_event_attributes: *const c_void,
            b_manual_reset: i32,
            b_initial_state: i32,
            lp_name: *const u16,
        ) -> *mut c_void;
        fn SetEvent(h_event: *mut c_void) -> i32;
        fn ResetEvent(h_event: *mut c_void) -> i32;
        fn CloseHandle(h_object: *mut c_void) -> i32;
        fn FindFirstChangeNotificationW(
            lp_path_name: *const u16,
            b_watch_subtree: i32,
            dw_notify_filter: u32,
        ) -> *mut c_void;
        fn FindNextChangeNotification(h_change_handle: *mut c_void) -> i32;
        fn FindCloseChangeNotification(h_change_handle: *mut c_void) -> i32;
        fn WaitForMultipleObjects(
            n_count: u32,
            lp_handles: *const *mut c_void,
            b_wait_all: i32,
            dw_milliseconds: u32,
        ) -> u32;
        fn GetDriveTypeW(lp_root_path_name: *const u16) -> u32;
    }

    static GLOBAL_WAKE_EVENT: AtomicUsize = AtomicUsize::new(0);

    pub fn create_wake_fn() -> Arc<dyn Fn() + Send + Sync> {
        Arc::new(|| {
            let h = GLOBAL_WAKE_EVENT.load(Ordering::Acquire);
            if h != 0 {
                unsafe {
                    SetEvent(h as *mut c_void);
                }
            }
        })
    }

    fn is_local_watchable_win_path(path: &Path) -> bool {
        let s = path.to_string_lossy();
        if s.starts_with(r"\\?\UNC\") || s.starts_with(r"\\") && !s.starts_with(r"\\?\") {
            return false;
        }
        let clean = s.strip_prefix(r"\\?\").unwrap_or(&s);
        let bytes = clean.as_bytes();
        if bytes.len() >= 2 && bytes[1] == b':' {
            let root: Vec<u16> = format!("{}:\\\0", bytes[0] as char).encode_utf16().collect();
            let dtype = unsafe { GetDriveTypeW(root.as_ptr()) };
            if dtype == DRIVE_REMOTE {
                return false;
            }
        }
        path.is_dir()
    }

    pub fn run_watcher_loop(
        shared: Arc<(Mutex<WatcherShared>, Condvar)>,
        _wake_fn: Arc<dyn Fn() + Send + Sync>,
        tx: Sender<Vec<PathBuf>>,
        on_change_wakeup: Arc<dyn Fn() + Send + Sync>,
    ) {
        let wake_event = unsafe { CreateEventW(std::ptr::null(), 1, 0, std::ptr::null()) };
        if wake_event.is_null() || wake_event == INVALID_HANDLE_VALUE {
            return;
        }
        GLOBAL_WAKE_EVENT.store(wake_event as usize, Ordering::Release);

        let mut watches: Vec<(PathBuf, *mut c_void)> = Vec::new();
        let mut last_gen: u64 = 0;
        let mut debounce = DirDebounceQueue::new();

        loop {
            let (shutdown, desired_gen, desired_dirs) = {
                let st = shared.0.lock().unwrap_or_else(|e| e.into_inner());
                (st.shutdown, st.desired_gen, st.desired_dirs.clone())
            };
            if shutdown {
                break;
            }

            if desired_gen != last_gen {
                let target_set: HashSet<PathBuf> = desired_dirs
                    .iter()
                    .filter(|p| is_local_watchable_win_path(p))
                    .take(MAX_DIR_HANDLES)
                    .cloned()
                    .collect();

                watches.retain(|(p, h)| {
                    if !target_set.contains(p) {
                        unsafe { FindCloseChangeNotification(*h) };
                        false
                    } else {
                        true
                    }
                });

                for p in &desired_dirs {
                    if watches.len() >= MAX_DIR_HANDLES {
                        break;
                    }
                    if !target_set.contains(p) || watches.iter().any(|(wp, _)| wp == p) {
                        continue;
                    }
                    let mut wide: Vec<u16> = p.as_os_str().to_string_lossy().encode_utf16().collect();
                    wide.push(0);
                    let h = unsafe { FindFirstChangeNotificationW(wide.as_ptr(), 0, WATCH_FLAGS) };
                    if !h.is_null() && h != INVALID_HANDLE_VALUE {
                        watches.push((p.clone(), h));
                    }
                }

                debounce.retain_paths(&target_set);
                last_gen = desired_gen;
                let mut st = shared.0.lock().unwrap_or_else(|e| e.into_inner());
                st.applied_gen = desired_gen;
                shared.1.notify_all();
            }

            let now = Instant::now();
            let timeout_ms: u32 = match debounce.next_timeout(now) {
                None => INFINITE,
                Some(d) => d.as_millis().clamp(1, (INFINITE - 1) as u128) as u32,
            };

            let mut handles: Vec<*mut c_void> = Vec::with_capacity(1 + watches.len());
            handles.push(wake_event);
            for (_, h) in &watches {
                handles.push(*h);
            }

            let wait_res = unsafe {
                WaitForMultipleObjects(handles.len() as u32, handles.as_ptr(), 0, timeout_ms)
            };

            if wait_res == WAIT_OBJECT_0 {
                unsafe { ResetEvent(wake_event) };
            } else if wait_res > WAIT_OBJECT_0
                && (wait_res - WAIT_OBJECT_0) < handles.len() as u32
            {
                let watch_idx = (wait_res - WAIT_OBJECT_0 - 1) as usize;
                let mut remove_stale = false;
                if let Some((path, h)) = watches.get(watch_idx) {
                    debounce.record_event(path.clone(), Instant::now());
                    if unsafe { FindNextChangeNotification(*h) } == 0 {
                        unsafe { FindCloseChangeNotification(*h) };
                        remove_stale = true;
                    }
                }
                if remove_stale {
                    watches.remove(watch_idx);
                }
            } else if wait_res == WAIT_FAILED {
                std::thread::sleep(Duration::from_millis(150));
            } else if wait_res == WAIT_TIMEOUT {
                // Flush ready debounce timers below
            }

            let ready = debounce.drain_ready(Instant::now());
            if !ready.is_empty() {
                if tx.send(ready).is_err() {
                    break;
                }
                on_change_wakeup();
            }
        }

        for (_, h) in watches.drain(..) {
            unsafe { FindCloseChangeNotification(h) };
        }
        let cur = GLOBAL_WAKE_EVENT.load(Ordering::Acquire);
        if cur == wake_event as usize {
            GLOBAL_WAKE_EVENT.store(0, Ordering::Release);
        }
        unsafe { CloseHandle(wake_event) };
    }
}

#[cfg(all(unix, not(target_os = "macos")))]
mod backend {
    use super::{DirDebounceQueue, WatcherShared};
    use std::collections::{HashMap, HashSet};
    use std::ffi::{c_char, c_int, c_void, CString};
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicI32, Ordering};
    use std::sync::mpsc::Sender;
    use std::sync::{Arc, Condvar, Mutex};
    use std::time::Instant;

    const IN_CREATE: u32 = 0x0000_0100;
    const IN_DELETE: u32 = 0x0000_0200;
    const IN_MODIFY: u32 = 0x0000_0002;
    const IN_ATTRIB: u32 = 0x0000_0004;
    const IN_CLOSE_WRITE: u32 = 0x0000_0008;
    const IN_MOVED_FROM: u32 = 0x0000_0040;
    const IN_MOVED_TO: u32 = 0x0000_0080;
    const IN_DELETE_SELF: u32 = 0x0000_0400;
    const IN_MOVE_SELF: u32 = 0x0000_0800;
    const INOTIFY_MASK: u32 = IN_CREATE
        | IN_DELETE
        | IN_MODIFY
        | IN_ATTRIB
        | IN_CLOSE_WRITE
        | IN_MOVED_FROM
        | IN_MOVED_TO
        | IN_DELETE_SELF
        | IN_MOVE_SELF;

    const POLLIN: i16 = 0x0001;
    const O_NONBLOCK: c_int = 2048;
    const F_GETFL: c_int = 3;
    const F_SETFL: c_int = 4;

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct PollFd {
        fd: c_int,
        events: i16,
        revents: i16,
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct InotifyEventHeader {
        wd: c_int,
        mask: u32,
        cookie: u32,
        len: u32,
    }

    extern "C" {
        fn inotify_init() -> c_int;
        fn inotify_add_watch(fd: c_int, pathname: *const c_char, mask: u32) -> c_int;
        fn inotify_rm_watch(fd: c_int, wd: c_int) -> c_int;
        fn pipe(fds: *mut c_int) -> c_int;
        fn fcntl(fd: c_int, cmd: c_int, ...) -> c_int;
        fn poll(fds: *mut PollFd, nfds: usize, timeout: c_int) -> c_int;
        fn read(fd: c_int, buf: *mut c_void, count: usize) -> isize;
        fn write(fd: c_int, buf: *const c_void, count: usize) -> isize;
        fn close(fd: c_int) -> c_int;
    }

    static GLOBAL_WAKE_FD: AtomicI32 = AtomicI32::new(-1);

    pub fn create_wake_fn() -> Arc<dyn Fn() + Send + Sync> {
        Arc::new(|| {
            let fd = GLOBAL_WAKE_FD.load(Ordering::Acquire);
            if fd >= 0 {
                let b: u8 = 1;
                unsafe {
                    write(fd, &b as *const u8 as *const c_void, 1);
                }
            }
        })
    }

    pub fn run_watcher_loop(
        shared: Arc<(Mutex<WatcherShared>, Condvar)>,
        _wake_fn: Arc<dyn Fn() + Send + Sync>,
        tx: Sender<Vec<PathBuf>>,
        on_change_wakeup: Arc<dyn Fn() + Send + Sync>,
    ) {
        let inotify_fd = unsafe { inotify_init() };
        if inotify_fd < 0 {
            return;
        }
        let mut wake_fds = [-1i32; 2];
        if unsafe { pipe(wake_fds.as_mut_ptr()) } != 0 {
            unsafe { close(inotify_fd) };
            return;
        }
        unsafe {
            for fd in [inotify_fd, wake_fds[0], wake_fds[1]] {
                let fl = fcntl(fd, F_GETFL, 0);
                if fl >= 0 {
                    fcntl(fd, F_SETFL, fl | O_NONBLOCK);
                }
            }
        }
        GLOBAL_WAKE_FD.store(wake_fds[1], Ordering::Release);

        let mut watches: HashMap<PathBuf, c_int> = HashMap::new();
        let mut wd_to_path: HashMap<c_int, PathBuf> = HashMap::new();
        let mut last_gen: u64 = 0;
        let mut debounce = DirDebounceQueue::new();
        let mut buf = [0u8; 4096];

        loop {
            let (shutdown, desired_gen, desired_dirs) = {
                let st = shared.0.lock().unwrap_or_else(|e| e.into_inner());
                (st.shutdown, st.desired_gen, st.desired_dirs.clone())
            };
            if shutdown {
                break;
            }

            if desired_gen != last_gen {
                let desired_set: HashSet<PathBuf> = desired_dirs.iter().cloned().collect();
                watches.retain(|p, wd| {
                    if !desired_set.contains(p) {
                        unsafe { inotify_rm_watch(inotify_fd, *wd) };
                        wd_to_path.remove(wd);
                        false
                    } else {
                        true
                    }
                });
                for p in &desired_dirs {
                    if !watches.contains_key(p) {
                        if let Ok(cs) = CString::new(p.to_string_lossy().as_bytes()) {
                            let wd = unsafe { inotify_add_watch(inotify_fd, cs.as_ptr(), INOTIFY_MASK) };
                            if wd >= 0 {
                                watches.insert(p.clone(), wd);
                                wd_to_path.insert(wd, p.clone());
                            }
                        }
                    }
                }
                debounce.retain_paths(&desired_set);
                last_gen = desired_gen;
                let mut st = shared.0.lock().unwrap_or_else(|e| e.into_inner());
                st.applied_gen = desired_gen;
                shared.1.notify_all();
            }

            let timeout_ms: c_int = match debounce.next_timeout(Instant::now()) {
                None => -1,
                Some(d) => d.as_millis().clamp(1, i32::MAX as u128) as c_int,
            };

            let mut pfds = [
                PollFd {
                    fd: wake_fds[0],
                    events: POLLIN,
                    revents: 0,
                },
                PollFd {
                    fd: inotify_fd,
                    events: POLLIN,
                    revents: 0,
                },
            ];
            let pr = unsafe { poll(pfds.as_mut_ptr(), 2, timeout_ms) };
            if pr < 0 {
                let err = std::io::Error::last_os_error();
                if err.kind() == std::io::ErrorKind::Interrupted {
                    continue;
                }
                break;
            }

            if (pfds[0].revents & POLLIN) != 0 {
                let mut drain = [0u8; 128];
                while unsafe { read(wake_fds[0], drain.as_mut_ptr() as *mut c_void, drain.len()) } > 0 {}
            }

            if (pfds[1].revents & POLLIN) != 0 {
                loop {
                    let n = unsafe {
                        read(
                            inotify_fd,
                            buf.as_mut_ptr() as *mut c_void,
                            buf.len(),
                        )
                    };
                    if n <= 0 {
                        break;
                    }
                    let mut off = 0usize;
                    let total = n as usize;
                    let hdr_sz = std::mem::size_of::<InotifyEventHeader>();
                    while off + hdr_sz <= total {
                        let hdr = unsafe {
                            std::ptr::read_unaligned(buf.as_ptr().add(off) as *const InotifyEventHeader)
                        };
                        if let Some(p) = wd_to_path.get(&hdr.wd) {
                            debounce.record_event(p.clone(), Instant::now());
                        }
                        off += hdr_sz + hdr.len as usize;
                    }
                }
            }

            let ready = debounce.drain_ready(Instant::now());
            if !ready.is_empty() {
                if tx.send(ready).is_err() {
                    break;
                }
                on_change_wakeup();
            }
        }

        let cur = GLOBAL_WAKE_FD.load(Ordering::Acquire);
        if cur == wake_fds[1] {
            GLOBAL_WAKE_FD.store(-1, Ordering::Release);
        }
        unsafe {
            close(wake_fds[0]);
            close(wake_fds[1]);
            close(inotify_fd);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};

    #[test]
    fn test_debounce_queue_coalesces_bursts_and_enforces_cooldown() {
        let mut q = DirDebounceQueue::new();
        let dir = PathBuf::from("/tmp/test_dir_debounce");
        let t0 = Instant::now();

        assert_eq!(q.next_timeout(t0), None);
        q.record_event(dir.clone(), t0);
        assert_eq!(q.next_timeout(t0), Some(DEBOUNCE_DELAY));

        // Additional burst events within 150ms should coalesce into 1 emission
        q.record_event(dir.clone(), t0 + Duration::from_millis(80));
        assert!(q.drain_ready(t0 + Duration::from_millis(200)).is_empty());

        let flushed = q.drain_ready(t0 + Duration::from_millis(310));
        assert_eq!(flushed, vec![dir.clone()]);

        // Event arriving immediately during cooldown window must wait until COOLDOWN_INTERVAL
        q.record_event(dir.clone(), t0 + Duration::from_millis(350));
        assert!(q.drain_ready(t0 + Duration::from_millis(600)).is_empty());
        let flushed_after_cooldown =
            q.drain_ready(t0 + Duration::from_millis(310) + COOLDOWN_INTERVAL);
        assert_eq!(flushed_after_cooldown, vec![dir]);
    }

    #[test]
    fn test_dir_watcher_detects_create_rename_delete_live() {
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos();
        let dir = std::env::temp_dir().join(format!("mine_watch_test_{}_{}", std::process::id(), nanos));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let canonical = std::fs::canonicalize(&dir).unwrap_or_else(|_| dir.clone());

        let wakeups = Arc::new(AtomicUsize::new(0));
        let wake_clone = Arc::clone(&wakeups);
        let watcher = DirWatcher::new(Arc::new(move || {
            wake_clone.fetch_add(1, Ordering::Relaxed);
        }));
        watcher.set_watched_dirs(vec![canonical.clone()]);
        std::thread::sleep(Duration::from_millis(100));

        // 1. Create a file
        let f1 = canonical.join("first.txt");
        std::fs::write(&f1, b"hello").unwrap();

        let deadline = Instant::now() + Duration::from_secs(2);
        let mut saw_create = false;
        while Instant::now() < deadline {
            if watcher.poll_changed_dirs().contains(&canonical) {
                saw_create = true;
                break;
            }
            std::thread::sleep(Duration::from_millis(40));
        }
        assert!(saw_create, "Expected DirWatcher to report newly created file");
        assert!(wakeups.load(Ordering::Relaxed) >= 1);

        // Wait past cooldown, then burst-create 15 files and ensure they coalesce into <= 2 events
        std::thread::sleep(Duration::from_millis(750));
        for i in 0..15 {
            std::fs::write(canonical.join(format!("burst_{}.txt", i)), b"x").unwrap();
        }
        std::thread::sleep(Duration::from_millis(450));
        let burst_hits = watcher
            .poll_changed_dirs()
            .into_iter()
            .filter(|p| p == &canonical)
            .count();
        assert!(burst_hits <= 2, "Expected burst coalescing <= 2 batches, got {}", burst_hits);

        // Wait past cooldown, then rename + remove and confirm notification
        std::thread::sleep(Duration::from_millis(750));
        let _ = watcher.poll_changed_dirs();
        let f2 = canonical.join("renamed.txt");
        std::fs::rename(&f1, &f2).unwrap();
        std::fs::remove_file(&f2).unwrap();

        let deadline2 = Instant::now() + Duration::from_secs(2);
        let mut saw_del = false;
        while Instant::now() < deadline2 {
            if watcher.poll_changed_dirs().contains(&canonical) {
                saw_del = true;
                break;
            }
            std::thread::sleep(Duration::from_millis(40));
        }
        assert!(saw_del, "Expected DirWatcher to detect rename/delete");

        drop(watcher);
        let _ = std::fs::remove_dir_all(&dir);
    }
}
