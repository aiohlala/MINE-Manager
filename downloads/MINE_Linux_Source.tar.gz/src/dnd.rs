use std::path::PathBuf;

/// Result of attempting to hand off a drag operation to the host OS native drag-and-drop engine.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[allow(dead_code)]
pub enum ExternalDragResult {
    /// macOS AppKit `NSDraggingSession` started asynchronously; poll via `poll_external_drag_ended`.
    StartedAsync,
    /// Windows OLE `DoDragDrop` ran synchronously to completion.
    Completed { dropped: bool, moved: bool },
    /// Platform does not support outbound native drag or path list is empty.
    Unsupported,
    /// Native drag attempt failed cleanly without crashing.
    Failed,
}

/// Returns `true` when the pointer is currently outside MINE's window or over another app's window.
pub fn is_cursor_over_other_window() -> bool {
    platform::is_cursor_over_other_window()
}

/// Returns the cursor position in MINE's window logical points during external OS drags.
pub fn cursor_pos_in_window(pixels_per_point: f32) -> Option<[f32; 2]> {
    platform::cursor_pos_in_window(pixels_per_point)
}

/// Queries the OS hardware primary mouse button state (immune to swallowed `mouseUp` events).
pub fn is_left_mouse_down() -> bool {
    platform::is_left_mouse_down()
}

/// Initiates an OS-native outbound file drag for `paths` so users can drop onto browsers/external apps.
pub fn start_external_file_drag(paths: &[PathBuf]) -> ExternalDragResult {
    if paths.is_empty() {
        return ExternalDragResult::Unsupported;
    }
    platform::start_external_file_drag(paths)
}

/// Returns `true` while an asynchronous OS drag session (macOS) is currently in flight.
pub fn is_os_drag_session_running() -> bool {
    platform::is_os_drag_session_running()
}

/// Polls completion of an asynchronous OS drag session: `Some((dropped, moved))` when finished.
pub fn poll_external_drag_ended() -> Option<(bool, bool)> {
    platform::poll_external_drag_ended()
}

/// Strips Windows extended-length verbatim prefixes (`\\?\` / `\\?\UNC\`) for Win32 Shell/OLE compatibility.
#[allow(dead_code)]
pub fn strip_windows_verbatim_prefix(raw: &str) -> String {
    if let Some(stripped) = raw.strip_prefix(r"\\?\UNC\") {
        format!(r"\\{}", stripped)
    } else if let Some(stripped) = raw.strip_prefix(r"\\?\") {
        stripped.to_string()
    } else {
        raw.to_string()
    }
}

/// Encodes a `CF_HDROP` `DROPFILES` buffer (20-byte header + UTF-16LE paths + double NUL terminator).
#[allow(dead_code)]
pub fn encode_dropfiles_utf16(paths: &[PathBuf]) -> Vec<u8> {
    let mut wide_units: Vec<u16> = Vec::new();
    for p in paths {
        let clean = strip_windows_verbatim_prefix(&p.as_os_str().to_string_lossy());
        if clean.is_empty() {
            continue;
        }
        wide_units.extend(clean.encode_utf16());
        wide_units.push(0);
    }
    if wide_units.is_empty() {
        return Vec::new();
    }
    wide_units.push(0); // Final NUL terminating the double-null list

    const DROPFILES_HEADER_SIZE: u32 = 20;
    let mut bytes = Vec::with_capacity(DROPFILES_HEADER_SIZE as usize + wide_units.len() * 2);
    bytes.extend_from_slice(&DROPFILES_HEADER_SIZE.to_le_bytes()); // pFiles
    bytes.extend_from_slice(&0i32.to_le_bytes()); // pt.x
    bytes.extend_from_slice(&0i32.to_le_bytes()); // pt.y
    bytes.extend_from_slice(&0i32.to_le_bytes()); // fNC
    bytes.extend_from_slice(&1i32.to_le_bytes()); // fWide = TRUE (UTF-16)
    for unit in wide_units {
        bytes.extend_from_slice(&unit.to_le_bytes());
    }
    bytes
}

#[cfg(target_os = "macos")]
mod platform {
    use super::ExternalDragResult;
    use std::ffi::{c_char, c_int, CString};
    use std::path::PathBuf;

    extern "C" {
        fn mine_macos_is_left_mouse_down() -> c_int;
        fn mine_macos_is_cursor_over_other_window() -> c_int;
        fn mine_macos_cursor_pos_in_window(out_x: *mut f32, out_y: *mut f32) -> c_int;
        fn mine_macos_begin_file_drag(paths_utf8: *const *const c_char, count: c_int) -> c_int;
        fn mine_macos_is_drag_session_running() -> c_int;
        fn mine_macos_poll_drag_ended(out_dropped: *mut c_int, out_was_move: *mut c_int) -> c_int;
    }

    pub fn is_cursor_over_other_window() -> bool {
        unsafe { mine_macos_is_cursor_over_other_window() != 0 }
    }

    pub fn cursor_pos_in_window(_pixels_per_point: f32) -> Option<[f32; 2]> {
        let mut x = 0.0f32;
        let mut y = 0.0f32;
        if unsafe { mine_macos_cursor_pos_in_window(&mut x, &mut y) != 0 } {
            Some([x, y])
        } else {
            None
        }
    }

    pub fn is_left_mouse_down() -> bool {
        unsafe { mine_macos_is_left_mouse_down() != 0 }
    }

    pub fn start_external_file_drag(paths: &[PathBuf]) -> ExternalDragResult {
        let mut cstrings: Vec<CString> = Vec::with_capacity(paths.len());
        for p in paths {
            if !p.exists() && p.symlink_metadata().is_err() {
                continue;
            }
            if let Ok(cs) = CString::new(p.to_string_lossy().as_bytes()) {
                cstrings.push(cs);
            }
        }
        if cstrings.is_empty() {
            return ExternalDragResult::Failed;
        }
        let ptrs: Vec<*const c_char> = cstrings.iter().map(|s| s.as_ptr()).collect();
        let ok = unsafe { mine_macos_begin_file_drag(ptrs.as_ptr(), ptrs.len() as c_int) };
        if ok != 0 {
            ExternalDragResult::StartedAsync
        } else {
            ExternalDragResult::Failed
        }
    }

    pub fn is_os_drag_session_running() -> bool {
        unsafe { mine_macos_is_drag_session_running() != 0 }
    }

    pub fn poll_external_drag_ended() -> Option<(bool, bool)> {
        let mut dropped: c_int = 0;
        let mut was_move: c_int = 0;
        let ended = unsafe { mine_macos_poll_drag_ended(&mut dropped, &mut was_move) };
        if ended != 0 {
            Some((dropped != 0, was_move != 0))
        } else {
            None
        }
    }
}

#[cfg(target_os = "windows")]
mod platform {
    use super::{encode_dropfiles_utf16, ExternalDragResult};
    use std::ffi::c_void;
    use std::path::PathBuf;
    use std::ptr::null_mut;
    use std::sync::atomic::{AtomicU32, Ordering};

    const CF_HDROP: u16 = 15;
    const TYMED_HGLOBAL: u32 = 1;
    const DVASPECT_CONTENT: u32 = 1;
    const DATADIR_GET: u32 = 1;

    const DROPEFFECT_COPY: u32 = 1;
    const DROPEFFECT_MOVE: u32 = 2;
    const DROPEFFECT_LINK: u32 = 4;

    const MK_LBUTTON: u32 = 1;
    const MK_RBUTTON: u32 = 2;
    const GHND: u32 = 0x0042;

    const VK_LBUTTON: i32 = 0x01;
    const VK_RBUTTON: i32 = 0x02;
    const SM_SWAPBUTTON: i32 = 23;

    const S_OK: i32 = 0;
    const S_FALSE: i32 = 1;
    const E_NOTIMPL: i32 = 0x8000_4001_u32 as i32;
    const E_NOINTERFACE: i32 = 0x8000_4002_u32 as i32;
    const E_INVALIDARG: i32 = 0x8007_0057_u32 as i32;
    const E_OUTOFMEMORY: i32 = 0x8007_000E_u32 as i32;
    const DV_E_FORMATETC: i32 = 0x8004_0064_u32 as i32;
    const OLE_E_ADVISENOTSUPPORTED: i32 = 0x8004_0003_u32 as i32;
    const DRAGDROP_S_DROP: i32 = 0x0004_0100_u32 as i32;
    const DRAGDROP_S_CANCEL: i32 = 0x0004_0101_u32 as i32;
    const DRAGDROP_S_USEDEFAULTCURSORS: i32 = 0x0004_0102_u32 as i32;
    const DATA_S_SAMEFORMATETC: i32 = 0x0004_0130_u32 as i32;

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct Point {
        x: i32,
        y: i32,
    }

    #[repr(C)]
    #[derive(Clone, Copy, PartialEq, Eq)]
    struct Guid {
        data1: u32,
        data2: u16,
        data3: u16,
        data4: [u8; 8],
    }

    const IID_IUNKNOWN: Guid = Guid {
        data1: 0x0000_0000,
        data2: 0x0000,
        data3: 0x0000,
        data4: [0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46],
    };
    const IID_IDROPSOURCE: Guid = Guid {
        data1: 0x0000_0121,
        data2: 0x0000,
        data3: 0x0000,
        data4: [0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46],
    };
    const IID_IDATAOBJECT: Guid = Guid {
        data1: 0x0000_010E,
        data2: 0x0000,
        data3: 0x0000,
        data4: [0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46],
    };
    const IID_IENUMFORMATETC: Guid = Guid {
        data1: 0x0000_0103,
        data2: 0x0000,
        data3: 0x0000,
        data4: [0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46],
    };

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct FormatEtc {
        cf_format: u16,
        ptd: *mut c_void,
        dw_aspect: u32,
        lindex: i32,
        tymed: u32,
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct StgMedium {
        tymed: u32,
        data: *mut c_void,
        p_unk_for_release: *mut c_void,
    }

    #[repr(C)]
    struct IUnknownVtbl {
        query_interface:
            unsafe extern "system" fn(*mut c_void, *const Guid, *mut *mut c_void) -> i32,
        add_ref: unsafe extern "system" fn(*mut c_void) -> u32,
        release: unsafe extern "system" fn(*mut c_void) -> u32,
    }

    #[repr(C)]
    struct IDropSourceVtbl {
        base: IUnknownVtbl,
        query_continue_drag: unsafe extern "system" fn(*mut c_void, i32, u32) -> i32,
        give_feedback: unsafe extern "system" fn(*mut c_void, u32) -> i32,
    }

    #[repr(C)]
    struct IEnumFormatEtcVtbl {
        base: IUnknownVtbl,
        next: unsafe extern "system" fn(*mut c_void, u32, *mut FormatEtc, *mut u32) -> i32,
        skip: unsafe extern "system" fn(*mut c_void, u32) -> i32,
        reset: unsafe extern "system" fn(*mut c_void) -> i32,
        clone: unsafe extern "system" fn(*mut c_void, *mut *mut c_void) -> i32,
    }

    #[repr(C)]
    struct IDataObjectVtbl {
        base: IUnknownVtbl,
        get_data: unsafe extern "system" fn(*mut c_void, *const FormatEtc, *mut StgMedium) -> i32,
        get_data_here:
            unsafe extern "system" fn(*mut c_void, *const FormatEtc, *mut StgMedium) -> i32,
        query_get_data: unsafe extern "system" fn(*mut c_void, *const FormatEtc) -> i32,
        get_canonical_format_etc:
            unsafe extern "system" fn(*mut c_void, *const FormatEtc, *mut FormatEtc) -> i32,
        set_data:
            unsafe extern "system" fn(*mut c_void, *const FormatEtc, *const StgMedium, i32) -> i32,
        enum_format_etc: unsafe extern "system" fn(*mut c_void, u32, *mut *mut c_void) -> i32,
        d_advise: unsafe extern "system" fn(
            *mut c_void,
            *const FormatEtc,
            u32,
            *mut c_void,
            *mut u32,
        ) -> i32,
        d_unadvise: unsafe extern "system" fn(*mut c_void, u32) -> i32,
        enum_d_advise: unsafe extern "system" fn(*mut c_void, *mut *mut c_void) -> i32,
    }

    #[link(name = "user32")]
    extern "system" {
        fn GetCursorPos(lp_point: *mut Point) -> i32;
        fn WindowFromPoint(point: Point) -> *mut c_void;
        fn ScreenToClient(h_wnd: *mut c_void, lp_point: *mut Point) -> i32;
        fn GetWindowThreadProcessId(h_wnd: *mut c_void, lpdw_process_id: *mut u32) -> u32;
        fn GetAsyncKeyState(v_key: i32) -> i16;
        fn GetSystemMetrics(n_index: i32) -> i32;
        fn ReleaseCapture() -> i32;
    }

    #[link(name = "kernel32")]
    extern "system" {
        fn GetCurrentProcessId() -> u32;
        fn GlobalAlloc(u_flags: u32, dw_bytes: usize) -> *mut c_void;
        fn GlobalLock(h_mem: *mut c_void) -> *mut c_void;
        fn GlobalUnlock(h_mem: *mut c_void) -> i32;
        fn GlobalFree(h_mem: *mut c_void) -> *mut c_void;
    }

    #[link(name = "ole32")]
    extern "system" {
        fn OleInitialize(pv_reserved: *mut c_void) -> i32;
        fn OleUninitialize();
        fn DoDragDrop(
            p_data_obj: *mut c_void,
            p_drop_source: *mut c_void,
            dw_ok_effects: u32,
            pdw_effect: *mut u32,
        ) -> i32;
    }

    // ---- COM: IDropSource ----

    #[repr(C)]
    struct MineDropSource {
        vtbl: *const IDropSourceVtbl,
        ref_count: AtomicU32,
    }

    static DROP_SOURCE_VTBL: IDropSourceVtbl = IDropSourceVtbl {
        base: IUnknownVtbl {
            query_interface: drop_source_qi,
            add_ref: drop_source_add_ref,
            release: drop_source_release,
        },
        query_continue_drag: drop_source_query_continue,
        give_feedback: drop_source_give_feedback,
    };

    unsafe extern "system" fn drop_source_qi(
        this: *mut c_void,
        riid: *const Guid,
        ppv: *mut *mut c_void,
    ) -> i32 {
        if ppv.is_null() || riid.is_null() {
            return E_INVALIDARG;
        }
        let iid = *riid;
        if iid == IID_IUNKNOWN || iid == IID_IDROPSOURCE {
            drop_source_add_ref(this);
            *ppv = this;
            S_OK
        } else {
            *ppv = null_mut();
            E_NOINTERFACE
        }
    }

    unsafe extern "system" fn drop_source_add_ref(this: *mut c_void) -> u32 {
        let obj = &*(this as *const MineDropSource);
        obj.ref_count.fetch_add(1, Ordering::Relaxed) + 1
    }

    unsafe extern "system" fn drop_source_release(this: *mut c_void) -> u32 {
        let obj = &*(this as *const MineDropSource);
        let prev = obj.ref_count.fetch_sub(1, Ordering::Release);
        if prev == 1 {
            std::sync::atomic::fence(Ordering::Acquire);
            drop(Box::from_raw(this as *mut MineDropSource));
        }
        prev - 1
    }

    unsafe extern "system" fn drop_source_query_continue(
        _this: *mut c_void,
        f_escape_pressed: i32,
        grf_key_state: u32,
    ) -> i32 {
        if f_escape_pressed != 0 || (grf_key_state & MK_RBUTTON) != 0 {
            DRAGDROP_S_CANCEL
        } else if (grf_key_state & MK_LBUTTON) == 0 {
            DRAGDROP_S_DROP
        } else {
            S_OK
        }
    }

    unsafe extern "system" fn drop_source_give_feedback(_this: *mut c_void, _dw_effect: u32) -> i32 {
        DRAGDROP_S_USEDEFAULTCURSORS
    }

    // ---- COM: IEnumFORMATETC ----

    #[repr(C)]
    struct MineEnumFormatEtc {
        vtbl: *const IEnumFormatEtcVtbl,
        ref_count: AtomicU32,
        index: AtomicU32,
    }

    static ENUM_FORMAT_VTBL: IEnumFormatEtcVtbl = IEnumFormatEtcVtbl {
        base: IUnknownVtbl {
            query_interface: enum_fmt_qi,
            add_ref: enum_fmt_add_ref,
            release: enum_fmt_release,
        },
        next: enum_fmt_next,
        skip: enum_fmt_skip,
        reset: enum_fmt_reset,
        clone: enum_fmt_clone,
    };

    impl MineEnumFormatEtc {
        fn new_raw(index: u32) -> *mut c_void {
            Box::into_raw(Box::new(Self {
                vtbl: &ENUM_FORMAT_VTBL,
                ref_count: AtomicU32::new(1),
                index: AtomicU32::new(index),
            })) as *mut c_void
        }
    }

    unsafe extern "system" fn enum_fmt_qi(
        this: *mut c_void,
        riid: *const Guid,
        ppv: *mut *mut c_void,
    ) -> i32 {
        if ppv.is_null() || riid.is_null() {
            return E_INVALIDARG;
        }
        let iid = *riid;
        if iid == IID_IUNKNOWN || iid == IID_IENUMFORMATETC {
            enum_fmt_add_ref(this);
            *ppv = this;
            S_OK
        } else {
            *ppv = null_mut();
            E_NOINTERFACE
        }
    }

    unsafe extern "system" fn enum_fmt_add_ref(this: *mut c_void) -> u32 {
        let obj = &*(this as *const MineEnumFormatEtc);
        obj.ref_count.fetch_add(1, Ordering::Relaxed) + 1
    }

    unsafe extern "system" fn enum_fmt_release(this: *mut c_void) -> u32 {
        let obj = &*(this as *const MineEnumFormatEtc);
        let prev = obj.ref_count.fetch_sub(1, Ordering::Release);
        if prev == 1 {
            std::sync::atomic::fence(Ordering::Acquire);
            drop(Box::from_raw(this as *mut MineEnumFormatEtc));
        }
        prev - 1
    }

    unsafe extern "system" fn enum_fmt_next(
        this: *mut c_void,
        celt: u32,
        rgelt: *mut FormatEtc,
        pcelt_fetched: *mut u32,
    ) -> i32 {
        if celt > 0 && rgelt.is_null() {
            return E_INVALIDARG;
        }
        if celt > 1 && pcelt_fetched.is_null() {
            return E_INVALIDARG;
        }
        if celt == 0 {
            if !pcelt_fetched.is_null() {
                *pcelt_fetched = 0;
            }
            return S_OK;
        }
        let obj = &*(this as *const MineEnumFormatEtc);
        if obj.index.swap(1, Ordering::Relaxed) == 0 {
            *rgelt = FormatEtc {
                cf_format: CF_HDROP,
                ptd: null_mut(),
                dw_aspect: DVASPECT_CONTENT,
                lindex: -1,
                tymed: TYMED_HGLOBAL,
            };
            if !pcelt_fetched.is_null() {
                *pcelt_fetched = 1;
            }
            if celt == 1 {
                S_OK
            } else {
                S_FALSE
            }
        } else {
            if !pcelt_fetched.is_null() {
                *pcelt_fetched = 0;
            }
            S_FALSE
        }
    }

    unsafe extern "system" fn enum_fmt_skip(this: *mut c_void, celt: u32) -> i32 {
        if celt == 0 {
            return S_OK;
        }
        let obj = &*(this as *const MineEnumFormatEtc);
        let prev = obj.index.swap(1, Ordering::Relaxed);
        if prev == 0 && celt == 1 {
            S_OK
        } else {
            S_FALSE
        }
    }

    unsafe extern "system" fn enum_fmt_reset(this: *mut c_void) -> i32 {
        let obj = &*(this as *const MineEnumFormatEtc);
        obj.index.store(0, Ordering::Relaxed);
        S_OK
    }

    unsafe extern "system" fn enum_fmt_clone(this: *mut c_void, ppenum: *mut *mut c_void) -> i32 {
        if ppenum.is_null() {
            return E_INVALIDARG;
        }
        let obj = &*(this as *const MineEnumFormatEtc);
        *ppenum = MineEnumFormatEtc::new_raw(obj.index.load(Ordering::Relaxed));
        S_OK
    }

    // ---- COM: IDataObject (CF_HDROP) ----

    #[repr(C)]
    struct MineDataObject {
        vtbl: *const IDataObjectVtbl,
        ref_count: AtomicU32,
        drop_bytes: Vec<u8>,
    }

    static DATA_OBJECT_VTBL: IDataObjectVtbl = IDataObjectVtbl {
        base: IUnknownVtbl {
            query_interface: data_obj_qi,
            add_ref: data_obj_add_ref,
            release: data_obj_release,
        },
        get_data: data_obj_get_data,
        get_data_here: data_obj_get_data_here,
        query_get_data: data_obj_query_get_data,
        get_canonical_format_etc: data_obj_get_canonical,
        set_data: data_obj_set_data,
        enum_format_etc: data_obj_enum_format_etc,
        d_advise: data_obj_d_advise,
        d_unadvise: data_obj_d_unadvise,
        enum_d_advise: data_obj_enum_d_advise,
    };

    fn is_supported_format(fmt: &FormatEtc) -> bool {
        fmt.cf_format == CF_HDROP
            && (fmt.tymed & TYMED_HGLOBAL) != 0
            && (fmt.dw_aspect == DVASPECT_CONTENT || fmt.dw_aspect == 0)
            && (fmt.lindex == -1 || fmt.lindex == 0)
    }

    unsafe extern "system" fn data_obj_qi(
        this: *mut c_void,
        riid: *const Guid,
        ppv: *mut *mut c_void,
    ) -> i32 {
        if ppv.is_null() || riid.is_null() {
            return E_INVALIDARG;
        }
        let iid = *riid;
        if iid == IID_IUNKNOWN || iid == IID_IDATAOBJECT {
            data_obj_add_ref(this);
            *ppv = this;
            S_OK
        } else {
            *ppv = null_mut();
            E_NOINTERFACE
        }
    }

    unsafe extern "system" fn data_obj_add_ref(this: *mut c_void) -> u32 {
        let obj = &*(this as *const MineDataObject);
        obj.ref_count.fetch_add(1, Ordering::Relaxed) + 1
    }

    unsafe extern "system" fn data_obj_release(this: *mut c_void) -> u32 {
        let obj = &*(this as *const MineDataObject);
        let prev = obj.ref_count.fetch_sub(1, Ordering::Release);
        if prev == 1 {
            std::sync::atomic::fence(Ordering::Acquire);
            drop(Box::from_raw(this as *mut MineDataObject));
        }
        prev - 1
    }

    unsafe extern "system" fn data_obj_query_get_data(
        _this: *mut c_void,
        p_format_etc: *const FormatEtc,
    ) -> i32 {
        if p_format_etc.is_null() {
            return E_INVALIDARG;
        }
        if is_supported_format(&*p_format_etc) {
            S_OK
        } else {
            DV_E_FORMATETC
        }
    }

    unsafe extern "system" fn data_obj_get_data(
        this: *mut c_void,
        p_format_etc_in: *const FormatEtc,
        p_medium: *mut StgMedium,
    ) -> i32 {
        if p_format_etc_in.is_null() || p_medium.is_null() {
            return E_INVALIDARG;
        }
        *p_medium = StgMedium {
            tymed: 0,
            data: null_mut(),
            p_unk_for_release: null_mut(),
        };
        if !is_supported_format(&*p_format_etc_in) {
            return DV_E_FORMATETC;
        }
        let obj = &*(this as *const MineDataObject);
        if obj.drop_bytes.is_empty() {
            return E_INVALIDARG;
        }
        let h_mem = GlobalAlloc(GHND, obj.drop_bytes.len());
        if h_mem.is_null() {
            return E_OUTOFMEMORY;
        }
        let dst = GlobalLock(h_mem) as *mut u8;
        if dst.is_null() {
            GlobalFree(h_mem);
            return E_OUTOFMEMORY;
        }
        std::ptr::copy_nonoverlapping(obj.drop_bytes.as_ptr(), dst, obj.drop_bytes.len());
        GlobalUnlock(h_mem);

        *p_medium = StgMedium {
            tymed: TYMED_HGLOBAL,
            data: h_mem,
            p_unk_for_release: null_mut(),
        };
        S_OK
    }

    unsafe extern "system" fn data_obj_get_data_here(
        _this: *mut c_void,
        _p_format_etc: *const FormatEtc,
        _p_medium: *mut StgMedium,
    ) -> i32 {
        E_NOTIMPL
    }

    unsafe extern "system" fn data_obj_get_canonical(
        _this: *mut c_void,
        p_format_etc_in: *const FormatEtc,
        p_format_etc_out: *mut FormatEtc,
    ) -> i32 {
        if !p_format_etc_out.is_null() && !p_format_etc_in.is_null() {
            *p_format_etc_out = *p_format_etc_in;
            (*p_format_etc_out).ptd = null_mut();
        }
        DATA_S_SAMEFORMATETC
    }

    unsafe extern "system" fn data_obj_set_data(
        _this: *mut c_void,
        _p_format_etc: *const FormatEtc,
        _p_medium: *const StgMedium,
        _f_release: i32,
    ) -> i32 {
        E_NOTIMPL
    }

    unsafe extern "system" fn data_obj_enum_format_etc(
        _this: *mut c_void,
        dw_direction: u32,
        pp_enum_format_etc: *mut *mut c_void,
    ) -> i32 {
        if pp_enum_format_etc.is_null() {
            return E_INVALIDARG;
        }
        *pp_enum_format_etc = null_mut();
        if dw_direction == DATADIR_GET {
            *pp_enum_format_etc = MineEnumFormatEtc::new_raw(0);
            S_OK
        } else {
            E_NOTIMPL
        }
    }

    unsafe extern "system" fn data_obj_d_advise(
        _this: *mut c_void,
        _p_format_etc: *const FormatEtc,
        _advf: u32,
        _p_adv_sink: *mut c_void,
        pdw_connection: *mut u32,
    ) -> i32 {
        if !pdw_connection.is_null() {
            *pdw_connection = 0;
        }
        OLE_E_ADVISENOTSUPPORTED
    }

    unsafe extern "system" fn data_obj_d_unadvise(_this: *mut c_void, _dw_connection: u32) -> i32 {
        OLE_E_ADVISENOTSUPPORTED
    }

    unsafe extern "system" fn data_obj_enum_d_advise(
        _this: *mut c_void,
        pp_enum_advise: *mut *mut c_void,
    ) -> i32 {
        if !pp_enum_advise.is_null() {
            *pp_enum_advise = null_mut();
        }
        OLE_E_ADVISENOTSUPPORTED
    }

    pub fn is_cursor_over_other_window() -> bool {
        unsafe {
            let mut pt = Point { x: 0, y: 0 };
            if GetCursorPos(&mut pt) == 0 {
                return false;
            }
            let hwnd = WindowFromPoint(pt);
            if hwnd.is_null() {
                return true;
            }
            let mut pid = 0u32;
            GetWindowThreadProcessId(hwnd, &mut pid);
            pid != GetCurrentProcessId()
        }
    }

    pub fn cursor_pos_in_window(pixels_per_point: f32) -> Option<[f32; 2]> {
        unsafe {
            let mut pt = Point { x: 0, y: 0 };
            if GetCursorPos(&mut pt) == 0 {
                return None;
            }
            let hwnd = WindowFromPoint(pt);
            if hwnd.is_null() {
                return None;
            }
            let mut pid = 0u32;
            GetWindowThreadProcessId(hwnd, &mut pid);
            if pid != GetCurrentProcessId() {
                return None;
            }
            if ScreenToClient(hwnd, &mut pt) == 0 {
                return None;
            }
            let scale = if pixels_per_point > 0.0 {
                pixels_per_point
            } else {
                1.0
            };
            Some([pt.x as f32 / scale, pt.y as f32 / scale])
        }
    }

    pub fn is_left_mouse_down() -> bool {
        unsafe {
            let vk = if GetSystemMetrics(SM_SWAPBUTTON) != 0 {
                VK_RBUTTON
            } else {
                VK_LBUTTON
            };
            (GetAsyncKeyState(vk) as u16 & 0x8000) != 0
        }
    }

    pub fn start_external_file_drag(paths: &[PathBuf]) -> ExternalDragResult {
        let valid: Vec<PathBuf> = paths
            .iter()
            .filter(|p| p.exists() || p.symlink_metadata().is_ok())
            .cloned()
            .collect();
        let drop_bytes = encode_dropfiles_utf16(&valid);
        if drop_bytes.is_empty() {
            return ExternalDragResult::Failed;
        }

        unsafe {
            let ole_hr = OleInitialize(null_mut());
            if ole_hr != S_OK && ole_hr != S_FALSE {
                return ExternalDragResult::Failed;
            }

            ReleaseCapture();

            let data_obj = Box::into_raw(Box::new(MineDataObject {
                vtbl: &DATA_OBJECT_VTBL,
                ref_count: AtomicU32::new(1),
                drop_bytes,
            })) as *mut c_void;

            let drop_src = Box::into_raw(Box::new(MineDropSource {
                vtbl: &DROP_SOURCE_VTBL,
                ref_count: AtomicU32::new(1),
            })) as *mut c_void;

            let mut effect: u32 = 0;
            let hr = DoDragDrop(
                data_obj,
                drop_src,
                DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK,
                &mut effect,
            );

            data_obj_release(data_obj);
            drop_source_release(drop_src);
            OleUninitialize();

            let dropped = hr == DRAGDROP_S_DROP;
            let moved = dropped && (effect & DROPEFFECT_MOVE) != 0;
            ExternalDragResult::Completed { dropped, moved }
        }
    }

    pub fn is_os_drag_session_running() -> bool {
        false
    }

    pub fn poll_external_drag_ended() -> Option<(bool, bool)> {
        None
    }
}

#[cfg(not(any(target_os = "macos", target_os = "windows")))]
mod platform {
    use super::ExternalDragResult;
    use std::path::PathBuf;

    pub fn is_cursor_over_other_window() -> bool {
        false
    }

    pub fn cursor_pos_in_window(_pixels_per_point: f32) -> Option<[f32; 2]> {
        None
    }

    pub fn is_left_mouse_down() -> bool {
        true
    }

    pub fn start_external_file_drag(_paths: &[PathBuf]) -> ExternalDragResult {
        ExternalDragResult::Unsupported
    }

    pub fn is_os_drag_session_running() -> bool {
        false
    }

    pub fn poll_external_drag_ended() -> Option<(bool, bool)> {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_strip_windows_verbatim_prefix() {
        assert_eq!(strip_windows_verbatim_prefix(r"C:\Users\test.txt"), r"C:\Users\test.txt");
        assert_eq!(
            strip_windows_verbatim_prefix(r"\\?\D:\folder\file.png"),
            r"D:\folder\file.png"
        );
        assert_eq!(
            strip_windows_verbatim_prefix(r"\\?\UNC\192.168.1.10\share\a.zip"),
            r"\\192.168.1.10\share\a.zip"
        );
    }

    #[test]
    fn test_encode_dropfiles_utf16_layout() {
        let paths = vec![PathBuf::from(r"\\?\C:\a.txt"), PathBuf::from(r"D:\中.png")];
        let buf = encode_dropfiles_utf16(&paths);
        assert!(buf.len() > 24);

        // First 4 bytes = pFiles (20u32 LE)
        assert_eq!(u32::from_le_bytes(buf[0..4].try_into().unwrap()), 20);
        // Bytes 16..20 = fWide (1i32 LE)
        assert_eq!(i32::from_le_bytes(buf[16..20].try_into().unwrap()), 1);

        // Decode UTF-16 payload
        let units: Vec<u16> = buf[20..]
            .chunks_exact(2)
            .map(|c| u16::from_le_bytes([c[0], c[1]]))
            .collect();
        let mut expected: Vec<u16> = r"C:\a.txt".encode_utf16().collect();
        expected.push(0);
        expected.extend(r"D:\中.png".encode_utf16());
        expected.push(0);
        expected.push(0);
        assert_eq!(units, expected);
    }
}
