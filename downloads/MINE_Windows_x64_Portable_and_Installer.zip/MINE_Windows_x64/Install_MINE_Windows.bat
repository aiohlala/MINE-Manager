@echo off
chcp 65001 >nul
echo ========================================================
echo   MINE - Modernized Integrated Navigator & Explorer
echo   Windows Automatic Installer
echo ========================================================
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\MINE"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
copy /Y "%~dp0MINE.exe" "%INSTALL_DIR%\MINE.exe" >nul
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\MINE File Manager.lnk'); $s.TargetPath = '%INSTALL_DIR%\MINE.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.IconLocation = '%INSTALL_DIR%\MINE.exe,0'; $s.Save()"
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Programs') + '\MINE File Manager.lnk'); $s.TargetPath = '%INSTALL_DIR%\MINE.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.IconLocation = '%INSTALL_DIR%\MINE.exe,0'; $s.Save()"
echo.
echo [OK] Installed to: %INSTALL_DIR%\MINE.exe
echo [OK] Desktop and Start Menu shortcuts created!
start "" "%INSTALL_DIR%\MINE.exe"
pause
