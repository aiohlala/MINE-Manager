MINE - Modernized Integrated Navigator & Explorer (Windows x64)
===============================================================
1. Portable Mode (免安裝直接執行):
   Double-click "MINE.exe" directly. Zero dependencies required.

2. Installer Mode (安裝至系統並建立桌面捷徑):
   Double-click "Install_MINE_Windows.bat".

3. Uninstall (解除安裝):
   Double-click "Uninstall_MINE_Windows.bat".
