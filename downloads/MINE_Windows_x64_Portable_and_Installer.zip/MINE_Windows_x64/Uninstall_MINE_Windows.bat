@echo off
chcp 65001 >nul
taskkill /F /IM MINE.exe >nul 2>&1
del /F /Q "%USERPROFILE%\Desktop\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MINE File Manager.lnk" >nul 2>&1
rmdir /S /Q "%LOCALAPPDATA%\Programs\MINE" >nul 2>&1
echo [OK] MINE has been uninstalled.
pause
