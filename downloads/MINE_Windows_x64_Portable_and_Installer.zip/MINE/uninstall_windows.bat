@echo off
setlocal
title MINE File Manager - Windows Uninstaller
set "BAT_PATH=%~f0"
set "BAT_DIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$c = [System.IO.File]::ReadAllText($env:BAT_PATH, [System.Text.Encoding]::UTF8); $idx = $c.IndexOf([char]10 + '::POWERSHELL_CODE::'); if ($idx -ge 0) { & ([ScriptBlock]::Create($c.Substring($idx + 20))) } else { Write-Error 'Failed to bootstrap uninstaller.'; pause }"
exit /b %errorlevel%
::POWERSHELL_CODE::
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$host.UI.RawUI.WindowTitle = "MINE File Manager - Windows Uninstaller"

Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "  🗑️ MINE File Manager - 解除安裝精靈 (Uninstaller)" -ForegroundColor Yellow
Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "即將進行完整清理："
Write-Host "  • 終止正在執行的 MINE 程式"
Write-Host "  • 刪除桌面捷徑 (MINE.lnk / MINE File Manager.lnk)"
Write-Host "  • 刪除開始功能表捷徑"
Write-Host "  • 清除 Windows 檔案總管右鍵選單註冊表項目"
Write-Host "  • 清除系統安裝目錄 (%LOCALAPPDATA%\Programs\MINE)"
Write-Host "  (注意：您原本解壓縮的綠色免安裝版資料夾不會被刪除)" -ForegroundColor Gray
Write-Host ""

$response = Read-Host "確定要解除安裝 MINE 嗎？ (Y=確定解除安裝 / N=取消) [Y/N]"
if ($response -notmatch '^[Yy]$') {
    Write-Host ""
    Write-Host "已取消解除安裝。" -ForegroundColor Gray
    Write-Host "按任意鍵關閉此視窗..." -ForegroundColor Gray
    try { [Console]::ReadKey($true) | Out-Null } catch { Read-Host }
    exit 0
}

Write-Host ""
Write-Host "正在解除安裝 MINE..." -ForegroundColor Cyan

# 1. 終止執行中的 mine.exe
Get-Process -Name "mine" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300

# 2. 徹底清理桌面捷徑 (包含目前使用者桌面與公共桌面，多種常見命名)
$desktopPaths = @(
    [Environment]::GetFolderPath('Desktop'),
    "$env:USERPROFILE\Desktop",
    "$env:PUBLIC\Desktop"
)
$shortcutNames = @("MINE.lnk", "MINE File Manager.lnk", "mine.lnk")

foreach ($dPath in $desktopPaths) {
    if (Test-Path $dPath) {
        foreach ($sName in $shortcutNames) {
            $fullLnk = [System.IO.Path]::Combine($dPath, $sName)
            if (Test-Path $fullLnk) {
                Remove-Item -Path $fullLnk -Force -ErrorAction SilentlyContinue
                Write-Host "  • 已刪除桌面捷徑: $fullLnk" -ForegroundColor Gray
            }
        }
    }
}

# 3. 清理開始功能表捷徑
$startMenuPaths = @(
    [Environment]::GetFolderPath('Programs'),
    "$env:APPDATA\Microsoft\Windows\Start Menu\Programs",
    "$env:ProgramData\Microsoft\Windows\Start Menu\Programs"
)

foreach ($smPath in $startMenuPaths) {
    if (Test-Path $smPath) {
        foreach ($sName in $shortcutNames) {
            $fullLnk = [System.IO.Path]::Combine($smPath, $sName)
            if (Test-Path $fullLnk) {
                Remove-Item -Path $fullLnk -Force -ErrorAction SilentlyContinue
                Write-Host "  • 已刪除開始功能表捷徑: $fullLnk" -ForegroundColor Gray
            }
        }
    }
}

# 4. 清除註冊表右鍵選單
$shellKey = "HKCU:\Software\Classes\Directory\shell\MINE"
if (Test-Path $shellKey) {
    Remove-Item -Path $shellKey -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "  • 已清除資料夾右鍵選單註冊表" -ForegroundColor Gray
}

$bgShellKey = "HKCU:\Software\Classes\Directory\Background\shell\MINE"
if (Test-Path $bgShellKey) {
    Remove-Item -Path $bgShellKey -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "  • 已清除空白處右鍵選單註冊表" -ForegroundColor Gray
}

# 5. 清除系統安裝目錄
$installDir = [System.IO.Path]::Combine($env:LOCALAPPDATA, "Programs", "MINE")
$isCurrentInInstallDir = $false
if ($env:BAT_DIR) {
    $curDir = $env:BAT_DIR.TrimEnd('\')
    if ($curDir.Equals($installDir, [System.StringComparison]::OrdinalIgnoreCase)) {
        $isCurrentInInstallDir = $true
    }
}

if (Test-Path $installDir) {
    if ($isCurrentInInstallDir) {
        Get-ChildItem -Path $installDir -Exclude "uninstall_windows.bat" -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
        Start-Process -WindowStyle Hidden -FilePath "cmd.exe" -ArgumentList "/c ping 127.0.0.1 -n 3 >nul & rmdir /s /q `"$installDir`""
        Write-Host "  • 已排程清除安裝目錄: $installDir" -ForegroundColor Gray
    } else {
        Remove-Item -Path $installDir -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "  • 已清除安裝目錄: $installDir" -ForegroundColor Gray
    }
}

Write-Host ""
Write-Host "============================================================================" -ForegroundColor Green
Write-Host "  ✅ MINE 已徹底解除安裝完成！" -ForegroundColor Green
Write-Host "============================================================================" -ForegroundColor Green
Write-Host "  • 桌面捷徑已刪除" -ForegroundColor Gray
Write-Host "  • 開始功能表捷徑已刪除" -ForegroundColor Gray
Write-Host "  • 檔案總管右鍵選單已清除" -ForegroundColor Gray
Write-Host "  • 系統安裝目錄已移除" -ForegroundColor Gray
Write-Host ""
Write-Host "按任意鍵關閉此視窗..."
try { [Console]::ReadKey($true) | Out-Null } catch { Read-Host }
