@echo off
title MINE File Manager - Windows Uninstaller
echo ========================================================
echo   MINE - Windows Uninstaller
echo ========================================================
echo.

taskkill /F /IM mine.exe >nul 2>&1
taskkill /F /IM MINE.exe >nul 2>&1

del /F /Q "%USERPROFILE%\Desktop\MINE.lnk" >nul 2>&1
del /F /Q "%USERPROFILE%\Desktop\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%PUBLIC%\Desktop\MINE.lnk" >nul 2>&1
del /F /Q "%PUBLIC%\Desktop\MINE File Manager.lnk" >nul 2>&1

del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MINE.lnk" >nul 2>&1
del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs\MINE.lnk" >nul 2>&1
del /F /Q "%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs\MINE File Manager.lnk" >nul 2>&1

reg delete "HKCU\Software\Classes\Directory\shell\MINE" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\Background\shell\MINE" /f >nul 2>&1

if /I "%~dp0"=="%LOCALAPPDATA%\Programs\MINE\" (
    start "" /b cmd /c "ping 127.0.0.1 -n 2 >nul & rmdir /s /q \"%LOCALAPPDATA%\Programs\MINE\""
) else (
    rmdir /S /Q "%LOCALAPPDATA%\Programs\MINE" >nul 2>&1
)

echo.
echo [OK] MINE shortcuts and program files have been completely removed.
echo.
pause
