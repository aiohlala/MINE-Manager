@echo off
chcp 65001 >nul
title MINE File Manager - Windows Uninstaller
echo ========================================================
echo   MINE - Windows Uninstaller
echo ========================================================
echo.

echo [1/4] 正在檢查並終止執行中的 MINE 程式...
taskkill /F /IM mine.exe >nul 2>&1
taskkill /F /IM MINE.exe >nul 2>&1

echo [2/4] 正在徹底清除桌面與開始功能表捷徑...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d = [Environment]::GetFolderPath('Desktop'); @('MINE.lnk','MINE File Manager.lnk') | ForEach-Object { $f = Join-Path $d $_; if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue } }; $p = [Environment]::GetFolderPath('Programs'); @('MINE.lnk','MINE File Manager.lnk') | ForEach-Object { $f = Join-Path $p $_; if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue } }" >nul 2>&1

del /F /Q "%USERPROFILE%\Desktop\MINE.lnk" >nul 2>&1
del /F /Q "%USERPROFILE%\Desktop\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%USERPROFILE%\OneDrive\Desktop\MINE.lnk" >nul 2>&1
del /F /Q "%USERPROFILE%\OneDrive\Desktop\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%PUBLIC%\Desktop\MINE.lnk" >nul 2>&1
del /F /Q "%PUBLIC%\Desktop\MINE File Manager.lnk" >nul 2>&1

del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MINE.lnk" >nul 2>&1
del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs\MINE.lnk" >nul 2>&1
del /F /Q "%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs\MINE File Manager.lnk" >nul 2>&1

echo [3/4] 正在清除檔案總管右鍵選單註冊表...
reg delete "HKCU\Software\Classes\Directory\shell\MINE" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\Background\shell\MINE" /f >nul 2>&1

echo [4/4] 正在清理系統安裝目錄...
if /I "%~dp0"=="%LOCALAPPDATA%\Programs\MINE\" (
    start "" /b cmd /c "ping 127.0.0.1 -n 2 >nul & rmdir /s /q \"%LOCALAPPDATA%\Programs\MINE\""
) else (
    rmdir /S /Q "%LOCALAPPDATA%\Programs\MINE" >nul 2>&1
)

echo.
echo ========================================================
echo   [OK] MINE 桌面捷徑、開始功能表與系統安裝目錄已全數清除！
echo ========================================================
echo.
pause
