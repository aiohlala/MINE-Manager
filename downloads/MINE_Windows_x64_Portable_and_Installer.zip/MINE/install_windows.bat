@echo off
title MINE File Manager - Windows Installer
echo ========================================================
echo   MINE - Multiple Interface Next-gen Explorer
echo   Windows Setup ^& Shell Integration
echo ========================================================
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\MINE"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

taskkill /F /IM mine.exe >nul 2>&1
taskkill /F /IM MINE.exe >nul 2>&1

copy /Y "%~dp0mine.exe" "%INSTALL_DIR%\mine.exe" >nul
if exist "%~dp0mine_config.json" copy /Y "%~dp0mine_config.json" "%INSTALL_DIR%\mine_config.json" >nul
copy /Y "%~dp0uninstall_windows.bat" "%INSTALL_DIR%\uninstall_windows.bat" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\MINE.lnk'); $s.TargetPath = '%INSTALL_DIR%\mine.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.IconLocation = '%INSTALL_DIR%\mine.exe,0'; $s.Save()"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Programs') + '\MINE.lnk'); $s.TargetPath = '%INSTALL_DIR%\mine.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.IconLocation = '%INSTALL_DIR%\mine.exe,0'; $s.Save()"

reg add "HKCU\Software\Classes\Directory\shell\MINE" /ve /d "Open in MINE" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\shell\MINE" /v "Icon" /d "\"%INSTALL_DIR%\mine.exe\"" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\shell\MINE\command" /ve /d "\"%INSTALL_DIR%\mine.exe\" \"%%1\"" /f >nul 2>&1

reg add "HKCU\Software\Classes\Directory\Background\shell\MINE" /ve /d "Open in MINE" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\Background\shell\MINE" /v "Icon" /d "\"%INSTALL_DIR%\mine.exe\"" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\Background\shell\MINE\command" /ve /d "\"%INSTALL_DIR%\mine.exe\" \"%%V\"" /f >nul 2>&1

echo [OK] Installed to: %INSTALL_DIR%\mine.exe
echo [OK] Desktop shortcut created: MINE.lnk
echo [OK] Start Menu shortcut created: MINE.lnk
echo [OK] Explorer context menu registered
echo.
start "" "%INSTALL_DIR%\mine.exe"
pause
