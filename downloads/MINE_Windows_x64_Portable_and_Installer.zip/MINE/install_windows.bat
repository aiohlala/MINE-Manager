@echo off
setlocal
title MINE File Manager - Windows Installer
set "BAT_PATH=%~f0"
set "BAT_DIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$c = [System.IO.File]::ReadAllText($env:BAT_PATH, [System.Text.Encoding]::UTF8); $idx = $c.IndexOf([char]10 + '::POWERSHELL_CODE::'); if ($idx -ge 0) { & ([ScriptBlock]::Create($c.Substring($idx + 20))) } else { Write-Error 'Failed to bootstrap installer.'; pause }"
exit /b %errorlevel%
::POWERSHELL_CODE::
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$host.UI.RawUI.WindowTitle = "MINE File Manager - Windows Setup"

Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "  🗂️ MINE (Multiple Interface Next-gen Explorer) - Windows 10/11 Setup" -ForegroundColor Green
Write-Host "  致敬經典 MDIE 的新世代超輕量級多視窗/滑鼠手勢檔案管理程式" -ForegroundColor Gray
Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "[1] 綠色免安裝模式 (Portable Mode):" -ForegroundColor Yellow
Write-Host "    若您偏好綠色免安裝，請輸入 [N] 退出。"
Write-Host "    直接在此目錄執行 mine.exe 即可使用，設定檔將自動儲存於 mine_config.json。"
Write-Host ""
Write-Host "[2] 系統安裝模式 (Install to System & Context Menu):" -ForegroundColor Yellow
$installDir = [System.IO.Path]::Combine($env:LOCALAPPDATA, "Programs", "MINE")
Write-Host "    目標安裝路徑: $installDir"
Write-Host "    • 自動複製程式檔案至系統應用程式目錄"
Write-Host "    • 自動建立「桌面捷徑 (MINE.lnk)」與「開始功能表」"
Write-Host "    • 自動註冊 Windows 檔案總管右鍵選單「以 MINE 開啟 (Open in MINE)」"
Write-Host ""

$response = Read-Host "是否要安裝至系統並建立桌面捷徑與右鍵選單？ (Y=安裝 / N=僅使用免安裝版) [Y/N]"
if ($response -notmatch '^[Yy]$') {
    Write-Host ""
    Write-Host "已取消安裝。您可以直接在目前目錄執行 mine.exe (綠色免安裝版)。" -ForegroundColor Gray
    Write-Host ""
    Write-Host "按任意鍵關閉此視窗..." -ForegroundColor Gray
    try { [Console]::ReadKey($true) | Out-Null } catch { Read-Host }
    exit 0
}

Write-Host ""
Write-Host "正在安裝 MINE 至系統..." -ForegroundColor Cyan

# 1. 確保正在運行的 mine.exe 先關閉，避免檔案佔用
Get-Process -Name "mine" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300

# 2. 建立安裝目錄
if (-not (Test-Path $installDir)) {
    New-Item -ItemType Directory -Path $installDir -Force | Out-Null
}

# 3. 複製主程式與設定檔
$srcDir = $env:BAT_DIR.TrimEnd('\')
$srcExe = [System.IO.Path]::Combine($srcDir, "mine.exe")
if (Test-Path $srcExe) {
    Copy-Item -Path $srcExe -Destination [System.IO.Path]::Combine($installDir, "mine.exe") -Force
} else {
    Write-Host "錯誤: 找不到來源檔案 $srcExe" -ForegroundColor Red
    Write-Host "按任意鍵關閉此視窗..."
    try { [Console]::ReadKey($true) | Out-Null } catch { Read-Host }
    exit 1
}

$srcConfig = [System.IO.Path]::Combine($srcDir, "mine_config.json")
if (Test-Path $srcConfig) {
    Copy-Item -Path $srcConfig -Destination [System.IO.Path]::Combine($installDir, "mine_config.json") -Force
}

# 複製解除安裝腳本至安裝目錄，方便使用者隨時解除安裝
$srcUninst = [System.IO.Path]::Combine($srcDir, "uninstall_windows.bat")
if (Test-Path $srcUninst) {
    Copy-Item -Path $srcUninst -Destination [System.IO.Path]::Combine($installDir, "uninstall_windows.bat") -Force
}

$targetExe = [System.IO.Path]::Combine($installDir, "mine.exe")

# 4. 註冊資料夾與空白處右鍵選單 (HKCU，無需管理者權限)
$shellKey = "HKCU:\Software\Classes\Directory\shell\MINE"
New-Item -Path $shellKey -Force | Out-Null
Set-ItemProperty -Path $shellKey -Name "(Default)" -Value "以 MINE 開啟 (Open in MINE)"
Set-ItemProperty -Path $shellKey -Name "Icon" -Value "`"$targetExe`""
New-Item -Path "$shellKey\command" -Force | Out-Null
Set-ItemProperty -Path "$shellKey\command" -Name "(Default)" -Value "`"$targetExe`" `"%1`""

$bgShellKey = "HKCU:\Software\Classes\Directory\Background\shell\MINE"
New-Item -Path $bgShellKey -Force | Out-Null
Set-ItemProperty -Path $bgShellKey -Name "(Default)" -Value "以 MINE 開啟 (Open in MINE)"
Set-ItemProperty -Path $bgShellKey -Name "Icon" -Value "`"$targetExe`""
New-Item -Path "$bgShellKey\command" -Force | Out-Null
Set-ItemProperty -Path "$bgShellKey\command" -Name "(Default)" -Value "`"$targetExe`" `"%V`""

# 5. 建立桌面與開始功能表捷徑
try {
    $ws = New-Object -ComObject WScript.Shell
    
    # 桌面捷徑
    $desktopDir = [Environment]::GetFolderPath('Desktop')
    $desktopShortcut = $ws.CreateShortcut([System.IO.Path]::Combine($desktopDir, "MINE.lnk"))
    $desktopShortcut.TargetPath = $targetExe
    $desktopShortcut.WorkingDirectory = $installDir
    $desktopShortcut.Description = "MINE File Manager - Multiple Interface Next-gen Explorer"
    $desktopShortcut.IconLocation = "$targetExe,0"
    $desktopShortcut.Save()

    # 開始功能表捷徑
    $programsDir = [Environment]::GetFolderPath('Programs')
    $startShortcut = $ws.CreateShortcut([System.IO.Path]::Combine($programsDir, "MINE.lnk"))
    $startShortcut.TargetPath = $targetExe
    $startShortcut.WorkingDirectory = $installDir
    $startShortcut.Description = "MINE File Manager - Multiple Interface Next-gen Explorer"
    $startShortcut.IconLocation = "$targetExe,0"
    $startShortcut.Save()
} catch {
    Write-Host "建立捷徑時發生警告: $_" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "============================================================================" -ForegroundColor Green
Write-Host "  ✅ MINE 安裝與整合完成！" -ForegroundColor Green
Write-Host "============================================================================" -ForegroundColor Green
Write-Host "  • 安裝路徑: $installDir" -ForegroundColor Gray
Write-Host "  • 桌面捷徑: 已建立 (MINE.lnk)" -ForegroundColor Gray
Write-Host "  • 開始功能表: 已加入 MINE" -ForegroundColor Gray
Write-Host "  • 右鍵選單: 已加入「以 MINE 開啟 (Open in MINE)」" -ForegroundColor Gray
Write-Host ""
Write-Host "如需解除安裝，隨時執行安裝目錄或壓縮包內的 uninstall_windows.bat 即可。" -ForegroundColor Gray
Write-Host ""
Write-Host "按任意鍵關閉此視窗..."
try { [Console]::ReadKey($true) | Out-Null } catch { Read-Host }
