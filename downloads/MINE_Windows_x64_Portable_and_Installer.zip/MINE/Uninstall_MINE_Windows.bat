@echo off
chcp 65001 >nul
echo ========================================================
echo   MINE - Windows Automatic Uninstaller
echo ========================================================
taskkill /F /IM MINE.exe >nul 2>&1
taskkill /F /IM mine.exe >nul 2>&1

del /F /Q "%USERPROFILE%\Desktop\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%USERPROFILE%\Desktop\MINE.lnk" >nul 2>&1
del /F /Q "%PUBLIC%\Desktop\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%PUBLIC%\Desktop\MINE.lnk" >nul 2>&1

del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\MINE.lnk" >nul 2>&1
del /F /Q "%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs\MINE File Manager.lnk" >nul 2>&1
del /F /Q "%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs\MINE.lnk" >nul 2>&1

reg delete "HKCU\Software\Classes\Directory\shell\MINE" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\Background\shell\MINE" /f >nul 2>&1

rmdir /S /Q "%LOCALAPPDATA%\Programs\MINE" >nul 2>&1
echo.
echo [OK] MINE shortcuts and files have been completely uninstalled.
pause
