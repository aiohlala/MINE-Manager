@echo off
chcp 65001 >nul
echo ========================================================
echo   MINE - Modernized Integrated Navigator & Explorer
echo   Windows Automatic Installer
echo ========================================================
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\MINE"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

taskkill /F /IM MINE.exe >nul 2>&1
taskkill /F /IM mine.exe >nul 2>&1

if exist "%~dp0MINE.exe" copy /Y "%~dp0MINE.exe" "%INSTALL_DIR%\MINE.exe" >nul
if exist "%~dp0mine.exe" copy /Y "%~dp0mine.exe" "%INSTALL_DIR%\MINE.exe" >nul
if exist "%~dp0mine_config.json" copy /Y "%~dp0mine_config.json" "%INSTALL_DIR%\mine_config.json" >nul

copy /Y "%~f0" "%INSTALL_DIR%\Install_MINE_Windows.bat" >nul 2>&1
if exist "%~dp0Uninstall_MINE_Windows.bat" copy /Y "%~dp0Uninstall_MINE_Windows.bat" "%INSTALL_DIR%\Uninstall_MINE_Windows.bat" >nul 2>&1
if exist "%~dp0uninstall_windows.bat" copy /Y "%~dp0uninstall_windows.bat" "%INSTALL_DIR%\uninstall_windows.bat" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\MINE File Manager.lnk'); $s.TargetPath = '%INSTALL_DIR%\MINE.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.IconLocation = '%INSTALL_DIR%\MINE.exe,0'; $s.Save()"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Programs') + '\MINE File Manager.lnk'); $s.TargetPath = '%INSTALL_DIR%\MINE.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.IconLocation = '%INSTALL_DIR%\MINE.exe,0'; $s.Save()"

reg add "HKCU\Software\Classes\Directory\shell\MINE" /ve /d "Open in MINE" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\shell\MINE" /v "Icon" /d "\"%INSTALL_DIR%\MINE.exe\"" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\shell\MINE\command" /ve /d "\"%INSTALL_DIR%\MINE.exe\" \"%%1\"" /f >nul 2>&1

reg add "HKCU\Software\Classes\Directory\Background\shell\MINE" /ve /d "Open in MINE" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\Background\shell\MINE" /v "Icon" /d "\"%INSTALL_DIR%\MINE.exe\"" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\Background\shell\MINE\command" /ve /d "\"%INSTALL_DIR%\MINE.exe\" \"%%V\"" /f >nul 2>&1

echo.
echo [OK] Installed to: %INSTALL_DIR%\MINE.exe
echo [OK] Desktop and Start Menu shortcuts created!
echo [OK] Explorer context menu registered!
echo.
start "" "%INSTALL_DIR%\MINE.exe"
pause
