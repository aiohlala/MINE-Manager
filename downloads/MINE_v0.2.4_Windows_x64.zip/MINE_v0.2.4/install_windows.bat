@echo off
chcp 65001 >nul
title MINE File Manager v0.2.4 - Windows Installer
echo ========================================================
echo   MINE v0.2.4 - Multiple Interface Next-gen Explorer
echo   Windows Setup ^& Shell Integration
echo ========================================================
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\MINE"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [1/4] 正在檢查並關閉執行中程式...
taskkill /F /IM mine.exe >nul 2>&1
taskkill /F /IM MINE.exe >nul 2>&1

echo [2/4] 正在複製主程式與設定檔至系統目錄...
copy /Y "%~dp0mine.exe" "%INSTALL_DIR%\mine.exe" >nul
if exist "%~dp0mine.ico" copy /Y "%~dp0mine.ico" "%INSTALL_DIR%\mine.ico" >nul
if exist "%~dp0mine_config.json" copy /Y "%~dp0mine_config.json" "%INSTALL_DIR%\mine_config.json" >nul
copy /Y "%~dp0uninstall_windows.bat" "%INSTALL_DIR%\uninstall_windows.bat" >nul 2>&1

echo [3/4] 正在建立桌面捷徑與開始功能表...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $d = [Environment]::GetFolderPath('Desktop'); $ico = if (Test-Path '%INSTALL_DIR%\mine.ico') { '%INSTALL_DIR%\mine.ico,0' } else { '%INSTALL_DIR%\mine.exe,0' }; $s = $ws.CreateShortcut($d + '\MINE.lnk'); $s.TargetPath = '%INSTALL_DIR%\mine.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.IconLocation = $ico; $s.Save(); $p = [Environment]::GetFolderPath('Programs'); $sm = $ws.CreateShortcut($p + '\MINE.lnk'); $sm.TargetPath = '%INSTALL_DIR%\mine.exe'; $sm.WorkingDirectory = '%INSTALL_DIR%'; $sm.IconLocation = $ico; $sm.Save();"

echo [4/4] 正在註冊 Windows 檔案總管右鍵選單...
reg add "HKCU\Software\Classes\Directory\shell\MINE" /ve /d "Open in MINE" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\shell\MINE" /v "Icon" /d "\"%INSTALL_DIR%\mine.ico\"" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\shell\MINE\command" /ve /d "\"%INSTALL_DIR%\mine.exe\" \"%%1\"" /f >nul 2>&1

reg add "HKCU\Software\Classes\Directory\Background\shell\MINE" /ve /d "Open in MINE" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\Background\shell\MINE" /v "Icon" /d "\"%INSTALL_DIR%\mine.ico\"" /f >nul 2>&1
reg add "HKCU\Software\Classes\Directory\Background\shell\MINE\command" /ve /d "\"%INSTALL_DIR%\mine.exe\" \"%%V\"" /f >nul 2>&1

echo.
echo ========================================================
echo   [OK] MINE v0.2.4 安裝完成！
echo   • 安裝路徑: %INSTALL_DIR%\mine.exe
echo   • 桌面捷徑: 已建立 (MINE.lnk)
echo   • 開始功能表: 已加入 MINE
echo   • 右鍵選單: 已註冊「Open in MINE」
echo ========================================================
echo.
echo 正在啟動 MINE...
start "" "%INSTALL_DIR%\mine.exe"
pause
