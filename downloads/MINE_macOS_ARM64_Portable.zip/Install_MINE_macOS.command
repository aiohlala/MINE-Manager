#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "Installing MINE.app to /Applications..."
rm -rf /Applications/MINE.app
cp -R "$DIR/MINE.app" /Applications/MINE.app
xattr -cr /Applications/MINE.app 2>/dev/null || true
codesign --force --deep --sign - /Applications/MINE.app 2>/dev/null || true
echo "✅ MINE.app installed! Launching..."
open /Applications/MINE.app
